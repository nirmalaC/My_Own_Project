package automation.satsuma.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class HomeCredit extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	By byPageHeader = By.cssSelector("section[role=main] h1");
	By bySubPageHeader = By.cssSelector("h3[class=central]");
	By byTxtFirstname = By.id("CustomerFirstnameSignature");
	By byTxtSurname = By.id("CustomerSurnameSignature");
	By byDDContactTime = By.id("PreferredContactTime");
	By byChkAgreeToComplete = By.id("AgreeToComplete");
	By byBtnApply = By.id("applyButtonSubmit");

	// accept page
	By byDivAcceptResult28 = By.id("Result28");
	By byDivDeclineResult30 = By.id("Result30");
	By byAcceptMessageCustomerName = By.cssSelector(".central > p:nth-child(1)");
	By byAcceptMessageConfirmation = By.cssSelector(".central > p:nth-child(2)");
	By byDeclineMessageCustomerName = By.cssSelector(".central > p:nth-child(2)");
	By byDeclineMessageConfirmation = By.cssSelector(".central > p:nth-child(3)");
	protected String testName;
	protected int screenshotNumber;

	public HomeCredit() {
	}

	public HomeCredit(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public void fillInPageHomeCreditReferral(String firstname, String surname) {
		getDriver().findElement(byTxtFirstname).sendKeys(firstname);
		getDriver().findElement(byTxtSurname).sendKeys(surname);
		(new Select(getDriver().findElement(byDDContactTime))).selectByIndex(2);
		getDriver().findElement(byChkAgreeToComplete).click();

		takeIncrementScreenshot();

		getDriver().findElement(byBtnApply).click();
	}

	public void assertOnPageHomeCreditAcceptedInPrinciple(String gsSatsumaUrl, String title, String firstname, String surname) {
		waitForUrl(gsSatsumaUrl + "home-credit/complete");
		waitForTitle( "Your Application Decision | Satsuma Loans");

		getDriver().findElement(byDivAcceptResult28);
		Assert.assertEquals(getDriver().findElement(byAcceptMessageCustomerName).getText(), "Dear " + title + " " + firstname + " " + surname + ",");
		Assert.assertEquals(getDriver().findElement(byAcceptMessageConfirmation).getText(), "Thank you for applying for a loan with Provident Personal Credit. We’re pleased to tell you that your application has been accepted in principle, subject to final approval by a local agent.");
	}

	public void assertOnPageHomeCreditDeclined(String gsSatsumaUrl, String title, String firstname, String surname) {
		waitForUrl(gsSatsumaUrl + "home-credit/finished");
		waitForTitle( "Thank you for applying for a Provident Loan | Satsuma Loans");

		getDriver().findElement(byDivDeclineResult30);
		Assert.assertEquals(getDriver().findElement(byDeclineMessageCustomerName).getText(), "Dear " + title + " " + firstname + " " + surname);
		Assert.assertEquals(getDriver().findElement(byDeclineMessageConfirmation).getText(), "Thank you for your recent request for a loan from Provident Personal Credit. Unfortunately your request has not been successful on this occasion.");
	}

	public void takeIncrementScreenshot() {
		log.debug("Taking screenshot to " + "target/surefire-reports/screenshots/" + testName + "/" + screenshotNumber + ".png");
		takeScreenshot("target/surefire-reports/screenshots/" + testName + "/" + screenshotNumber + ".png");
		screenshotNumber++;
	}

}
