package automation.tests.framework;


public class XmlParserTest {

	// @Test
	// public void test() throws ParserConfigurationException, SAXException,
	// IOException {
	// XmlWorkflowGlobalVariables workflowGlobalVariables = new
	// XmlWorkflowGlobalVariables(ZoralScoreDatabaseHelper.getWorkflowGlobalVariablesFromDecisionRef(SatsumaApplicationDatabaseHelper.getDecisionReferenceFromAgreement("800000040200")));
	// Log.info("PreDipFilterScore: " +
	// workflowGlobalVariables.getValue("PreDipFilterScore"));
	// }
}
