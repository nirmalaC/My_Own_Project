package automation.tests.smartcheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.SmartCheckBaseTest;

public class SmartCheckAcceptHappyPath extends SmartCheckBaseTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		NewCustomerTest(408);
	}
}
