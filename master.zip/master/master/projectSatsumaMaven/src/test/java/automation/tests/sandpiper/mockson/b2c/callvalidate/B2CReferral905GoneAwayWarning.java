package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnIDVReferralTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CReferral905GoneAwayWarning extends B2CAllMocksOnIDVReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String GONE_AWAY_WARNING_DESC = "Gone Away";
	private static final String GONE_AWAY_WARNING_CODE = "905";
	private static final int WEEKLY_APPLICANT_ID = 254;
	private static final int NEW_BUS_WEEKLY_APPLICANT_ID = 295;
	private static final int MONTHLY_APPLICANT_ID = 253;
	private static final int NEW_BUS_MONTHLY_APPLICANT_ID = 296;

	@Test
	public void testB2cNbReferralWeekly() throws Exception {
		b2CNewBusinessReferral(NEW_BUS_WEEKLY_APPLICANT_ID, GONE_AWAY_WARNING_CODE, GONE_AWAY_WARNING_DESC);
	}

	@Test
	public void testB2cNbReferralMonthly() throws Exception {
		b2CNewBusinessReferral(NEW_BUS_MONTHLY_APPLICANT_ID, GONE_AWAY_WARNING_CODE, GONE_AWAY_WARNING_DESC);
	}

	@Test
	public void testB2cFLReferralWeekly() throws Exception {
		b2CFLReferral(WEEKLY_APPLICANT_ID, GONE_AWAY_WARNING_CODE, GONE_AWAY_WARNING_DESC);
	}

	@Test
	public void testB2cFLReferralMonthly() throws Exception {
		b2CFLReferral(MONTHLY_APPLICANT_ID, GONE_AWAY_WARNING_CODE, GONE_AWAY_WARNING_DESC);
	}

	@Test
	public void testB2cLoginReferralWeekly() throws Exception {
		b2CLoginFLReferral(WEEKLY_APPLICANT_ID, GONE_AWAY_WARNING_DESC, GONE_AWAY_WARNING_CODE);
	}

	@Test
	public void testB2cLoginReferralMonthly() throws Exception {
		b2CLoginFLReferral(MONTHLY_APPLICANT_ID, GONE_AWAY_WARNING_DESC, GONE_AWAY_WARNING_CODE);
	}

	// @Test
	// public void B2CReferWeekly() throws Exception {
	//
	// String sAgreementNumber;
	//
	// // Data Preparation
	// // ================
	//
	// // Get a application profile for applicant on Mocked Callcredit test
	// // environment who is flagged with Deceased_warning.xml
	// gcb.prGetApplicantProfile(223);
	// gcb.setRandomEmail();
	// gcb.setRandomPostcode();
	//
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Your Quote page
	// // ==============
	//
	// gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
	//
	// // Invoke Next action: Next: Bank Details
	// gcb.prClickForNextAction();
	//
	// // Bank Details page
	// // =================
	//
	// gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);
	//
	// // Fill in applicants bank details from the profile
	// gcb.prFillInPageBankDetailsRandom();
	//
	// // Invoke Next action: Next: Payment Details
	// gcb.prClickForNextAction();
	//
	// // WorldPay Test Page
	// // ==================
	//
	// // Fill in applicants card details from the profile and trigger a
	// // Approved response
	// gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved",
	// "Postcode and address matched");
	//
	// // Password screen Login Phase 2
	// // =====================
	//
	// // Fill in password box
	// gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
	// gcb.fillInPageMySatsumaAccount("Password1");
	//
	// // Credit Agreement page
	// // ======================
	//
	// gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);
	//
	// // Read and Sign the Credit Agreement
	// gcb.prReadAndSignCreditAgreement();
	//
	// // Capture Agreement Number from the Credit Agreement page
	// sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
	//
	// // Invoke Next action: Next: Complete Your Agreement
	// gcb.prClickForNextAction();
	//
	// // Former Paid Up Vulnerable Completion page
	// // =========================================
	//
	// gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct refer on "Vulnerable Customer is set"
	// // reason is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(sAgreementNumber);
	//
	// // Expect agreement to be referred for 901 - Vulnerable Customer -
	// // Primary Referral
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Referred");
	// Assert.assertTrue(getDriver().getPageSource().contains("704"));
	// Assert.assertTrue(getDriver().getPageSource().contains("Deceased Warning is set"));
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
