package automation.tests.outboundsales;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnOutboundTest;
import automation.dao.CustomerType;
import automation.satsuma.pages.ApplicationType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class ObsDecline401BankEnhancedFailure extends AllMocksOnOutboundTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	String pancode = "401";
	private final static int WEEKLY_APPLICANT_ID = 367;

	@Test
	public void ObsNbWeeklyDecline() throws Exception {
		test401(pancode, WEEKLY_APPLICANT_ID);
	}

	private void test401(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		int counter = 3;
		while (counter > 0) {

			outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

			// Fill in applicants bank details from the profile
			gcb.prFillInPageBankDetailsRandom();

			// Invoke Next action: Next: Payment Details
			gcb.prClickForNextAction();
			counter--;
		}

		gcb.prAssertOnPageHomeCredit(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();

		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
