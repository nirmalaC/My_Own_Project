//Pre-Requisite - make sure this XML file exists in "D:\inetpub\wwwroot\Satsuma.Service\bin\Responses\Experian.Interactive\JASMINE.BETTY" on the WebServer and also make sure the Experian Mock is switched "ON".

package automation.tests.allmockon.testsuite.b2c.declines;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class TestCase_11325_DeclineHCR207DMPRulePostBureauReject extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_DMPPostBureauRejectApplicantReferredToHomeCredit() throws Exception {

		// Initialise gcb.gsPANAgreementNumber for new customer scenario
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile for Post Bureau Reject result 207 -
		// DMP
		gcb.prGetApplicantProfile(48);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
			// " found, please remove and re-try test");
			log.warn("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// //CV - 09.03.2016
		// There is no HC referral for post bureau checks since NPRT route is
		// now established in S3

		gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================
		//
		// gcb.prAssertOnPageHomeCredit( gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on "DMP Rule" reason is
		// recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 207 - DMP Rule.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));

		// gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}

}
