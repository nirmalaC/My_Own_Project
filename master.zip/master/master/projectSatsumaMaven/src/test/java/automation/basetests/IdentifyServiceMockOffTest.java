package automation.basetests;


public class IdentifyServiceMockOffTest extends ScreenshottingTest {

}
