package automation.tools;

import static com.jayway.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.testng.Assert;

import automation.test.offerservice.entities.RetrieveOfferRequest;
import automation.test.offerservice.entities.RetrieveOfferResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.restassured.response.Response;

public class RestHelper {

	public static String postOffer(String jsonRequest) throws InterruptedException {

		String offerServicePostEndpoint;
		String apimKey;
		// get proxy info
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		InputStream input = null;

		try {
			input = new FileInputStream("target/classes/config.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// load a properties file
		try {
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sProxyPort = prop.getProperty("ProxyPort");
		sProxyIP = prop.getProperty("ProxyIP");
		sNoProxyOn = prop.getProperty("NoProxyOn");
		offerServicePostEndpoint = prop.getProperty("OfferServicePostEndpoint");
		apimKey = prop.getProperty("ApimKey");

		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotEquals(offerServicePostEndpoint, "", "check that offerservice endpoint is not blank");
		Thread.sleep(1000);
		// login
		Response response = given()
				.proxy(sProxyIP, Integer.parseInt(sProxyPort))
				.contentType("application/json")
				.header("Ocp-Apim-Subscription-Key", apimKey)
				.log()
				.all()
				.body(jsonRequest)
				.when()
				.post(offerServicePostEndpoint)
				.then()
				.log()
				.all()
				.statusCode(200)
				.extract()
				.response();
		return response.asString();
	}

	public static RetrieveOfferResponse getOffer(String forename, String surname, Date dob) {

		String offerServiceGetEndpoint;
		String apimKey;
		// get proxy info
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		InputStream input = null;

		try {
			input = new FileInputStream("target/classes/config.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// load a properties file
		try {
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sProxyPort = prop.getProperty("ProxyPort");
		sProxyIP = prop.getProperty("ProxyIP");
		sNoProxyOn = prop.getProperty("NoProxyOn");
		offerServiceGetEndpoint = prop.getProperty("OfferServiceGetEndpoint");
		apimKey = prop.getProperty("ApimKey");

		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotEquals(offerServiceGetEndpoint, "", "check that offerservice endpoint is not blank");

		RetrieveOfferRequest req = new RetrieveOfferRequest(forename, surname, dob);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		gsonBuilder.setDateFormat("yyyy-MM-dd");
		Gson gson = gsonBuilder.create();

		String jsonRequest = gson.toJson(req);

		// login
		Response response = given().proxy(sProxyIP, Integer.parseInt(sProxyPort)).contentType("application/json").header("Ocp-Apim-Subscription-Key", apimKey).log().all().body(jsonRequest).when().post(offerServiceGetEndpoint).then().log().all().statusCode(200).extract().response();

		return response.getBody().as(RetrieveOfferResponse.class);
	}
}
