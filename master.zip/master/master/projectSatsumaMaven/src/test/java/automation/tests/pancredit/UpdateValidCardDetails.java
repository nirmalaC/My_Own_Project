package automation.tests.pancredit;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class UpdateValidCardDetails extends AllMocksOnTest {

	@Override
	@BeforeMethod
	public void setUpBefore() throws Exception {
	}

	private List<String> extractAgreementNumbers(String delimitedAgreementString) {
		final String delimiter = ",";
		String[] tempArray = delimitedAgreementString.split(delimiter);
		List<String> arrangements = Arrays.asList(tempArray);
		return arrangements;
	}

	@Test
	public void test() throws Exception {
		getDriver().manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);

		By byLinkContAuth = By.linkText("Continuous Authority");
		By byBtnEnterNewCard = By.id("enterNewCardDetailsButton");

		By byLinkHome = By.xpath("//span[text()='Home']");

		List<String> agreements = extractAgreementNumbers(gcb._getConfigProperty("agreementsToHaveCardUpdated"));
		// List<String> agreements = Arrays.asList("800000036784",
		// "800000036784");

		final String ADDRESS_LINE_1 = "1 STREET ST";
		final String TOWN = "BRADFORD";
		final String POSTCODE = "BD1 2SU";
		final String CARD_HOLDER = "AUTO TEST";
		final String CARD_NUMBER = "4444333322221111";
		final String CVV_NUMBER = "123";
		final String EXP_MONTH = "12";
		final String EXP_YEAR = "2034";

		gcb.prLogIntoPanCreditFrontOffice();

		for (String agreement : agreements) {
			log.debug("Changing credit card for agreement: " + agreement);
			gcb.prNavigateToPANCreditAgreement(agreement);
			getDriver().findElement(byLinkContAuth).click();
			getDriver().findElement(byBtnEnterNewCard).click();

			Select dropdown;

			gcb.waitForTitle("Card Details");
			Assert.assertEquals(getDriver().getTitle(), "Card Details", "Check page title");

			getDriver().findElement(By.id("cardNumber")).click();
			getDriver().findElement(By.id("cardNumber")).sendKeys(CARD_NUMBER);
			getDriver().findElement(By.id("cardholderName")).click();
			getDriver().findElement(By.id("cardholderName")).sendKeys(CARD_HOLDER);
			dropdown = new Select(getDriver().findElement(By.id("expiryMonth")));
			dropdown.selectByVisibleText(EXP_MONTH);
			dropdown = new Select(getDriver().findElement(By.id("expiryYear")));
			dropdown.selectByVisibleText(EXP_YEAR);

			gcb.waitForRefresh(By.className("smallIcons"));
			getDriver().findElement(By.id("securityCode")).click();
			getDriver().findElement(By.id("securityCode")).sendKeys(CVV_NUMBER);
			getDriver().findElement(By.id("pin-helpimg")).click();

			By byAddrLine1 = By.id("billingAddressLine1");
			By byCity = By.id("billingAddressCity");
			By byPostcode = By.id("billingAddressPostcode");
			By byDDCountry = By.id("billingAddressCountry");
			By byConfirmBtn = By.id("billingContainerPanelHideButtonL");

			getDriver().findElement(byAddrLine1).sendKeys(ADDRESS_LINE_1);
			getDriver().findElement(byCity).sendKeys(TOWN);
			getDriver().findElement(byPostcode).sendKeys(POSTCODE);
			new Select(getDriver().findElement(byDDCountry)).selectByVisibleText("United Kingdom");
			getDriver().findElement(byConfirmBtn).click();

			// Invoke Next action: Simulator Test Page
			By byBtnMakePayment = By.id("submitButton");
			gcb.waitForClickableElement(byBtnMakePayment);
			getDriver().findElement(byBtnMakePayment).click();

			log.debug("Completed agreement: " + agreement);

			getDriver().findElement(byLinkHome).click();

		}
		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
