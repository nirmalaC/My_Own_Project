package automation.tests.identifyservicemockoff.testsuite.b2c.referrals;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.IdentifyServiceMockOffTest;
import automation.dao.CustomerType;
import automation.satsuma.pages.CookBook;
import automation.tools.ToolBox;

public class TestCase_11359_ReferredFRD704NewCustomerCallCreditDeceasedWarningIsSet extends IdentifyServiceMockOffTest {

	static WebDriver driver;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	public String gsSatsumaSiteUrl; // Satsuma Site
	public String gsdbTESTSHEDConnectionString; // TestShed database connection
												// string

	String gsCurrentUrl;

	CookBook gcb = new CookBook();
	ToolBox gtb = new ToolBox();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		// Read config.properties for firefox proxy settings
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		String sZoralAppServerStatusUrl;
		InputStream input = null;

		input = new FileInputStream("config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sProxyIP = prop.getProperty("ProxyIP");
		if (sProxyIP.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyIP missing");
		else
			log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);

		sProxyPort = prop.getProperty("ProxyPort");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyPort missing");
		else
			log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);

		sNoProxyOn = prop.getProperty("NoProxyOn");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties NoProxyOn missing");
		else
			log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);

		sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
		if (sZoralAppServerStatusUrl.isEmpty())
			Assert.fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
		else
			log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" + sZoralAppServerStatusUrl);

		input.close();

		// Setup Browser with proxy
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", sProxyIP);
		profile.setPreference("network.proxy.http_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.ssl", sProxyIP);
		profile.setPreference("network.proxy.ssl_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
		driver = new FirefoxDriver(profile);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		// Check Satsuma mock status - Abort test if inconsistent status found
		//
		// Mock Requirements for these tests are
		// 1. Experian mock : On
		// 2. CallCredit mock : On
		// 3. PanCredit mock : Off
		// 4. Affordability mock: On
		// 5. Statistical calculations mock: On
		// 6. IdentifyService mock: Off

		driver.get(sZoralAppServerStatusUrl);

		assertEquals("Satsuma services", driver.getTitle());
		assertEquals("Experian mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[1]")).getText());
		assertEquals("CallCredit mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[2]")).getText());
		// assertEquals("PanCredit mock: Off",driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[3]")).getText());
		assertEquals("Affordability mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[4]")).getText());
		assertEquals("Statistical calculations mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[5]")).getText());
		assertEquals("IdentifyService mock: Off", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[6]")).getText());

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		// Terminate Browser
		driver.quit();
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		// Goto Satsuma site
		driver.get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		driver.findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		driver.findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database

	}

	@AfterMethod
	public void tearDown() throws Exception {

		// Disconnect from TestShed database

	}

	@Test
	public void test_ReferIfApplicantCallCreditSearchDeterminesDeceasedWarningIsSet() throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for applicant on Mocked Callcredit test
		// environment who is flagged with Deceased Warning
		// Applicant Ben FRDNCCCDDEC
		gcb.prGetApplicantProfile(152);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 60)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page
		// ===============

		// Landed on completion page type Result11 in context Your application
		// is now being processed and verified.
		// Within 24 hours customer care team will contact you whether your
		// application has been accepted.
		gcb.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on "Deceased Warning is set"
		// reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 704 - Deceased Warning is set
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Referral Queue");
		assertTrue(getDriver().getPageSource().contains("Deceased Warning is set"));

		driver.findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("title")));
		dropdown.selectByVisibleText(gcb.gsTitle);

		String tmpStr = driver.findElement(By.id("surname")).getAttribute("value");
		if (!(tmpStr.contains("AutoDel"))) {
			driver.findElement(By.id("surname")).clear();
			driver.findElement(By.id("surname")).sendKeys("AutoDel" + tmpStr);
		}
		driver.findElement(By.id("PanLinkSubmit_5")).click();

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}
