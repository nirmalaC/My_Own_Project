package automation.tests.monthly;

import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class MonthlyAboutYouCalculatorTest extends PageValidationTest {

	@BeforeMethod
	public void before() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================
		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

	}

	@Test
	public void test3Months() throws InterruptedException, SQLException {
		test_AboutYouSliderPricingCalculations("Monthly", 3, 100, 1000);
	}

	@Test
	public void test4Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 4, 100, 1000);
	}

	@Test
	public void test5Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 5, 100, 1000);
	}

	@Test
	public void test6Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 6, 100, 1000);
	}

	@Test
	public void test7Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 7, 100, 1000);
	}

	@Test
	public void test8Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 8, 100, 1000);
	}

	@Test
	public void test9Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 9, 100, 1000);
	}

	@Test
	public void test10Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 10, 100, 1000);
	}

	@Test
	public void test11Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 11, 100, 1000);
	}

	@Test
	public void test12Months() throws InterruptedException, SQLException {

		test_AboutYouSliderPricingCalculations("Monthly", 12, 100, 1000);
	}

	@Test
	public void test13Weeks() throws InterruptedException, SQLException {
		test_AboutYouSliderPricingCalculations("Weekly", 13, 100, 1000);
	}

	@Test
	public void test52Weeks() throws InterruptedException, SQLException {
		test_AboutYouSliderPricingCalculations("Weekly", 52, 100, 1000);
	}

}
