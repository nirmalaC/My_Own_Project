package automation.tests.experian.downsell;

import automation.basetests.ExperianMockOffTestAdapted;

public class TestCase_MonthlyDownsellParameters extends ExperianMockOffTestAdapted {
	//
	// @UseAsTestName()
	// @Test
	// @Parameters({ "surname", "forename", "amount", "term" })
	// public void downsell(String surname, String forename, String amount,
	// String term) throws Exception {
	// downsellMonthlyAccept(forename, surname, amount, term);
	// }
	//
	// @AfterMethod
	// @Parameters({ "forename", "surname" })
	// public void afterTest(String forename, String surname) throws Exception {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, forename, surname);
	// gcb.prLogIntoPanCreditFrontOffice();
	// gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(forename,
	// surname, "*", "AutoDel" + surname);
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }
	//
	// private void downsellMonthlyAccept(String forename, String surname,
	// String loanAmount, String term) throws Exception {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, forename, surname);
	// SatsumaExperianAgreement agreement =
	// ExperianDataHelper.getSatsumaExperianAgreement(forename, surname);
	// log.debug(agreement.toString());
	// ExperianDataHelper.convertToCookbook(agreement, gcb);
	// gcb.setRandomEmail();
	// newCustomerQuoteVerifyDownsell(loanAmount, term, "Monthly", 133, true);
	// }
}
