package automation.test.offerservice.enums;

public class OfferPartyStatus {
	public static final int FROZEN_DEFAULTED = 1;
	public static final int ACTIVE = 2;
	public static final int PAID_UP = 3;
	public static final int UNKNOWN = 4;
	public static final int OTHER = 5;

}
