package automation.tests.framework;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automation.basetests.ParameterRenameTest;
import automation.satsuma.pages.UseAsTestName;

public class UseAsTestNameTest extends ParameterRenameTest {

	@UseAsTestName()
	@Parameters({ "testname", "testparameter" })
	@Test()
	public void shouldHaveTestNamesBasedOnMethodName(@Optional("foo") String testname, @Optional("bar") String testparameter) {
		System.out.println("testname");
	}
}
