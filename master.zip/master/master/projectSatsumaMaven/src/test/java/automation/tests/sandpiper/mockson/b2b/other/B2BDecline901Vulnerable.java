package automation.tests.sandpiper.mockson.b2b.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.satsuma.pages.ApplicationType;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

public class B2BDecline901Vulnerable extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 387;
	private static final int MONTHLY_APPLICANT_ID = 386;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "901";

	// not currently a decline

	@Test
	public void b2BLoginDeclineWeekly() throws Exception {
		testFL901(WEEKLY_APPLICANT_ID);
	}

	private void testFL901(int applicantId) throws Exception {

		gcb.prGetApplicantProfile(applicantId);
		gcb.prCreateUniquePerson();

		// seed agreement
		gcb.prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// seed eligible offer
		gcb.seedFLEEligibleOffer(false, 2000d, true);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// clear history again
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");

	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
