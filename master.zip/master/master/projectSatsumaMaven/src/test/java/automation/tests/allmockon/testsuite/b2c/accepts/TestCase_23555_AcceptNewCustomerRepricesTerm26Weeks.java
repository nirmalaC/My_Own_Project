package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23555_AcceptNewCustomerRepricesTerm26Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice26weeks100() throws Exception {
		newCustomerAccept("100", "26", "Weekly", 133);
	}

	@Test
	public void test_Reprice26weeks500() throws Exception {
		newCustomerAccept("500", "26", "Weekly", 133);
	}

	@Test
	public void test_Reprice26weeks1000() throws Exception {
		newCustomerAccept("1000", "26", "Weekly", 133);
	}

}
