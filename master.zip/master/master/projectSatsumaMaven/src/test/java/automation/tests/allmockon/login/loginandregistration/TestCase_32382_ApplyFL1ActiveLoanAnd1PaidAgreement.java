package automation.tests.allmockon.login.loginandregistration;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import automation.basetests.MySatsumaSliderBarTest;

import com.eviware.soapui.support.SoapUIException;

public class TestCase_32382_ApplyFL1ActiveLoanAnd1PaidAgreement extends MySatsumaSliderBarTest {

	@Test
	public void test() throws XmlException, SoapUIException, Exception {
		// seed and register an agreement
		seedAndRegisterLogin(300f, "52", true);

		gcb.prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(gcb.gsPanCreditServiceServer, gcb.gsPANAgreementNumber);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();
		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// // change bank details in PAN
		// gcb.prLogIntoPanCreditFrontOffice();
		// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
		// gcb.prNavigateToPANBankDetails();
		// String changedName = "";
		// String changedSortCode = "";
		// String changedAccountNo = "";
		// gcb.prEditPANBankDetails("Changed Name", "888888", "88888888");
		// // continue bank application to bank details screen and verify

		// apply for different loan amount
		gcb.gsRequestedLoanAmount = "200";
		gcb.gsRequestedTerm = "26";
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// verify you cannot amend bank details

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(Float.toString(gcb.calcEligibleAmount(100f, 71.58f)))));

		log.debug(gcb.gsRequestedLoanAmount);

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		gcb.waitForClickableElement(By.id("ContinueButtonStep1"));
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}

}
