package automation.tests.monthly;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_MonthlyFL3Months extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_LoanAmount200() throws Exception {
		loginAndApplyFL("200", "3", "Monthly");
	}

	@Test
	public void test_LoanAmount500() throws Exception {
		loginAndApplyFL("500", "3", "Monthly");
	}

	@Test
	public void test_LoanAmount1000() throws Exception {
		loginAndApplyFL("1000", "3", "Monthly");
	}

	@Test
	public void test_LoanAmount2000() throws Exception {
		loginAndApplyFL("2000", "3", "Monthly");
	}

}
