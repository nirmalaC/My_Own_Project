package automation.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.test.offerservice.entities.OfferRequest;
import automation.test.offerservice.entities.RetrieveOfferResponse;
import automation.test.offerservice.enums.EligibilityReasonCode;
import automation.test.offerservice.enums.OfferPartyStatus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class RestHelperTest {

	@Test
	public void TestRequest() throws InterruptedException {
		String forename = "Leonard";
		String surname = "Nimoy";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dob = null;
		try {
			dob = sdf.parse("1970-01-01");
		} catch (ParseException e) {
			System.err.println("Error invalid date");
		}

		OfferRequest req = OfferServiceRequestBuilder.eligible(forename, surname, dob, "SA", 800d, 500, OfferPartyStatus.ACTIVE, false);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		String response = RestHelper.postOffer(json);

		// Assert.assertTrue(response.contains("id"));

		// System.out.println(response);

		// retrieve offer and assert
		RetrieveOfferResponse offerResponse = RestHelper.getOffer(forename, surname, dob);

		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferParty().getId(), MatchKeyHelper.generateMatchKey(forename, surname, dob));
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferParty().getOfferPartyStatus(), OfferPartyStatus.ACTIVE);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getEligibilityReasonCode(), EligibilityReasonCode.HAS_ACTIVE);

	}

	@Test
	public void TestRequestInEligible() throws InterruptedException {
		String forename = "Johny";
		String surname = "Rotten";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dob = null;
		try {
			dob = sdf.parse("1970-01-01");
		} catch (ParseException e) {
			System.err.println("Error invalid date");
		}

		OfferRequest req = OfferServiceRequestBuilder.ineligible(forename, surname, dob, "BA", 501, OfferPartyStatus.ACTIVE, false);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		String response = RestHelper.postOffer(json);

		// Assert.assertTrue(response.contains("id"));

		// System.out.println(response);

		// retrieve offer and assert
		RetrieveOfferResponse offerResponse = RestHelper.getOffer(forename, surname, dob);

		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferParty().getId(), MatchKeyHelper.generateMatchKey(forename, surname, dob));
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferParty().getOfferPartyStatus(), OfferPartyStatus.ACTIVE);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getEligibilityReasonCode(), EligibilityReasonCode.FROZEN);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getIsEligibleForLending(), false);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getSource(), "SX");

	}
}
