package automation.tests.experian.downsell;

import automation.basetests.ExperianMockOffTestAdapted;

public class TestCase_MonthlyDownsellNPRTScoreTo300 extends ExperianMockOffTestAdapted {
	//
	// @Test
	// public void downsellTo300() throws Exception {
	// SatsumaExperianAgreement agreement =
	// ExperianDataHelper.getSatsumaExperianAgreement("MOHAMMED", "INCE");
	// log.debug(agreement.toString());
	// ExperianDataHelper.convertToCookbook(agreement, gcb);
	// gcb.setRandomEmail();
	// newCustomerQuoteVerifyDownsell("1000", "6", "Monthly", 133, true);
	// }

}
