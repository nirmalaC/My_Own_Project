package automation.tests.allmockon.testsuite.b2c.referrals;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;

public class TestCase_11341_ReferredFRD702PaidUpVulnerableCustomerCallCreditPEPWarning extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_ReferVulnerableApplicantCallCreditPEPWarning() throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for applicant on Mocked Callcredit test
		// environment who is flagged with PEP Warning
		// Applicant Pep Warning
		gcb.prGetApplicantProfile(74);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
			// " found, but not fully paid, please remove and re-try test");
			log.warn("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, but not fully paid, please remove and re-try test");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);

			// Seed a fully paid up agreement for this person in PAN
			gcb.prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

			log.info("Fully Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of fully paid agreement for this test failed.");
			}
		} else {

			// Seed a fully paid up agreement for this person in PAN
			gcb.prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

			log.info("Fully Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of fully paid agreement for this test failed.");
			}

		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// CV - 08.03.2016 - now includes the Change Loan Amount screen despite
		// the fact that loan requested is within limits

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Loan Amount Slider defaulted to £200 as this is the maximum amount
		// the customer is offered as his previous request was higher
		Assert.assertEquals("200", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));
		gcb.prConfirmLVA();

		gcb.prClickForNextAction();
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.EXISTING_NOT_ACTIVE_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Former Paid Up Vulnerable Completion page
		// =========================================

		// gcb.prAssertOnPageCompletionIDResult18(gsSatsumaSiteUrl);
		// gcb.prAssertOnPageCompletionIDResult12(gsSatsumaSiteUrl);
		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct refer on "Vulnerable Customer is set"
		// reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred for 901 - Vulnerable Customer -
		// Primary Referral
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Suspected Vulnerable (NB)");
		Assert.assertTrue(getDriver().getPageSource().contains("Vulnerable Customer"));
		// Expect agreement to be referred for fraud 702 - Callcredit PEP
		// Warning is set Secondary Referral
		Assert.assertTrue(getDriver().getPageSource().contains("PEP Warning is set"));
		// Not expecting specific 904 - Income Verification Referral
		Assert.assertFalse(getDriver().getPageSource().contains("Income Verification Referral"));

		// gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
