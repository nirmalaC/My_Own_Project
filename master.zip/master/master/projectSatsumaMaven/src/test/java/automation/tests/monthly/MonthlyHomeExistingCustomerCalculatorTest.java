package automation.tests.monthly;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class MonthlyHomeExistingCustomerCalculatorTest extends PageValidationTest {

	@BeforeMethod
	public void before() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		gcb.waitForVisibilityOfElement(By.id("header-link-existing-customers"));
		gcb.waitForClickableElement(By.id("header-link-existing-customers"));
		getDriver().findElement(By.id("header-link-existing-customers")).click();

	}

	@Test
	public void test3Months() throws Exception {
		test_HomeSliderPricingCalculations("Monthly", 3, 100, 2000);
	}

	@Test
	public void test4Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 4, 100, 2000);
	}

	@Test
	public void test5Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 5, 100, 2000);
	}

	@Test
	public void test6Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 6, 100, 2000);
	}

	@Test
	public void test7Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 7, 100, 2000);
	}

	@Test
	public void test8Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 8, 100, 2000);
	}

	@Test
	public void test9Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 9, 100, 2000);
	}

	@Test
	public void test10Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 10, 100, 2000);
	}

	@Test
	public void test11Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 11, 100, 2000);
	}

	@Test
	public void test12Months() throws Exception {

		test_HomeSliderPricingCalculations("Monthly", 12, 100, 2000);
	}

	@Test
	public void test13Weeks() throws Exception {

		test_HomeSliderPricingCalculations("Weekly", 13, 100, 2000);
	}

	@Test
	public void test52Weeks() throws Exception {

		test_HomeSliderPricingCalculations("Weekly", 52, 100, 2000);
	}
}
