package automation.tests.allmockon.testsuite.b2c.referrals;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_11362_ReferredFRD752NewCustomerCallCreditOFADifferentIndividual extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_ReferIfApplicantCallCreditSearchDeterminesOFADifferentIndividual() throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for applicant on Mocked Callcredit test
		// environment who is flagged with OFA Different Individual
		// Applicant Mr OFA Individual
		gcb.prGetApplicantProfile(239);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
			// " found, please remove and re-try test");
			log.warn("Agreement " + gcb.gsPANAgreementNumber + " found, trying to remove it");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login
		// ===============

		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// // Landed on completion page type Result11 in context Your
		// application
		// // is now being processed and verified.
		// // Within 24 hours customer care team will contact you whether your
		// // application has been accepted.
		// gcb.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "Ownership Fraud Alert - Different Individual" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 752 - Ownership Fraud Alert -
		// Different Individual
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Referral Queue");
		Assert.assertTrue(getDriver().getPageSource().contains("Ownership Fraud Alert - Different Individual"));

		gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}
