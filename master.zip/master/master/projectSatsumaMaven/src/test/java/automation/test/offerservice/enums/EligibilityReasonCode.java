package automation.test.offerservice.enums;

public class EligibilityReasonCode {
	public static final int HAS_NO_AGREEMENT = 1;
	public static final int HAS_APPROVED_PROPOSAL = 2;
	public static final int HAS_ANY_OTHER_STATUS = 3;
	public static final int HAS_ACTIVE = 4;
	public static final int HAS_DECLINE_5M = 5;
	public static final int HAS_UNSIGNED_PROPOSAL = 6;
	public static final int FROZEN = 7;
	public static final int CONCURRENT_MAX = 8;
	public static final int HAS_PAIDUP = 9;
	public static final int NOT_SET = 0;
}