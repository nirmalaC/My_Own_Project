package automation.tests.allmockon.testsuite.b2b.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

/*
 * System Test
 This test is concerned with ensuring that applications that result in a XML Score <= the threshold are accepted.
 To test use the attached WCFStorm XML and use the attached Experian mock response and place in D:\inetpub\wwwroot\Satsuma.Service\bin\Responses\Experian.Interactive on the appropriate App Server.
 Ensure that the SatsumaBrokerPreliminaryEnhancedWorkflow has ItemId="61" : SamplingRatioA="0.00".
 Experian Mock must be ON, all others can be ON or OFF

 15.09 - CV - Application variables no longer use in scoring within PCO strategy, test has been updated to new bureau file for new threshold
 */

public class TestCase_30723_XmlScoreLessThanThresholdIsAccepted extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		// xmlscore_greaterthanthreshold
		// threshold is 438 for source of HA or HQ
		gcb.prGetApplicantProfile(403);
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.gsDOB = "04/04/1967";

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		gcb.seedFLEEligibleOffer("HA", 100d, false);

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30708_Satsuma B2B: Accept Happy Path", "Aspire", "");

		// Assert.assertEquals(PowerCurveDBHelper.getScore(gcb.powercurveDB,
		// gcb.gsFirstname, gcb.gsSurname), 40.0f, "Score");
		Assert.assertEquals(PowerCurveDBHelper.getScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 450.0f, "Score");
	}
}
