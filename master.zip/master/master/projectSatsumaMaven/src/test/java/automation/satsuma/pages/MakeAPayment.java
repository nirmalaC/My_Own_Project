package automation.satsuma.pages;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.SkipException;

public class MakeAPayment extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	public MakeAPayment(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public MakeAPayment(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public void searchForCustomerAgreement(String firstname, String surname, String postcode) {
		searchForCustomerAgreement(firstname, surname, postcode, 0);
	}

	public void searchForCustomerAgreement(String forename, String surname, String postcode, int index) {
		getDriver().findElement(By.id("surname")).sendKeys(surname);
		getDriver().findElement(By.id("forename")).sendKeys(forename);
		getDriver().findElement(By.id("postcode")).sendKeys(postcode);

		// Search now
		getDriver().findElement(By.id("PanLinkSubmit")).click();

		// get list of all the agreements found
		List<WebElement> elements = getDriver().findElements(By.cssSelector(".linkWithBullet"));

		if (elements.size() == 0) {
			log.warn("Element not found skipping test");
			throw new SkipException("Customer: \"" + forename + " " + surname + "\" not found skipping test");
		}

		// click the first one
		elements.get(index).click();
	}

	public void findAgreementInArrearsInPAN() throws ParseException {
		findAgreementInArrearsInPAN(0);
	}

	public void findAgreementInArrearsInPAN(int index) throws ParseException {
		// assumes you are on the pan homepage
		// click collections tab
		getDriver().findElement(By.xpath("//span[text()='Collections']")).click();

		// wait for header
		waitForSelectedTextInElement(By.cssSelector(".titleBarMiddle"), "Collections Queued Agreements");

		// select arrears - provadmin queue
		Select select = new Select(getDriver().findElement(By.id("plan")));
		select.selectByVisibleText("Arrears - PROVADMIN");

		// select first agreement in arrears
		getDriver().findElements(By.cssSelector(".linkWithBullet")).get(index).click();
	}

	public void getAgreementInfoFromPAN() throws ParseException {
		// assumes you are on the agreement info page

		// get agreement number
		gsPANAgreementNumber = getDriver().findElement(By.cssSelector("#titlebar > span.titleBarRight > span:nth-child(1)")).getText(); // agreement
		// number

		// dob
		gsDOB = formatDate(getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(1) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(1) > td:nth-child(4)")).getText(), "dd-MMM-yyyy", "dd/MM/yyyy");

		// get email
		gsEmailAddress = getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(1) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(5) > td:nth-child(4)")).getText();

		// get loan freq, amount, term
		gsRequestedLoanAmount = getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(2) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(4) > td:nth-child(2)")).getText();
		gsRequestedTerm = getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(2) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(11) > td:nth-child(2)")).getText();

		if (getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(2) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(1) > td:nth-child(2)")).getText().contains("New Monthly"))
			gsRepaymentFrequency = "Monthly";
		else if (getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(2) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(1) > td:nth-child(2)")).getText().contains("Weekly"))
			gsRepaymentFrequency = "Weekly";
		else
			throw new SkipException("invalid frequency found");

		log.info("Got loan info, agreement: " + gsPANAgreementNumber + " amount: " + gsRequestedLoanAmount + " term: " + gsRequestedTerm + " freq: " + gsRepaymentFrequency);

		// click name and address link
		waitForClickableElement(By.linkText("Name & Address"));
		getDriver().findElement(By.linkText("Name & Address")).click();

		// get firstname,surname
		gsFirstname = getDriver().findElement(By.id("forename")).getAttribute("value");
		gsSurname = getDriver().findElement(By.id("surname")).getAttribute("value");
		// postcode
		gsPostcode = getDriver().findElement(By.id("postcode")).getAttribute("value");

		log.info("Got customer details, firstname: " + gsFirstname + " surname: " + gsSurname + " email: " + gsEmailAddress + " dob: " + gsDOB + " postcode: " + gsPostcode);
	}

	public void makeAPayment(float amount) {
		// click make a catchup payment
		getDriver().findElement(By.linkText("Make a catchup payment")).click();

		// wait for button to appear
		waitForVisibilityOfElement(By.id("btn-make-a-payment"));

		// Pay x amount now
		getDriver().findElement(By.id("btn-make-a-payment")).click();

		// wait for button in popup
		waitForVisibilityOfElement(By.id("lnk-catchup-payment"));

		// click
		getDriver().findElement(By.id("lnk-catchup-payment")).click();
	}

	public void assertOnPageMapWorldPay() {
		waitForUrl("https://payments-test.worldpay.com/app/hpp/payment/multicard");
	}

	public void fillInPageMapWorldpay() {
		// card no and name
		getDriver().findElement(By.id("cardNumber")).sendKeys(gsCreditCardNumber);
		getDriver().findElement(By.id("cardholderName")).sendKeys(gsFirstname + " " + gsSurname);

		// expiry
		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("expiryMonth")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(0, 2));
		dropdown = new Select(getDriver().findElement(By.id("expiryYear")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(3, 7));

		waitForClickableElement(By.id("securityCode"));
		getDriver().findElement(By.id("securityCode")).click();
		getDriver().findElement(By.id("securityCode")).sendKeys(gsCreditCardCVS);

		// wait for button to activate
		waitForClickableElement(By.id("submitButton"));

		getDriver().findElement(By.id("submitButton")).click();

		// url
		// http://satzorapp3.ho.pfgroup.provfin.com/my-satsuma/catchup-payment-response?paymentResult=AUTHORISED&orderKey=PROVIDENTTEST^ECOMTEST1^900000047899_a40884cd-cfe6-4260-829c-3c6177ad84a4&paymentStatus=AUTHORISED&paymentAmount=21200&paymentCurrency=GBP&mac2=773302384754f553a31b32cd8742b9777d0536c1ade2560204d4028518db46b4

		// header text
		// .main-content > h2:nth-child(1)
		// Payment successful

		// message text
		// .main-content > p:nth-child(2)

		// check for email

		// click mysatsuma
		// doesn't seem to show immediately
	}

	public void verifyArrearsZero() {
		Assert.assertEquals(getDriver().findElement(By.cssSelector("#PanForm > div.outercontent > div:nth-child(2) > div.contentNoMargin > table > tbody > tr > td:nth-child(1) > table > tbody > tr:nth-child(11) > td:nth-child(2)")).getText(), "0.00");
	}

	// method assumes that email address var has been changed
	public void changeEmailAddressInPAN() {
		// go to personal details
		getDriver().findElement(By.linkText("Personal Details")).click();
		waitForClickableElement(By.id("emailAddress"));
		getDriver().findElement(By.id("emailAddress")).sendKeys(gsEmailAddress);
		waitForClickableElement(By.name("monthlyPayment"));
		getDriver().findElement(By.name("monthlyPayment")).sendKeys("1");
		waitForClickableElement(By.id("PanLinkSubmit"));
		getDriver().findElement(By.id("PanLinkSubmit")).click();
	}

	public void verifyPaymentInMySatsuma() {
		// click mysatsuma from LHS
		getDriver().findElement(By.linkText("MySatsuma")).click();

		waitForVisibilityOfElement(By.cssSelector(".card__subtitle"));

		// verify agreement is there
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".card__subtitle")).getText(), "Agreement no: " + gsPANAgreementNumber);
		// click agreement
		getDriver().findElement(By.cssSelector(".card__subtitle")).click();

		waitForVisibilityOfElement(By.cssSelector(".status"));
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".status")).getText(), "Up to date");
	}
}
