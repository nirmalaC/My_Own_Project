package automation.tests.smartcheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.SmartCheckBaseTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class SmartCheckDecline202Bankruptcy extends SmartCheckBaseTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		newCustPCODeclineTest(215, "202");
	}

	@AfterMethod
	public void teardown() throws Exception {
		// clear down customer
		if (smartcheck.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, smartcheck.gsFirstname, smartcheck.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname, smartcheck.gsDOB);
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(smartcheck.gsFirstname, smartcheck.gsSurname, "*", "AutoDel" + smartcheck.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
