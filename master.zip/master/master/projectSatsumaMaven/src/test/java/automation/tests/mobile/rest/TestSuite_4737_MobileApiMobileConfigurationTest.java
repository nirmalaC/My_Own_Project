package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;

public class TestSuite_4737_MobileApiMobileConfigurationTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	// 31892 - fetch content
	@Test
	public void testCase_31011_mobileConfigIOS() throws Exception {
		String responseString = given().contentType("application/json").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(200).extract().response()
				.asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	// 31892 - fetch content
	@Test
	public void testCase_31013_mobileConfigAndroid() {
		String responseString = given().contentType("application/json").log().all().header("platform", "Android").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(200).extract().response()
				.asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	// 31892 - no date header
	@Test
	public void testCase_31018_mobileConfigNoDateHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("appVersionNumber", APP_VERSION_NO).when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));
	}

	// 31892 - invalid app version header
	@Test
	public void testCase_31012_31014_mobileConfigInvalidAppVersionHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", "0").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(400).body("FailureType", equalTo("AppVersionNotSupported"))
				.body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));
	}

	// 31892 - no app version header
	@Test
	public void testCase_31016_mobileConfigNoAppVersionHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31019_mobileConfigInvalidPlatformHeader() {
		given().contentType("application/json").log().all().header("platform", "Windows").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader"))
				.body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_31017_mobileConfigNoPlatformHeader() {
		given().contentType("application/json").log().all().header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(MOBILE_CONFIG_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'Platform'"));
	}
}
