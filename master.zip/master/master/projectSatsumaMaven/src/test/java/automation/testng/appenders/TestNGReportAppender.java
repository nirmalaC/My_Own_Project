package automation.testng.appenders;

import org.testng.Reporter;

import ch.qos.logback.core.AppenderBase;

public class TestNGReportAppender extends AppenderBase {
	//
	// private String eventToString(final LoggingEvent event) {
	// final StringBuilder result = new StringBuilder(layout.format(event));
	//
	// if (layout.ignoresThrowable()) {
	// final String[] s = event.getThrowableStrRep();
	// if (s != null) {
	// for (final String value : s) {
	// result.append(value).append(Layout.LINE_SEP);
	// }
	// }
	// }
	// return result.toString();
	// }
	//
	// @Override
	// public void close() {
	//
	// }
	//
	// @Override
	// public boolean requiresLayout() {
	// return true;
	// }
	//
	// @Override
	// protected void append(LoggingEvent event) {
	// Reporter.log(eventToString(event));
	// }

	@Override
	protected void append(Object event) {

		Reporter.log(event.toString());
	}

}
