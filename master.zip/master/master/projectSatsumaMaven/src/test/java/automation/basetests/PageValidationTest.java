package automation.basetests;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class PageValidationTest extends BrowserTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected final By linkExistingCustomers = By.id("header-link-existing-customers");
	protected final By byDdAccountOpenMonth = By.id("DisplayAccountOpened_Month");
	protected final By byDdAccountOpenYear = By.id("DisplayAccountOpened_Year");
	protected final By byLblAccountOpened = By.xpath("//label[@for='AccountOpened']");
	protected final By bySpanAccountHolder = By.xpath("//span[@for='AccountHolder']");

	public void test_AboutYouSliderPricingCalculations(String psFrequency, int piTerm, int piMinLoanAmount, int piMaxLoanAmount) throws SQLException {

		String termText = "";
		switch (psFrequency) {
		case "Weekly":
			termText = "weeks";
			// click weekly tab
			gcb.waitForVisibilityOfElement(By.id("TermTypeAboutYouCalcWeekly"));
			gcb.waitForClickableElement(By.id("TermTypeAboutYouCalcWeekly"));
			getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();

			gcb.waitForRefresh(By.id("TermAboutYouCalcDropdown"));

			int retries = 2;

			while (!((new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")))).getFirstSelectedOption().getText().contains("weeks"))) {
				if (retries == 0) {

					Assert.fail("Couldn't get to correct frequency screen");
					break;
				}
				log.info("Couldn't find correct dropdown value, trying to click again");
				getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();
				retries--;
			}

			break;
		case "Monthly":
			termText = "months";
			// click monthly tab
			gcb.waitForVisibilityOfElement(By.id("TermTypeAboutYouCalcMonthly"));
			gcb.waitForClickableElement(By.id("TermTypeAboutYouCalcMonthly"));
			getDriver().findElement(By.id("TermTypeAboutYouCalcMonthly")).click();

			gcb.waitForRefresh(By.id("TermAboutYouCalcDropdown"));

			retries = 2;
			while (!((new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")))).getFirstSelectedOption().getText().contains("months"))) {
				if (retries == 0) {
					Assert.fail("Couldn't get to correct frequency screen");
					break;
				}
				log.info("Couldn't find correct dropdown value, trying to click again");
				getDriver().findElement(By.id("TermTypeAboutYouCalcMonthly")).click();
				retries--;
			}

			break;
		}

		gcb.waitForVisibilityOfElement(By.id("TermAboutYouCalcDropdown"));
		gcb.waitForVisibilityOfElement(By.id("LoanAmountAboutYouCalcDropdown"));
		gcb.waitForClickableElement(By.id("TermAboutYouCalcDropdown"));
		gcb.waitForClickableElement(By.id("LoanAmountAboutYouCalcDropdown"));

		// Validate the slider displayed charges - TAP, Interest, Re-payment
		// (and APR has been removed)

		String sTerm;
		String sLoanAmount;
		String sInterest;
		String sRepayment;
		String sTotalToRepay;
		String sAPR;

		String formattedInterest;
		String formattedTAP;
		String formattedRepayment;

		// String gsTmp;
		CallableStatement SQLStmt = null;

		try {
			gcb.DBConnectTESTSHED(gcb._getConfigProperty("TestShedDBConnection"));

			SQLStmt = gcb.gdbConnTESTSHED.prepareCall("{call [dbo].[prGetRangedSatsumaLoanCharges] (?,?,?,?)}");
			SQLStmt.setNString(1, psFrequency);
			SQLStmt.setInt(2, piTerm);
			SQLStmt.setInt(3, piMinLoanAmount);
			SQLStmt.setInt(4, piMaxLoanAmount);

			// JavascriptExecutor js = (JavascriptExecutor) getDriver();

			int retries = 2;
			while (true) {
				try {
					// gsTmp = "pfg.LoanCalculator.setAmount(" +
					// Integer.toString(piMinLoanAmount) + ")";
					// js.executeScript(gsTmp);
					// //
					// getDriver().findElement(By.id("LoanAmountHomeCalc")).click();
					// gsTmp = "pfg.LoanCalculator.setTerm(" +
					// Integer.toString(piTerm) + ")";
					// js.executeScript(gsTmp);

					Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown")));
					dropdown.selectByValue(Integer.toString(piMinLoanAmount));

					Select dropdown2 = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")));
					dropdown2.selectByVisibleText(piTerm + " " + termText);

					// wait for dropdown to have the right value which we
					// selected
					gcb.waitForDropdownSelectedText(By.id("TermAboutYouCalcDropdown"), Integer.toString(piTerm) + " " + termText);
					gcb.waitForDropdownSelectedText(By.id("LoanAmountAboutYouCalcDropdown"), "£" + Integer.toString(piMinLoanAmount));
					(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.textToBePresentInElement(new

					Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"))).getFirstSelectedOption(), Integer.toString(piMinLoanAmount)));
					break;
				} catch (TimeoutException e) {
					log.warn("loan term not selected, retries: " + retries);
					if (retries < 1)
						throw e;
				}
				retries--;
			}

			ResultSet rs = SQLStmt.executeQuery();

			retries = 0;

			while (rs.next()) {
				sTerm = rs.getString(2);
				sLoanAmount = "£" + rs.getString(3);
				sTotalToRepay = "£" + rs.getString(4);
				sInterest = "£" + rs.getString(5);
				sRepayment = "£" + rs.getString(6);
				sAPR = rs.getString(7) + "%";

				formattedInterest = gcb.formatCurrencyToDisplay(rs.getString(5));
				formattedRepayment = gcb.formatCurrencyToDisplay(rs.getString(6));
				formattedTAP = gcb.formatCurrencyToDisplay(rs.getString(4));

				retries = 2;
				while (true) {
					try {
						selectOption(new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"))), sLoanAmount.substring(1, sLoanAmount.length() - 2));
						gcb.waitForDropdownSelectedText(By.id("LoanAmountAboutYouCalcDropdown"), sLoanAmount.replace(".0", ""));
						break;
					} catch (TimeoutException e) {
						log.warn("Loan amount option not selected correctly, remaining retries: " + retries);
						log.warn("expected " + sLoanAmount.replace(".0", ""));
						log.warn("actual " + new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"))).getFirstSelectedOption().getText());
						if (retries < 1)
							break;
					}
					retries--;
				}

				Assert.assertEquals(sLoanAmount.substring(1, sLoanAmount.length() - 2), new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"))).getFirstSelectedOption().getAttribute("value"));

				log.info("prGetRangedSatsumaLoanCharges: Term:" + sTerm + ",Frequency:" + psFrequency + ",LoanAmount:" + sLoanAmount + ",Interest:" + sInterest + ",Repayment:" + sRepayment + ",TotalToRepay:" + sTotalToRepay + ",Apr:" + sAPR);

				Assert.assertEquals(getDriver().findElement(By.id("TotalInterestAboutYouCalcText")).getText(), formattedInterest);
				Assert.assertEquals(getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText(), formattedRepayment);
				Assert.assertEquals(getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText(), formattedTAP);

				// take screenshot
				gcb.takeIncrementScreenshot();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e1) {

			e1.printStackTrace();
		} finally {
			if (SQLStmt != null) {
				try {
					SQLStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void test_HomeSliderPricingCalculations(String psFrequency, final int piTerm, final int piMinLoanAmount, int piMaxLoanAmount) throws Exception {
		String termText = "";
		switch (psFrequency) {
		case "Weekly":
			termText = "weeks";
			// click weekly tab
			gcb.waitForVisibilityOfElement(By.id("TermTypeHomeCalcWeekly"));
			gcb.waitForClickableElement(By.id("TermTypeHomeCalcWeekly"));
			getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

			gcb.waitForRefresh(By.id("TermHomeCalcDropdown"));

			int retries = 2;

			while (!((new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")))).getFirstSelectedOption().getText().contains("weeks"))) {
				if (retries == 0) {

					Assert.fail("Couldn't get to correct frequency screen");
					break;
				}
				log.info("Couldn't find correct dropdown value, trying to click again");
				getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();
				retries--;
			}

			break;
		case "Monthly":
			termText = "months";
			// click monthly tab
			gcb.waitForVisibilityOfElement(By.id("TermTypeHomeCalcMonthly"));
			gcb.waitForClickableElement(By.id("TermTypeHomeCalcMonthly"));
			getDriver().findElement(By.id("TermTypeHomeCalcMonthly")).click();

			gcb.waitForRefresh(By.id("TermHomeCalcDropdown"));

			retries = 2;
			while (!((new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")))).getFirstSelectedOption().getText().contains("months"))) {
				if (retries == 0) {
					Assert.fail("Couldn't get to correct frequency screen");
					break;
				}
				log.info("Couldn't find correct dropdown value, trying to click again");
				getDriver().findElement(By.id("TermTypeHomeCalcMonthly")).click();
				retries--;
			}

			break;
		}

		gcb.waitForVisibilityOfElement(By.id("TermHomeCalcDropdown"));
		gcb.waitForVisibilityOfElement(By.id("LoanAmountHomeCalcDropdown"));
		gcb.waitForClickableElement(By.id("TermHomeCalcDropdown"));
		gcb.waitForClickableElement(By.id("LoanAmountHomeCalcDropdown"));

		// Validate the slider displayed charges - TAP, Interest, Re-payment
		// (and APR has been removed)

		String sTerm;
		String sLoanAmount;
		String sInterest;
		String sRepayment;
		String sTotalToRepay;
		String sAPR;

		String formattedInterest;
		String formattedTAP;
		String formattedRepayment;

		gcb.DBConnectTESTSHED(gcb._getConfigProperty("TestShedDBConnection"));

		// String gsTmp;
		CallableStatement SQLStmt = null;

		try {

			SQLStmt = gcb.gdbConnTESTSHED.prepareCall("{call [dbo].[prGetRangedSatsumaLoanCharges] (?,?,?,?)}");
			SQLStmt.setNString(1, psFrequency);
			SQLStmt.setInt(2, piTerm);
			SQLStmt.setInt(3, piMinLoanAmount);
			SQLStmt.setInt(4, piMaxLoanAmount);

			// JavascriptExecutor js = (JavascriptExecutor) getDriver();

			int retries = 2;
			while (true) {
				try {

					Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
					dropdown.selectByValue(Integer.toString(piMinLoanAmount));

					Select dropdown2 = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
					dropdown2.selectByVisibleText(piTerm + " " + termText);

					// wait for dropdown to have the right value which we
					// selected
					gcb.waitForDropdownSelectedText(By.id("TermHomeCalcDropdown"), Integer.toString(piTerm) + " " + termText);
					gcb.waitForDropdownSelectedText(By.id("LoanAmountHomeCalcDropdown"), "£" + Integer.toString(piMinLoanAmount));
					(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.textToBePresentInElement(new

					Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"))).getFirstSelectedOption(), Integer.toString(piMinLoanAmount)));
					break;
				} catch (TimeoutException e) {
					log.warn("loan term not selected, retries: " + retries);
					if (retries < 1)
						throw e;
				}
				retries--;
			}

			ResultSet rs = SQLStmt.executeQuery();

			retries = 0;

			while (rs.next()) {
				sTerm = rs.getString(2);
				sLoanAmount = "£" + rs.getString(3);
				sTotalToRepay = "£" + rs.getString(4);
				sInterest = "£" + rs.getString(5);
				sRepayment = "£" + rs.getString(6);
				sAPR = rs.getString(7) + "%";

				formattedInterest = gcb.formatCurrencyToDisplay(rs.getString(5));
				formattedRepayment = gcb.formatCurrencyToDisplay(rs.getString(6));
				formattedTAP = gcb.formatCurrencyToDisplay(rs.getString(4));

				retries = 2;
				while (true) {
					try {
						selectOption(new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"))), sLoanAmount.substring(1, sLoanAmount.length() - 2));
						gcb.waitForDropdownSelectedText(By.id("LoanAmountHomeCalcDropdown"), sLoanAmount.replace(".0", ""));
						break;
					} catch (TimeoutException e) {
						log.warn("Loan amount option not selected correctly, remaining retries: " + retries);
						log.warn("expected " + sLoanAmount.replace(".0", ""));
						log.warn("actual " + new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"))).getFirstSelectedOption().getText());
						if (retries < 1)
							break;
					}
					retries--;
				}

				Assert.assertEquals(sLoanAmount.substring(1, sLoanAmount.length() - 2), new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"))).getFirstSelectedOption().getAttribute("value"));

				log.info("prGetRangedSatsumaLoanCharges: Term:" + sTerm + ",Frequency:" + psFrequency + ",LoanAmount:" + sLoanAmount + ",Interest:" + sInterest + ",Repayment:" + sRepayment + ",TotalToRepay:" + sTotalToRepay + ",Apr:" + sAPR);

				Assert.assertEquals(getDriver().findElement(By.id("TotalInterestHomeCalcText")).getText(), formattedInterest);
				Assert.assertEquals(getDriver().findElement(By.id("RepaymentAmountHomeCalcText")).getText(), formattedRepayment);
				Assert.assertEquals(getDriver().findElement(By.id("TotalAmountHomeCalcText")).getText(), formattedTAP);

				// take screenshot
				gcb.takeIncrementScreenshot();

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (SQLStmt != null) {
				try {
					SQLStmt.close();
					gcb.DBDisconnectTESTSHED();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	protected void waitForStaleThenActiveElement(By by) {
		WebDriverWait wait = new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT);

		try {
			// search causes element to be stale
			wait.until(ExpectedConditions.stalenessOf(getDriver().findElement(by)));
		} catch (TimeoutException e) {
			log.warn("Element " + by.toString() + " did not become stale");
		}

		try {
			// wait for element to be available again
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
		} catch (TimeoutException e) {
			log.warn("Element " + by.toString() + " did not become active again");
		}
	}

	private void selectOption(Select dropdown, String optionValue) {
		boolean found = false;
		for (WebElement option : dropdown.getOptions()) {
			if (option.getAttribute("value").equals(optionValue)) {
				option.click();
				found = true;
				break;
			}
		}
		if (!found)
			log.warn("Option " + optionValue + " was not found!");
	}

}
