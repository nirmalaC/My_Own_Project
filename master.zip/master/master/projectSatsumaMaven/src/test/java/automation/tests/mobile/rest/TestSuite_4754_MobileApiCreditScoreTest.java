package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;

/*
 * The only tests that can be ran against credit score in an automated way are new applications, as aging is required for maturity or arrears changes to the loans.
 */
public class TestSuite_4754_MobileApiCreditScoreTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	@Test
	public void testCase_31583_creditScoreNewAgreement() throws Exception {
		satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given()
				.contentType("application/x-www-form-urlencoded")
				.log()
				.all()
				.header("platform", PLATFORM)
				.header("appVersionNumber", APP_VERSION_NO)
				.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT")
				.param("grant_type", "password")
				.param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress())
				.param("password", encodedPassword)
				.when()
				.post(TOKEN_URL)
				.then()
				.log()
				.all()
				.body("token_type", equalTo("bearer"))
				.statusCode(200)
				.extract()
				.response()
				.asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Active");
	}

	@Test
	public void testCase_32750_creditScorePaidUpAgreement() throws Exception {
		satsumaCustomer = addNewPaidUpAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEEligibleOffer(true, 1000d);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount").toString(), "1000.0");
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "NotActive");
	}

	@Test
	public void testCase_32097_creditScoreNullReferredAgreement() throws Exception {
		satsumaCustomer = addNewReferredAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Pending");
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("CreditScore"), null);
	}

}
