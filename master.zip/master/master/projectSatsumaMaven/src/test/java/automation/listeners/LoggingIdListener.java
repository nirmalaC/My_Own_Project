package automation.listeners;

import org.slf4j.MDC;
import org.testng.ITestContext;
import org.testng.TestListenerAdapter;

public class LoggingIdListener extends TestListenerAdapter {

	@Override
	public void onStart(ITestContext testContext) {
		MDC.put("testid", String.format("%010d", testContext.hashCode()));
	}
}
