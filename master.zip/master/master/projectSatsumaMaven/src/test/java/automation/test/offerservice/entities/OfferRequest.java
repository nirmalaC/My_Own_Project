package automation.test.offerservice.entities;


public class OfferRequest {
	private OfferParty OfferParty;

	private OfferProducts[] OfferProducts;

	public OfferParty getOfferParty() {
		return OfferParty;
	}

	public void setOfferParty(OfferParty OfferParty) {
		this.OfferParty = OfferParty;
	}

	public OfferProducts[] getOfferProducts() {
		return OfferProducts;
	}

	public void setOfferProducts(OfferProducts[] OfferProducts) {
		this.OfferProducts = OfferProducts;
	}

	@Override
	public String toString() {
		return "ClassPojo [OfferParty = " + OfferParty + ", OfferProducts = " + OfferProducts + "]";
	}
}