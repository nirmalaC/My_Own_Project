package automation.test.offerservice.entities;

public class OfferProducts {

	public OfferProducts() {

	}

	public OfferProducts(boolean hasOffer, double lendingAgreementBalance, boolean isEligibleForLending, String lendingCompletedDate, String id, String source, int offerProductName, int riskScore,
			int lendingMinAmount, double lendingReducedInstalment, String createdDateTime, int refinanceCount, double lendingContraSettlementAmount, String matchKey, String $type,
			Double lendingMaxAmount, int lendingMaxTerm) {
		super();
		this.$type = $type;
		HasOffer = hasOffer;
		LendingAgreementBalance = lendingAgreementBalance;
		IsEligibleForLending = isEligibleForLending;
		LendingCompletedDate = lendingCompletedDate;
		this.id = id;
		Source = source;
		OfferProductName = offerProductName;
		RiskScore = riskScore;
		LendingMinAmount = lendingMinAmount;
		LendingReducedInstalment = lendingReducedInstalment;
		CreatedDateTime = createdDateTime;
		RefinanceCount = refinanceCount;
		LendingContraSettlementAmount = lendingContraSettlementAmount;
		MatchKey = matchKey;
		LendingMaxAmount = lendingMaxAmount;
		LendingMaxTerm = lendingMaxTerm;
	}

	private String $type;

	private boolean HasOffer;

	private double LendingAgreementBalance;

	private boolean IsEligibleForLending;

	private String LendingCompletedDate;

	private String id;

	private String Source;

	private String Sourcev2;

	private int OfferProductName;

	private int RiskScore;

	private int LendingMinAmount;

	private double LendingReducedInstalment;

	private String CreatedDateTime;

	private int RefinanceCount;

	private double LendingContraSettlementAmount;

	private String MatchKey;

	private Double LendingMaxAmount;

	private int LendingMaxTerm;

	private int EligibilityReasonCode;

	public int getEligibilityReasonCode() {
		return EligibilityReasonCode;
	}

	public void setEligibilityReasonCode(int eligibilityReasonCode) {
		EligibilityReasonCode = eligibilityReasonCode;
	}

	public String getSourcev2() {
		return Sourcev2;
	}

	public void setSourcev2(String sourcev2) {
		Sourcev2 = sourcev2;
	}

	public boolean getHasOffer() {
		return HasOffer;
	}

	public void setHasOffer(boolean HasOffer) {
		this.HasOffer = HasOffer;
	}

	public double getLendingAgreementBalance() {
		return LendingAgreementBalance;
	}

	public void setLendingAgreementBalance(double LendingAgreementBalance) {
		this.LendingAgreementBalance = LendingAgreementBalance;
	}

	public boolean getIsEligibleForLending() {
		return IsEligibleForLending;
	}

	public void setIsEligibleForLending(boolean IsEligibleForLending) {
		this.IsEligibleForLending = IsEligibleForLending;
	}

	public String getLendingCompletedDate() {
		return LendingCompletedDate;
	}

	public void setLendingCompletedDate(String LendingCompletedDate) {
		this.LendingCompletedDate = LendingCompletedDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSource() {
		return Source;
	}

	public void setSource(String Source) {
		this.Source = Source;
	}

	public int getOfferProductName() {
		return OfferProductName;
	}

	public void setOfferProductName(int OfferProductName) {
		this.OfferProductName = OfferProductName;
	}

	public int getRiskScore() {
		return RiskScore;
	}

	public void setRiskScore(int RiskScore) {
		this.RiskScore = RiskScore;
	}

	public double getLendingMinAmount() {
		return LendingMinAmount;
	}

	public void setLendingMinAmount(int LendingMinAmount) {
		this.LendingMinAmount = LendingMinAmount;
	}

	public double getLendingReducedInstalment() {
		return LendingReducedInstalment;
	}

	public void setLendingReducedInstalment(double LendingReducedInstalment) {
		this.LendingReducedInstalment = LendingReducedInstalment;
	}

	public String getCreatedDateTime() {
		return CreatedDateTime;
	}

	public void setCreatedDateTime(String CreatedDateTime) {
		this.CreatedDateTime = CreatedDateTime;
	}

	public int getRefinanceCount() {
		return RefinanceCount;
	}

	public void setRefinanceCount(int RefinanceCount) {
		this.RefinanceCount = RefinanceCount;
	}

	public double getLendingContraSettlementAmount() {
		return LendingContraSettlementAmount;
	}

	public void setLendingContraSettlementAmount(double LendingContraSettlementAmount) {
		this.LendingContraSettlementAmount = LendingContraSettlementAmount;
	}

	public String getMatchKey() {
		return MatchKey;
	}

	public void setMatchKey(String MatchKey) {
		this.MatchKey = MatchKey;
	}

	public String get$type() {
		return $type;
	}

	public void set$type(String $type) {
		this.$type = $type;
	}

	public Double getLendingMaxAmount() {
		return LendingMaxAmount;
	}

	public void setLendingMaxAmount(Double LendingMaxAmount) {
		this.LendingMaxAmount = LendingMaxAmount;
	}

	public int getLendingMaxTerm() {
		return LendingMaxTerm;
	}

	public void setLendingMaxTerm(int LendingMaxTerm) {
		this.LendingMaxTerm = LendingMaxTerm;
	}

	@Override
	public String toString() {
		return "ClassPojo [HasOffer = " + HasOffer + ", LendingAgreementBalance = " + LendingAgreementBalance + ", IsEligibleForLending = " + IsEligibleForLending + ", LendingCompletedDate = "
				+ LendingCompletedDate + ", id = " + id + ", Source = " + Source + ", OfferProductName = " + OfferProductName + ", RiskScore = " + RiskScore + ", LendingMinAmount = "
				+ LendingMinAmount + ", LendingReducedInstalment = " + LendingReducedInstalment + ", CreatedDateTime = " + CreatedDateTime + ", RefinanceCount = " + RefinanceCount
				+ ", LendingContraSettlementAmount = " + LendingContraSettlementAmount + ", MatchKey = " + MatchKey + ", $type = " + $type + ", LendingMaxAmount = " + LendingMaxAmount
				+ ", LendingMaxTerm = " + LendingMaxTerm + "]";
	}
}
