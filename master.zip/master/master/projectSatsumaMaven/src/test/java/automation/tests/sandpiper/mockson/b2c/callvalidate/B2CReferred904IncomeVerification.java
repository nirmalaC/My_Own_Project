package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnCallCreditReferralTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CReferred904IncomeVerification extends B2CAllMocksOnCallCreditReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Income Verification";
	private static final String EXPECTED_2ND_PAN_DESC = "Vulnerable";
	private static final String EXPECTED_PAN_CODE = "901";
	private static final String EXPECTED_2ND_PAN_CODE = "904";
	private static final int WEEKLY_APPLICANT_ID = 242;
	private static final int MONTHLY_APPLICANT_ID = 266;

	@Test
	public void testWeekly() throws Exception {
		test904(WEEKLY_APPLICANT_ID);
	}

	@Test
	public void testMonthly() throws Exception {
		test904(MONTHLY_APPLICANT_ID);
	}

	public void test904(int applicantId) throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for a mocked whose's affordability is
		// Applicant income verification
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		gcb.prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		gcb.seedFLEEligibleOffer(true, 1000d, true);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		gcb.prConfirmLVA();

		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Referral
		// ===========================

		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// (Primary reason for referral)
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_PAN_CODE));
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_PAN_DESC));
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_2ND_PAN_CODE));
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_2ND_PAN_DESC));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
