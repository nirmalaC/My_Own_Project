package automation.tests.allmockon.testsuite.b2c.validation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;
import automation.dao.CustomerType;

public class TestCase_13951_PageValidationBankDetails extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database

		gcb.gsPANAgreementNumber = "";

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);
		gcb.prCreateUniquePerson();
		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

	}

	// @Test
	// public void main() throws Exception {
	// test_PageDefaults();
	// test_MandatoryFieldsAstrix();
	// test_MandatoryFieldValidationmessages();
	// test_FieldLengthInvalidCharacters();
	// // Run the following after test_MandatoryFieldValidationmessages
	// test_AvailableOpenMonthOptions();
	// test_AvailableOpenYearOptions();
	//
	// }

	@Test
	public void test_PageDefaults() throws Exception {

		log.info("INFO: test_PageDefaults");

		// Account Holder - Default is blank
		Assert.assertEquals(getDriver().findElement(By.id("AccountHolder")).getText(), "");

		// Sort Code - Default is blank
		Assert.assertEquals(getDriver().findElement(By.id("SortCode_Part1")).getText(), "");
		Assert.assertEquals(getDriver().findElement(By.id("SortCode_Part2")).getText(), "");
		Assert.assertEquals(getDriver().findElement(By.id("SortCode_Part3")).getText(), "");

		// Account Number - Default is blank
		Assert.assertEquals(getDriver().findElement(By.id("AccountNumber")).getText(), "");

		// When did you open your account - Default is MM YYYY

		// not checking defaults as S13 default is not selecting these options
		// by default
		// timehack being used for testing is changing the default selection.
		// Select dropdown = new
		// Select(getDriver().findElement(byDdAccountOpenMonth));
		// Assert.assertEquals("-- Month --",
		// dropdown.getFirstSelectedOption().getText());
		// dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		// Assert.assertEquals("-- Year --",
		// dropdown.getFirstSelectedOption().getText());

		// ** End Of Test **/
	}

	@Test
	public void test_MandatoryFieldsAstrix() {

		log.info("INFO: test_MandatoryFieldsAsterix");

		Assert.assertEquals("Your name*", getDriver().findElement(By.xpath("//label[@for='AccountHolder']")).getText());
		Assert.assertEquals("Your sort code*", getDriver().findElement(By.xpath("//label[@for='SortCode']")).getText());
		Assert.assertEquals("Your account number*", getDriver().findElement(By.xpath("//label[@for='AccountNumber']")).getText());
		Assert.assertEquals("When did you open your bank account?*", getDriver().findElement(byLblAccountOpened).getText());

		// ** End Of Test **
	}

	@Test
	public void test_MandatoryFieldValidationmessages() {

		log.info("INFO: test_MandatoryFieldValidationmessages");

		// click on the Next:Payment Details

		Select dropdown = new Select(getDriver().findElement(byDdAccountOpenMonth));
		dropdown.selectByVisibleText("-- Month --");
		dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		dropdown.selectByVisibleText("-- Year --");

		// driver.findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);
		gcb.waitForVisibilityOfElement(By.xpath("//span[@for='AccountHolder']"));

		// Check validation message for Account Holder
		Assert.assertEquals("Please enter the name of the account holder", getDriver().findElement(By.xpath("//span[@for='AccountHolder']")).getText());

		// Check validation message for Sort Code
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());

		// Check validation message for Account Number
		Assert.assertEquals("Please enter your account number", getDriver().findElement(By.xpath("//span[@for='AccountNumber']")).getText());

		// changed in S3 to a single message
		// Check validation message for account open date
		// Assert.assertEquals("Month Opened is required.",
		// getDriver().findElement(By.xpath("//span[@for='AccountOpenMonth']")).getText());
		// Assert.assertEquals("Year Opened is required.",
		// getDriver().findElement(By.xpath("//span[@for='AccountOpenYear']")).getText());

		Assert.assertEquals("Account must have already been opened", getDriver().findElement(By.xpath("//span[@for='DisplayAccountOpened_Year']")).getText());

		// ** End Of Test **
	}

	@Test
	public void test_FieldLengthInvalidCharacters() {

		log.info("INFO: test_FieldLengthInvalidCharacters");

		// Where field lengths on certain fields are breached or where invalid
		// characters maintained
		// a validation message is raised

		// Account Holder

		// Added Test for invalid characters
		getDriver().findElement(By.id("AccountHolder")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890123456789012345678901234567890@#?<>&$£1");
		getDriver().findElement(By.id("AccountHolder")).sendKeys(Keys.TAB);
		Assert.assertEquals("The account holder contains invalid characters", getDriver().findElement(bySpanAccountHolder).getText());
		getDriver().findElement(By.id("AccountHolder")).clear();

		// Reject if more than 100 characters in length
		// getDriver().findElement(By.id("AccountHolder")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890123456789012345678901234567890@#?<>&$£1");
		getDriver().findElement(By.id("AccountHolder")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy");
		getDriver().findElement(By.id("AccountHolder")).sendKeys(Keys.TAB);

		Assert.assertEquals("Your name must be a maximum length of 50 characters", getDriver().findElement(bySpanAccountHolder).getText());
		// Assert.assertEquals("The account holder contains invalid characters",
		// getDriver().findElement(By.xpath("//span[@for='AccountHolder']")).getText());
		getDriver().findElement(By.id("AccountHolder")).clear();

		// Accept if less than 50 characters in length
		// getDriver().findElement(By.id("AccountHolder")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890123456789012345678901234567890@#?<>&$£");
		getDriver().findElement(By.id("AccountHolder")).sendKeys("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
		getDriver().findElement(By.id("AccountHolder")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(bySpanAccountHolder).size());
		getDriver().findElement(By.id("AccountHolder")).clear();

		// Following are only server side validation

		// Reject Sort Code if part1 not filled in
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part2 not filled in
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part3 not filled in
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part1 filled in with single digit
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("1");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part2 filled in with single digit
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("2");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part3 filled in with single digit
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("3");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part1 is alphanumeric
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("o1");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part2 is alphanumeric
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("O2");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("03");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject Sort Code if part3 is alphanumeric
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys("01");
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys("02");
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys("3O");
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Each part of the sort code should be 2 numbers", getDriver().findElement(By.xpath("//span[@for='SortCode_Part3']")).getText());
		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Reject alphabetic Account Number
		getDriver().findElement(By.id("AccountNumber")).sendKeys("AbCdEfgH");
		getDriver().findElement(By.id("AccountNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your account number must be 8 numbers", getDriver().findElement(By.xpath("//span[@for='AccountNumber']")).getText());
		getDriver().findElement(By.id("AccountNumber")).clear();

		// Reject alphanumeric Account Number
		getDriver().findElement(By.id("AccountNumber")).sendKeys("OOO12345");
		getDriver().findElement(By.id("AccountNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your account number must be 8 numbers", getDriver().findElement(By.xpath("//span[@for='AccountNumber']")).getText());
		getDriver().findElement(By.id("AccountNumber")).clear();

		// Reject whitespace split Account Number
		getDriver().findElement(By.id("AccountNumber")).sendKeys("000 1234");
		getDriver().findElement(By.id("AccountNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your account number must be 8 numbers", getDriver().findElement(By.xpath("//span[@for='AccountNumber']")).getText());
		getDriver().findElement(By.id("AccountNumber")).clear();

		// Accept Leading spaced Account Holder
		getDriver().findElement(By.id("AccountHolder")).sendKeys(" A N Other");
		getDriver().findElement(By.id("AccountHolder")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(bySpanAccountHolder).size());
		getDriver().findElement(By.id("AccountHolder")).clear();

		// Accept Trailing spaced Account Holder
		getDriver().findElement(By.id("AccountHolder")).sendKeys("A N Other ");
		getDriver().findElement(By.id("AccountHolder")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(bySpanAccountHolder).size());
		getDriver().findElement(By.id("AccountHolder")).clear();

		// Change in S3 this is no longer valid
		// // Accept Leading spaced Account Number
		// getDriver().findElement(By.id("AccountNumber")).sendKeys(" 00012345");
		// getDriver().findElement(By.id("AccountNumber")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='AccountNumber']")).size());
		// getDriver().findElement(By.id("AccountNumber")).clear();
		//
		// // Accept Trailing spaced Account Number
		// getDriver().findElement(By.id("AccountNumber")).sendKeys("00012345 ");
		// getDriver().findElement(By.id("AccountNumber")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='AccountNumber']")).size());
		// getDriver().findElement(By.id("AccountNumber")).clear();

		// ** End Of Test **
	}

	@Test
	public void test_AvailableOpenMonthOptions() {

		log.info("INFO: test_AvailableOpenMonthOptions");

		// Open account month
		Select dropdown = new Select(getDriver().findElement(byDdAccountOpenMonth));
		dropdown.selectByVisibleText("-- Month --");
		dropdown.selectByVisibleText("January");
		dropdown.selectByVisibleText("February");
		dropdown.selectByVisibleText("March");
		dropdown.selectByVisibleText("April");
		dropdown.selectByVisibleText("May");
		dropdown.selectByVisibleText("June");
		dropdown.selectByVisibleText("July");
		dropdown.selectByVisibleText("August");
		dropdown.selectByVisibleText("September");
		dropdown.selectByVisibleText("October");
		dropdown.selectByVisibleText("November");
		dropdown.selectByVisibleText("December");

		// Validate no more items listed than above - Expect 13 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(13, l.size());

		// ** End of Test **
	}

	@Test
	public void test_AvailableOpenYearOptions() {

		log.info("INFO: test_AvailableOpenYearOptions");

		// Open account year
		Select dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		dropdown.selectByVisibleText("-- Year --");
		dropdown.selectByVisibleText("2016");
		dropdown.selectByVisibleText("2000");
		dropdown.selectByVisibleText("1993");
		dropdown.selectByVisibleText("1966");
		dropdown.selectByVisibleText("1963");

		// Validate no more items listed than above - Expect 101 items
		List<WebElement> l = dropdown.getOptions();
		// now 102 options
		Assert.assertEquals(102, l.size());

		// ** End Of Test **
	}

}
