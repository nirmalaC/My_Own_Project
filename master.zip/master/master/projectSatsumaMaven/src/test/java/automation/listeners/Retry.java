package automation.listeners;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private Map<String, Integer> retryCountsPerParameter = new HashMap<String, Integer>();
	private int retryCount = 0;
	private int maxRetryCount = 2; // retry a failed test 2 additional times
	private boolean paramTest = false;

	@Override
	public boolean retry(ITestResult result) {
		// if downsell test we need to check the name to determine if count
		// should de
		if (result.getParameters().length > 0) {
			String surname = result.getParameters()[0].toString();
			log.debug("found surname parameter " + surname);
			paramTest = true;
			// if surname is already in there update it
			if (retryCountsPerParameter.containsKey(surname)) {
				// if the counter is already over 2 then do not retry
				if (retryCountsPerParameter.get(surname) < maxRetryCount) {
					retryCountsPerParameter.put(surname, retryCountsPerParameter.get(surname) + 1);
					log.debug("retrying parameter test with surname " + surname + " remaining retries: " + (maxRetryCount - retryCountsPerParameter.get(surname)));
					return true;
				} else {
					log.debug("Not retrying, retryCount: " + retryCountsPerParameter.get(surname) + " maxRetryCount: " + maxRetryCount);
					return false;
				}
			}
			// if not put the first count in there
			else {
				retryCountsPerParameter.put(surname, 1);
				log.debug("retrying parameter test with surname " + surname + " remaining retries: " + (maxRetryCount - retryCountsPerParameter.get(surname)));
				return true;
			}
		} else {
			if (retryCount < maxRetryCount) {
				retryCount++;
				log.debug("Retrying test, remaining retries: " + (maxRetryCount - retryCount));
				return true;
			} else {
				log.debug("Not retrying, retryCount: " + retryCount + " maxRetryCount: " + maxRetryCount);
				return false;
			}
		}
	}

	// public boolean isRetryAvailable() {
	// return (retryCount < maxRetryCount);
	// }

	public boolean isRetryAvailable(ITestResult result) {
		// if downsell test we need to check the name to determine if count
		// should de
		if (result.getParameters().length > 0) {
			String surname = result.getParameters()[0].toString();
			if (retryCountsPerParameter.containsKey(surname)) {
				// if the counter is already over 2 then do not retry
				return (retryCountsPerParameter.get(surname) < maxRetryCount);
			} else {
				log.error("Couldn't find retry for test for customer with surname " + surname);
				return false;
			}
		} else {
			return (retryCount < maxRetryCount);
		}
	}

	public boolean hasTestBeenRetried(ITestResult result) {
		// if downsell test we need to check the name to determine if count
		// should de
		if (result.getParameters().length > 0) {
			String surname = result.getParameters()[0].toString();
			if (retryCountsPerParameter.containsKey(surname)) {
				// if the counter is already over 2 then do not retry
				return (retryCountsPerParameter.get(surname) != 0);
			} else {
				log.error("Couldn't find retry for test for customer with surname " + surname);
				return false;
			}
		} else {
			return (retryCount != 0);
		}

	}
}