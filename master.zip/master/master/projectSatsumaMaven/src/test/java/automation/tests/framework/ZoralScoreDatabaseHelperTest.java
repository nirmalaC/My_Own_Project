package automation.tests.framework;

import org.testng.annotations.Test;

import automation.tools.ZoralScoreDatabaseHelper;

public class ZoralScoreDatabaseHelperTest {
	//
	// @Test
	// public void test() {
	// ZoralScoreDatabaseHelper.getWorkflowGlobalVariablesFromDecisionRef(SatsumaApplicationDatabaseHelper.getDecisionReferenceFromAgreement("800000040200"));
	// }
	@Test
	public void test() {
		ZoralScoreDatabaseHelper.getRetuneScoreFromDecisionRef("TST7DecisionEngineStoragev13", "396a3900-9b76-e611-a457-005056ae561b");
		ZoralScoreDatabaseHelper.getNonPayerScoreFromDecisionRef("TST7DecisionEngineStoragev13", "396a3900-9b76-e611-a457-005056ae561b");
	}
}
