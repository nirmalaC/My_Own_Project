package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23893_AcceptActiveCustomerRepricesTerm34Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice34weeks1020() throws Exception {
		existingCustomerAccepts("1020", "34", "Weekly", "680", 133);
	}

	@Test
	public void test_Reprice34weeks1120() throws Exception {
		existingCustomerAccepts("1120", "34", "Weekly", "880", 133);
	}

	@Test
	public void test_Reprice34weeks1000() throws Exception {
		existingCustomerAccepts("1000", "34", "Weekly", "1000", 133);
	}

}
