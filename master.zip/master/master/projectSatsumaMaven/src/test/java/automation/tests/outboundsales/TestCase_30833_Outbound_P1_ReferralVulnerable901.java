package automation.tests.outboundsales;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnOutboundTest;
import automation.dao.CustomerType;
import automation.tools.OutboundSalesHelper;

public class TestCase_30833_Outbound_P1_ReferralVulnerable901 extends AllMocksOnOutboundTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(171);

		gcb.prCreateUniquePerson();
		gcb.setRandomPostcode();
		gcb.prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// seed vulnerble offer
		gcb.seedFLEEligibleOffer(false, 500d, true);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// CV - 08.03.2016 - now includes the Change Loan Amount screen despite
		// the fact that loan requested is within limits

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."), "check LVA page header says 'great news...'");

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		outbound.prAssertOnPageCompletionIDResult12(gsSatsumaSiteUrl);

		// verify vulnerable in PAN

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 901 - Vulnerable Customer is
		// set.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Suspected Vulnerable (NB)");
		Assert.assertTrue(getDriver().getPageSource().contains("Vulnerable Customer"));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
