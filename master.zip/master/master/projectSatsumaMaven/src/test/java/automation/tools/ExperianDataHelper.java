package automation.tools;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import automation.dao.SatsumaExperianAgreement;
import automation.satsuma.pages.CookBook;

/*
 * This class will simply help in extracting Experian (transient data which changes month to month) from the testshed db and deserializes it into a customer object
 * 
 */

public class ExperianDataHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public static final String SYSTEM_LOGGING_DB_CONNECTION_STRING = "jdbc:sqlserver://IT500764;instance=SQLEXPRESS;Databasename=DBTestShed;username=sa;password=P@ssw0rd123";

	public static SatsumaExperianAgreement getSatsumaExperianAgreement(String forename, String surname) {
		ResultSet rs = null;
		CallableStatement statement = null;
		Connection conn = null;
		SatsumaExperianAgreement satsumaAgreement = null;

		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);

			statement = conn.prepareCall("{call [dbo].[GetExperianCustomerProfile] (?,?)}");
			statement.setString("forename", forename);
			statement.setString("surname", surname);

			rs = statement.executeQuery();

			if (rs.next()) {

				satsumaAgreement = new SatsumaExperianAgreement(rs.getString("DateOfBirth"), rs.getString("Title"), rs.getString("FirstName"), rs.getString("LastName"), rs.getString("FlatNumber"),
						rs.getString("HouseNumber"), rs.getString("HouseName"), rs.getString("Street"), rs.getString("Town"), rs.getString("County"), rs.getString("Postcode"),
						rs.getString("MaritalStatus"), rs.getString("Income"), rs.getString("IncomeFrequency"), rs.getString("MonthlyOutgoings"), rs.getString("SourceOfIncome"),
						rs.getString("AccomodationStatus"), rs.getString("Age"), rs.getString("Dependents"), rs.getString("MonthlyHousingCosts"), rs.getString("LoanPurpose"),
						rs.getString("MarketingCompany"), rs.getString("Loans"), rs.getString("PreferredRepaymentDayOfTheWeek"), rs.getString("PreferredRepaymentDayOfTheWeekId"),
						rs.getString("CurrentMovingInDate"), rs.getString("DateBankAccountOpened"), rs.getString("MonthlyLoanRepayments"), rs.getString("CreditCards"), rs.getString("ContactByMail"),
						rs.getString("NiNumber"), rs.getString("ContactByPhone"), rs.getString("ContactByPost"));
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return satsumaAgreement;
	}

	public static String getExpectedRTScore(String forename, String surname, String term, String loanAmount) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String rtScore = null;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			statement = conn.createStatement();
			String queryString = "select [B2cReTunedScore] from [DBTestShed].[dbo].[Monthly_" + term + "] where FirstName='" + forename + "' and LastName='" + surname + "' and [RequestedLoanValue]="
					+ loanAmount;

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				rtScore = rs.getString(1);
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(rtScore);
		return rtScore;
	}

	public static String getExpectedNPScore(String forename, String surname, String term, String loanAmount) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String npScore = null;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			statement = conn.createStatement();
			String queryString = "select [B2cNonPayerScore] from [DBTestShed].[dbo].[Monthly_" + term + "] where FirstName='" + forename + "' and LastName='" + surname + "' and [RequestedLoanValue]="
					+ loanAmount;

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				npScore = rs.getString(1);
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		// log.debug(npScore);
		return npScore;
	}

	public static void convertToCookbook(SatsumaExperianAgreement agreement, CookBook cb) throws ParseException {
		// map all the agreement parameters to the cookbook
		cb.gsFirstname = agreement.getFirstName();
		cb.gsSurname = agreement.getLastName();
		if ((agreement.getTitle() == null) || (agreement.getTitle().equals(""))) {
			cb.gsTitle = "Mr";
		} else {
			cb.gsTitle = "M" + agreement.getTitle().substring(1).toLowerCase();
		}
		cb.gsStreet = agreement.getStreet();
		cb.gsTownCity = agreement.getTown();
		cb.gsCounty = agreement.getCounty();
		cb.gsCountry = "UK";
		cb.gsPostcode = agreement.getPostcode().trim();
		cb.gsCurrentHouseMovedInDate = cb.formatDate(agreement.getCurrentMovingInDate(), "yyyy-MM-dd hh:mm:ss");

		cb.gsBankAccountOpenDate = agreement.getDateBankAccountOpened();
		cb.gsEmploymentStatus = agreement.getSourceOfIncome();
		cb.gsSourceOfIncome = agreement.getSourceOfIncome();
		cb.gsMaritalStatus = agreement.getMaritalStatus();
		cb.gsHousingCosts = agreement.getMonthlyHousingCosts();
		cb.gsResidentialStatus = agreement.getAccomodationStatus();
		cb.gsNumberOfDependants = agreement.getDependents();
		cb.gsDOB = cb.formatDate(agreement.getDateOfBirth(), "yyyy-MM-dd hh:mm:ss");
		cb.gsIncome = agreement.getIncome();
		cb.gsMonthlyLoanRepayments = agreement.getMonthlyLoanRepayments();
		cb.gsMonthlyOtherOutgoings = agreement.getMonthlyOutgoings();
		cb.gsLoanPurpose = agreement.getLoanPurpose();
		cb.gsIncomeFrequency = agreement.getIncomeFrequency();
		cb.gsPreferredPaymentDow = agreement.getPreferredRepaymentDayOfTheWeek();
		cb.gsNumberOfDependants = agreement.getDependents();

		cb.gsMarketingOptInPhone = agreement.getContactByPhone();
		cb.gsMarketingOptInPost = agreement.getContactByPost();
		cb.gsMarketingOptInEmail = agreement.getContactByMail();
		cb.gsMarketingOptInSMS = agreement.getContactByPhone();
		cb.gsBuildingName = agreement.getHouseName();
		cb.gsBuildingNumber = agreement.getHouseNumber();
		cb.gsHasCreditCards = agreement.getCreditCards();
		cb.gsHasExistingLoans = agreement.getLoans();
		cb.gsBankAccountOpenDate = cb.formatDate(agreement.getDateBankAccountOpened(), "yyyy-MM-dd hh:mm:ss");

		// set the other ones which are not set by the agreement e.g. loan
		// amount, loan term
		cb.gsRequestedLoanAmount = "100";
		cb.gsRequestedTerm = "13";
		cb.gsEmailAddress = agreement.getLastName() + "@email.com";
		cb.gsMobileNumber = "07999999999";
		cb.gsIncomePaymentMethod = "Direct Into Bank Account";
		cb.gsConsentToCreditSearch = "true";
		cb.gsBankAccountName = "test name";
		cb.gsBankAccountNumber = "11111111";
		cb.gsBankSortcode = "111111";

		cb.gsCreditCardCVS = "123";
		cb.gsCreditCardExpiryDate = "01/2020";
		cb.gsCreditCardNumber = "5454545454545454";
		cb.gsCreditCardType = "Mastercard";

	}
}
