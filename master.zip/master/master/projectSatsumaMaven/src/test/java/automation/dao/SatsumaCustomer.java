package automation.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class SatsumaCustomer {
	private String forename;
	private String surname;
	private String dob;
	private String personId;
	private String postcode;
	private String emailAddress;
	private List<String> agreements;

	public List<String> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<String> agreements) {
		this.agreements = agreements;
	}

	public void addAgreements(String agreementNumber) {
		agreements.add(agreementNumber);
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public SatsumaCustomer(String forename, String surname, String dob, String personId, String postcode, String emailAddress, List<String> agreements) {
		this.forename = forename;
		this.surname = surname;
		this.dob = dob;
		this.personId = personId;
		this.postcode = postcode;
		this.emailAddress = emailAddress;
		this.agreements = agreements;
	}

	@Override
	public String toString() {
		return "SatsumaCustomer [forename=" + forename + ", surname=" + surname + ", dob=" + dob + ", personId=" + personId + ", postcode=" + postcode + ", email=" + emailAddress + "]";
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getDob() throws ParseException {
		SimpleDateFormat fromFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat toFormat = new SimpleDateFormat("yyyy-MM-dd");
		return toFormat.format(fromFormat.parse(dob));
	}

	public String getDob(String returnformat) throws ParseException {
		SimpleDateFormat fromFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat toFormat = new SimpleDateFormat(returnformat);
		return toFormat.format(fromFormat.parse(dob));
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

}
