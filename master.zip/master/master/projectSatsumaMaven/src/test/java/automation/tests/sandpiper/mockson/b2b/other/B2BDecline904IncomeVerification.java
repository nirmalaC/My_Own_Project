package automation.tests.sandpiper.mockson.b2b.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.satsuma.pages.ApplicationType;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

public class B2BDecline904IncomeVerification extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 398;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "904";

	@Test
	public void b2BNBDeclineWeekly() throws Exception {
		test904(WEEKLY_APPLICANT_ID);
	}

	private void test904(int applicantId) throws Exception {

		gcb.prGetApplicantProfile(applicantId);

		gcb.seedFLEEligibleOffer(false, 2000d, true);

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");

	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
