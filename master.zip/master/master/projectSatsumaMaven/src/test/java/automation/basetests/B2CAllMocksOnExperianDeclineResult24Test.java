package automation.basetests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CAllMocksOnExperianDeclineResult24Test extends MySatsumaSliderBarTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public void b2CNewBusinessHardDecline(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();
		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		gcb.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on "Applicant Has IVA" reason
		// is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 203 - Applicant Has IVA.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
		// "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode));
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	public void b2CFurtherLendingHardDecline(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {

		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();
		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		gcb.prConfirmLVA();

		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		gcb.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================
		//
		// gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on "Applicant Has IVA" reason
		// is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 203 - Applicant Has IVA.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
		// "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode));
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

	public void b2CLoginFurtherLendingHardDecline(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {
		// seed and register an agreement
		seedSpecifiedRegisterLogin(100f, "52", "Weekly", true, applicantId);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 0f)));

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// login.assertOnPageFL(gsSatsumaSiteUrl,
		// gcb.formatCurrencyToDisplay(String.valueOf(Float.toString(gcb.calcEligibleAmount(100f,
		// 71.58f)))));

		login.selectLoanAndTerm(gcb.gsRequestedLoanAmount, gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow);

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDPNoComma(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow,Boolean.parseBoolean(gcb.gsMarketingOptInEmail),Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		login.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================
		//
		// gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found.");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on "Applicant Has IVA" reason
		// is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
		// "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode), "check for code " + expectedPanCode);
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription), "check for text " + expectedDescription);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

}
