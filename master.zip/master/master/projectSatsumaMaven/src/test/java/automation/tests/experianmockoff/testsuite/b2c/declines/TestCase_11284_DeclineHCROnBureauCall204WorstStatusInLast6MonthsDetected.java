package automation.tests.experianmockoff.testsuite.b2c.declines;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.ExperianMockOffTest;
import automation.dao.CustomerType;

public class TestCase_11284_DeclineHCROnBureauCall204WorstStatusInLast6MonthsDetected extends ExperianMockOffTest {

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("header-apply-link")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

	}

	@AfterMethod
	public void tearDown() throws Exception {
	}

	@Test
	public void test_IsWorstStatus6MonthsApplicantReferredToHomeCredit() throws Exception {

		// Data Preparation
		// ================

		// Get a Experian application profile for Bureau result 204 - Worst
		// Status in last 6 months detected
		gcb.prGetApplicantProfile(27);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Home Credit page
		// ================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found.");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "Invalid: Worst Status in last 6 months" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 204 - Experian Worst Status in
		// last 6 months Detected.
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		assertTrue(getDriver().getPageSource().contains("Invalid: Worst Status in last 6 months"));

		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("title")));
		dropdown.selectByVisibleText(gcb.gsTitle);

		String tmpStr = getDriver().findElement(By.id("surname")).getAttribute("value");
		if (!(tmpStr.contains("AutoDel"))) {
			getDriver().findElement(By.id("surname")).clear();
			getDriver().findElement(By.id("surname")).sendKeys("AutoDel" + tmpStr);
		}
		getDriver().findElement(By.id("PanLinkSubmit_5")).click();

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}