package automation.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OutboundSalesHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public static final String SYSTEM_LOGGING_DB_CONNECTION_STRING = "jdbc:sqlserver://HODEVGLODB1;databaseName=SystemLogging;integratedSecurity=true;";

	// look in system logging db last 5 mins
	protected static String getMessageFromDb(String server, String email) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String message = null;
		try {
			Date now = new Date();

			Calendar cal = Calendar.getInstance();
			cal.setTime(now);
			cal.setTimeZone(TimeZone.getTimeZone("UTC"));
			cal.add(Calendar.MINUTE, -5);
			Date fiveMinsAgo = cal.getTime();

			// 2016-07-06 13:21:13.7601006
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.000");
			// must use UTC time as database is on UTC
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			log.debug("connected to database looking for app db: " + server);
			statement = conn.createStatement();
			String queryString = "SELECT [Message] FROM Logs WHERE LogRemoteServerName = '" + server + "' and LoggerName ='Pfg.BusinessLogic.OnlineLoans.Email.EmailService' and LogRemoteCreatedDateTime > '" + sdf.format(fiveMinsAgo) + "' and Message like '%" + email
					+ "%' ORDER BY [LogRemoteCreatedDateTime] DESC";

			log.debug(queryString);
			int retries = 2;
			while (true) {

				rs = statement.executeQuery(queryString);

				if (rs.next()) {
					message = rs.getString(1);
					break;
				} else {
					retries--;
					if (retries == 0) {
						log.error("No results found, not retrying, retries: " + retries);
						break;
					}
					log.error("No results found, trying again, retries: " + retries);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		// log.debug(message);
		return message;
	}

	public static String extractUrlFromEmail(String satsumaSiteServer, String satsumaAppServer, String email) {
		String messageText = getMessageFromDb(satsumaAppServer, email);
		if (messageText != null) {
			final String pattern = "key=(.*?)\"";
			// log.debug("pattern: " + pattern);
			Pattern r = Pattern.compile(pattern);
			Matcher m = r.matcher(messageText);

			if (m.find()) {
				String outboundUrl = "http://" + satsumaSiteServer + "/salescustomer?key=" + m.group(1);

				log.debug("Found the outbound url " + outboundUrl);
				return outboundUrl;
			} else {
				log.error("Couldn't find customer link");
				return null;
			}
		} else {
			log.error("Error no message found in database");
			return null;

		}
	}
}
