package automation.tests.sandpiper.mockson.b2c.experian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnExperianDeclineTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline207DMP extends B2CAllMocksOnExperianDeclineTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String DMP_DESC = "DMP rule";
	private static final String DMP_CODE = "207";
	private static final int WEEKLY_APPLICANT_ID = 221;
	private static final int MONTHLY_APPLICANT_ID = 222;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		b2CNewBusinessHardDecline(WEEKLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		b2CNewBusinessHardDecline(MONTHLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	@Test
	public void testB2cFlDeclineWeekly() throws Exception {
		b2CFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	@Test
	public void testB2cFlDeclineMonthly() throws Exception {
		b2CFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	@Test
	public void testB2cLoginDeclineWeekly() throws Exception {
		b2CLoginFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	@Test
	public void testB2cLoginDeclineMonthly() throws Exception {
		b2CLoginFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, DMP_CODE, DMP_DESC);
	}

	// @Test
	// public void testB2cNbDeclineWeekly() throws Exception {
	//
	// // Data Preparation
	// // ================
	// log.info("WARNING: This Experian test subject is mocked and requires deployment of mocked response XML file max_dmprule.xml in Experian SCEMs mock on the app box");
	//
	// // Get a Experian application profile for Bureau result 207 - Applicant
	// gcb.prGetApplicantProfile(221);
	// gcb.setRandomEmail();
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	//
	// // // Home Credit page
	// // // ================
	// //
	// // gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Applicant Has IVA" reason
	// // is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 203 - Applicant Has IVA.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));
	// Assert.assertTrue(getDriver().getPageSource().contains("207"));
	//
	// // gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }
	//
	// @Test
	// public void testB2cNbDeclineMonthly() throws Exception {
	// // Data Preparation
	// // ================
	// log.info("WARNING: This Experian test subject is mocked and requires deployment of mocked response XML file james_bankruptcy.xml in Experian SCEMs mock on the app box");
	//
	// // Get a Experian application profile for Bureau result 202 - Applicant
	// // james bankruptcy
	// gcb.prGetApplicantProfile(222);
	//
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	//
	// // // Home Credit page
	// // // ================
	// //
	// // gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Applicant Has IVA" reason
	// // is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 203 - Applicant Has IVA.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));
	// Assert.assertTrue(getDriver().getPageSource().contains("207"));
	//
	// // gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }
	//
	// @Test
	// public void testB2cFlDeclineMonthly() throws Exception {
	// }
	//
	// @Test
	// public void testB2cFlDeclineWeekly() throws Exception {
	//
	// // Data Preparation
	// // ================
	// log.info("WARNING: This Experian test subject is mocked and requires deployment of mocked response XML file ricky_iva.xml in Experian SCEMs mock on the app box");
	//
	// // Get a Experian application profile for Bureau result 203 - Applicant
	// // Has IVA = ricky iva
	// gcb.prGetApplicantProfile(221);
	//
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);
	//
	// gcb.prConfirmLVA();
	//
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	//
	// // // Home Credit page
	// // // ================
	// //
	// // gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Applicant Has IVA" reason
	// // is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 203 - Applicant Has IVA.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));
	// Assert.assertTrue(getDriver().getPageSource().contains("207"));
	//
	// // gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	//
	// }
	//
	// @Test
	// public void testB2cLoginFlDeclineWeekly() throws Exception {
	// // seed and register an agreement
	// seedSpecifiedRegisterLogin(300f, "52", "Monthly", true, 221);
	//
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// login.clickApplyStartSecondLoan();
	// login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname,
	// Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));
	//
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // verify you cannot amend bank details
	//
	// login.assertOnPageFL(gsSatsumaSiteUrl,
	// gcb.formatCurrencyToDisplay(String.valueOf(Float.toString(gcb.calcEligibleAmount(100f,
	// 71.58f)))));
	//
	// login.confirmDetailsAboutYou("Household Goods",
	// gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)),
	// gcb.gsRequestedTerm, gcb.gsRepaymentFrequency,
	// gcb.gsPreferredPaymentDow);
	//
	// gcb.prClickForNextAction();
	//
	// login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);
	//
	// login.confirmDetailsYourFinances();
	//
	// gcb.prClickForNextAction();
	//
	// gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	//
	// // // Home Credit page
	// // // ================
	// //
	// // gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Applicant Has IVA" reason
	// // is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 203 - Applicant Has IVA.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));
	// Assert.assertTrue(getDriver().getPageSource().contains("207"));
	//
	// // gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }
	//
	// @Test
	// public void testB2cLoginFlDeclineMonthly() throws Exception {
	// // seed and register an agreement
	// seedSpecifiedRegisterLogin(300f, "6", "Monthly", true, 222);
	//
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// login.clickApplyStartSecondLoan();
	// login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname,
	// Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));
	//
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // verify you cannot amend bank details
	//
	// login.assertOnPageFL(gsSatsumaSiteUrl,
	// gcb.formatCurrencyToDisplay(String.valueOf(Float.toString(gcb.calcEligibleAmount(100f,
	// 71.58f)))));
	//
	// login.confirmDetailsAboutYou("Household Goods",
	// gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)),
	// gcb.gsRequestedTerm, gcb.gsRepaymentFrequency,
	// gcb.gsPreferredPaymentDow);
	//
	// gcb.prClickForNextAction();
	//
	// login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);
	//
	// login.confirmDetailsYourFinances();
	//
	// gcb.prClickForNextAction();
	//
	// login.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	//
	// // // Home Credit page
	// // // ================
	// //
	// // gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Applicant Has IVA" reason
	// // is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 203 - Applicant Has IVA.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("DMP rule"));
	// Assert.assertTrue(getDriver().getPageSource().contains("207"));
	//
	// // gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	// }

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
