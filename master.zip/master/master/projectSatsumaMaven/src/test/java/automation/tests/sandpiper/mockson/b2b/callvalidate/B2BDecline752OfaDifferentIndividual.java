package automation.tests.sandpiper.mockson.b2b.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

public class B2BDecline752OfaDifferentIndividual extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 387;
	private static final int MONTHLY_APPLICANT_ID = 386;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "752";

	@Test
	public void b2BNBDeclineWeekly() throws Exception {
		b2bDeclineTest(PAN_CODE, WEEKLY_APPLICANT_ID);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
