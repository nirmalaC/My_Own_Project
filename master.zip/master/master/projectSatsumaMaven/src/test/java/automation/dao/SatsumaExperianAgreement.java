package automation.dao;

public class SatsumaExperianAgreement {

	private String dateOfBirth;
	private String title;
	private String firstName;
	private String lastName;
	private String flatNumber;
	private String houseNumber;
	private String houseName;
	private String street;
	private String town;
	private String county;
	private String postcode;
	private String maritalStatus;
	private String income;
	private String incomeFrequency;
	private String monthlyOutgoings;
	private String sourceOfIncome;
	private String accomodationStatus;
	private String age;
	private String dependents;
	private String monthlyHousingCosts;
	private String loanPurpose;
	private String marketingCompany;
	private String loans;
	private String preferredRepaymentDayOfTheWeek;
	private String preferredRepaymentDayOfTheWeekId;
	private String currentMovingInDate;
	private String dateBankAccountOpened;
	private String monthlyLoanRepayments;
	private String creditCards;
	private String contactByMail;
	private String niNumber;
	private String contactByPhone;
	private String contactByPost;

	public SatsumaExperianAgreement(String dateOfBirth, String title, String firstName, String lastName, String flatNumber, String houseNumber, String houseName, String street, String town, String county, String postcode, String maritalStatus, String income, String incomeFrequency, String monthlyOutgoings, String sourceOfIncome, String accomodationStatus, String age, String dependents, String monthlyHousingCosts, String loanPurpose, String marketingCompany, String loans, String preferredRepaymentDayOfTheWeek, String preferredRepaymentDayOfTheWeekId, String currentMovingInDate, String dateBankAccountOpened, String monthlyLoanRepayments, String creditCards, String contactByMail, String niNumber, String contactByPhone, String contactByPost) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.flatNumber = flatNumber;
		this.houseNumber = houseNumber;
		this.houseName = houseName;
		this.street = street;
		this.town = town;
		this.county = county;
		this.postcode = postcode;
		this.maritalStatus = maritalStatus;
		this.income = income;
		this.incomeFrequency = incomeFrequency;
		this.monthlyOutgoings = monthlyOutgoings;
		this.sourceOfIncome = sourceOfIncome;
		this.accomodationStatus = accomodationStatus;
		this.age = age;
		this.dependents = dependents;
		this.monthlyHousingCosts = monthlyHousingCosts;
		this.loanPurpose = loanPurpose;
		this.marketingCompany = marketingCompany;
		this.loans = loans.toLowerCase().trim();
		this.preferredRepaymentDayOfTheWeek = preferredRepaymentDayOfTheWeek;
		this.preferredRepaymentDayOfTheWeekId = preferredRepaymentDayOfTheWeekId;
		this.currentMovingInDate = currentMovingInDate;
		this.dateBankAccountOpened = dateBankAccountOpened;
		this.monthlyLoanRepayments = monthlyLoanRepayments;
		this.creditCards = creditCards.toLowerCase().trim();
		this.contactByMail = contactByMail.toLowerCase().trim();
		this.niNumber = niNumber;
		this.contactByPhone = contactByPhone.toLowerCase().trim();
		this.contactByPost = contactByPost.toLowerCase().trim();
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getHouseName() {
		return houseName;
	}

	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getIncomeFrequency() {
		return incomeFrequency;
	}

	public void setIncomeFrequency(String incomeFrequency) {
		this.incomeFrequency = incomeFrequency;
	}

	public String getMonthlyOutgoings() {
		return monthlyOutgoings;
	}

	public void setMonthlyOutgoings(String monthlyOutgoings) {
		this.monthlyOutgoings = monthlyOutgoings;
	}

	public String getSourceOfIncome() {
		return sourceOfIncome;
	}

	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}

	public String getAccomodationStatus() {
		return accomodationStatus;
	}

	public void setAccomodationStatus(String accomodationStatus) {
		this.accomodationStatus = accomodationStatus;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getDependents() {
		return dependents;
	}

	public void setDependents(String dependents) {
		this.dependents = dependents;
	}

	public String getMonthlyHousingCosts() {
		return monthlyHousingCosts;
	}

	public void setMonthlyHousingCosts(String monthlyHousingCosts) {
		this.monthlyHousingCosts = monthlyHousingCosts;
	}

	public String getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	public String getMarketingCompany() {
		return marketingCompany;
	}

	public void setMarketingCompany(String marketingCompany) {
		this.marketingCompany = marketingCompany;
	}

	public String getLoans() {
		return loans;
	}

	public void setLoans(String loans) {
		this.loans = loans;
	}

	public String getPreferredRepaymentDayOfTheWeek() {
		return preferredRepaymentDayOfTheWeek;
	}

	public void setPreferredRepaymentDayOfTheWeek(String preferredRepaymentDayOfTheWeek) {
		this.preferredRepaymentDayOfTheWeek = preferredRepaymentDayOfTheWeek;
	}

	public String getPreferredRepaymentDayOfTheWeekId() {
		return preferredRepaymentDayOfTheWeekId;
	}

	public void setPreferredRepaymentDayOfTheWeekId(String preferredRepaymentDayOfTheWeekId) {
		this.preferredRepaymentDayOfTheWeekId = preferredRepaymentDayOfTheWeekId;
	}

	public String getCurrentMovingInDate() {
		return currentMovingInDate;
	}

	public void setCurrentMovingInDate(String currentMovingInDate) {
		this.currentMovingInDate = currentMovingInDate;
	}

	public String getDateBankAccountOpened() {
		return dateBankAccountOpened;
	}

	public void setDateBankAccountOpened(String dateBankAccountOpened) {
		this.dateBankAccountOpened = dateBankAccountOpened;
	}

	public String getMonthlyLoanRepayments() {
		return monthlyLoanRepayments;
	}

	public void setMonthlyLoanRepayments(String monthlyLoanRepayments) {
		this.monthlyLoanRepayments = monthlyLoanRepayments;
	}

	public String getCreditCards() {
		return creditCards;
	}

	public void setCreditCards(String creditCards) {
		this.creditCards = creditCards;
	}

	public String getContactByMail() {
		return contactByMail;
	}

	public void setContactByMail(String contactByMail) {
		this.contactByMail = contactByMail;
	}

	public String getNiNumber() {
		return niNumber;
	}

	public void setNiNumber(String niNumber) {
		this.niNumber = niNumber;
	}

	public String getContactByPhone() {
		return contactByPhone;
	}

	@Override
	public String toString() {
		return "SatsumaExperianAgreement [dateOfBirth=" + dateOfBirth + ", title=" + title + ", firstName=" + firstName + ", lastName=" + lastName + ", flatNumber=" + flatNumber + ", houseNumber=" + houseNumber + ", houseName=" + houseName + ", street=" + street + ", town=" + town + ", county=" + county + ", postcode=" + postcode + ", maritalStatus=" + maritalStatus + ", income=" + income + ", incomeFrequency=" + incomeFrequency + ", monthlyOutgoings=" + monthlyOutgoings + ", sourceOfIncome=" + sourceOfIncome + ", accomodationStatus=" + accomodationStatus + ", age=" + age + ", dependents=" + dependents + ", monthlyHousingCosts=" + monthlyHousingCosts + ", loanPurpose=" + loanPurpose + ", marketingCompany=" + marketingCompany + ", loans=" + loans + ", preferredRepaymentDayOfTheWeek=" + preferredRepaymentDayOfTheWeek + ", preferredRepaymentDayOfTheWeekId=" + preferredRepaymentDayOfTheWeekId + ", currentMovingInDate=" + currentMovingInDate + ", dateBankAccountOpened="
				+ dateBankAccountOpened + ", monthlyLoanRepayments=" + monthlyLoanRepayments + ", creditCards=" + creditCards + ", contactByMail=" + contactByMail + ", niNumber=" + niNumber + ", contactByPhone=" + contactByPhone + ", contactByPost=" + contactByPost + "]";
	}

	public void setContactByPhone(String contactByPhone) {
		this.contactByPhone = contactByPhone;
	}

	public String getContactByPost() {
		return contactByPost;
	}

	public void setContactByPost(String contactByPost) {
		this.contactByPost = contactByPost;
	}

}
