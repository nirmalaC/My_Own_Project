package automation.tests.allmockon.login.uat;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;

public class TestCase_14301_CheckUmbracoInstalled extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() {
		getDriver().get(gsSatsumaSiteUrl + "umbraco");
		getDriver().findElement(By.cssSelector("input[placeholder='Enter your username']"));
		getDriver().findElement(By.cssSelector("input[placeholder='Enter your password']"));
		log.debug("Title: " + getDriver().getTitle());
		Assert.assertTrue(getDriver().getTitle().contains("Umbraco"), "title contains umbraco");
	}
}
