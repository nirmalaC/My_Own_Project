package automation.tests.allmockon.login.loginandregistration;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.SatsumaCustomer;

import com.eviware.soapui.support.SoapUIException;

public class TestCase_RegisterUserFromAgreementNumber extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Override
	@BeforeMethod
	public void setUpBefore() throws Exception {

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");
	}

	// registers a user using agreement number by logging into pan and then into
	// registration screen
	@Test
	public void test() throws Exception {
		List<String> agreements = extractAgreementNumbers(gcb._getConfigProperty("agreementsToHaveCardUpdated"));

		for (String agreement : agreements) {
			log.debug("doing agreement " + agreement);
			registerByAgreementNumber(agreement);
			log.debug("done agreement " + agreement);
		}
	}

	private List<String> extractAgreementNumbers(String delimitedAgreementString) {
		final String delimiter = ",";
		String[] tempArray = delimitedAgreementString.split(delimiter);
		List<String> arrangements = Arrays.asList(tempArray);
		return arrangements;
	}

	public void registerByAgreementNumber(String agreementNumber) throws XmlException, IOException, SoapUIException, ParseException {
		SatsumaCustomer satsumaCustomer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(satsumaCustomer.toString());
		// // Get a Mocked application profile as template for creating a
		// dynamic
		// // unique person.

		gcb.gsFirstname = satsumaCustomer.getForename();
		gcb.gsSurname = satsumaCustomer.getSurname();
		gcb.gsDOB = satsumaCustomer.getDob("dd/MM/yyyy");
		gcb.gsPostcode = satsumaCustomer.getPostcode();
		gcb.gsFirstname = satsumaCustomer.getForename();
		gcb.gsPANAgreementNumber = agreementNumber;
		gcb.gsEmailAddress = satsumaCustomer.getEmailAddress();
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);
	}
}
