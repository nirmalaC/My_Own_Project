package automation.tests.callcreditmockoff.testsuite.b2c.declines;

import static org.testng.AssertJUnit.assertEquals;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.CallCreditOffTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;

public class TestCase_11298_DeclineHCROnCallCredit3TimesInvalidBankDetailsEntered extends CallCreditOffTest {

	@Test
	public void test_Is3TimeInvalidBankDetailsApplicantReferredToHomeCredit() throws Exception {

		// Data Preparation
		// ================

		// Get a Call Credit application profile
		// Applicant Mr Benjamin Tate
		gcb.prGetApplicantProfile(37);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Your Bank Details page 1st Attempt
		// ==================================

		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Card Details
		gcb.prClickForNextAction();

		// Your Bank Details page 2nd Attempt
		// ==================================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Unable to verify some bank details error message visible
		assertEquals(
				"Unfortunately, we have been unable to verify some of the bank account details you have provided. Please check the information you have entered carefully, make any necessary changes and re-submit.",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText());

		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Card Details
		gcb.prClickForNextAction();

		// Your Bank Details page 3rd Attempt
		// ==================================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Unable to verify some bank details error message visible
		assertEquals(
				"Unfortunately, we have been unable to verify some of the bank account details you have provided. Please check the information you have entered carefully, make any necessary changes and re-submit.",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText());

		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Card Details
		gcb.prClickForNextAction();

		// Home Credit page
		// ================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check that no proposal agreement is created in PAN to record this
		// decline
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement is found, not expecting one to be created
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement is found, not expecting an agreement to be created for this scenario.");
		}

	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
