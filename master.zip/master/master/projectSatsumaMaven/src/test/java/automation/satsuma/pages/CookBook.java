package automation.satsuma.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.ProxySelector;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.ValidatableResponse;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.xmlbeans.XmlException;
import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import automation.dao.CustomerType;
import automation.dao.SatsumaCustomer;
import automation.test.offerservice.entities.OfferRequest;
import automation.test.offerservice.entities.RetrieveOfferResponse;
import automation.test.offerservice.enums.EligibilityReasonCode;
import automation.test.offerservice.enums.OfferPartyStatus;
import automation.tools.DbTestShedHelper;
import automation.tools.MatchKeyHelper;
import automation.tools.OfferServiceRequestBuilder;
import automation.tools.RestHelper;
import automation.tools.ToolBox;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.support.SoapUIException;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.google.common.base.Function;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import static com.jayway.restassured.RestAssured.given;

public class CookBook {

	public static final int EXPLICIT_TIMEOUT = 60;
	public static final int STALENESS_TIMEOUT = 5;

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	public CookBook() {
	}

	protected int screenshotNumber;

	ThreadLocal<?> threadDriver = null;

	protected String testName;

	public CookBook(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public CookBook(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		screenshotNumber = 1;
	}

	public WebDriver getDriver() {
		return (WebDriver) threadDriver.get();
	}

	ToolBox gtb = new ToolBox();

	// Database connection to the testing frame database
	public Connection gdbConnTESTSHED;

	public String applicationDB;
	public String entityHubDB;
	public String entitySearchDB;
	public String powercurveDB;
	public String monthlyOff = "";

	// Applicant Profile Data Set
	public String gsPreferredPaymentDom;
	public String gsApplicantProfileId;
	public String gsCustomerId;
	public String gsMaritalStatus;
	public String gsNumberOfDependants;
	public String gsResidentialStatus;
	public String gsEmploymentStatus;
	public String gsSourceOfIncome;
	public String gsIncome;
	public String gsIncomeFrequency;
	public String gsIncomePaymentMethod;
	public String gsHasCreditCards;
	public String gsHasExistingLoans;
	public String gsMortgageCosts;
	public String gsRentCosts;
	public String gsMonthlyLoanRepayments;
	public String gsMonthlyOtherOutgoings;
	public String gsCurrentHouseMovedInDate;
	public String gsBankAccountName;
	public String gsBankAccountNumber;
	public String gsBankSortcode;
	public String gsBankAccountOpenDate;
	public String gsCreditCardNumber;
	public String gsCreditCardType;
	public String gsCreditCardExpiryDate;
	public String gsCreditCardCVS;
	public String gsRequestLoanProduct;
	public String gsRequestedLoanAmount;
	public String gsRequestedTerm;
	public String gsLoanPurpose;
	public String gsRepaymentFrequency;
	public String gsConsentToCreditSearch;
	public String gsMarketingOptInPost;
	public String gsMarketingOptInSMS;
	public String gsMarketingOptInEmail;
	public String gsMarketingOptInPhone;
	public String gsPreferredContactMethod;
	public String gsPreferredContactDetails;
	public String gsProfileBriefNote;
	public String gsDataSource;
	public String gsTitle;
	public String gsFirstname;
	public String gsMiddlename;
	public String gsSurname;
	public String gsSurnameTemp;
	public String gsDOB;
	public String gsGender;
	public String gsMobileNumber;
	public String gsHomeNumber;
	public String gsWorkNumber;
	public String gsFlatNumber;
	public String gsBuildingName;
	public String gsBuildingNumber;
	public String gsStreet;
	public String gsDistrict;
	public String gsTownCity;
	public String gsCounty;
	public String gsPostcode;
	public String gsCountry;
	public String gsEmailAddress;
	public String gsHousingCosts;
	public String gsPreferredPaymentDow;

	public String gsMonthlyOutgoings;
	public String gsCreditCardRepayments;

	public String gsEmploymentStatusBroker;
	public String gsIncomePaymentMethodBroker;
	// End of Data Set

	// Quick Apply
	public String gsQuickApply;

	// SOAPUI Projects Data Set
	public String gsSOAPUIProjectFolder;

	// PAN Data Set
	public String gsPanCreditServiceServer;
	public String gsPANSystemDate;
	public String gsPANAgreementStartDate;
	public String gsPANAgreementNumber;
	public String gsPANAgreementStatus;
	public String gsPANAgreementSecondaryStatus;
	public String gsPANPersonAgreementStatus;
	public String gsPANPersonAgreementStatusDesc;
	public String gsPANPersonId;
	public String gsPANApplicantFound;
	public String gsPANDecisionReasonId;
	public String gsPANPaidUpAmount;
	public String gsPANStopCategoryId;
	public String gsPANLendingMaxAmount;
	public String gsPANLendingMinAmount;
	public String gsPANLendingMaxTerm;
	public String gsPANRefinanceCount;
	public String gsPANConcurrentLoanCount;
	public String gsPANFrontOfficeUid;
	public String gsPANFrontOfficePwd;
	public String gsPANAgreementFound;
	public String gsPANFurtherLendingAgreementNumber;
	public String gsPANInArrearsAmount;
	// End of Data Set

	// Pricing
	public String gsExpectedInterest;
	public String gsExpectedRepayment;
	public String gsExpectedTAP;
	public String gsExpectedAPR;
	public String gsExpectedDailyRate;
	public String gsExpectedFlatRate;
	// End of Data Set

	// Invalid National Insurance Numbers
	public String AInvalidNINO_FA400737D = "FA400737D";
	public String AInvalidNINO_IA400737D = "IA400737D";
	public String AInvalidNINO_QA400737D = "QA400737D";
	public String AInvalidNINO_UA400737D = "UA400737D";
	public String AInvalidNINO_VA400737D = "VA400737D";
	public String AInvalidNINO_ND400737D = "ND400737D";
	public String AInvalidNINO_NF400737D = "NF400737D";
	public String AInvalidNINO_NI400737D = "NI400737D";
	public String AInvalidNINO_NQ400737D = "NQ400737D";
	public String AInvalidNINO_NU400737D = "NU400737D";
	public String AInvalidNINO_NV400737D = "NV400737D";
	public String AInvalidNINO_NO400737D = "NO400737D";
	public String AInvalidNINO_BG400737D = "BG400737D";
	public String AInvalidNINO_GB400737D = "GB400737D";
	public String AInvalidNINO_NK400737D = "NK400737D";
	public String AInvalidNINO_KN400737D = "KN400737D";
	public String AInvalidNINO_TN400737D = "TN400737D";
	public String AInvalidNINO_ZZ400737D = "ZZ400737D";
	public String AInvalidNINO_NA400737E = "NA400737E";
	public String AInvalidNINO_NA400737F = "NA400737F";
	public String AInvalidNINO_NA400737G = "NA400737G";
	public String AInvalidNINO_NA400737H = "NA400737H";
	public String AInvalidNINO_NA400737I = "NA400737I";
	public String AInvalidNINO_NA400737J = "NA400737J";
	public String AInvalidNINO_NA400737K = "NA400737K";
	public String AInvalidNINO_NA400737L = "NA400737L";
	public String AInvalidNINO_NA400737M = "NA400737M";
	public String AInvalidNINO_NA400737N = "NA400737N";
	public String AInvalidNINO_NA400737 = "NA400737";
	public String AInvalidNINO_NA400737DA = "NA400737DA";
	public String AInvalidNINO_NAX00737D = "NAX00737D";
	public String AInvalidNINO_NA4X0737D = "NA4X0737D";
	public String AInvalidNINO_NA40X737D = "NA40X737D";
	public String AInvalidNINO_NA400X37D = "NA400X37D";
	public String AInvalidNINO_NA4007X7D = "NA4007X7D";
	public String AInvalidNINO_NA40073XD = "NA40073XD";
	public String AInvalidNINO_NA400737O = "NA400737O";
	public String AInvalidNINO_NA400737P = "NA400737P";
	public String AInvalidNINO_NA400737Q = "NA400737Q";
	public String AInvalidNINO_NA400737R = "NA400737R";
	public String AInvalidNINO_NA400737S = "NA400737S";
	public String AInvalidNINO_NA400737T = "NA400737T";
	public String AInvalidNINO_NA400737U = "NA400737U";
	public String AInvalidNINO_NA400737V = "NA400737V";
	public String AInvalidNINO_NA400737W = "NA400737W";
	public String AInvalidNINO_NA400737X = "NA400737X";
	public String AInvalidNINO_NA400737Z = "NA400737Z";
	public String AInvalidNINO_NA4007370 = "NA4007370";
	public String AInvalidNINO_NA4007371 = "NA4007371";
	public String AInvalidNINO_NA4007372 = "NA4007372";
	public String AInvalidNINO_NA4007373 = "NA4007373";
	public String AInvalidNINO_NA4007374 = "NA4007374";
	public String AInvalidNINO_NA4007375 = "NA4007375";
	public String AInvalidNINO_NA4007376 = "NA4007376";
	public String AInvalidNINO_NA4007377 = "NA4007377";
	public String AInvalidNINO_NA4007378 = "NA4007378";
	public String AInvalidNINO_NA4007379 = "NA4007379";

	// End of Invalid NINO's

	public void DBConnectTESTSHED(String psConnectionString) throws SQLException {

		String sdbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		try {
			Class.forName(sdbClass);
			gdbConnTESTSHED = DriverManager.getConnection(psConnectionString);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void DBDisconnectTESTSHED() throws SQLException {
		if (gdbConnTESTSHED != null) {
			try {
				gdbConnTESTSHED.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void prGetApplicantProfile(int piApplicantProfileId) throws Exception {

		DBConnectTESTSHED(_getConfigProperty("TestShedDBConnection"));
		CallableStatement SQLStmt = null;

		try {
			SQLStmt = gdbConnTESTSHED.prepareCall("{call [dbo].[pr_GetApplicantProfile] (?)}");
			SQLStmt.setInt(1, piApplicantProfileId);

			ResultSet rs = SQLStmt.executeQuery();
			while (rs.next()) {
				gsApplicantProfileId = rs.getString(1);
				gsCustomerId = rs.getString(2);
				gsMaritalStatus = rs.getString(3);
				gsNumberOfDependants = rs.getString(4);
				gsResidentialStatus = rs.getString(5);
				gsEmploymentStatus = rs.getString(6);
				gsSourceOfIncome = rs.getString(7);
				gsIncome = rs.getString(8);
				gsIncomeFrequency = rs.getString(9);
				gsIncomePaymentMethod = rs.getString(10);
				gsHasCreditCards = rs.getString(11);
				gsHasExistingLoans = rs.getString(12);
				gsMortgageCosts = rs.getString(13);
				gsRentCosts = rs.getString(14);
				gsMonthlyLoanRepayments = rs.getString(15);
				gsMonthlyOtherOutgoings = rs.getString(16);
				gsCurrentHouseMovedInDate = rs.getString(17);
				gsBankAccountName = rs.getString(18);
				gsBankAccountNumber = rs.getString(19);
				gsBankSortcode = rs.getString(20);
				gsBankAccountOpenDate = rs.getString(21);
				gsCreditCardNumber = rs.getString(22);
				gsCreditCardType = rs.getString(23);
				gsCreditCardExpiryDate = rs.getString(24);
				gsCreditCardCVS = rs.getString(25);
				gsRequestLoanProduct = rs.getString(26);
				gsRequestedLoanAmount = rs.getString(27);
				gsRequestedTerm = rs.getString(28);
				gsLoanPurpose = rs.getString(29);
				gsRepaymentFrequency = rs.getString(30);
				gsConsentToCreditSearch = rs.getString(31);
				gsMarketingOptInPost = rs.getString(32);
				gsMarketingOptInSMS = rs.getString(33);
				gsMarketingOptInEmail = rs.getString(34);
				gsMarketingOptInPhone = rs.getString(35);
				gsPreferredContactMethod = rs.getString(36);
				gsPreferredContactDetails = rs.getString(37);
				gsProfileBriefNote = rs.getString(38);
				gsCustomerId = rs.getString(39);
				gsDataSource = rs.getString(40);
				gsTitle = rs.getString(41);
				gsFirstname = rs.getString(42);
				gsMiddlename = rs.getString(43);
				gsSurname = rs.getString(44);
				gsDOB = rs.getString(45);
				gsGender = rs.getString(46);
				gsMobileNumber = rs.getString(47);
				gsHomeNumber = rs.getString(48);
				gsWorkNumber = rs.getString(49);
				gsFlatNumber = rs.getString(50);
				gsBuildingName = rs.getString(51);
				gsBuildingNumber = rs.getString(52);
				gsStreet = rs.getString(53);
				gsDistrict = rs.getString(54);
				gsTownCity = rs.getString(55);
				gsCounty = rs.getString(56);
				gsPostcode = rs.getString(57);
				gsCountry = rs.getString(58);
				// gsEmailAddress = rs.getString(59);
				gsEmailAddress = gsSurname + "@test.com";
				gsHousingCosts = rs.getString(60);
				gsPreferredPaymentDow = rs.getString(61);
				gsMonthlyOutgoings = rs.getString(62);
				gsCreditCardRepayments = rs.getString(63);
				gsEmploymentStatusBroker = getEmploymentStatusBroker(gsEmploymentStatus);
				gsIncomePaymentMethodBroker = getIncomePaymentMethodBroker(gsIncomePaymentMethod);

				log.info("prGetApplicantProfile: Found Applicant Profile: " + gsApplicantProfileId + " loan amount: " + gsRequestedLoanAmount + " loan term: " + gsRequestedTerm + " frequency: " + gsRepaymentFrequency);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (SQLStmt != null) {
				try {
					SQLStmt.close();
					DBDisconnectTESTSHED();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private String getIncomePaymentMethodBroker(String IncomePaymentMethod) {
		String IncomePayMentMethodBroker;
		switch (IncomePaymentMethod) {
		case "Cash":
			IncomePayMentMethodBroker = "Cash";
			break;
		case "Cheque":
			IncomePayMentMethodBroker = "Cheque";
			break;
		case "Direct Into Bank Account":
			IncomePayMentMethodBroker = "DirectDeposit";
			break;
		case "Other":
			IncomePayMentMethodBroker = "Other";
			break;
		default:
			throw new IllegalArgumentException("Invalid Income Payment Method: " + IncomePaymentMethod);
		}
		return IncomePayMentMethodBroker;
	}

	private String getEmploymentStatusBroker(String EmploymentStatus) {
		String EmploymentStatusBroker;
		switch (EmploymentStatus) {
		case "Benefits":
			EmploymentStatusBroker = "BenefitsAndFullTimeEmployed";
			break;
		case "Full Time Employed":
			EmploymentStatusBroker = "FullTimeEmployed";
			break;
		case "Full Time Employment Only":
			EmploymentStatusBroker = "FullTimeEmployed";
			break;
		case "FullTimeEmployed":
			EmploymentStatusBroker = "FullTimeEmployed";
			break;
		case "Homemaker":
			EmploymentStatusBroker = "Homemaker";
			break;
		case "Part Time Employment only":
			EmploymentStatusBroker = "PartTimeEmployed";
			break;
		case "PartTimeEmployed":
			EmploymentStatusBroker = "PartTimeEmployed";
			break;
		case "Retired":
			EmploymentStatusBroker = "Retired";
			break;
		case "Self Employed":
			EmploymentStatusBroker = "SelfEmployed";
			break;
		case "Unemployed":
			EmploymentStatusBroker = "Unemployed";
			break;

		default:
			throw new IllegalArgumentException("Invalid Employment Status: " + EmploymentStatus);
		}
		return EmploymentStatusBroker;
	}

	@Deprecated
	public String fn_PreferredPaymentDate(String sCurrentDate, String psDoW) {
		Date currentDate = null;
		SimpleDateFormat dateIn = new SimpleDateFormat("dd/MM/yyyy");
		try {
			currentDate = dateIn.parse(sCurrentDate);
		} catch (ParseException e) {
			log.error("Error currentDate is not a valid date in format dd/MM/yyyy");
		}

		int iDoW;
		int iReqDoW = 0;

		switch (psDoW.toUpperCase()) {
		case "SATURDAY":
			iReqDoW = 0;
			break;
		case "SUNDAY":
			iReqDoW = 1;
			break;
		case "MONDAY":
			iReqDoW = 2;
			break;
		case "TUESDAY":
			iReqDoW = 3;
			break;
		case "WEDNESDAY":
			iReqDoW = 4;
			break;
		case "THURSDAY":
			iReqDoW = 5;
			break;
		case "FRIDAY":
			iReqDoW = 6;
			break;
		}
		// Get todays date
		Calendar now = Calendar.getInstance();
		now.setTime(currentDate);

		iDoW = now.get(Calendar.DAY_OF_WEEK);

		// if requested day of week is later then current day of week
		if (iReqDoW >= iDoW) {
			// go to next week plus difference up to requested day
			now.add(Calendar.DATE, 7 + iReqDoW - iDoW);
			// log.debug("req day later than or same as current day");
		} else {
			// if its earlier in the week, we gotta go 7 days + up to requested
			// day
			// log.debug("req day earlier than current day");
			now.add(Calendar.DATE, 14 - (iDoW - iReqDoW));
		}

		SimpleDateFormat sdf = new SimpleDateFormat("d'%s' MMMMM yyyy");
		String myDate = String.format(sdf.format(now.getTime()), dateSuffix(now));

		return myDate;
	}

	public void prIsApplicantKnownToPAN(String psPanServiceServer, String psFirstname, String psSurname, String psDoB) throws XmlException, SoapUIException, Exception {

		log.info("prIsApplicantKnownToPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		gsPANSystemDate = null;
		gsPANAgreementStartDate = "";
		gsPANAgreementNumber = "";
		gsPANAgreementStatus = "";
		gsPANPersonAgreementStatus = "1";
		gsPANPersonAgreementStatusDesc = "Person has no agreements";
		gsPANApplicantFound = "No";
		gsPANPersonId = "";

		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectPanCredit-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("RESTTestSuite_Exploratory_ToolSet");
		TestCase testCase = testSuite.getTestCaseByName("TestCase: IsApplicantKnownToPAN");

		log.info("IsApplicantKnownToPan: " + psPanServiceServer + ": " + psFirstname + " " + psSurname + " " + psDoB);
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServer", psPanServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDoB", psDoB);
		testCase.setPropertyValue("ptcAgreementStartDate", gsPANAgreementStartDate);
		testCase.setPropertyValue("ptcAgreementNumber", gsPANAgreementNumber);
		testCase.setPropertyValue("ptcAgreementStatus", gsPANAgreementStatus);
		testCase.setPropertyValue("ptcPersonAgreementStatus", gsPANPersonAgreementStatus);
		testCase.setPropertyValue("ptcPersonAgreementStatusDesc", gsPANPersonAgreementStatusDesc);
		testCase.setPropertyValue("ptcApplicantFound", gsPANApplicantFound);
		testCase.setPropertyValue("ptcPersonId", gsPANPersonId);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		// Assert.assertEquals(TestRunner.Status.FINISHED,runner.getStatus());

		gsPANSystemDate = testCase.getPropertyValue("ptcProcessDate");
		gsPANAgreementStartDate = testCase.getPropertyValue("ptcAgreementStartDate");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANAgreementStatus = testCase.getPropertyValue("ptcAgreementStatus");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANApplicantFound = testCase.getPropertyValue("ptcApplicantFound");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Pan System Date: " + gsPANSystemDate);
		log.info("Applicant Found: " + gsPANApplicantFound);
		log.info("Person Agreement Status: " + gsPANPersonAgreementStatus);
		log.info("Person Agreement Status Description: " + gsPANPersonAgreementStatusDesc);
		log.info("Agreement Number: " + gsPANAgreementNumber);
		log.info("Agreement Status: " + gsPANAgreementStatus);
		log.info("Person Id: " + gsPANPersonId);
	}

	public void prCreateUniquePerson() throws XmlException, SoapUIException, IOException, Exception {

		// gsFirstname = getRandomName();
		// gsSurname = getRandomName();
		setRandomForeName();
		setRandomSurname();
		setRandomDOB();
		setRandomPostcode();
		gsEmailAddress = gsSurname + "@test.com";

		log.debug("Dynamic Unique Person (NOT SOAPUI): " + gsFirstname + " " + gsSurname + " " + gsDOB + " " + gsPostcode + " " + gsEmailAddress);
	}

	public String getRandomDOB() {
		// String months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
		// "Aug", "Sep", "Oct", "Nov", "Dec" };

		Random rand = new Random();

		int month = rand.nextInt(12) + 1;
		int daylimit = 28;
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			daylimit = 31;
		case 2:
			daylimit = 28;
		case 4:
		case 6:
		case 9:
		case 11:
			daylimit = 30;
		}

		int day = rand.nextInt(daylimit) + 1;
		// String monthString = new
		// DateFormatSymbols().getMonths()[rand.nextInt(12) + 1];
		int year = rand.nextInt(40) + 1955;
		// String dob = String.format("%02d", day) + "-" + months[month - 1] +
		// "-" + year;
		String dob = String.format("%02d", day) + "/" + String.format("%02d", month) + "/" + year;
		return dob;
	}

	@Deprecated
	public// Should be removed if replacement method is working
	void prOldCreateUniquePerson() throws XmlException, SoapUIException, IOException, Exception {

		log.info("prCreateUniquePerson: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		ProxySelector.setDefault(proxy);

		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePerson");
		ProxySelector.setDefault(proxy);

		// Set attributes before submission
		testCase.setPropertyValue("ptcFirstname", gsFirstname);

		TestRunner runner = testCase.run(new PropertiesMap(), false);
		ProxySelector.setDefault(proxy);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB);

		project = null;
		testSuite = null;
		testCase = null;
		runner = null;
	}

	public void prCreateUniquePersonExceptDOB() throws XmlException, SoapUIException, IOException, Exception {

		log.info("prCreateUniquePerson: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		ProxySelector.setDefault(proxy);

		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePerson");
		ProxySelector.setDefault(proxy);

		// Set attributes before submission
		testCase.setPropertyValue("ptcFirstname", gsFirstname);

		TestRunner runner = testCase.run(new PropertiesMap(), false);
		ProxySelector.setDefault(proxy);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		// gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB);

		project = null;
		testSuite = null;
		testCase = null;
		runner = null;
	}

	public void prCreateBySurnameUniquePersonContactInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prCreatebySurnameUniquePersonContactInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateBySurnameUniquePersonContact");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", "");
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);
		testCase.setPropertyValue("ptcHomeNumber", gsHomeNumber);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsSurnameTemp = testCase.getPropertyValue("ptcSurname");

		log.info("Dynamic Unique By Surname Person Contact: " + gsFirstname + " " + gsSurnameTemp + " " + gsDOB);
	}

	public void prSeedUniqueActiveAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueActiveAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + "PANAgreement: " + gsPANAgreementNumber);
	}

	public void prSeedUniqueActiveAgreementInArrangementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueActiveAgreementInArrangementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreementInTemporaryArrangement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcAmount", gsRequestedLoanAmount);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");

		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + "PANAgreement: " + gsPANAgreementNumber);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prPersonHasOnlyOneAgreement(String psPanCreditServiceServer, String psPersonId) throws XmlException, SoapUIException, Exception {

		// Use the called SOAPUI script to check if supplied PAN person only has
		// one agreement.
		// SOAPUI pass assumes Person has only one agreement
		log.info("prPersonHasOnlyOneAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_PersonHasOnlyOneAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPersonId", psPersonId);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prApplicantKnownNoCreate(String psPanCreditServiceServer, String psFirstname, String psSurname, String psDOB) throws XmlException, SoapUIException, Exception {

		// Use the called SOAPUI script to return Applicant Known response for
		// supplied person
		log.info("prApplicantKnownNoCreate: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_ApplicantKnownNoCreate");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDOB", psDOB);
		TestRunner runner = testCase.run(new PropertiesMap(), false);

		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANLendingMaxAmount = testCase.getPropertyValue("ptcLendingMaxAmount");
		gsPANLendingMinAmount = testCase.getPropertyValue("ptcLendingMinAmount");
		gsPANLendingMaxTerm = testCase.getPropertyValue("ptcLendingMaxTerm");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANRefinanceCount = testCase.getPropertyValue("ptcRefinanceCount");
		gsPANConcurrentLoanCount = testCase.getPropertyValue("ptcConcurrentLoanCount");
		gsPANApplicantFound = testCase.getPropertyValue("ptcPersonFound");

		log.info("PersonId: " + gsPANPersonId);
		log.info("LendingMaxAmount: " + gsPANLendingMaxAmount);
		log.info("LendingMinAmount: " + gsPANLendingMinAmount);
		log.info("LendingMaxTerm: " + gsPANLendingMaxTerm);
		log.info("PersonAgreemenStatus: " + gsPANPersonAgreementStatus);
		log.info("PersonAgreemenStatusDesc: " + gsPANPersonAgreementStatusDesc);
		log.info("RefinanceCount: " + gsPANRefinanceCount);
		log.info("ConcurrentLoanCount: " + gsPANConcurrentLoanCount);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prSeedUniqueReferredAgreementInPAN(String psPanCreditServiceServer, String psPanDecisionReasonID) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueReferredAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonReferredAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPANDecisionReasonID", psPanDecisionReasonID);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcAmount", gsRequestedLoanAmount);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_ApplicantKnown#Response#//ApplicantResult[1]/PersonID}");

		log.info("PersonID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANDecisionReasonId = testCase.getPropertyValue("ptcPANDecisionReasonID");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Referred Decision: " + gsPANDecisionReasonId);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedUniqueRejectedAgreementInPAN(String psPanCreditServiceServer, String psPanDecisionReasonID) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueRejectedAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonDeclinedAgreement");

		log.info(psPanCreditServiceServer);
		log.info(psPanDecisionReasonID);
		log.info(gsFirstname);
		log.info(gsStreet);
		log.info(gsTownCity);
		log.info(gsPostcode);
		log.info(gsNumberOfDependants);
		log.info(gsResidentialStatus);
		log.info(gsMaritalStatus);
		log.info(gsCurrentHouseMovedInDate);

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPANDecisionReasonID", psPanDecisionReasonID);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANDecisionReasonId = testCase.getPropertyValue("ptcPANDecisionReasonID");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Referred Decision: " + gsPANDecisionReasonId);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prSeedUniqueHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement50PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);


		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");

		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedUniqueThirdPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueThirdPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN(String psPanCreditServiceServer, String psRequestedLoanAmount, String psRequestedLoanFrequency, String psRequestedLoanTerm) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonWithSpecifiedLoanActiveAgreement50PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", psRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedLoanFrequency", psRequestedLoanFrequency);
		testCase.setPropertyValue("ptcRequestedLoanTerm", psRequestedLoanTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueSpecifiedLoanThirdPaidUpAgreementInPAN(String psPanCreditServiceServer, String psRequestedLoanAmount, String psRequestedLoanFrequency, String psRequestedLoanTerm) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonWithSpecifiedLoanActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", psRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedLoanFrequency", psRequestedLoanFrequency);
		testCase.setPropertyValue("ptcRequestedLoanTerm", psRequestedLoanTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement100PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueFrozenAgreementInPAN(String psPanCreditServiceServer, String psPanStopCategoryId) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueFrozenAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreementAndFreeze");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcStopCategoryID", psPanStopCategoryId);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_UpdateStopCategory#Response#//UpdateStopCategory[1]/Agreement[1]/CustomerID}");
		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANStopCategoryId = testCase.getPropertyValue("ptcStopCategoryID");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Stop Category: " + gsPANStopCategoryId);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedUnique100PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique100PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonAgreement100PercentPaidUpSpecifiedLoanTerms");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonAgreement50PercentPaidUpSpecifiedLoanTerms");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUnique33PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique33PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		log.info(gsResidentialStatus);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");
		gsPostcode = testCase.getPropertyValue("ptcPostcode");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prGetPersonsLatestAgreementStatusInPAN(String psPanCreditServiceServer, String psFirstname, String psSurname, String psDOB, String psPostcode) throws XmlException, SoapUIException, Exception {
		log.info("prGetPersonsLatestAgreementStatusInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_GetPersonsLatestAgreementStatus");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDOB", psDOB);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		log.info("Find Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " " + gsPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(runner.getStatus(), TestRunner.Status.FINISHED, "soapui call status");

		gsPANAgreementFound = testCase.getPropertyValue("ptcAgreementFound");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANAgreementStatus = testCase.getPropertyValue("ptcAgreementPrimaryStatus");
		gsPANAgreementSecondaryStatus = testCase.getPropertyValue("ptcAgreementSecondaryStatus");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANConcurrentLoanCount = testCase.getPropertyValue("ptcConcurrentLoanCount");
		gsPANFurtherLendingAgreementNumber = testCase.getPropertyValue("ptcFurtherLendingAgreementNumber");
		gsPANInArrearsAmount = testCase.getPropertyValue("ptcInArrearsAmount");
		gsPANLendingMaxAmount = testCase.getPropertyValue("ptcLendingMaxAmount");

		log.info("PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PrimaryStatus: " + gsPANAgreementStatus + " SecondaryStatus: " + gsPANAgreementSecondaryStatus + " ConcurrentLoansCount: " + gsPANConcurrentLoanCount + " FurtherLendingAgreementNumber: "
				+ gsPANFurtherLendingAgreementNumber + " FurtherLendingMaxAmount: " + gsPANLendingMaxAmount + " InArrearsAmount: " + gsPANInArrearsAmount);
	}

	public String _getConfigProperty(String psName) throws Exception {

		Properties prop = new Properties();
		String sTmp;
		InputStream input = null;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sTmp = prop.getProperty(psName);
		log.info("_getConfigProperty: " + psName + "=" + sTmp);
		return sTmp;
	}

	public void prGetACurrentSatsumaLoanCharge(String psFrequency, int piTerm, int piLoanAmount

	) throws Exception {

		log.info("prGetACurrentSatsumaLoanCharge: Frequency=" + psFrequency + ",Term=" + Integer.toString(piTerm) + ",LoanAmount=" + Integer.toString(piLoanAmount));
		DBConnectTESTSHED(_getConfigProperty("TestShedDBConnection"));

		CallableStatement SQLStmt = null;
		ResultSet rs = null;
		try {
			SQLStmt = gdbConnTESTSHED.prepareCall("{call [dbo].[prGetACurrentSatsumaLoanCharge] (?,?,?)}");
			SQLStmt.setString(1, psFrequency);
			SQLStmt.setInt(2, piTerm);
			SQLStmt.setInt(3, piLoanAmount);

			rs = SQLStmt.executeQuery();
			while (rs.next()) {
				gsExpectedTAP = rs.getString(3);
				gsExpectedInterest = rs.getString(4);
				gsExpectedRepayment = rs.getString(5);
				gsExpectedAPR = rs.getString(6);
				gsExpectedFlatRate = rs.getString(7);
				gsExpectedDailyRate = rs.getString(8);
				log.info("prGetACurrentSatsumaLoanCharge: TAP=" + gsExpectedTAP + ",Interest=" + gsExpectedInterest + ",Repayment=" + gsExpectedRepayment + ",ExpectedAPR=" + gsExpectedAPR + ",ExpectedDailyRate=" + gsExpectedDailyRate + ",ExpectedFlatRate=" + gsExpectedFlatRate);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (SQLStmt != null) {
				try {
					SQLStmt.close();
					DBDisconnectTESTSHED();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void prAssertNewNonBrokeredRejectedAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW,
			String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: TestCase_AssertNewNonBrokeredRejectedAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: prAssertNewNonBrokeredRejectedAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psPreferredDoW:" + psPreferredDoW);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		log.debug("proxy changed = " + ProxySelector.getDefault());
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredRejectedAgreement");
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcPreferredDOW", psPreferredDoW);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);
		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
	}

	public void prAssertNewNonBrokeredAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW,
			String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psPreferredDoW:" + psPreferredDoW);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		log.debug("proxy changed = " + ProxySelector.getDefault());
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreement");
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcPreferredDOW", psPreferredDoW);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);
		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
	}

	public void prAssertNewNonBrokeredAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW,
			String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode, String scheduleStartDate, String scheduleEndDate) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psPreferredDoW:" + psPreferredDoW);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		log.info("DEBUG: scheduleStartDate:" + scheduleStartDate);
		log.info("DEBUG: scheduleEndDate:" + scheduleEndDate);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		log.debug("proxy changed = " + ProxySelector.getDefault());
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreement");
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcPreferredDOW", psPreferredDoW);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);
		testCase.setPropertyValue("ptcScheduleStartDate", scheduleStartDate);
		testCase.setPropertyValue("ptcScheduleEndDate", scheduleEndDate);
		TestRunner runner = testCase.run(new PropertiesMap(), false);



		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
	}

	public void prAssertNewNonBrokeredAgreementForPaidUpCustomer(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP,
			String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {

		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreementForPaidCustomer: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreementForPaidUpCustomer");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreementForPaidUpCustomer");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prAssertNewNonBrokeredAgreementForActiveCustomer(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP,
			String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreementForActiveCustomer: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreementForActiveCustomer");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreementForActiveCustomer");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prAssertNewNonBrokeredReferredAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW,
			String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created referred
		// proposal PAN agreement
		log.info("DEBUG: prAssertNewNonBrokeredReferredAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredReferredAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredReferredAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prFillCreditAgreementPage(WebDriver driver) {

		// Credit Agreement
		// ----------------

		// Product Explanation - Read acknowledged

		getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).click();

		getDriver().findElement(By.xpath("//input[@id='ReadProductExplanation']")).click();

		// Pre-Contract Credit Information
		// -------------------------------

		// 1. Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();

		// 2. Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();

		// 3. Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();

		// 4. Other important legal aspects - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();

		// 5. Additional information innthe case of distance marketing of
		// financial services - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();

		// Contractual Terms and Conditions
		// --------------------------------

		// 6. Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();

		// 7. Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();

		// Confirm above sections read
		getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).click();

		// Credit Agreement and E-Signature
		// Fixed Sum Loan Agreement
		// --------------------------------

		// Parties to the Agreement - Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();

		// Check name on agreement
		getDriver().getPageSource().contains(gsTitle + " " + gsFirstname + " " + gsSurname);

		// Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features-credit-product']")).click();

		// Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();

		// Right of withdrawal - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();

		// Other important information - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();

		// Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();

		// Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();

		// Confirm above section read
		getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).click();

		// Signature of Customer
		// ---------------------

		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gsFirstname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gsSurname);
	}

	public void prSeedSpecifiedPersonActiveAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedPersonActiveAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonActiveAgreement");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		// set frequency and loan product
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcAmount", gsRequestedLoanAmount);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_ApplicantKnown#Response#//ApplicantResult[1]/PersonID}");

		log.info("PersonID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(String psPanCreditServiceServer, String agreementNumber) throws XmlException, SoapUIException, Exception {
		prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(psPanCreditServiceServer, agreementNumber, "100", "13");
	}

	public void prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(String psPanCreditServiceServer, String agreementNumber, String loanAmount, String loanTerm) throws XmlException, SoapUIException, Exception {

		log.info("prSeedSpecifiedPersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_MobileTools");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AddNewHalfPaidUpAgreement");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", agreementNumber);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcAmount", loanAmount);
		testCase.setPropertyValue("ptcTerm", loanTerm);
		testCase.setPropertyValue("ptcCounty", gsCounty);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

//		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");
//
//		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Further Loan Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber);

//		Date today = new Date();
//		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
//		String date = DATE_FORMAT.format(today);
//
//		KeyStore keyStore = null;
//		SSLConfig config = null;
//		String password = "password";
//
//
//		//Added the self signed certificate
//		keyStore = KeyStore.getInstance("PKCS12");
//		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
//		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
//
//		// set the config in rest assured
//		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
//		RestAssured.config = RestAssured.config().sslConfig(config);
//
//		//Rest Assured test
//		ValidatableResponse response = given()
//				.contentType("application/x-www-form-urlencoded")
//				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
//				.header("Content-Type", "application/json")
//				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
//				.log()
//				.all()
//				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
//				.then()
//				.log()
//				.all()
//				.statusCode(201);
//		log.info(response.toString());


	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedSpecifiedPersonFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonAgreement100PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcLoanTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");

		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
		Thread.sleep(500);
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedSpecifiedPersonFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonAgreement100PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcLoanTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcFrequency", gsRepaymentFrequency);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");

		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
		Thread.sleep(500);
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://apipp.provident.services/PreProd/party-api/v2/person/")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());

	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer, String loanAmount, String loanTerm, String frequency) throws XmlException, SoapUIException, Exception {
		//
		// log.info("prSeedSpecifiedPersonFullPaidUpAgreementInPAN: SOAPUI project - location "
		// + gsSOAPUIProjectFolder);
		// ProxySelector proxy = ProxySelector.getDefault();
		// WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder +
		// "projectSatsuma-soapui-project.xml");
		// ProxySelector.setDefault(proxy);
		// TestSuite testSuite =
		// project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		// TestCase testCase =
		// testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonAgreement100PercentPaidUp");

		log.debug("loanAmount: " + loanAmount);
		log.debug("loanTerm: " + loanTerm);
		log.debug("loanFreq: " + frequency);

		String tempAmount = gsRequestedLoanAmount;
		String tempTerm = gsRequestedTerm;
		String tempFreq = gsRepaymentFrequency;

		gsRequestedLoanAmount = loanAmount;
		gsRequestedTerm = loanTerm;
		gsRepaymentFrequency = frequency;

		prSeedSpecifiedPersonFullPaidUpAgreementInPAN(psPanCreditServiceServer);

		gsRequestedLoanAmount = tempAmount;
		gsRequestedTerm = tempTerm;
		gsRepaymentFrequency = tempFreq;
	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(String psPanCreditServiceServer, String loanAmount, String loanTerm, String frequency) throws XmlException, SoapUIException, Exception {

		log.debug("loanAmount: " + loanAmount);
		log.debug("loanTerm: " + loanTerm);
		log.debug("loanFreq: " + frequency);

		String tempAmount = gsRequestedLoanAmount;
		String tempTerm = gsRequestedTerm;
		String tempFreq = gsRepaymentFrequency;

		gsRequestedLoanAmount = loanAmount;
		gsRequestedTerm = loanTerm;
		gsRepaymentFrequency = frequency;

		prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(psPanCreditServiceServer);

		gsRequestedLoanAmount = tempAmount;
		gsRequestedTerm = tempTerm;
		gsRepaymentFrequency = tempFreq;
	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer, String loanAmount, String loanTerm) throws XmlException, SoapUIException, Exception {
		prSeedSpecifiedPersonFullPaidUpAgreementInPAN(psPanCreditServiceServer, loanAmount, loanTerm, "Weekly");
	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(String psPanCreditServiceServer, String loanAmount, String loanTerm) throws XmlException, SoapUIException, Exception {
		prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(psPanCreditServiceServer, loanAmount, loanTerm, "Weekly");
	}
	public void prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedVulnerablePersonAgreement100PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsTitle + " " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(String psPanCreditServiceServer, String loanAmount, String loanTerm, String repaymentFrequency) throws XmlException, SoapUIException, Exception {
		log.debug("calling prSeedSpecifiedPersonHalfPaidUpAgreementInPAN with loan " + loanAmount + " term " + loanTerm);

		String tempAmount = gsRequestedLoanAmount;
		String tempTerm = gsRequestedTerm;
		String tempFreq = gsRepaymentFrequency;

		gsRequestedLoanAmount = loanAmount;
		gsRequestedTerm = loanTerm;
		gsRepaymentFrequency = repaymentFrequency;

		prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(psPanCreditServiceServer);
		gsRequestedLoanAmount = tempAmount;
		gsRequestedTerm = tempTerm;
		gsRepaymentFrequency = tempFreq;
	}

	public void prSeedSpecifiedPersonHalfPaidUpAgreementInPANUat(String psPanCreditServiceServer, String loanAmount, String loanTerm, String repaymentFrequency) throws XmlException, SoapUIException, Exception {
		log.debug("calling prSeedSpecifiedPersonHalfPaidUpAgreementInPAN with loan " + loanAmount + " term " + loanTerm);

		String tempAmount = gsRequestedLoanAmount;
		String tempTerm = gsRequestedTerm;
		String tempFreq = gsRepaymentFrequency;

		gsRequestedLoanAmount = loanAmount;
		gsRequestedTerm = loanTerm;
		gsRepaymentFrequency = repaymentFrequency;

		prSeedSpecifiedPersonHalfPaidUpAgreementInPANUat(psPanCreditServiceServer);
		gsRequestedLoanAmount = tempAmount;
		gsRequestedTerm = tempTerm;
		gsRepaymentFrequency = tempFreq;
	}

	public void prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedPersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonActiveAgreement50PercentPaidUp");

		log.debug(psPanCreditServiceServer);
		log.debug(gsTitle);
		log.debug(gsFirstname);
		log.debug(gsSurname);
		log.debug(gsDOB);
		log.debug(gsStreet);
		log.debug(gsTownCity);
		log.debug(gsPostcode);

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		testCase.setPropertyValue("ptcLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcLoanTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcRepaymentFrequency", gsRepaymentFrequency);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");
		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://pfgnonprodapim.azure-api.net/sit/party-api/v2/person")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());
	}

	public void prSeedSpecifiedPersonHalfPaidUpAgreementInPANUat(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedPersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonActiveAgreement50PercentPaidUp");

		log.debug(psPanCreditServiceServer);
		log.debug(gsTitle);
		log.debug(gsFirstname);
		log.debug(gsSurname);
		log.debug(gsDOB);
		log.debug(gsStreet);
		log.debug(gsTownCity);
		log.debug(gsPostcode);

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcAccountName", gsBankAccountName);
		testCase.setPropertyValue("ptcAccountNumber", gsBankAccountNumber);
		testCase.setPropertyValue("ptcSortCode", gsBankSortcode);
		testCase.setPropertyValue("ptcAccountOpenDate", gsBankAccountOpenDate);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		testCase.setPropertyValue("ptcLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcLoanTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcRepaymentFrequency", gsRepaymentFrequency);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		String customerId = runner.getRunContext().expand("${RQ_PostPaymentToAgreement#Response#//PostPaymentToAgreement[1]/Agreement[1]/CustomerID}");
		log.info("CustomerID ----> " + customerId );

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);

		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String date = DATE_FORMAT.format(today);

		KeyStore keyStore = null;
		SSLConfig config = null;
		String password = "password";


		//Added the self signed certificate
		keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream("C:\\certificate\\PartyApiTestMock.p12"), password.toCharArray());
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

		// set the config in rest assured
		config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
		RestAssured.config = RestAssured.config().sslConfig(config);

		//Rest Assured test
		ValidatableResponse response = given()
				.contentType("application/x-www-form-urlencoded")
//				.header("Ocp-Apim-Subscription-Key", "104e29ee6ac348068634797d2a9b58c2")
				.header("Ocp-Apim-Subscription-Key", "ea78f3646c7b42c48a117ccff1febec7")
				.header("Content-Type", "application/json")
				.body("{\n    \"party\": {\n      \"partyType\": \"organisation\",\n      \"residentialStatusType\": \"notSet\",\n      \"organisationReference\": \"Ref1\",\n      \"createdDate\": \"" + date + "\",\n      \"partyNumber\": 17,\n      \"legalHoldInd\": true\n    },\n    \"partyConsents\": {\n      \"consents\": [\n        {\n          \"brand\": \"satsuma\",\n          \"consentType\": \"smsMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"web\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        },\n        {\n          \"brand\": \"ppcGB\",\n          \"consentType\": \"emailMarketing\",\n          \"consentVersion\": \"1\",\n          \"captureChannel\": \"email\",\n          \"optInInd\": true,\n          \"startDate\": \"2018-04-18T09:12:38Z\",\n          \"endDate\": \"\"\n        }\n      ]\n    },\n    \"partyXrefs\": {\n      \"partyParentInd\": true,\n      \"partyXref\": [\n        {\n          \"sourceType\": \"satsumaId\",\n          \"sourceId\": \"" + customerId + "\",\n          \"createdDate\": \"" + date + "\"\n        }\n      ]\n    }\n  }")
				.log()
				.all()
				.when().post("https://apipp.provident.services/PreProd/party-api/v2/person/")
				.then()
				.log()
				.all()
				.statusCode(201);
		log.info(response.toString());
	}

	public void prSeedUniqueFullPaidUpVulnerableAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueFullPaidUpVulnerableAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonVulnerableAgreement100PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedVulnerablePersonActiveAgreement50PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prLogIntoPanCreditFrontOffice() throws Exception {

	    Thread.sleep(500);
		// Log into PanCredit front office
		log.info("prLogIntoPanCreditFrontOffice: Logging into PanCredit Front Office: " + gsPanCreditServiceServer);

		getDriver().get(gsPanCreditServiceServer + "/panCoreSaas/app");

		// Check page attributes
		Assert.assertTrue(getDriver().getTitle().contains("pancredit"));

		waitForVisibilityOfElement(By.id("username"));
		waitForClickableElement(By.id("username"));
		getDriver().findElement(By.id("username")).sendKeys(gsPANFrontOfficeUid);
		getDriver().findElement(By.id("password")).sendKeys(gsPANFrontOfficePwd);

		getDriver().findElement(By.id("PanLinkSubmit")).click();
		 Thread.sleep(500);

		// Landed successfully
		// Assert.assertTrue(getDriver().getCurrentUrl().toLowerCase().contains(gsPanCreditServiceServer.toLowerCase()
		// + "/pancoresaas/app"));

	}

	public void prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(String psFirstname, String psSurname, String psPostcode, String psSurnameRename) throws Exception {

		while (true) {
			if (psSurnameRename.length() > 20)
				psSurnameRename = psSurnameRename.substring(0, 19);

			// Log into PanCredit front office
			log.info("prSearchForCustomerInPanCreditFrontOffice: Searching for customer: " + psFirstname + " " + psSurname + " " + psPostcode + " and renaming to " + psSurnameRename);

			getDriver().findElement(By.id("surname")).sendKeys(psSurname);
			getDriver().findElement(By.id("forename")).sendKeys(psFirstname);
			getDriver().findElement(By.id("postcode")).sendKeys(psPostcode);

			// Search now
			getDriver().findElement(By.id("PanLinkSubmit")).click();

			// Landed successfully
			Assert.assertEquals(gsPanCreditServiceServer.toLowerCase() + "/pancoresaas/app", getDriver().getCurrentUrl().toLowerCase());

			// View customer
			try {
				getDriver().findElement(By.xpath("//div[@class='results']/table/tbody/tr[2]/td[7]/a")).click();
			} catch (NoSuchElementException e) {
				// Assert.fail("Couldn't find customer, maybe they were already deleted?");
				log.warn("Couldn't find customer, maybe they were already deleted?");
				break;
			}

			getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

			Select dropdown;
			dropdown = new Select(getDriver().findElement(By.id("title")));
			dropdown.selectByVisibleText("Mr");
			getDriver().findElement(By.id("surname")).clear();
			getDriver().findElement(By.id("surname")).sendKeys(psSurnameRename);

			getDriver().findElement(By.id("forename")).clear();
			getDriver().findElement(By.id("forename")).sendKeys(psSurnameRename);

			prPANClickNameUpdateButton();

			// close window
			getDriver().findElement(By.id("PanLinkSubmit_4")).click();
		}

	}

	public void prNavigateToPANHome() throws Exception {
		// Logout of PanCredit Front Office
		log.info("prNavigateToHome: trying to click home tab");
		getDriver().findElement(By.xpath("//span[text()='Home']")).click();
	}

	public void prLogoutFromPanCreditFrontOfficeWithButton() throws Exception {
		// Logout of PanCredit Front Office
		log.info("prLogoutFromPanCreditFrontOffice: Logging out from PanCredit Front Office: " + gsPanCreditServiceServer);

		getDriver().findElement(By.linkText("Logout")).click();
	}

	public void prLogoutFromPanCreditFrontOffice() throws Exception {

		// Logout of PanCredit Front Office
		log.info("prLogoutFromPanCreditFrontOffice: Logging out from PanCredit Front Office: " + gsPanCreditServiceServer);

		getDriver().get(gsPanCreditServiceServer + "/panCoreSaas/app?component=%24PanDirectLink_48&page=HomePage&service=direct&session=T&state:HomePage=BrO0ABXcSAAAAAQAAC2N1cnJlbnRQYWdlc3IAEWphdmEubGFuZy5JbnRlZ2VyEuKgpPeBhzgCAAFJAAV2YWx1ZXhyABBqYXZhLmxhbmcuTnVtYmVyhqyVHQuU4IsCAAB4cAAAAAE%3D");

	}

	public void prNavigateToPANCreditAgreement(String psAgreementNumber) throws Exception {


		// Navigate to PAN Credit agreement
		log.info("prNavigateToPANCreditAgreement : Navigating to agreement " + psAgreementNumber);
        waitForVisibilityOfElement(By.id("agreementNumber"));
		getDriver().findElement(By.id("agreementNumber")).sendKeys(psAgreementNumber);
		getDriver().findElement(By.id("PanLinkSubmit_0")).click();
        waitForClickableElement(By.className("linkWithBullet"));
        getDriver().findElement(By.className("linkWithBullet")).click();
//		waitForClickableElement(By.xpath("//a[@href='/panCoreSaas/app?component=%24PanDirectLink&page=HomeExistingAgreements&service=direct&session=T&sp=S" + psAgreementNumber + "']"));
//		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?component=%24PanDirectLink&page=HomeExistingAgreements&service=direct&session=T&sp=S" + psAgreementNumber + "']")).click();

	}

	public void prNavigateToPANBankDetails() throws Exception {
		By byLinkBankDetails = By.linkText("Bank Details");
		waitForClickableElement(byLinkBankDetails);
		getDriver().findElement(byLinkBankDetails).click();
	}

	public void prAssertOnPageBankDetails() throws Exception {

		By byLbLBankName = By.cssSelector("[for='bankName']");
		By byLbLBranchName = By.cssSelector("[for='branchName']");

		Assert.assertEquals(getDriver().findElement(byLbLBankName).getText(), "Bank Name");
		Assert.assertEquals(getDriver().findElement(byLbLBranchName).getText(), "Branch Name");
	}

	By byTxtAccountName = By.id("accountName");
	By byTxtAccountNumber = By.id("accountNumber");
	By byTxtSortCode1 = By.id("sortCode1");
	By byTxtSortCode2 = By.id("sortCode2");
	By byTxtSortCode3 = By.id("sortCode3");
	By byContinueButton = By.id("PanLinkSubmit_0");

	// must use valid sort code
	public void prEditPANBankDetails(String accountName, String sortCode, String accountNo) throws Exception {

		// Navigate to PAN Credit agreement
		log.info("prEditPANBankDetails");

		getDriver().findElement(byTxtAccountName).sendKeys(accountName);
		getDriver().findElement(byTxtAccountNumber).sendKeys(accountNo);
		getDriver().findElement(byTxtSortCode1).sendKeys(sortCode.substring(0, 2));
		getDriver().findElement(byTxtSortCode2).sendKeys(sortCode.substring(2, 2));
		getDriver().findElement(byTxtSortCode3).sendKeys(sortCode.substring(4, 2));
		getDriver().findElement(byContinueButton).click();
	}

	// must use valid sort code
	public void prAssertPANBankDetails(String accountName, String sortCode, String accountNo) throws Exception {
		// Navigate to PAN Credit agreement
		log.info("prAssertPANBankDetails");
		waitForVisibilityOfElement(byTxtAccountName);
		Assert.assertEquals(getDriver().findElement(byTxtAccountName).getAttribute("value"), accountName);
		Assert.assertEquals(getDriver().findElement(byTxtAccountNumber).getAttribute("value"), accountNo);
		Assert.assertEquals(getDriver().findElement(byTxtSortCode1).getAttribute("value"), sortCode.substring(0, 2));
		Assert.assertEquals(getDriver().findElement(byTxtSortCode2).getAttribute("value"), sortCode.substring(2, 4));
		Assert.assertEquals(getDriver().findElement(byTxtSortCode3).getAttribute("value"), sortCode.substring(4, 6));

	}

	public void prPANRenameAgreementsApplicantSurname() throws Exception {

		// By renaming the applicant surname with prefix "AutoDel" we are
		// logically removing the agreement from the target test applicant
		// This technique is used to allow us to repeat the test using the same
		// test subject.

		prPANChangePersonTitle("Mr");
		String tmpStr = getDriver().findElement(By.id("surname")).getAttribute("value");
		String tmpStr2 = getDriver().findElement(By.id("forename")).getAttribute("value");
		if (!(tmpStr.contains("AutoDel"))) {
			getDriver().findElement(By.id("surname")).clear();
			getDriver().findElement(By.id("surname")).sendKeys("AutoDel" + tmpStr);
		}
		if (!(tmpStr2.contains("AutoDel"))) {
			getDriver().findElement(By.id("forename")).clear();
			getDriver().findElement(By.id("forename")).sendKeys("AutoDel" + tmpStr2);
		}

		prPANClickNameUpdateButton();

	}

	public void prPANRenameAgreementsApplicantSurname(String psAgreementNumber) throws Exception {

		// By renaming the applicant surname with prefix "AutoDel" we are
		// logically removing the agreement from the target test applicant
		// This technique is used to allow us to repeat the test using the same
		// test subject.
		log.info("prRenameAgreementsApplicantSurname: Renaming applicants surname on agreement " + psAgreementNumber);

		prPANRenameAgreementsApplicantSurname();

	}

	public void prPANClickNameUpdateButton() {
		boolean foundButton = false;
		try {
			new WebDriverWait(getDriver(), 2).until(ExpectedConditions.elementToBeClickable(By.linkText("Continue")));
			getDriver().findElement(By.linkText("Continue")).click();
			log.debug("Clicked continue button");
			foundButton = true;
		} catch (TimeoutException e) {
			log.warn("Couldn't find continue button, going to look for save button instead");
		}
		if (!foundButton) {
			new WebDriverWait(getDriver(), 2).until(ExpectedConditions.elementToBeClickable(By.linkText("Save")));
			getDriver().findElement(By.linkText("Save")).click();
			log.debug("Clicked save button");
		}
	}

	public void prAssertOnPageHome(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase();

		// Landed on Home page
		log.info("prAssertOnPageHome: Am I on expected landing page url - " + sExpectedPageUrl);

		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageYourApplication(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply";

		// Landed on Your Application page
		log.info("prAssertOnPageYourApplication: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageAboutYou(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/about-you";

		// Landed on About You page
		log.info("prAssertOnPageAboutYou: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		getDriver().navigate().refresh();
		Thread.sleep(200);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageLoanValueAdjustment(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/change-loan-amount";

		// Landed on Customer Authentication page
		log.info("prAssertOnPageLoanValueAdjustment: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageAuthentication(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/authentication";

		// Landed on Customer Authentication page
		log.info("prAssertOnPageAuthentication: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageYourFinances(String psSatsumaSiteUrl) throws Exception {

		Thread.sleep(200);
		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/income-and-outgoings";

		// Landed on Your Finances page
		log.info("prAssertOnPageYourFinances: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

	}

	public void prAssertOnPageVBLYourFinances(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "brokersatsuma/income-and-outgoings";

		// Landed on Your Finances page
		log.info("prAssertOnPageYourFinances: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

	}

	public void prAssertOnPageQuote(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/quote";

		// Landed on Quote page
		log.info("prAssertOnPageQuote: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageBankDetails(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/bank-details";

		// Landed on Bank Details page
		log.info("prAssertOnPageBankDetails: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageVBLBankDetails(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "brokersatsuma/bank-details";

		// Landed on Bank Details page
		log.info("prAssertOnPageBankDetails: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageCreditAgreement(String psSatsumaSiteUrl) throws Exception {

		By byCreditAgreementHeader = By.cssSelector("[id=loan-agreement-container] .central h1");
		(new WebDriverWait(getDriver(), 180)).until(ExpectedConditions.presenceOfElementLocated(byCreditAgreementHeader));

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "And finally...!", "check credit agreement header");

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/agreement";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageFLCreditAgreement(String psSatsumaSiteUrl) throws Exception {

		waitForVisibilityOfElement(By.cssSelector("#product-explanation-loan-amount"), 180);

		By byCreditAgreementHeader = By.cssSelector(".central h1");
		waitForVisibilityOfElement(byCreditAgreementHeader);

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "And finally...", "check credit agreement header");

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "further-lending/agreement";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageVBLCreditAgreement(String psSatsumaSiteUrl) throws Exception {

		waitForVisibilityOfElement(By.cssSelector("#product-explanation-loan-amount"), 180);

		By byCreditAgreementHeader = By.cssSelector("#JourneyForm > h2:nth-child(1)");

		waitForVisibilityOfElement(byCreditAgreementHeader);

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "Credit agreement", "check credit agreement header");

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "brokersatsuma/agreement";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageB2BCreditAgreement(String psSatsumaSiteUrl) throws Exception {
		waitForVisibilityOfElement(By.cssSelector("#product-explanation-loan-amount"), 180);

		By byCreditAgreementHeader = By.cssSelector("#loan-agreement-container .central h2");
		(new WebDriverWait(getDriver(), 180)).until(ExpectedConditions.presenceOfElementLocated(byCreditAgreementHeader));

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "Credit agreement", "check credit agreement header");

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "referral/agreement";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageHomeCredit(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "home-credit";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageHomeCredit: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		// Check that HCR page does not default the forename and Surname of the
		// applying Satsuma applicant
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerFirstnameSignature")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerSurnameSignature")).getAttribute("value"));
	}

	public void prAssertOnPagePayslip(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/payslip";

		// Landed on Payslip page
		log.info("prAssertOnPagePayslip: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageFinishedIDResult2(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result2 > Decline - We're sorry,
		// We’ve had a quick look at your Satsuma Loans account and based on
		// what we know we’ll be unable to continue with your application for a
		// further loan today
		// This is because you have reached the outstanding loan limit on your
		// account
		log.info("prAssertOnPageFinishedIDResult2: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result2")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult2: Finished Page: Not Result2 page - We're sorry, This is because you have reached the outstanding loan limit on your account.");
		}
	}

	public void prAssertOnPageFinishedIDResult3(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result3 > Decline - We can see that
		// you have already submitted an application for a Satsuma Loan
		log.info("prAssertOnPageFinishedIDResult3: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result3")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult3: Finished Page: Not Result3 page - We can see that you have already submitted an application for a Satsuma Loan");
		}
	}

	public void prAssertOnPageFinishedIDResult4(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result4 > Unfortunately, we are
		// unable to proceed with your application as we have been unable to
		// verify the agreement number you have entered and confirm your
		// identity
		log.info("prAssertOnPageFinishedIDResult4: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result4")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult4: Finished Page: Not Result4 page - Unfortunately, we are unable to proceed with your application as we have been unable to verify the agreement number you have entered and confirm your identity");
		}
	}

	public void prAssertOnPageFinishedIDResult5(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result5 > Thank you for your interest
		// in another Satsuma Loan. Unfortunately we're unable to process your
		// application for a further loan today.
		log.info("prAssertOnPageFinishedIDResult5: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result5")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult5: Finished Page: Thank you for your interest in another Satsuma Loan. Unfortunately we're unable to process your application for a further loan today.");
		}
	}

	public void prAssertOnPageFinishedIDResult25(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		log.info("prAssertOnPageFinishedIDResult25: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result25")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult25: Finished Page");
		}
	}

	public void prAssertOnPageFinishedIDResult7(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result7 > Generic Decline Thank you
		// for applying for a Satsuma Loan. Unfortunately your application has
		// not been successful on this occasion.
		log.info("prAssertOnPageFinishedIDResult7: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result7")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult7: Finished Page: Not Result7 page - Generic Decline - Thank you for applying for a Satsuma Loan. Unfortunately your application has not been successful on this occasion.");
		}
	}

	public void prAssertOnPageFinishedIDResult8(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result8 > Decline - You have
		// previously been declined for a Satsuma loan.
		// We can see that you have previously submitted an application for a
		// Satsuma Loan, which was unfortunately declined
		log.info("prAssertOnPageFinishedIDResult8: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result8")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult8: Finished Page: Not Result8 page - We can see that you have previously submitted an application for a Satsuma Loan, which was unfortunately declined");
		}
	}

	public void prAssertOnPageFinishedIDResult9(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Result9 > Thank you for applying for
		// a Satsuma Loan. Unfortunately your application has not been
		// successful on this occasion.
		log.info("prAssertOnPageFinishedIDResult9: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result9")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result9 page - Thank you for applying for a Satsuma Loan. Unfortunately your application has not been successful on this occasion.");
		}
	}

	public void prAssertOnPageFinishedIDResult22(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Resul22 > Thank you for applying for
		// a Satsuma Loan, We're sorry but we're unable to continue with your
		// application for a Satsuma Loan this time. Our checks at the Credit
		// Reference Agency have revealed information relating to you that has
		// contributed to our decision not to proceed with your application.
		log.info("prAssertOnPageFinishedIDResult22: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result22")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result22 page - Thank you for applying for a Satsuma Loan, We're sorry but we're unable to continue with your application for a Satsuma Loan this time. Our checks at the Credit Reference Agency have revealed information relating to you that has contributed to our decision not to proceed with your application.");
		}
	}

	public void prAssertOnPageFinishedIDResult23(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Resul23 > We're sorry but we can't
		// help today, We can see that you are currently a Home Credit Customer
		log.info("prAssertOnPageFinishedIDResult23: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result23")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result23 page -  We're sorry be can't help today, We can see that you are currently a Home Credit Customer.");
		}
	}

	public void prAssertOnPageFinishedIDResult24(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";

		// Landed on Finished page of type Resul24 > Thank you for applying for
		// a Satsuma Loan, Unfortunately your application
		// has not been successful on this occasion, Please note we've not
		// carried out a credit check as part of your application
		// todays and your credit record will not be affected.
		log.info("prAssertOnPageFinishedIDResult24: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result24")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result24 page -  We're sorry be can't help today, Please note we've not carried out a credit check as part of your application today and your credit record will not be affected.");
		}
	}

	public void prAssertOnPageCompletionIDResult11(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result11 > Your application is now
		// being processed and verified.
		// Within 24 hours customer care team will contact you whether your
		// application has been accepted.
		log.info("prAssertOnPageCompletionIDResult11: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result11")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult11: Completion Page: Not Result11 page - Your application is now being processed and verified. Within 24 hours customer care team will contact you whether your application has been accepted.");
		}
	}

	public void prAssertOnPageCompletionIDResult12(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result12 > Great news! Your next
		// Satsuma Loan has been approved in principle
		log.info("prAssertOnPageCompletionIDResult12: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result12")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult12: Completion Page: Not Result12 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved in principle.");
		}
	}

	public void prAssertOnPageCompletionIDResult13(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result13 > Great news! Your next
		// Satsuma Loan has been approved
		log.info("prAssertOnPageCompletionIDResult13: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result13")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult13: Completion Page: Not Result13 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageCompletionIDResult15(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result15 > Lets have a chat. We
		// will call you in the next 4 hours.
		log.info("prAssertOnPageCompletionIDResult15: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result15")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult15: Completion Page: Not Result15 page - Expecting page in context of Lets have a chat. We will call you in the next 4 hours.");
		}
	}

	public void prAssertOnPageCompletionIDResult16(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result16 > Waiting for your email
		log.info("prAssertOnPageCompletionIDResult16: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result16")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult16: Completion Page: Not Result16 page - Expecting page in context of Waiting for your email.");
		}
	}

	public void prAssertOnPageCompletionIDResult17(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result17 > Great news! Your loan
		// with Satsuma has been approved in principle. We just need to verify
		// your income. We will call you in the next 4 hours.
		log.info("prAssertOnPageCompletionIDResult17: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result17")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult17: Completion Page: Not Result17 page - Expecting page in context of Great news! Your loan with Satsuma has been approved in principle. We just need to verify your income. We will call you in the next 4 hours.");
		}
	}

	public void prAssertOnPageCompletionIDResult18(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result18 > Great news! Your loan
		// with Satsuma Loans has been approved in principle
		log.info("prAssertOnPageCompletionIDResult18: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result18")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult18: Completion Page: Not Result18 page - Expecting page in context of Great news! Your loan with Satsuma Loans has been approved in principle");
		}
	}

	public void prAssertOnPageCompletionIDResult19(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";

		// Landed on Completion page of type Result19 > Great news! Your Satsuma
		// Loan has been approved
		log.info("prAssertOnPageCompletionIDResult19: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result19")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result19 page - Expecting page in context of Great news! Your Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageB2BCompletionIDResult19(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "referral/complete";

		// Landed on Completion page of type Result19 > Great news! Your Satsuma
		// Loan has been approved
		log.info("prAssertOnPageCompletionIDResult19: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result19")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result19 page - Expecting page in context of Great news! Your Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageB2BCompletionIDResult13(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "referral/complete";

		// Landed on Completion page of type Result19 > Great news! Your Satsuma
		// Loan has been approved
		log.info("prAssertOnPageCompletionIDResult13: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result13")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result13 page - Expecting page in context of Great news! Your Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageVBLCompletionIDResult19(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "brokersatsuma/complete";

		// Landed on Completion page of type Result19 > Great news! Your Satsuma
		// Loan has been approved
		log.info("prAssertOnPageCompletionIDResult19: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result19")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result19 page - Expecting page in context of Great news! Your Satsuma Loan has been approved.");
		}
	}

	public void prFillInPageAboutYou() throws Exception {

		Thread.sleep(100);
		Select dropdown;

		if (gsPANAgreementNumber == null) {
			// Do you currently have, or have you previously had a Satsuma Loan?
			// - Default click is No
			if (!getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected()) {
				getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
			}
		} else if (gsPANAgreementNumber.isEmpty()) {
			// Do you currently have, or have you previously had a Satsuma Loan?
			// - Default click is No
			if (!getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected()) {
				getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
			}
		} else {
			if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
				getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
			}
			getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(gsPANAgreementNumber);
		}

		log.debug("loan amount: " + gsRequestedLoanAmount + " loan term: " + gsRequestedTerm + " " + gsRepaymentFrequency);

		// How much would you like to borrow ?
		// Loan Amount

		dropdown = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown")));
		dropdown.selectByValue(gsRequestedLoanAmount);

		String termText = "";

		if (!(monthlyOff.equalsIgnoreCase("true"))) {
			if (gsRepaymentFrequency.equals("Weekly")) {
				getDriver().findElement(By.id("SaysIsExistingCustomerNo")).sendKeys(Keys.TAB);
				// click weekly tab
				getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();
				termText = "weeks";
			} else if (gsRepaymentFrequency.equals("Monthly")) {
				getDriver().findElement(By.id("SaysIsExistingCustomerNo")).sendKeys(Keys.TAB);
				// click monthly tab
				getDriver().findElement(By.id("TermTypeAboutYouCalcMonthly")).click();
				termText = "months";
			} else {
				Assert.fail("Invalid loan frequency " + gsRepaymentFrequency);
			}
		} else {
			termText = "weeks";
		}
		// Requested Term
		dropdown = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")));

		// try to select term, if can't find element try again after 0.5 second
		// up to 3 times
		int retries = 2;
		while (true)
			try {
				dropdown.selectByVisibleText(gsRequestedTerm + " " + termText);
				break;
			} catch (ElementNotFoundException e) {
				if (retries > 0) {
					log.warn("Couldn't find the term option '" + gsRequestedTerm + " " + termText + "' trying again, retries: " + retries);
					Thread.sleep(500);
					retries--;
				} else {
					throw e;
				}
			}
		// Validate selected pricing details
		String actualRepayment = getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText();
		String actualTap = getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText();
		String actualInterest = getDriver().findElement(By.id("TotalInterestAboutYouCalcText")).getText();

		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedRepayment), actualRepayment);
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedTAP), actualTap);
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedInterest), actualInterest);

		// On which day of the week would you like to make your repayments, only
		// applicable for Weekly Frequency

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();

		}

		String firstRepaymentDate = "";
		String lastRepaymentDate = "";
		String preferredPaymentDay = "";

		if (gsRepaymentFrequency.equals("Weekly")) {


			getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB));
			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
			scrollToElement(getDriver().findElement(By.id("PreferredPaymentDayValue")));
//			dropdown.selectByVisibleText("Friday");
			Thread.sleep(200);
			dropdown.selectByVisibleText(gsPreferredPaymentDow);
			Thread.sleep(500);

			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Weekly", gsPreferredPaymentDow);
			lastRepaymentDate = getLastRepaymentDate("Weekly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDow;

		} else if (gsRepaymentFrequency.equals("Monthly")) {

			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayOfMonthValue")));
			scrollToElement(getDriver().findElement(By.id("PreferredPaymentDayOfMonthValue")));
			if ((gsPreferredPaymentDom == null) || (gsPreferredPaymentDom.equals("")))
				gsPreferredPaymentDom = "1st";

			dropdown.selectByVisibleText(gsPreferredPaymentDom);

			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Monthly", gsPreferredPaymentDom);
			lastRepaymentDate = getLastRepaymentDate("Monthly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDom;
		} else {
			log.error("Invalid repayment frequency");
		}

		// verify first payment date and last payment date
		By byFirstPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(1)");
		By bySelectedPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(2)");
		By byLastPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(3)");

		waitForRefresh(byFirstPaymentDateText);
		waitForVisibilityOfElement(byFirstPaymentDateText);

		String[] temp = getDriver().findElement(byFirstPaymentDateText).getText().split(" ");
		String actualFirstPaymentDate = formatDate(temp[6].substring(0, temp[6].length() - 2) + " " + temp[7] + " " + temp[8], "dd MMMM yyyy", "dd/MM/yyyy");

		waitForVisibilityOfElement(bySelectedPaymentDateText);
		String actualSelectedPaymentDate = getDriver().findElement(bySelectedPaymentDateText).getText().split(" ")[2];

		waitForVisibilityOfElement(byLastPaymentDateText);
		temp = getDriver().findElement(byLastPaymentDateText).getText().split(" ");
		String actualLastPaymentDate = formatDate(temp[6].substring(0, temp[6].length() - 2) + " " + temp[7] + " " + temp[8], "dd MMMM yyyy", "dd/MM/yyyy");

		Assert.assertEquals(actualFirstPaymentDate, firstRepaymentDate);
		Assert.assertEquals(actualSelectedPaymentDate.replace(".", ""), preferredPaymentDay);
		Assert.assertEquals(actualLastPaymentDate, lastRepaymentDate);

		// What will you use your loan for?*
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText(gsLoanPurpose);

		// Please read our website cookie policy and tick this box to agree -
		// Tick please
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Personal Details
		// ----------------

		// Applicants Title
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText(gsTitle);
		// Applicants Firstname
		getDriver().findElement(By.id("Forename")).sendKeys(gsFirstname);
		// Applicants Surname
		getDriver().findElement(By.id("Surname")).sendKeys(gsSurname);

		log.debug("Applicant details:" + gsFirstname + " | " + gsSurname + " | " + gsDOB + " | " + gsPostcode + " | " + gsEmailAddress);

		getDriver().findElement(By.id("DateOfBirth_Day")).sendKeys(Keys.TAB);

		// Applicants DOB - Day
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText(gsDOB.substring(0, 2));
		// Applicants DOB - Month
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gsDOB.substring(3, 5)));
		// Applicants DOB - Year
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText(gsDOB.substring(6, 10));
		// Applicants Marital Status
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText(gsMaritalStatus);
		// Applicants Number Of Dependants
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText(gsNumberOfDependants);

		// Your Address
		// ------------

		// Applicants Residential Status
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText(gsResidentialStatus);

		log.debug("moved in month: " + gtb.fn_GetMonthFullWording(gsCurrentHouseMovedInDate.substring(3, 5)) + " moved in year: " + gsCurrentHouseMovedInDate.substring(6, 10));

		// Applicants Current Address Moved In Date
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gsCurrentHouseMovedInDate.substring(3, 5)));
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(gsCurrentHouseMovedInDate.substring(6, 10));

		getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")).sendKeys(Keys.TAB);

		WebDriverWait wait = new WebDriverWait(getDriver(), 30);

		WebElement linkCurrentAddressManualEntry = getDriver().findElement(By.id("CurrentAddressManualEntry"));

		// tab house number to get manual address element on screen
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).sendKeys(Keys.TAB);

		// tab house number to get manual address element on screen
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys(Keys.TAB);

		// sendkeys instead of click as element is not clickable exception keeps
		// happening in chrome
		linkCurrentAddressManualEntry.sendKeys(Keys.SPACE);

		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentAddress_FlatNumber")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentAddress_FlatNumber")));

		// Flat number
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_FlatNumber")), gsFlatNumber);

		// House/Building name
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_BuildingName")), gsBuildingName);

		// House Number
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_HouseNumber")), gsBuildingNumber);

		// Street
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_Street")), gsStreet);

		// District
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_District")), gsDistrict);

		// Town/City
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_TownCity")), gsTownCity);

		// County
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_County")), gsCounty);

		// Postcode
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_Postcode")), gsPostcode);

		// // May want to specify a previous address if moved in date is less
		// than
		// // 3 years

		SimpleDateFormat dateIn = new SimpleDateFormat("dd/MM/yyyy");

		// get real date object
		Date tempDate = (new DateTime(dateIn.parse(gsCurrentHouseMovedInDate))).plusYears(3).toDate();
		Date currentDate = new Date();

		// check if its less then 3 years old
		if (tempDate.after(currentDate)) {

			// Postcode BD1 2SU should only return 1 address at No 1 Godwin
			// Street
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).clear();
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD1 2SU");
			// Search now, click keeps failing due to hovering divs
			getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.PAGE_DOWN);
			getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();

			int buttonClickRetries = 0;

			while (buttonClickRetries < 3) {
				try {
					// wait until the drop down appears
					wait.until(ExpectedConditions.visibilityOf(getDriver().findElement(By.id("PreviousAddress_PreviousAddressChosenAddress"))));
					break;
				} catch (TimeoutException e) {
					log.warn("Previous address dropdown didn't appear, will try again...");
					// Search now, click keeps failing due to hovering divs
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.PAGE_DOWN);
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
					buttonClickRetries++;
				} catch (NoSuchElementException e) {
					log.warn("Previous address dropdown didn't appear, will try again...");
					// Search now, click keeps failing due to hovering divs
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.PAGE_DOWN);
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
					buttonClickRetries++;
				} catch (StaleElementReferenceException e) {
					log.warn("Previous address dropdown didn't appear, will try again...");
					// Search now, click keeps failing due to hovering divs
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.PAGE_DOWN);
					getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
					buttonClickRetries++;
				}
			}

			dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_PreviousAddressChosenAddress")));
			if (dropdown.getOptions().size() != 2) {
				Assert.fail("Failed: Expecting only 1 address to be listed");
			}

			// Assert that the single address found is selected automatically
			Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", new Select(getDriver().findElement(By.id("PreviousAddress_PreviousAddressChosenAddress"))).getFirstSelectedOption().getText());

			String previousAddressMoveInYear = "2000";
			String previousAddressMoveInMonth = "January";

			// enter previous address move in date
			dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
			dropdown.selectByVisibleText(previousAddressMoveInMonth);
			dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
			dropdown.selectByVisibleText(previousAddressMoveInYear);
		}

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(gsMobileNumber);
		// Applicant Email Address
		getDriver().findElement(By.id("EmailAddress")).sendKeys(gsEmailAddress);

		// get to bottom of screen
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.PAGE_DOWN);
		waitForVisibilityOfElement(By.id("ContinueButton"));

		// Marketing Options
		selectContactPrefs(Boolean.parseBoolean(gsMarketingOptInEmail), Boolean.parseBoolean(gsMarketingOptInSMS), Boolean.parseBoolean(gsMarketingOptInPost), Boolean.parseBoolean(gsMarketingOptInPhone));

		takeIncrementScreenshot();
	}

	// works out last repayment date
	public String getLastRepaymentDate(String termType, String firstRepaymentDateStr, int gsRequestedTerm) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		// convert first repayment date
		Date firstRepaymentDate = null;
		try {
			firstRepaymentDate = sdf.parse(firstRepaymentDateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// get current date
		Calendar finalRepaymentDate = Calendar.getInstance();
		finalRepaymentDate.setTime(firstRepaymentDate);

		// if monthly then add months
		if (termType.equalsIgnoreCase("Monthly")) {
			finalRepaymentDate.add(Calendar.MONTH, (gsRequestedTerm - 1));

			System.out.println(finalRepaymentDate);
		} else {
			// else weekly add weeks
			finalRepaymentDate.add(Calendar.WEEK_OF_YEAR, (gsRequestedTerm - 1));
		}

		Date returnDate = finalRepaymentDate.getTime();

		return sdf.format(returnDate);
	}

	// works out first repayment date
	public String getFirstRepaymentDate(String currentDateStr, String termType, String gsPreferredPaymentDay) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		// if term is weekly
		if (termType.equalsIgnoreCase("Weekly")) {
			Date currentDate = null;
			SimpleDateFormat dateIn = new SimpleDateFormat("dd/MM/yyyy");
			try {
				currentDate = dateIn.parse(currentDateStr);
			} catch (ParseException e) {
				log.error("Error currentDate is not a valid date in format dd/MM/yyyy");
			}

			int iDoW;
			int iReqDoW = 0;

			switch (gsPreferredPaymentDay.toUpperCase()) {
			case "SATURDAY":
				iReqDoW = 0;
				break;
			case "SUNDAY":
				iReqDoW = 1;
				break;
			case "MONDAY":
				iReqDoW = 2;
				break;
			case "TUESDAY":
				iReqDoW = 3;
				break;
			case "WEDNESDAY":
				iReqDoW = 4;
				break;
			case "THURSDAY":
				iReqDoW = 5;
				break;
			case "FRIDAY":
				iReqDoW = 6;
				break;
			}
			// Get todays date
			Calendar now = Calendar.getInstance();
			now.setTime(currentDate);

			iDoW = now.get(Calendar.DAY_OF_WEEK);

			// if requested day of week is later then current day of week
			if (iReqDoW >= iDoW) {
				// go to next week plus difference up to requested day
				now.add(Calendar.DATE, 7 + iReqDoW - iDoW);
				// log.debug("req day later than or same as current day");
			} else {
				// if its earlier in the week, we gotta go 7 days + up to
				// requested
				// day
				// log.debug("req day earlier than current day");
				now.add(Calendar.DATE, 14 - (iDoW - iReqDoW));
			}

			// SimpleDateFormat sdf = new SimpleDateFormat("d'%s' MMMMM yyyy");
			// String myDate = String.format(sdf.format(now.getTime()),
			// dateSuffix(now));

			return sdf.format(now.getTime());

			// if term is monthly
		} else {

			int preferredDay = Integer.parseInt(gsPreferredPaymentDay.substring(0, gsPreferredPaymentDay.length() - 2));

			// if payment date is < 28 days from now

			// parse date
			Date currentDate = null;
			try {
				currentDate = sdf.parse(currentDateStr);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Calendar nowPlus28 = Calendar.getInstance();
			nowPlus28.setTime(currentDate);

			// add 28 days to current date
			nowPlus28.add(Calendar.DAY_OF_YEAR, 28);

			// get date next month for day selected
			Calendar nextMonthSelectedDay = Calendar.getInstance();
			nextMonthSelectedDay.setTime(currentDate);
			nextMonthSelectedDay.add(Calendar.MONTH, 1);
			nextMonthSelectedDay.set(Calendar.DAY_OF_MONTH, preferredDay);

			// if current_date_28 > date_next_month
			// make payment date this month
			if (nowPlus28.after(nextMonthSelectedDay)) {
				// return following month selected day
				nextMonthSelectedDay.add(Calendar.MONTH, 1);
			}
			Date returnDate = nextMonthSelectedDay.getTime();
			return sdf.format(returnDate);
		}
	}

	private void waitForOptionsToLoad(final Select dropdown, final int expectedNoOptions) {
		WebDriverWait wait = new WebDriverWait(getDriver(), 10);
		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver arg0) {
				return dropdown.getOptions().size() > expectedNoOptions;
			}
		});
		log.debug("Waited for " + expectedNoOptions + " options on dropdown " + dropdown.toString());
	}

	public void prFillInPageYourFinances(CustomerType customerType) throws Exception {
		Thread.sleep(100);
		prFillInPageYourFinances();
		By byChkOptInSummaryOfBorrowing = By.id("OptInToSummaryOfBorrowingEmail");
		By byChkAckSummaryOfBorrowing = By.id("SummaryOfBorrowingAcknowledged");
		By byLblAckSummaryBorrowingPleaseAccept = By.cssSelector("span[for=SummaryOfBorrowingAcknowledged]");

		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.PAGE_DOWN);

		// added for CMA based on customer type
		switch (customerType) {
		case NEW_CUSTOMER:
			// for new customers verify that summary of borrowing email is
			// available
			// and then check it
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
			scrollToElement(getDriver().findElement(byChkOptInSummaryOfBorrowing));
			getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");
			break;
		case ACTIVE_CUSTOMER:
			// for existing customers verify that summary of borrowing email is
			// available
			// and then check it
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
			scrollToElement(getDriver().findElement(byChkOptInSummaryOfBorrowing));
			getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");

			Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == false, "check ack summary of borrowing is unchecked");

			// try to proceed without clicking
			prClickForNextAction();

			// verify message appears
			Assert.assertEquals(getDriver().findElement(byLblAckSummaryBorrowingPleaseAccept).getText(), "Please accept to proceed", "mandatory ack summary of borrowing checkbox");

			// now check it and continue
			scrollToElement(getDriver().findElement(byChkOptInSummaryOfBorrowing));

			getDriver().findElement(byChkAckSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == true, "check ack summary of borrowing is now checked");

			break;
		case EXISTING_NOT_ACTIVE_CUSTOMER:
			// for existing customers verify that summary of borrowing email is
			// available
			// and then check it
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
			getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");
            getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == false, "check ack summary of borrowing is unchecked");

			// try to proceed without clicking
			prClickForNextAction();

			// verify message appears
			Assert.assertEquals(getDriver().findElement(byLblAckSummaryBorrowingPleaseAccept).getText(), "Please accept to proceed", "mandatory ack summary of borrowing checkbox");

			// now check it and continue
			getDriver().findElement(byChkAckSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == true, "check ack summary of borrowing is now checked");

			break;
		case LOGIN_CUSTOMER:
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
			getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
			Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");
			break;
		case B2B_CUSTOMER:

			break;
		default:
			Assert.fail("Not valid customer type");
			break;
		}
	}

	private void prFillInPageYourFinances() throws Exception {

		// Fill in Applicants finance details with stored applicant profile data
		log.info("prFillInPageYourFinances: Applicant profile data used to fill in page attributes.");

		Select dropdown;

		// Income source
		dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));

		switch (gsSourceOfIncome.toLowerCase()) {
		case "full time employment only":
			gsSourceOfIncome = "Full Time Employment Only";
			break;
		case "part time employment only":
			gsSourceOfIncome = "Part Time Employment Only";
			break;
		case "pension":
			gsSourceOfIncome = "Retired ( Pension)";
			break;
		case "self employed":
			gsSourceOfIncome = "Self Employed";
			break;
		case "benefits":
			gsSourceOfIncome = "Benefits";
			break;
		case "benefits and part time employment":
			gsSourceOfIncome = "Benefits And Part Time Employment";
			break;
		case "benefits and full time employment":
			gsSourceOfIncome = "Benefits And Full Time Employment";
			break;
		}

		dropdown.selectByVisibleText(gsSourceOfIncome);

		// Income
		getDriver().findElement(By.id("Income")).clear();
		getDriver().findElement(By.id("Income")).sendKeys(gsIncome);
		log.debug("income: " + gsIncome);

		// Income Frequency
		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText(gsIncomeFrequency);

		log.debug("income freq: " + gsIncomeFrequency);

		if (gsIncomeFrequency.equalsIgnoreCase("weekly")) {

			// NEW: day you receive this income
			dropdown = new Select(getDriver().findElement(By.id("WeeklyIncomeDay")));
			dropdown.selectByVisibleText(gsPreferredPaymentDow);

			log.debug("dow: " + gsPreferredPaymentDow);

		} else if (gsIncomeFrequency.equalsIgnoreCase("fortnightly")) {
			// NEW: day you receive this income
			dropdown = new Select(getDriver().findElement(By.id("FortnightlyIncomeDay")));
			dropdown.selectByVisibleText(gsPreferredPaymentDow);

			log.debug("dow: " + gsPreferredPaymentDow);

		} else if (gsIncomeFrequency.equalsIgnoreCase("monthly")) {
			// if monthly then you must select last business day, fixed date or
			// particular day
			dropdown = new Select(getDriver().findElement(By.id("MonthlyIncomeOption")));
			dropdown.selectByVisibleText("Last Working Day Of The Month");

			log.debug("dom: 1st");
			// last business day

			// fixed date x day of the month

			// particular day 1st-4th monday/tuesday/wednesday/thursday...etc

			// else: there is no payment day option
		} else if (gsIncomeFrequency.equalsIgnoreCase("annually")) {

		} else {
			Assert.fail("invalid income frequency");
		}

		// Income Method
		dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
		dropdown.selectByVisibleText(gsIncomePaymentMethod);

		// Housing costs amount
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(gsHousingCosts);

		log.debug("housing costs: " + gsHousingCosts);
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);

		if ((Integer.parseInt(gsHousingCosts) > 3000) || (Integer.parseInt(gsHousingCosts) == 0)) {
			// added for affordability
			if (!getDriver().findElement(By.id("HousingCostsAmountCheck")).isSelected()) {
				// element is not clickable in chrome
				// getDriver().findElement(By.id("HousingCostsAmountCheck")).click();
				getDriver().findElement(By.id("HousingCostsAmountCheck")).sendKeys(Keys.SPACE);
			}
		}

		boolean loansOrOtherCreditCards = false;

		log.debug("has credit cards: " + gsHasCreditCards);

		// Has Credit cards
		if (gsHasCreditCards.toLowerCase().equals("true") && !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).sendKeys(Keys.SPACE);

			loansOrOtherCreditCards = true;
		} else if (gsHasCreditCards.toLowerCase().equals("false") && !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).sendKeys(Keys.SPACE);
		}

		log.debug("has other loans: " + gsHasExistingLoans);

		// Has Other Loans
		if (gsHasExistingLoans.toLowerCase().equals("true") && !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).sendKeys(Keys.SPACE);

			loansOrOtherCreditCards = true;
		} else if (gsHasExistingLoans.toLowerCase().equals("false") && !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).sendKeys(Keys.SPACE);
		}

		log.debug("monthly loan repayments: " + gsMonthlyLoanRepayments);

		if (loansOrOtherCreditCards) {
			if (!(gsMonthlyLoanRepayments.equalsIgnoreCase("0")))
				getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(gsMonthlyLoanRepayments);
			else
				getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("1");

		}

		log.debug("other outgoings: " + gsMonthlyOtherOutgoings);

		// Other outgoings
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(gsMonthlyOtherOutgoings);
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);

		if (Integer.parseInt(gsMonthlyOtherOutgoings) == 0) {

			// Added for affordability
			getDriver().findElement(By.id("OtherOutgoingsAmountCheck")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("OtherOutgoingsAmountCheck")).click();

		}
		// check totals for affordability

		// String totalIncome =
		// String totalOutgoings =
		// String totalDisIncome =

		// totalIncome totalOutgoings totalDispIncome

		// Added for affordability
		getDriver().findElement(By.id("IncomeConfirmed")).sendKeys(Keys.TAB);
		if (!getDriver().findElement(By.id("IncomeConfirmed")).isSelected()) {
			scrollToElement(getDriver().findElement(By.id("IncomeConfirmed")));
			getDriver().findElement(By.id("IncomeConfirmed")).click();
		}

		// removed consents S2 2017.0.31

	}

	public void prAssertQuoteOfferAsPerRequest() throws Exception {

		String termText = "";
		String firstRepaymentDate = "";
		String lastRepaymentDate = "";
		String preferredPaymentDay = "";
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if (gsRepaymentFrequency.equals("Weekly")) {
			termText = "weeks";
			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Weekly", gsPreferredPaymentDow);
			lastRepaymentDate = getLastRepaymentDate("Weekly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDow;

		} else if (gsRepaymentFrequency.equals("Monthly")) {

			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Monthly", gsPreferredPaymentDom);
			lastRepaymentDate = getLastRepaymentDate("Monthly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDom;
			termText = "months";
		} else {
			Assert.fail("Invalid loan frequency " + gsRepaymentFrequency);
		}

		String actualRequestedLoanAmount = getDriver().findElement(By.id("LoanAmountCell")).getText();
		String actualRepayment = getDriver().findElement(By.id("InstalmentAmountCell")).getText().replace(",", "");
		String actualTap = getDriver().findElement(By.id("TotalAmountPayableCell")).getText().replace(",", "");

		// Check offer as requested
		Assert.assertEquals(formatCurrencyToDisplayNoDPNoComma(gsRequestedLoanAmount), actualRequestedLoanAmount);
		Assert.assertEquals(gsRequestedTerm + " " + termText, getDriver().findElement(By.id("LoanTermCell")).getText());
		Assert.assertEquals("£" + gsExpectedRepayment, actualRepayment);
		Assert.assertEquals("£" + gsExpectedTAP, actualTap);
		Assert.assertEquals(gsExpectedAPR + "%", getDriver().findElement(By.id("AprCell")).getText());

		// verify first payment date and last payment date
		By byFirstPaymentDateText = By.id("FirstPaymentDateCell");

		String actualFirstPaymentDate = getDriver().findElement(byFirstPaymentDateText).getText();

		// format date as on website

		Date dateFirstRepaymentDate = sdf.parse(firstRepaymentDate);
		Calendar calFirstRepaymentDate = Calendar.getInstance();
		calFirstRepaymentDate.setTime(dateFirstRepaymentDate);

		SimpleDateFormat dateFormatQuote = new SimpleDateFormat("EEEEE 'the' d'%s' 'of' MMMMM yyyy");
		String strFirstRepaymentDate = String.format(dateFormatQuote.format(calFirstRepaymentDate.getTime()), dateSuffix(calFirstRepaymentDate));

		Assert.assertEquals(actualFirstPaymentDate, strFirstRepaymentDate);

	}

	public void prFillInPageBankDetails() throws Exception {

		By byDdAccountOpenMonth = By.id("DisplayAccountOpened_Month");
		By byDdAccountOpenYear = By.id("DisplayAccountOpened_Year");

		// Fill in Applicants bank details with stored applicant profile data
		log.info("prFillInPageBankDetails: Applicant profile data used to fill in page attributes.");

		Select dropdown;

		// Account Holder
		getDriver().findElement(By.id("AccountHolder")).clear();
		getDriver().findElement(By.id("AccountHolder")).sendKeys(gsBankAccountName);

		getDriver().findElement(By.id("SortCode_Part1")).clear();
		getDriver().findElement(By.id("SortCode_Part2")).clear();
		getDriver().findElement(By.id("SortCode_Part3")).clear();

		// Account Sort Code
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys(gsBankSortcode.substring(0, 2));
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys(gsBankSortcode.substring(2, 4));
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys(gsBankSortcode.substring(4, 6));

		// Account Number
		getDriver().findElement(By.id("AccountNumber")).clear();
		getDriver().findElement(By.id("AccountNumber")).sendKeys(gsBankAccountNumber);

		// When did you open your account with the bank?
		// dropdown = new
		// Select(getDriver().findElement(By.id("DisplayAccountOpened_Month")));
		dropdown = new Select(getDriver().findElement(byDdAccountOpenMonth));
		String sMMM = "NotSet";
		String sMM = gsBankAccountOpenDate.substring(3, 5).replaceFirst("^0*", "");
		/*
		 * switch (sMM) { case "1" : sMMM = "January"; break; case "2" : sMMM =
		 * "February"; break; case "3" : sMMM = "March"; break; case "4" : sMMM
		 * = "April"; break; case "5" : sMMM = "May"; break; case "6" : sMMM =
		 * "June"; break; case "7" : sMMM = "July"; break; case "8" : sMMM =
		 * "August"; break; case "9" : sMMM = "September"; break; case "10" :
		 * sMMM = "October"; break; case "11" : sMMM = "November"; break; case
		 * "12" : sMMM = "December"; break; }
		 * dropdown.selectByVisibleText(sMMM);
		 */
		dropdown.selectByValue(sMM);
		// dropdown = new
		// Select(getDriver().findElement(By.id("DisplayAccountOpened_Year")));
		dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		dropdown.selectByVisibleText(gsBankAccountOpenDate.substring(6, 10));
	}

	public void prFillInPageBankDetailsRandom() throws Exception {
		Thread.sleep(100);
		setRandomBankDetails();

		prFillInPageBankDetails();
	}

	public void setRandomBankDetails() {
		// override account number with random
		gsBankSortcode = Integer.toString(ThreadLocalRandom.current().nextInt(100000, 999999 + 1));
		gsBankAccountNumber = Integer.toString(ThreadLocalRandom.current().nextInt(10000000, 99999999 + 1));
	}

	public void prFillInTestWorldPayAndRespond(String psPaRes, String psCVCRes, String psAVSRes, String satsumaSiteUrl) throws Exception {
		Thread.sleep(100);
		// Fill in WorldPay pages with applicant profile and respond with
		// required WorldPay Card response
		log.info("prFillInTestWorldPayAndRespond: Applicant profile data used to fill in page attributes. Response required PaRes:" + psPaRes + " CVCRes:" + psCVCRes + " AVSRes:" + psAVSRes);

		Select dropdown;

		waitForTitle("Card Details");
		Assert.assertEquals(getDriver().getTitle(), "Card Details", "Check page title");

		// // Has Mastercard, Visa Debit or Maestro
		// if (gsCreditCardType.equals("Mastercard")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-ECMC^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-ECMC^SSL']")).click();
		// } else if (gsCreditCardType.equals("Visa Debit")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-VISA^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-VISA^SSL']")).click();
		// } else if (gsCreditCardType.equals("Maestro")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-MAESTRO^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-MAESTRO^SSL']")).click();
		// } else {
		// Assert.fail("Aborted: Applicant Profile used must define CreditCardType as either Mastercard, Visa Debit or Maestro");
		// }
		//
		// int retries = 2;
		// // had issue with geckodriver jumping ahead without click registering
		// while (true) {
		// try {
		// waitForVisibilityOfElement(By.xpath("//input[@id='cardNoInput']"));
		// break;
		// } catch (NoSuchElementException e) {
		// if (retries == 0) {
		// Assert.fail("Couldn't find CardNum input element");
		// break;
		// }
		// log.debug("click didn't seem to work trying again, retries: " +
		// retries);
		// // Has Mastercard, Visa Debit or Maestro
		// if (gsCreditCardType.equals("Mastercard")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-ECMC^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-ECMC^SSL']")).click();
		// } else if (gsCreditCardType.equals("Visa Debit")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-VISA^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-VISA^SSL']")).click();
		// } else if (gsCreditCardType.equals("Maestro")) {
		// waitForClickableElement(By.cssSelector("input[name='op-DPChoose-MAESTRO^SSL']"));
		// getDriver().findElement(By.cssSelector("input[name='op-DPChoose-MAESTRO^SSL']")).click();
		// } else {
		// Assert.fail("Aborted: Applicant Profile used must define CreditCardType as either Mastercard, Visa Debit or Maestro");
		// }
		// retries--;
		// }
		// }

		getDriver().findElement(By.id("cardNumber")).click();
		getDriver().findElement(By.id("cardNumber")).sendKeys(gsCreditCardNumber);
		getDriver().findElement(By.id("cardholderName")).click();
		getDriver().findElement(By.id("cardholderName")).sendKeys(gsBankAccountName);
		dropdown = new Select(getDriver().findElement(By.id("expiryMonth")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(0, 2));
		dropdown = new Select(getDriver().findElement(By.id("expiryYear")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(3, 7));

		waitForRefresh(By.className("smallIcons"));
		getDriver().findElement(By.id("securityCode")).click();
		getDriver().findElement(By.id("securityCode")).sendKeys(gsCreditCardCVS);
		getDriver().findElement(By.id("pin-helpimg")).click();

		takeIncrementScreenshot();

		// Invoke Next action: Simulator Test Page
		By byBtnMakePayment = By.id("submitButton");
		waitForClickableElement(byBtnMakePayment);
		getDriver().findElement(byBtnMakePayment).click();

		// waitForTitle("Simulator page");
		// Assert.assertEquals(getDriver().getTitle(), "Simulator page",
		// "Assert we are on the simulator page");
		//
		// try {
		//
		// // wait for elements to be clickable
		// waitForClickableElement(By.name("PaRes"));
		// waitForClickableElement(By.name("CVCRes"));
		// waitForClickableElement(By.name("AVSRes"));
		//
		// // Simulate Approved response - Postcode and address matched
		// dropdown = new Select(getDriver().findElement(By.name("PaRes")));
		// dropdown.selectByVisibleText(psPaRes);
		// dropdown = new Select(getDriver().findElement(By.name("CVCRes")));
		// dropdown.selectByVisibleText(psCVCRes);
		// dropdown = new Select(getDriver().findElement(By.name("AVSRes")));
		// dropdown.selectByVisibleText(psAVSRes);
		//
		// takeIncrementScreenshot();
		//
		// } catch (TimeoutException e) {
		// log.error("Timed out waiting for URL: " +
		// getDriver().getCurrentUrl());
		// throw new TimeoutException(e);
		// }
		//
		// // Invoke Next action:
		// final By byWorldPayContinueButton =
		// By.xpath("//input[@name='continue']");
		// waitForClickableElement(byWorldPayContinueButton);
		// //
		// getDriver().findElement(byWorldPayContinueButton).sendKeys(Keys.TAB);
		// getDriver().findElement(byWorldPayContinueButton).click();
		// // uses enter instead so we can check for the holding page
		// //
		// getDriver().findElement(byWorldPayContinueButton).sendKeys(Keys.ENTER);
		//
		// // wait for small loading window
		// // waitForExistenceOfElement(By.cssSelector(".loading-anim"));
		// // takeIncrementScreenshot();
	}

	public void prReadAndSignCreditAgreement() throws Exception {

		By byChkReadAgreement = By.id("ReadLoanAgreement");

		// changed since S3, now a single checkbox, select read agreement
		scrollToBottomOfElement(getDriver().findElement(By.cssSelector(".loan-agreement")));
		By bySpanReadLoanAgreement = By.xpath("//span[@data-valmsg-for='ReadLoanAgreement']");

		// checkbox
		getDriver().findElement(byChkReadAgreement).sendKeys(Keys.SPACE);

		// keep trying to select checkbox 3 times until successful
		int retries = 2;
		while (true) {
			try {
				Thread.sleep(500); // needs to wait to allow message to appear
				(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.elementToBeSelected(byChkReadAgreement));
				break;
			} catch (TimeoutException e) {
				log.warn("Didn't click read agreement checkbox successfully, retries: " + retries);
				scrollToBottomOfElement(getDriver().findElement(By.cssSelector(".loan-agreement")));
				getDriver().findElement(byChkReadAgreement).sendKeys(Keys.SPACE);
				if (retries < 1)
					throw e;
			}
			retries--;
		}

		Assert.assertEquals(getDriver().findElement(bySpanReadLoanAgreement).getText(), "");

		// Signature of Customer
		// ---------------------
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gsFirstname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gsSurname);

	}

	public void scrollToBottomOfElement(WebElement element) {
		// scroll div to the bottom, measured 13 key presses to get to the
		// bottom
		for (int i = 0; i < 25; i++) {
			element.sendKeys(Keys.PAGE_DOWN);
		}
	}

	public void prClickForNextAction() throws Exception {

		// Invoke Next action
		// scrollToElement(
		// getDriver().findElement(By.id("ContinueButton")));

		takeIncrementScreenshot();
		Thread.sleep(200);
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.PAGE_DOWN);
		waitForVisibilityOfElement(By.id("ContinueButton"));
		waitForClickableElement(By.id("ContinueButton"));
		takeIncrementScreenshot();

		// getDriver().findElement(By.id("ContinueButton")).click();
		// javascript click instead
		javascriptClick(getDriver().findElement(By.id("ContinueButton")));

	}

    public void prClickForNextAction1() throws Exception {

        takeIncrementScreenshot();
        getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
        waitForVisibilityOfElement(By.id("ContinueButtonStep1"));
        waitForClickableElement(By.id("ContinueButtonStep1"));
        takeIncrementScreenshot();

//         getDriver().findElement(By.id("ContinueButton")).click();
        // javascript click instead
        javascriptClick(getDriver().findElement(By.id("ContinueButtonStep1")));

    }

	public String fnCaptureCreditAgreementNumber() throws Exception {

		waitForVisibilityOfElement(By.cssSelector("h3.esignature-title span.number"));
		gsPANAgreementNumber = getDriver().findElement(By.cssSelector("h3.esignature-title span.number")).getText();

		// // Capture the agreement number displayed in the Credit Agreement
		// page
		// gsPANAgreementNumber =
		// getDriver().findElement(By.xpath("//div[@id='CreditAgreementHeader']/span[2]")).getText();
		log.info("fnCaptureCreditAgreementNumber: Agreement Number> [" + gsPANAgreementNumber + "]");
		return gsPANAgreementNumber;
	}

	public void prAssertCreditAgreement() throws Exception {

		log.info("AssertCreditAgreement: check credit agreement details");

		// Check agreement content coincides with the customer requested loan
		// application details
		// --------------------------------------------------------------------------------------

		// Check name on agreement

		getDriver().getPageSource().contains(gsTitle + " " + gsFirstname + " " + gsSurname);

		// Product Explanation

		if (gsRepaymentFrequency.equals("Weekly")) {

			// WebElement cellActualRequestedLoanAmount =
			// getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)"));
			WebElement cellActualRequestedLoanAmount = getDriver().findElement(By.cssSelector("#product-explanation-loan-amount"));

			// WebElement cellActualRequestedLoanAmount =
			// getDriver().findElement(By.xpath("//*[@id=\"id=\"]"));

			String actualRequestedLoanAmount = cellActualRequestedLoanAmount.getText();
			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00", actualRequestedLoanAmount);

			// WebElement cellActualTap =
			// getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)"));
			WebElement cellActualTap = getDriver().findElement(By.cssSelector("#product-explanation-total-amount-payable"));

			String actualTap = cellActualTap.getText();
			Assert.assertEquals("£" + gsExpectedTAP, actualTap);

			// Assert.assertEquals("£" + gsExpectedRepayment + " each week",
			// getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());
			Assert.assertEquals("£" + gsExpectedRepayment + " each week", getDriver().findElement(By.cssSelector("#product-explanation-frequency")).getText());

			// Assert.assertEquals(gsRequestedTerm + " weeks",
			// getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " weeks", getDriver().findElement(By.cssSelector("#product-explanation-duration")).getText());

			// 2. Key features of the credit product
			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			Assert.assertEquals("£" + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " weeks.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());

//			Assert.assertEquals(gsRequestedTerm + " weekly payments of £" + gsExpectedRepayment + " starting on the first " + gsPreferredPaymentDow + " to follow seven days after the credit agreement is signed by us.",
//					getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " weekly payments of £" + gsExpectedRepayment + " starting on the first " + gsPreferredPaymentDow + " to follow seven days after the credit agreement is signed by us and continuing on the same day in each week thereafter.",
					getDriver().findElement(By.cssSelector("#key-features > div > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());

			// 3. Costs of the credit
			Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsExpectedAPR + " % APR.", getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			// Parties to the Agreement - Contact details

			String sTmp;
			sTmp = "";
			if (gsFlatNumber != null && !gsFlatNumber.isEmpty())
				sTmp = gsFlatNumber;
			if (gsBuildingName != null && !gsBuildingName.isEmpty())
				sTmp = sTmp + " " + gsBuildingName;
			sTmp = sTmp.trim();
			if (gsBuildingNumber != null && !gsBuildingNumber.isEmpty())
				sTmp = sTmp + " " + gsBuildingNumber;
			sTmp = sTmp.trim();
			if (gsStreet != null && !gsStreet.isEmpty())
				sTmp = sTmp + " " + gsStreet;
			sTmp = sTmp.trim();
			if (gsDistrict != null && !gsDistrict.isEmpty())
				sTmp = sTmp + ", " + gsDistrict;
			sTmp = sTmp.trim();
			if (gsTownCity != null && !gsTownCity.isEmpty())
				sTmp = sTmp + ", " + gsTownCity;
			sTmp = sTmp.trim();
			if (gsCounty != null && !gsCounty.isEmpty())
				sTmp = sTmp + ", " + gsCounty;
			sTmp = sTmp.trim();
			if (gsPostcode != null && !gsPostcode.isEmpty())
				sTmp = sTmp + ", " + gsPostcode + ".";
			sTmp = sTmp.trim();
			sTmp = gsTitle + " " + gsFirstname + " " + gsSurname + ",\n" + sTmp;

			Assert.assertEquals(sTmp.toLowerCase(), getDriver().findElement(By.cssSelector("#agreement-parties-to-agreement > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText().toLowerCase());

			// Key features of the credit product

			// log.info(getDriver().findElement(By.xpath("//div[@id='accordian-agreement-esig']//a[@href='#key-features']")).getText());
			// log.info(getDriver().findElement(By.cssSelector("#key-features")).getText());

			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " weeks.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " weekly payments of £" + gsExpectedRepayment + " starting on the first " + gsPreferredPaymentDow + " to follow seven days after the credit agreement is signed by us and continuing on the same day in each week thereafter.",

			getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());

			Assert.assertEquals("£" + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());

			// Costs of the credit

			Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsExpectedAPR + " % APR calculated on the assumption that you make all repayments on the agreed dates.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			// Deliberately not checking for daily rate in Right of withdrawal
			// due
			// to Pan possible being ahead on time
			// ========================================================================================================

		} else if (gsRepaymentFrequency.equals("Monthly")) {
			// Monthly

			// WebElement cellActualRequestedLoanAmount =
			// getDriver().findElement(By.cssSelector("#loan-agreement > div:nth-child(2) > table:nth-child(7) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)"));
			WebElement cellActualRequestedLoanAmount = getDriver().findElement(By.cssSelector("#product-explanation-loan-amount"));
			// WebElement cellActualRequestedLoanAmount =
			// getDriver().findElement(By.xpath("//*[@id=\"id=\"]"));
			String actualRequestedLoanAmount = cellActualRequestedLoanAmount.getText();
			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00", actualRequestedLoanAmount);

			// WebElement cellActualTap =
			// getDriver().findElement(By.cssSelector("#loan-agreement > div:nth-child(2) > table:nth-child(7) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)"));
			WebElement cellActualTap = getDriver().findElement(By.cssSelector("#product-explanation-total-amount-payable"));

			String actualTap = cellActualTap.getText();
			Assert.assertEquals("£" + gsExpectedTAP, actualTap);

			Assert.assertEquals("£" + gsExpectedRepayment + " each month", getDriver().findElement(By.cssSelector("#product-explanation-frequency")).getText());

			Assert.assertEquals(gsRequestedTerm + " months", getDriver().findElement(By.cssSelector("#product-explanation-duration")).getText());

			// 2. Key features of the credit product
			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			Assert.assertEquals("£" + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " months.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());

			// next probably depends on the date selected
			Assert.assertTrue(
					getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText().contains(gsRequestedTerm + " monthly payments of £" + gsExpectedRepayment + " starting on the"),
					"check agreement info is there");

			// Assert.assertEquals(gsRequestedTerm + " monthly payments of £" +
			// gsExpectedRepayment
			// +
			// " starting on the 1st of the month which falls at least 28 days after the credit agreement is signed by us and continuing on the same day in each later month.",
			// getDriver()
			// .findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());

			// 3. Costs of the credit
			Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsExpectedAPR + " % APR.", getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			// Parties to the Agreement - Contact details

			String sTmp;
			sTmp = "";
			if (gsFlatNumber != null && !gsFlatNumber.isEmpty())
				sTmp = gsFlatNumber;
			if (gsBuildingName != null && !gsBuildingName.isEmpty())
				sTmp = sTmp + " " + gsBuildingName;
			sTmp = sTmp.trim();
			if (gsBuildingNumber != null && !gsBuildingNumber.isEmpty())
				sTmp = sTmp + " " + gsBuildingNumber;
			sTmp = sTmp.trim();
			if (gsStreet != null && !gsStreet.isEmpty())
				sTmp = sTmp + " " + gsStreet;
			sTmp = sTmp.trim();
			if (gsDistrict != null && !gsDistrict.isEmpty())
				sTmp = sTmp + ", " + gsDistrict;
			sTmp = sTmp.trim();
			if (gsTownCity != null && !gsTownCity.isEmpty())
				sTmp = sTmp + ", " + gsTownCity;
			sTmp = sTmp.trim();
			if (gsCounty != null && !gsCounty.isEmpty())
				sTmp = sTmp + ", " + gsCounty;
			sTmp = sTmp.trim();
			if (gsPostcode != null && !gsPostcode.isEmpty())
				sTmp = sTmp + ", " + gsPostcode + ".";
			sTmp = sTmp.trim();
			sTmp = gsTitle + " " + gsFirstname + " " + gsSurname + ",\n" + sTmp;

			Assert.assertEquals(sTmp.toLowerCase(), getDriver().findElement(By.cssSelector("#agreement-parties-to-agreement > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText().toLowerCase());

			// Key features of the credit product

			Assert.assertEquals("£" + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsRequestedTerm + " months.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());

			// next statement may change based on the date selected for loan
			// repayment
			// Assert.assertEquals(gsRequestedTerm + " monthly payments of £" +
			// gsExpectedRepayment
			// +
			// " starting on the 1st of the month which falls at least 28 days after the credit agreement is signed by us and continuing on the same day in each later month.",
			// getDriver()
			// .findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());
			// next probably depends on the date selected
			Assert.assertTrue(
					getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText().contains(gsRequestedTerm + " monthly payments of £" + gsExpectedRepayment + " starting on the"),
					"check agreement info is there");

			Assert.assertEquals("£" + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());

			// Costs of the credit

			Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());

			Assert.assertEquals(gsExpectedAPR + " % APR calculated on the assumption that you make all repayments on the agreed dates.",
					getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

			// Deliberately not checking for daily rate in Right of
			// withdrawal due
			// to Pan possible being ahead on time
			// ========================================================================================================

		}
	}

	public void waitForTitle(String title) {
		try {
			log.debug("Waiting for title to be " + title);
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(EXPLICIT_TIMEOUT, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class);
			wait.until(ExpectedConditions.titleIs(title));
		} catch (TimeoutException e) {
			log.error("Timed out waiting for title: " + title + " current title: " + getDriver().getTitle());
			Assert.assertEquals(getDriver().getTitle(), title);
		}

	}

	public void waitForUrl(String expectedUrl) {
		try {
			log.debug("Waiting for url to be " + expectedUrl);
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(EXPLICIT_TIMEOUT, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class);
			wait.until(ExpectedConditions.urlToBe(expectedUrl));
		} catch (TimeoutException e) {
			log.error("Timed out waiting for url: " + expectedUrl + " current url: " + getDriver().getCurrentUrl());
			Assert.assertEquals(getDriver().getCurrentUrl(), expectedUrl);
		}

	}

	public void scrollToElementAndClick(WebDriver driver, WebElement element) {
		scrollToElement(element);
		while (true) {
			try {
				log.info("Trying to click");
				// try to click
				element.click();
				// if clickable go to next step
				break;
			} catch (WebDriverException e) {
				// scroll up if element is not clickable yet
				scrollDown();
			}
		}

	}

	// scrolls 10 times to try to see element
	public void scrollDownToElement(By by) {
		int counter = 10;
		while (counter > 0) {
			log.debug("scrolling down to element");
			try {
				counter--;
				scrollDown();
				FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(3, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class);
				wait.until(ExpectedConditions.elementToBeClickable(getDriver().findElement(by)));
				log.debug("found element!");
				break; // exception not thrown element is visible
			} catch (TimeoutException e) {
				log.debug("couldn't see element, trying again");
			}

		}
	}

	public void scrollToElement(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		scrollUp(75);
	}

	public void scrollUp() {
		scrollUp(200);
	}

	public void scrollUp(int pixels) {
		log.debug("scrolling up " + pixels + "px");
		((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,-" + pixels + ");");
	}

	public void scrollDown() {
		scrollDown(200);
	}

	public void scrollDown(int pixels) {
		log.debug("scrolling down " + pixels + "px");
		((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0," + pixels + ");");
	}

	public void sendKeysIfNotNull(WebElement element, String textString) {

		// if entry is not null
		if (textString != null) {
			element.sendKeys(textString);
		} else {
			// otherwise just tab to the next element
			element.sendKeys(Keys.TAB);
		}
	}

	public void prAssertOnPageExistingCustomer(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "existing-customers";

		// Landed on About You page
		log.info("prAssertOnPageAboutYou: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageWorldPayPaymentCancelled(String psSatsumaSiteUrl) throws Exception {
		Assert.assertEquals(getDriver().findElement(By.xpath("//td[@class='banner']/span")).getText(), "Thank you, your payment has been cancelled.");
		Assert.assertTrue(getDriver().getTitle().contains("Your payment has been cancelled."));

	}

	public void takeIncrementScreenshot() {
		log.debug("Taking screenshot to " + "target/surefire-reports/screenshots/" + testName + "/" + screenshotNumber + ".png");
		takeScreenshot("target/surefire-reports/screenshots/" + testName + "/" + String.format("%02d", screenshotNumber) + ".png");
		screenshotNumber++;
	}

	public void takeScreenshot(String path) {
		try {
			File scrFile = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(path));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForVisibilityOfElement(By by) {
		waitForVisibilityOfElement(by, EXPLICIT_TIMEOUT);
	}

	public void waitForVisibilityOfElement(By by, int timeout) {
		log.debug("Waiting for visibility of element  " + by);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(timeout, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class, NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOf(getDriver().findElement(by)));
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
	}

	public void waitForRefresh(By by) {
		log.debug("Waiting for staleness of element  " + by);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(STALENESS_TIMEOUT, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class);
		try {
			wait.until(ExpectedConditions.stalenessOf(getDriver().findElement(by)));
			waitForClickableElement(by);
		} catch (TimeoutException e) {
			log.debug("Element didn't go stale, test will still progress");
		}
	}

	public void waitForExistenceOfElement(By by) {
		log.debug("Waiting for existence of element  " + by);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(EXPLICIT_TIMEOUT, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public void waitForClickableElement(By by) {
		log.debug("Waiting for clickable element  " + by);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(EXPLICIT_TIMEOUT, TimeUnit.SECONDS).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(StaleElementReferenceException.class, TimeoutException.class);
		wait.until(ExpectedConditions.elementToBeClickable(getDriver().findElement(by)));
	}

	public void waitForDropdownSelectedText(final By by, final String textToWaitFor) {
		// wait for dropdown to have the right value which we selected, if true
		// returns immediately if false returns after 5 seconds
		log.debug("waiting for '" + textToWaitFor + "' currently '" + new Select(getDriver().findElement(by)).getFirstSelectedOption().getText().trim() + "'");
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(5, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(TimeoutException.class, StaleElementReferenceException.class);
		wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				return (new Select(driver.findElement(by)).getFirstSelectedOption().getText().trim().equalsIgnoreCase(textToWaitFor));
			}
		});
	}

	public void waitForSelectedTextInElement(final By by, final String textToWaitFor) {
		// returns immediately if false returns after 5 seconds
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(5, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(TimeoutException.class, StaleElementReferenceException.class);
		wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				return (driver.findElement(by).getText().equalsIgnoreCase(textToWaitFor));
			}
		});
	}

	// formats the currency to the format displayed on screen e.g. 1000 =
	// £1,000.00
	public String formatCurrencyToDisplay(String amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£###,###,###,###.00";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;
	}

	// formats the currency to the format displayed on screen e.g. 1000 =
	// £1,000.00
	public String formatCurrencyToDisplayNoDP(String amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£###,###,###,###";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;
	}

	// formats the currency to the format displayed on screen e.g. 1000 =
	// £1,000.00
	public String formatCurrencyToDisplayNoDPNoComma(String amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£###";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;
	}

	// date input format must be 'dd/MM/yyyy'
	public TestCase soapUISatsumaBrokerPANAPI(String testSuiteName, String testCaseName, String broker, String subAffiliate) throws XmlException, IOException, SoapUIException, Exception, SQLException {
		// Connect to SoapUI Project and find test case
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsumaBroker.xml");
		// TestSuite testSuite =
		// project.getTestSuiteByName("SatsumaB2B_HappyPath");
		// TestCase testCase =
		// testSuite.getTestCaseByName("TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13");
		TestSuite testSuite = project.getTestSuiteByName(testSuiteName);
		TestCase testCase = testSuite.getTestCaseByName(testCaseName);

		log.debug("TestCase: " + testCaseName);
		log.debug("TestSuite: " + testSuiteName);

		log.debug("gsFirstname: " + gsFirstname);
		log.debug("gsSurname: " + gsSurname);

		log.debug("loanPurpose " + convertLoanPurposeToBroker(gsLoanPurpose));
		log.debug("ptcIncome " + gsIncome);
		log.debug("ptcMortgage " + gsMortgageCosts);
		log.debug("ptcLoanRepayments " + gsMonthlyLoanRepayments);
		log.debug("ptcOtherOutgoings " + gsMonthlyOtherOutgoings);
		log.debug("ptcIncomeSchedule " + gsIncomeFrequency);
		log.debug("ptcLoanAmount " + gsRequestedLoanAmount);
		log.debug("ptcDOB before " + gsDOB);
		log.debug("ptcDOB after " + formatDate(gsDOB, "dd/MM/yyyy", "yyyy-MM-dd"));
		log.debug("ptcOutgoings " + gsMonthlyOutgoings);
		log.debug("ptcCreditCardRepayments " + gsCreditCardRepayments);
		log.debug("ptcBroker " + broker);
		log.debug("ptcRent " + gsRentCosts);
		log.debug("gsEmploymentStatusBroker " + gsEmploymentStatusBroker);

		// Set attributes before submission. ptc attributes are those stored in
		// the SOAPUI testcase &
		// gs attributes are those retuned from the gcb call
		testCase.setPropertyValue("ptcBroker", broker);
		testCase.setPropertyValue("ptcSubAffiliate", subAffiliate);
		testCase.setPropertyValue("ptcBrokerLeadEndpoint", _getConfigProperty("BrokerLeadEndpoint"));
		testCase.setPropertyValue("ptcLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcLoanTerm", gsRequestedTerm);
		testCase.setPropertyValue("ptcPaymentFrequency", gsRepaymentFrequency);
		testCase.setPropertyValue("ptcPurpose", convertLoanPurposeToBroker(gsLoanPurpose));
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDoB", formatDate(gsDOB, "dd/MM/yyyy", "yyyy-MM-dd"));
		testCase.setPropertyValue("ptcGender", gsGender);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcResidentialStatus", convertResidentialStatusToBroker(gsResidentialStatus));
		// testCase.setPropertyValue("ptcEmploymentStatus", gsEmploymentStatus);
		testCase.setPropertyValue("ptcEmploymentStatus", gsEmploymentStatusBroker);
		testCase.setPropertyValue("ptcHomeNo", gsHomeNumber);
		testCase.setPropertyValue("ptcMobileNo", gsMobileNumber);
		// testCase.setPropertyValue("ptcEmail",
		// _getConfigProperty("B2BEmail"));
		testCase.setPropertyValue("ptcEmail", gsEmailAddress);
		testCase.setPropertyValue("ptcFlatName", gsFlatNumber);
		testCase.setPropertyValue("ptcHouseNo", gsBuildingNumber);
		testCase.setPropertyValue("ptcBuildingName", gsBuildingName);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcDistrict", gsDistrict);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcCounty", gsCounty);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcCountry", gsCountry);
		testCase.setPropertyValue("ptcDateMovedIn", gsCurrentHouseMovedInDate.substring(6, 10) + "-" + gsDOB.substring(3, 5) + "-" + gsDOB.substring(0, 2));
		testCase.setPropertyValue("ptcIncome", gsIncome);
		testCase.setPropertyValue("ptcMortgage", gsMortgageCosts);
		testCase.setPropertyValue("ptcLoanRepayments", gsMonthlyLoanRepayments);
		testCase.setPropertyValue("ptcOtherOutgoings", gsMonthlyOtherOutgoings);
		testCase.setPropertyValue("ptcIncomeSchedule", gsIncomeFrequency);
		testCase.setPropertyValue("ptcHasCreditCards", gsHasCreditCards);
		testCase.setPropertyValue("ptcHasExistingLoans", gsHasExistingLoans);
		testCase.setPropertyValue("ptcCreditCardRepayments", gsCreditCardRepayments);
		testCase.setPropertyValue("ptcOutgoings", gsMonthlyOutgoings);
		testCase.setPropertyValue("ptcRent", gsRentCosts);
		// testCase.setPropertyValue("ptcIncomeMethodType",
		// gsIncomePaymentMethod);
		testCase.setPropertyValue("ptcIncomeMethodType", gsIncomePaymentMethodBroker);
		testCase.setPropertyValue("ptcNumberOfDependants", gsNumberOfDependants);

		// Get Satsuma loan Charges for Weekly, £100, 13 Weeks, from TestshedDB
		prGetACurrentSatsumaLoanCharge(gsRepaymentFrequency, Integer.parseInt(gsRequestedTerm), Integer.parseInt(gsRequestedLoanAmount));

		log.debug("Expected APR is " + gsExpectedAPR);
		log.debug("Expected Flat Rate is " + gsExpectedFlatRate);
		log.debug("Expected Interest is " + gsExpectedInterest);
		log.debug("Expected TAP is " + gsExpectedTAP);
		log.debug("Expected repayment is " + gsExpectedRepayment);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		// Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());
		return testCase;
	}

	// Login stuff

	By byLoginTxtForename = By.id("Forename");
	By byLoginTxtSurname = By.id("Surname");
	By byLoginDdDobDay = By.id("DateOfBirth_Day");
	By byLoginDdDobMonth = By.id("DateOfBirth_Month");
	By byLoginDdDobYear = By.id("DateOfBirth_Year");
	By byLoginTxtPostcode = By.id("Postcode");
	By byLoginTxtLoanAgreementNo = By.id("AgreementNumber");

	// By byLoginBtnRegister = By.id("SubmitRegiserForm");
	By byLoginBtnRegister = By.id("ContinueButton");

	By byLoginTxtPassword = By.id("NewPassword");
	// By byLoginBtnCompleteRegistration = By.id("SubmitRegisterPassword");
	By byLoginBtnCompleteRegistration = By.id("ContinueButton");

	By byLoginLoginScrnTxtUsername = By.id("UserName");
	By byLoginLoginScrnTxtPassword = By.id("Password");
	By byLoginLoginScrnBtnLogin = By.id("ContinueButton");
	// By byLoginLoginScrnBtnLogin = By.id("SubmitLoginForm");

	By byLnkSignOut = By.linkText("Sign out");
	By byBtnLoginHeader = By.id("header-login-link");
	By byLnkShowPassword = By.id("lnkShowHide");

	public String gsLoginUsername;
	public String gsLoginPassword;

	public void navigateToLoginPage(String satsumaSiteUrl) {
		getDriver().get(satsumaSiteUrl + "login");
		takeIncrementScreenshot();
	}

	public void navigateToRegistrationPage(String satsumaSiteUrl) {
		getDriver().get(satsumaSiteUrl + "mysatsuma-registration");
		takeIncrementScreenshot();
	}

	public void fillInPageIdentifyYourAccount() {
		getDriver().findElement(byLoginTxtForename).sendKeys(gsFirstname);
		getDriver().findElement(byLoginTxtSurname).sendKeys(gsSurname);

		new Select(getDriver().findElement(byLoginDdDobDay)).selectByVisibleText(gsDOB.substring(0, 2));
		new Select(getDriver().findElement(byLoginDdDobMonth)).selectByVisibleText(gtb.fn_GetMonthFullWording(gsDOB.substring(3, 5)));
		new Select(getDriver().findElement(byLoginDdDobYear)).selectByVisibleText(gsDOB.substring(6, 10));
		getDriver().findElement(byLoginTxtPostcode).sendKeys(gsPostcode);
		getDriver().findElement(byLoginTxtLoanAgreementNo).sendKeys(gsPANAgreementNumber);

		takeIncrementScreenshot();
		getDriver().findElement(byLoginBtnRegister).sendKeys(Keys.TAB);
		getDriver().findElement(byLoginBtnRegister).click();
	}

	public void fillInPageCompleteYourRegistration() {
		gsLoginUsername = gsEmailAddress;
		// gsLoginUsername = "chi.voong@provident.co.uk";
		// gsLoginPassword = getRandomPassword();
		// gsLoginPassword = "12letmeiN!";
		gsLoginPassword = "Password1";
		// gsLoginPassword = "kvdewvF5";
		getDriver().findElement(byLoginTxtPassword).sendKeys(gsLoginPassword);
		getDriver().findElement(byLnkShowPassword).click(); // show password
		takeIncrementScreenshot();
		getDriver().findElement(byLoginBtnCompleteRegistration).sendKeys(Keys.TAB);
		getDriver().findElement(byLoginBtnCompleteRegistration).click();

		log.debug("Username: " + gsLoginUsername + " Password: " + gsLoginPassword);
	}

	// one uppercase, one lowercase, one special character, one number, 7 or 8
	// characters
	private String getRandomPassword() {
		String result = RandomStringUtils.random(6, 0, 26, true, true, "abcdefghijklmnopqrstuvwxyz".toCharArray()) + RandomStringUtils.random(1, 0, 26, true, true, "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray()) + RandomStringUtils.random(1, 0, 10, true, true, "1234567890".toCharArray());
		return result;
	}

	// one uppercase, one lowercase, one special character, one number, 7 or 8
	// characters
	public String getRandomName() {
		String result = RandomStringUtils.random(1, 0, 52, true, true, "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray()) + RandomStringUtils.random(10, 0, 52, true, true, "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz".toCharArray());
		return result;
	}

	// Creates a random name by combining three word combinations 4 times,
	// should give enough combinations
	public String getReadableRandomName() {
		List<String> randomWords = Arrays.asList("JON", "CON", "HIN", "SON", "FOR", "JIM", "BOB", "BILL", "RON", "POD", "DIM", "ZOD", "PET", "OAK", "ANN", "WEB", "YAK", "NAG", "TOD", "ELK", "LUG", "JAB", "KIK");

		Random rand = new Random();
		String name = randomWords.get(rand.nextInt(randomWords.size())) + randomWords.get(rand.nextInt(randomWords.size())) + randomWords.get(rand.nextInt(randomWords.size())) + randomWords.get(rand.nextInt(randomWords.size()));

		return name;
	}

	public void setRandomForeName() {
		gsFirstname = getReadableRandomName();
	}

	public void setRandomSurname() {
		gsSurname = getReadableRandomName();
	}

	public void prPANChangePersonTitle(String title) {
		waitForClickableElement(By.linkText("Name & Address"));
		getDriver().findElement(By.linkText("Name & Address")).click();
		(new Select(getDriver().findElement(By.id("title")))).selectByVisibleText(title);
	}

	public void assertOnPagePassword(String url) {
		waitForUrl(url + "my-satsuma/register-password");
		Assert.assertEquals(getDriver().findElement(By.cssSelector("section[class='central top-buffer'] h1")).getText(), "Complete your registration");
		Assert.assertEquals(getDriver().findElement(By.cssSelector("div[class='BodyText'] p")).getText(), "Hooray, we've found you! You just need to create a password to finish setting up your MySatsuma account.");
	}

	public void assertOnPageRegistered(String url) {
		try {
			waitForUrl(url + "my-satsuma/register-completion?Username=" + URLEncoder.encode(gsLoginUsername, "UTF-8") + "&ContentPageName=Registration%20Complete&Content=Pfg.OnlineLoans.Content.Models.Content");
			Assert.assertEquals(getDriver().findElement(By.cssSelector("div[class='registered-email']")).getText(), gsLoginUsername);
			Assert.assertEquals(getDriver().findElement(By.cssSelector("section[class=central] h1")).getText(), "You're done!");
		} catch (UnsupportedEncodingException e) {
			log.error("Error username could not be encoded");
		}

	}

	public void loginInPageLogin() {
		getDriver().findElement(byLoginLoginScrnTxtUsername).sendKeys(gsLoginUsername);
		getDriver().findElement(byLoginLoginScrnTxtPassword).sendKeys(gsLoginPassword);
		getDriver().findElement(byLnkShowPassword).click(); // show password
		takeIncrementScreenshot();
		getDriver().findElement(byLoginLoginScrnBtnLogin).sendKeys(Keys.TAB);
		getDriver().findElement(byLoginLoginScrnBtnLogin).click();

	}

	public void prAssertOnPageLoggedIn(String url) {

		takeIncrementScreenshot();
		waitForUrl(url + "my-satsuma");
		Assert.assertTrue(getDriver().findElement(By.cssSelector("section.central:nth-child(2) > h1:nth-child(1)")).getText().toLowerCase().contains("hi " + gsFirstname.toLowerCase()), "Check firstname appears on screen");
	}

	public void logoutInPageLogin() {
		takeIncrementScreenshot();
		// element not visible
		// getDriver().findElement(byLnkSignOut).click();
		javascriptClick(getDriver().findElement(byLnkSignOut));
		takeIncrementScreenshot();
	}

	public void prAssertOnPageLoggedOut(String url) {
		takeIncrementScreenshot();
		waitForUrl(url + "?status=signedout");
		// waitForTitle("Short Term Loans | Official Site | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byBtnLoginHeader).getAttribute("title"), "Log in"); // verify
		// login
		// button
		// is
		// present
	}

	public void assertOnLoginPage(String url) {
		takeIncrementScreenshot();
		waitForUrl(url + "login");
		// waitForTitle("Login | Satsuma Loans");
		// Assert.assertEquals(getDriver().findElement(By.cssSelector("section[class='central top-buffer'] h1")).getText(),
		// "Login to MySatsuma");
	}

	By byLnkPANAdditionalDetails = By.linkText("Additional Details");

	public void prOpenAdditionalDetails() {
		getDriver().findElement(byLnkPANAdditionalDetails).click();
	}

	public void prVerifyAffiliate(String internetAffiliateSubId, String internetCampaign, String internetDevice, String internetSearchAdGroup, String internetSearchTerm, String internetSearch, String internetSource, String internetType, String marketingChannel, String marketingCompany) {
		// click second details link
		getDriver().findElement(byLnkPANAdditionalDetails).click();

		// log out all the contents of the iframe being verified
		saveFrameContents(By.cssSelector("div.scrollableExceptions:nth-child(1)"));

		// Verify the following properties
		// ---------------------------------
		// Internet Affiliate Sub ID BLANK
		// Internet Campaign onecard_20_60_banner
		// Internet Device DESK
		// NOT VERFIED = Internet IP Address 172.16.222.246
		// Internet Search Ad Group BLANK
		// Internet Search Campaign
		// Internet Search Term BLANK
		// Internet Source YOUTUBE
		// Internet Type Display Advert
		// Marketing Channel Internet
		// Marketing Company Satsuma

		// Internet Affiliate Sub ID BLANK
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[27]/td[2]")).getText(), internetAffiliateSubId);
		// Internet Campaign weblink1
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[28]/td[2]")).getText(), internetCampaign);
		// Internet Device DESK (or MOBI for mobile)
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[29]/td[2]")).getText(), internetDevice);
		// Internet Search Ad Group BLANK
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[31]/td[2]")).getText(), internetSearchAdGroup);
		// Internet Search Campaign
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[32]/td[2]")).getText(), internetSearch);
		// Internet Search Term BLANK
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[33]/td[2]")).getText(), internetSearchTerm);
		// Internet Source DIR_MODUS
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[34]/td[2]")).getText(), internetSource);
		// Internet Type Affiliate
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[35]/td[2]")).getText(), internetType);
		// Marketing Channel Internet
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[36]/td[2]")).getText(), marketingChannel);
		// Marketing Company Satsuma
		Assert.assertEquals(getDriver().findElement(By.xpath(".//*[@id='PanForm']/div[2]/div[2]/div[2]/div/div[1]/table/tbody/tr[37]/td[2]")).getText(), marketingCompany);

	}

	public void saveFrameContents(By by) {
		log.info(getDriver().findElement(by).getText());
	}

	By ddLoanAmount = By.id("LoanAmountAboutYouCalcDropdown");
	By cellVBLTAP = By.id("TotalAmountAboutYouCalcText");
	By cellVBLRepayAmount = By.id("RepaymentAmountAboutYouCalcText");
	By cellVBLRepayOver = By.id("RepayOverAboutYouCalcText");
	By cellVBLTotalInterest = By.id("TotalInterestAboutYouCalcText");
	By cellVBLLoanAmount = By.id("LoanAmountAboutYouCalcText");

	public void assertB2BVBLPage() {
		takeIncrementScreenshot();
		Assert.assertEquals((new Select(getDriver().findElement(ddLoanAmount))).getFirstSelectedOption().getText(), "£" + gsRequestedLoanAmount, "dropdown loan amount");
		Assert.assertEquals(getDriver().findElement(cellVBLTAP).getText(), "£" + gsExpectedTAP);
		Assert.assertEquals(getDriver().findElement(cellVBLRepayAmount).getText(), "£" + gsExpectedRepayment);
		Assert.assertEquals(getDriver().findElement(cellVBLRepayOver).getText(), gsRequestedTerm + " weeks");
		Assert.assertEquals(getDriver().findElement(cellVBLTotalInterest).getText(), "£" + gsExpectedInterest);
		Assert.assertEquals(getDriver().findElement(cellVBLLoanAmount).getText(), "£" + gsRequestedLoanAmount);
	}

	public void assertOnPagePANSummary() {
		Assert.assertEquals(getDriver().findElement(By.cssSelector("span[class=titleBarMiddle]")).getText(), "Summary");
	}

	// calculate your eligible amount based on your existing loan
	public float calcEligibleAmount(float originalLoanAmount, float outstandingBalance) {

		float eligibleLoanAmount;
		// // if paid up loan then 2x
		// if (outstandingBalance == 0) {
		// // eligibleLoanAmount = (float) (Math.ceil((originalLoanAmount * 2f)
		// // / 100) * 100);
		// eligibleLoanAmount = (float) (Math.ceil((originalLoanAmount * 1.5f) /
		// 100) * 100);
		// return eligibleLoanAmount;
		// }

		// if less then or equal to 300 then 2x and ceiling nearest 100
		// if (originalLoanAmount <= 300f) {
		if (originalLoanAmount <= 600f) {
			// eligibleLoanAmount = (float) (Math.ceil((originalLoanAmount * 2f)
			// / 100) * 100);
			// eligibleLoanAmount = (float) (Math.ceil((originalLoanAmount *
			// 1.5f) / 100) * 100);
			eligibleLoanAmount = 1000f;
			return eligibleLoanAmount;
		}

		// if greater then 300 then 1.5x and do calculation
		float eligibleBasedOnLoanAmount = originalLoanAmount * 1.5f;
		float eligibleBasedOnOutstandingBalance = 2000 - outstandingBalance;
		// return the smaller value between based on loan amount and based on
		if (eligibleBasedOnLoanAmount <= eligibleBasedOnOutstandingBalance) {
			eligibleLoanAmount = (float) (Math.ceil((eligibleBasedOnLoanAmount) / 100) * 100);
		} else {
			eligibleLoanAmount = (float) (Math.floor(eligibleBasedOnOutstandingBalance / 10) * 10);
		}
		// outstanding balance floor nearest 10
		return eligibleLoanAmount;
	}

	// calculate your MAX eligible amount based on your existing loan
	// requires existing loan outstanding amount, term requested
	public float calcEligibleAmount(float originalLoanAmount, float outstandingBalance, int requestedTerm, String requestedFrequency) throws ClassNotFoundException {
		// if original loan is between 0-600 then max eligible loan is 1000
		float eligibleBasedOnLoanAmount;

		if (originalLoanAmount <= 600) {
			eligibleBasedOnLoanAmount = 1000f;
			return eligibleBasedOnLoanAmount;
		} else
			eligibleBasedOnLoanAmount = originalLoanAmount * 1.5f;

		if (outstandingBalance == 0f) {
			eligibleBasedOnLoanAmount = (float) (Math.ceil((eligibleBasedOnLoanAmount) / 100) * 100);
			return eligibleBasedOnLoanAmount;
		} else {
			// what is the available TAP based on outstanding balance
			float eligibleTAPBasedOnLoanAmount = 2000 - outstandingBalance;

			float eligibleLoanAmount;

			eligibleLoanAmount = DbTestShedHelper.getLoanAmountFromAvailableTAPAndTerm(eligibleTAPBasedOnLoanAmount, requestedTerm, requestedFrequency);

			return eligibleLoanAmount;
		}
	}

	// calculate your eligible amount based on your existing loan
	// requires existing loan outstanding amount, term requested
	public float calcEligibleAmountVsRequestedAmount(float originalLoanAmount, float outstandingBalance, int requestedLoanAmount, int requestedTerm, String requestedFrequency) throws ClassNotFoundException {
		// if original loan is between 0-600 then max eligible loan is 1000
		float eligibleBasedOnLoanAmount;

		if (originalLoanAmount <= 600)
			eligibleBasedOnLoanAmount = 1000f;
		else
			eligibleBasedOnLoanAmount = originalLoanAmount * 1.5f;

		if (outstandingBalance == 0f)
			return eligibleBasedOnLoanAmount;
		else {
			// what is the available TAP based on outstanding balance
			float eligibleTAPBasedOnLoanAmount = 2000 - outstandingBalance;

			float eligibleLoanAmount;
			// get what the tap would be for the requested loan
			float requestedLoanTAP = (float) DbTestShedHelper.getTAPFromLoanAmountAndTerm(requestedLoanAmount, requestedTerm, requestedFrequency);

			// if requested loan creates a TAP of less than the eligible tap
			// then return that loan if not then see what the max is
			if (requestedLoanTAP < eligibleTAPBasedOnLoanAmount)
				eligibleLoanAmount = requestedLoanAmount;
			else
				eligibleLoanAmount = DbTestShedHelper.getLoanAmountFromAvailableTAPAndTerm(eligibleTAPBasedOnLoanAmount, requestedTerm, requestedFrequency);

			return eligibleLoanAmount;
		}
	}

	By byBtnSubmitPassword = By.id("submit-password-button");
	By byHeaderMySatsuma = By.cssSelector("div[id='register-password-container'] .central h1");
	By byTxtPassword = By.id("Password");

	public void fillInPageMySatsumaAccount(String password) {
		getDriver().findElement(byTxtPassword).sendKeys(password);
		getDriver().findElement(byBtnSubmitPassword).sendKeys(Keys.TAB);
//		getDriver().findElement(byBtnSubmitPassword).click();
		waitForClickableElement(byBtnSubmitPassword);
		javascriptClick(getDriver().findElement(byBtnSubmitPassword));
	}

	public void assertOnPageMySatsumaAccount(String sExpectedUrl) {
		takeIncrementScreenshot();
		waitForUrl(sExpectedUrl + "apply/agreement");
		waitForTitle("Agreement | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byHeaderMySatsuma).getText(), "Your MySatsuma account");
	}

	public void assertOnPageB2BMySatsumaAccount(String sExpectedUrl) {
		takeIncrementScreenshot();
		waitForUrl(sExpectedUrl + "referral/agreement");
		waitForTitle("Your credit agreement | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byHeaderMySatsuma).getText(), "Your MySatsuma account");
	}

	By byLblPopSuccessMsg = By.cssSelector("#small-dialog p strong");
	By byLblPopEmailMsg = By.cssSelector(".small-dialog h2");

	public void assertOnPageMySatsumaAccept(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "my-satsuma?status=welcome");
		waitForTitle("My Satsuma | Satsuma Loans");
		waitForVisibilityOfElement(byLblPopSuccessMsg);
		Assert.assertEquals(getDriver().findElement(byLblPopSuccessMsg).getText(), "Great news, your loan has been approved.", "Pop up message on mysatsuma");
	}

	public void assertOnPageMySatsumaReview(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "my-satsuma?status=review");
		waitForTitle("My Satsuma | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byLblPopSuccessMsg).getText(), "We're just reviewing your application.", "Pop up message on mysatsuma");
	}

	public void assertOnPageMySatsuma(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "my-satsuma");
		waitForTitle("My Satsuma | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".block")).getText(), "Welcome to MySatsuma", "my satsuma welcome message");

	}

	public void assertOnPageIDVReferral(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "apply/complete");
		waitForTitle("Thank you, we will be in touch | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(By.cssSelector("div[class='main-content col-md-12'] h1")).getText(), "You’re just a few clicks away", "page main header on idv complete page");
	}

	public void assertOnPageMySatsumaEmail(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "my-satsuma?status=verify-emp");
		waitForTitle("My Satsuma | Satsuma Loans");
		Assert.assertTrue(getDriver().findElement(byLblPopEmailMsg).getText().contains("Before you send your email please make sure"), "Pop up message on mysatsuma");
	}

	public void assertOnPageMySatsumaEmailUn(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "my-satsuma?status=verify-un");
		waitForTitle("My Satsuma | Satsuma Loans");
		Assert.assertTrue(getDriver().findElement(byLblPopEmailMsg).getText().contains("Before you send your email please make sure"), "Pop up message on mysatsuma");
	}

	public void assertOnPageMySatsumaWorldPayComplete() {
		takeIncrementScreenshot();

		waitForVisibilityOfElement(By.cssSelector(".main-content > h2:nth-child(1)"));
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".main-content > h2:nth-child(1)")).getText(), "Payment successful");

	}

	private String randomEmail() {
		String result = RandomStringUtils.random(1, 0, 52, true, true, "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray()) + RandomStringUtils.random(10, 0, 52, true, true, "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz".toCharArray());
		return result + "@randomemail.com";
	}

	public void setRandomEmail() {
		gsEmailAddress = randomEmail();
	}

	public String randomPostcode() {
		List<String> inwardList = Arrays.asList("BD", "LS", "SE", "E", "W", "SW", "N", "NW", "NE", "LE", "WF", "HG", "M");
		List<String> outwardList = Arrays.asList("SU", "AP", "LZ", "LW", "LD", "JQ", "HF", "GZ", "NY");
		Random rand = new Random();

		// inward = {};
		// outward = {};
		String inward = inwardList.get(rand.nextInt(inwardList.size()));
		String outward = outwardList.get(rand.nextInt(outwardList.size()));

		int inwardNumber = rand.nextInt(9) + 1;
		int outwardNumber = rand.nextInt(9) + 1;

		return inward + inwardNumber + " " + outwardNumber + outward;
	}

	public void setRandomPostcode() {
		gsPostcode = randomPostcode();
	}

	public void setRandomDOB() {
		gsDOB = getRandomDOB();
	}

	public void setRandomDOB(String year) {
		gsDOB = getRandomDOB().substring(0, 6) + year;
		log.debug("DOB with year: " + gsDOB);
	}

	public SatsumaCustomer prSOAPUIGetCustomerDetailsFromAgreement(String psPanCreditServiceServer, String agreementNumber) throws XmlException, IOException, SoapUIException {
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_MobileTools");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_GetCustomerDetails");

		log.info("Get Customer Details for agreement " + agreementNumber);
		// Set attributes before submission
		testCase.setPropertyValue("ptcAgreementNumber", agreementNumber);
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		List<String> agreements = new ArrayList<String>();
		agreements.add(agreementNumber);

		return new SatsumaCustomer(testCase.getPropertyValue("ptcForename"), testCase.getPropertyValue("ptcSurname"), testCase.getPropertyValue("ptcDOB"), testCase.getPropertyValue("ptcPersonId"), testCase.getPropertyValue("ptcPostcode"), testCase.getPropertyValue("ptcEmailAddress"), agreements);
	}

	public void javascriptFocus(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].focus();", element);

	}

	public void javascriptClick(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].focus();", element);
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", element);
	}

	public void prConfirmLVA() {

		log.warn("Temporarily set the loan amount and term again");

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByValue(gsRequestedLoanAmount);

		String termText = "";

		if (gsRepaymentFrequency.equals("Weekly")) {
			termText = "weeks";
		} else if (gsRepaymentFrequency.equals("Monthly")) {
			termText = "months";
		} else {
			Assert.fail("Invalid loan frequency " + gsRepaymentFrequency);
		}

		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gsRequestedTerm + " " + termText);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and that there are other
		// options available to them
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer"), "Check header is right for existing customer");

		// Assert that Interest, Weekly repayments and TAP are displayed
		// correctly
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedInterest), getDriver().findElement(By.id("TotalInterestLVACalcText")).getText());
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountLVACalcText")).getText());
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedTAP), getDriver().findElement(By.id("TotalAmountLVACalcText")).getText());

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB, Keys.SPACE));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();
		}

	}

	public String formatDate(String dateIn, String dateInFormat) throws ParseException {
		return formatDate(dateIn, dateInFormat, "dd/MM/yyyy");
	}

	public String formatDate(String dateIn, String dateInFormat, String dateOutFormat) throws ParseException {
		SimpleDateFormat dateInFormatter = new SimpleDateFormat(dateInFormat);
		SimpleDateFormat dateOutFormatter = new SimpleDateFormat(dateOutFormat);

		Date tempDate = dateInFormatter.parse(dateIn);

		return dateOutFormatter.format(tempDate);
	}

	public void prPANCheckNameChanged() {
		getDriver().findElement(By.linkText("Name & Address")).click();
		Assert.assertTrue(getDriver().findElement(By.id("surname")).getAttribute("value").contains("AutoDel"), "check surname has changed");
		Assert.assertTrue(getDriver().findElement(By.id("forename")).getAttribute("value").contains("AutoDel"), "check forename has changed");

	}

	@Deprecated
	public String getScheduleStartDateForMonthly(int preferredDOM, String strPanSystemDate) throws ParseException {
		// minimum is 28 days
		// eg today is 6/10/2016
		// I choose 1st
		// I get the 1st of december

		// if currentdate + 28 days is more than the DOM I choose and next month
		// it becomes the next month

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dtPanSystemDate = sdf.parse(strPanSystemDate);
		Calendar calExpectedDate = Calendar.getInstance();
		calExpectedDate.setTime(dtPanSystemDate);
		calExpectedDate.set(Calendar.DAY_OF_MONTH, preferredDOM);
		calExpectedDate.add(Calendar.MONTH, 1);
		Date expectedDateBasedOnDOM = calExpectedDate.getTime();

		Calendar calPossibleDate = Calendar.getInstance();
		calPossibleDate.setTime(dtPanSystemDate);
		calPossibleDate.add(Calendar.DATE, 28); // Adding 28 days
		Date compareDate = calPossibleDate.getTime();

		if (compareDate.after(expectedDateBasedOnDOM)) {
			calExpectedDate.add(Calendar.MONTH, 1);
			expectedDateBasedOnDOM = calExpectedDate.getTime();
		}
		return sdf.format(expectedDateBasedOnDOM);
	}

	@Deprecated
	public String getScheduleEndDateForMonthly(String startDate, int term) throws ParseException {
		// will be schedule end date + whatever term
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Date dtStartDate = sdf.parse(startDate);
		Calendar c = Calendar.getInstance();
		c.setTime(dtStartDate);
		c.add(Calendar.MONTH, term - 1);
		return sdf.format(c.getTime());
	}

	public void fetchPanDate() throws XmlException, IOException, SoapUIException, ParseException {
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("GetPanDate");

		testCase.setPropertyValue("ptcPanCreditServiceServer", gsPanCreditServiceServer);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		TimeHackHelper.setPanDate(formatDate(testCase.getPropertyValue("ptcPANDate"), "yyyy-MM-dd"));

		log.debug("panSystemDate: " + TimeHackHelper.getPanDate());

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	protected String formatCurrency2DP(float amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£###,###,###,###.00";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;
		// return "£" + String.format("%.2f", amount);
		// return "£" + String.format("%.0f", amount);
	}

	protected String formatCurrencyNoComma2DP(float amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£####.00";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;
		// return "£" + String.format("%.2f", amount);
		// return "£" + String.format("%.0f", amount);
	}

	public String formatCurrencyNoDP(float amount) {
		Double dblAmount = Double.valueOf(amount);
		String pattern = "£###,###,###,###";
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(dblAmount);
		return output;

		// return "£" + String.format("%.2f", amount);
		// return "£" + String.format("%.0f", amount);
	}

	public String getPANLoanPurpose(String webLoanPurpose) {
		String loanPurpose = "";
		switch (webLoanPurpose) {
		case "Family":
			loanPurpose = "Family Occasion";
			break;
		case "Home Improvements":
			loanPurpose = "Home Improvement";
			break;
		case "Personal":
			loanPurpose = "Personal Spend";
			break;
		}

		return loanPurpose;
	}

	public String getWebLoanPurpose(String panLoanPurpose) {
		String loanPurpose = "";
		switch (panLoanPurpose) {
		case "Family Occasion":
			loanPurpose = "Family";
			break;
		case "Home Improvement":
			loanPurpose = "Home Improvements";
			break;
		case "Personal Spend":
			loanPurpose = "Personal";
			break;
		}
		return loanPurpose;
	}

	// return correct suffix
	public String dateSuffix(final Calendar cal) {
		final int date = cal.get(Calendar.DATE);
		switch (date % 10) {
		case 1:
			if (date != 11) {
				return "st";
			}
			break;

		case 2:
			if (date != 12) {
				return "nd";
			}
			break;

		case 3:
			if (date != 13) {
				return "rd";
			}
			break;
		}
		return "th";
	}

	public String dateSuffix(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return dateSuffix(cal);
	}

	public void prGoToSatsumaHome(String gsSatsumaSiteUrl) {
		int errorCount = 0;
		while (true) {
			try {
				getDriver().get(gsSatsumaSiteUrl + "/development/backend/killsession");
				// Goto Satsuma site
				getDriver().get(gsSatsumaSiteUrl);
				// wait for calculator to appear
				waitForVisibilityOfElement(By.id("SubmitHomeCalc"));
				break; // if successful leave loop
			} catch (TimeoutException e) {
				// clear things down
				getDriver().manage().deleteAllCookies();
				if (errorCount > 2) {
					log.error("Error couldn't load homepage after 3 tries");
					Assert.fail("Error couldn't load homepage after 3 tries");
				} else {
					// warning
					log.warn("Couldn't load homepage, for some reason trying again, remaining retries: " + (2 - errorCount));
				}
				errorCount++;
			}
		}
	}

	public void prClickAndGoToApplyPage(String gsSatsumaSiteUrl) {
		final By byBtnApply = By.id("SubmitHomeCalc");
		final By byBtnStartYourApplication = By.linkText("Start your application");
		waitForVisibilityOfElement(byBtnApply);
		waitForClickableElement(byBtnApply);

		getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
		// scrollToElement(getDriver().findElement(byBtnApply));
		try {
			getDriver().findElement(byBtnApply).click();
		} catch (TimeoutException e) {
			log.warn("page didn't load");
		}
		int retryCounter = 0;
		while (true) {
			try {
				waitForVisibilityOfElement(byBtnStartYourApplication);
				break;
			} catch (NoSuchElementException e) {
				if (retryCounter > 2)
					Assert.fail("Couldn't click apply button");
				log.warn("Couldn't find start your application button, trying to click apply again.");
				int applyRetryCounter = 0;
				while (true) {
					try {
						getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
						getDriver().findElement(byBtnApply).click();
						retryCounter++;
						break;
					} catch (NoSuchElementException f) {
						if (applyRetryCounter > 2) {
							log.error("Couldn't find apply button after 2 retries");
							Assert.fail("Couldn't find apply button after 2 retries");
						}
						log.warn("Couldn't find apply button, trying again.");
						applyRetryCounter++;
						getDriver().get(gsSatsumaSiteUrl);
					}
				}
			}
		}
	}

	private String convertLoanPurposeToBroker(String loanPurpose) {
		switch (loanPurpose) {
		case "Personal Spend":
			return "Personal";
		case "Debt Repayment":
			return "DebtRepayment";
		default:
			return loanPurpose;
		}
	}

	private String convertResidentialStatusToBroker(String residentialStatus) {
		switch (residentialStatus) {
		case "Tenant Unfurnished":
			return "TenantUnfurnished";
		default:
			return residentialStatus;
		}
	}

	public String getReasonCodeFromPANCode(String panCode, ApplicationType type) {
		if (type.equals(ApplicationType.B2B)) {
			switch (panCode) {
			case "107HZ":
				return "PD08";
			case "107HY":
				return "PD09";
			case "107HX":
				return "PD10";
			case "107SX":
				return "PD13";
			case "107CF":
				return "PD15";
			case "107HA":
				return "PD02";
			case "107HQ":
				return "PD05";
			case "107HP":
				return "PD06";
			case "107SA":
				return "PD12";
			case "107SC":
				return "PD13";
			case "109":
				return "PD19";
			case "111":
				return "PD25";
			case "201":
				return "EX08";
			case "202":
				return "EX01";
			case "203":
				return "EX03";
			case "204":
				return "EX07";
			case "204a":
				return "EX07";
			case "204b":
				return "EX05";
				// return "EX05";???
			case "205":
				return "EX06";
			case "207":
				return "EX02";
			case "401":
				return "BE08";
				// xml only...
			case "403":
				return "BS01";
			case "405":
				return "BE01";
			case "406":
				return "BE05";
			case "407":
				return "BE04";
			case "702":
				return "IC11";
			case "703":
				return "IC06";
			case "704":
				return "IC02";
			case "705":
				return "IC05";
			case "706":
				return "IC01";
			case "707":
				return "IC13";
			case "708":
				return "IC07";
			case "709":
				return "IC08";
			case "710":
				return "IC12";
			case "711":
				return "IC03";
			case "720":
				return "IC09";
			case "721":
				return "IC10";
			case "722":
				return "IC04";
			case "750":
				return "BE03";
			case "751":
				return "BE06";
			case "752":
				return "BE02";
			case "801":
				return "";
			case "901":
				return "RQ04";
			case "904":
				return "AF01";
			default:
				return panCode;
			}

		} else {
			// else b2c or obs
			switch (panCode) {
			case "107HZ":
				return "PD08";
			case "107HY":
				return "PD09";
			case "107HX":
				return "PD10";
			case "107SX":
				return "PD13";
			case "107CF":
				return "PD15";
			case "107HA":
				return "PD02";
			case "107HQ":
				return "PD05";
			case "107HP":
				return "PD06";
			case "107SA":
				return "PD12";
			case "107SC":
				return "PD13";
			case "201":
				return "EX08";
			case "202":
				return "EX01";
			case "203":
				return "EX03";
			case "204":
				return "EX07";
			case "204a":
				return "EX07";
			case "204b":
				return "EX05";
				// return "EX05";???
			case "205":
				return "EX06";
			case "207":
				return "EX02";
			case "303":
				return "RQ02";
			case "401":
				return "BE07";
			case "403":
				return "BS01";
			case "405":
				return "RQ22";
			case "406":
				return "BE05";
			case "407":
				return "RQ24";
			case "702":
				return "RQ15";
			case "703":
				return "IC06";
			case "704":
				return "RQ10";
			case "705":
				return "RQ12";
			case "706":
				return "RQ09";
			case "707":
				return "RQ17";
			case "708":
				return "RQ13";
			case "709":
				return "RQ14";
			case "710":
				return "RQ16";
			case "711":
				return "RQ11";
			case "720":
				return "IC09";
			case "721":
			case "722":
				return "RQ18";
			case "750":
				return "RQ07";
			case "751":
				return "RQ08";
			case "752":
				return "RQ06";
			case "905":
				return "RQ19";
			case "907":
				return "RQ21";
			case "908":
				return "RQ18";
			case "909":
				return "RQ22";
			case "910":
				return "RQ23";
			default:
				return panCode;
			}
		}
	}

	public String getGroupCodeFromPANCode(String panCode, ApplicationType type) {
		String tempStr = null;
		if (panCode.startsWith("20"))
			tempStr = panCode.substring(0, 2);
		else
			tempStr = panCode;

		if (type.equals(ApplicationType.B2B)) {
			switch (tempStr) {
			case "107HZ":
			case "107HY":
			case "107HX":
			case "107SX":
			case "107CF":
			case "107HA":
			case "107HQ":
			case "107HP":
			case "107SA":
			case "107SC":
				return "DN04";
			case "109":
				return "DN04";
			case "111":
				return "DN02";
			case "20":
				return "DN05";
			case "407":
			case "401":
				return "DN06";
			case "403":
				return "DN06";
			case "405":
				return "DN06";
			case "406":
				return "DN06";
			case "702":
			case "703":
			case "704":
			case "705":
			case "706":
			case "707":
			case "708":
			case "709":
			case "710":
			case "711":
			case "720":
			case "721":
			case "722":
				return "DN07";
			case "750":
			case "751":
			case "752":
				return "DN06";
			case "801":
				return "DN10";
			case "901":
				return "RF11";
			case "904":
				return "DN08";
			default:
				return panCode;
			}
		} else {
			switch (tempStr) {
			case "107HZ":
			case "107HY":
			case "107HX":
			case "107SX":
			case "107CF":
			case "107HA":
			case "107HQ":
			case "107HP":
			case "107SA":
			case "107SC":
				return "DN04";
			case "20":
				return "DN05";
			case "303":
				return "RF11";
			case "407":
				return "RF11";
			case "401":
				return "DN06";
			case "403":
				return "DN06";
			case "405":
				return "DN06";
			case "406":
				return "DN06";
			case "702":
			case "704":
			case "705":
			case "706":
			case "707":
			case "708":
			case "709":
			case "710":
			case "711":
			case "750":
			case "751":
			case "752":
				return "RF11";
			case "703":
			case "720":
			case "721":
			case "722":
				return "DN07";
			case "801":
				return "DN09";
			case "905":
			case "906":
			case "907":
			case "908":
			case "909":
			case "910":
				return "RF11";
			default:
				return panCode;
			}
		}
	}

	public void waitForAttributeValue(WebElement element, final String name, final String value) throws Exception {
		(new FluentWait<WebElement>(element).withTimeout(30, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)).until(new Function<WebElement, Boolean>() {
			@Override
			public Boolean apply(WebElement element) {
				return element.getAttribute(name).equals(value);
			}
		});
	}

	public void clickStartYourApplicationRetryIfNeeded() {
		String currentUrl = getDriver().getCurrentUrl();
		int retries = 2;
		while (true) {
			try {
				// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
				scrollToElement(getDriver().findElement(By.linkText("Start your application")));
				getDriver().findElement(By.linkText("Start your application")).click();
			} catch (TimeoutException e) {
				retries--;
				// page load timed out reload page and try to click again
				if (retries == 0)
					break;
				getDriver().get(currentUrl);
			}
			break;
		}
	}

	public void scrollToTopOfPage() {
		((JavascriptExecutor) getDriver()).executeScript("window.scrollTo(0,0)");
	}

	public void disabledAssertFLEESigOffer() {

		// retrieve offer and assert
		RetrieveOfferResponse offerResponse;
		offerResponse = RestHelper.getOffer(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB));

		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferParty().getId(), MatchKeyHelper.generateMatchKey(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB)));
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getEligibilityReasonCode(), EligibilityReasonCode.HAS_APPROVED_PROPOSAL);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getIsEligibleForLending(), false);
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getSourcev2(), "WW");
		Assert.assertEquals(offerResponse.getOfferPartyProducts().getOfferProducts()[0].getSource(), "SP");

	}

	public void seedFLEIneligibleOffer(String sourceV2, int offerPartyStatus, boolean vulnerable) throws InterruptedException {
		boolean existingcustomer = false;

		int score = 0;

		// create and seed offer in offer service
		OfferRequest req = null;
		req = OfferServiceRequestBuilder.ineligible(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB), sourceV2, score, offerPartyStatus, vulnerable);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		RestHelper.postOffer(json);

	}

	public void seedFLEEligibleOffer(String sourcev2, Double eligibleAmount, boolean vulnerable) throws InterruptedException {
		int score = 500;
		int offerPartyStatus = OfferPartyStatus.UNKNOWN;

		// create and seed offer in offer service
		OfferRequest req = null;
		req = OfferServiceRequestBuilder.eligible(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB), sourcev2, eligibleAmount, score, offerPartyStatus, vulnerable);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		RestHelper.postOffer(json);
	}

	public void seedFLEEligibleOffer(String sourcev2, Double eligibleAmount, boolean vulnerable, int status) throws InterruptedException {

		seedFLEEligibleOffer(sourcev2, eligibleAmount, vulnerable, status, 500);
	}

	public void seedFLEEligibleOffer(String sourcev2, Double eligibleAmount, boolean vulnerable, int status, int score) throws InterruptedException {

		// create and seed offer in offer service
		OfferRequest req = null;
		req = OfferServiceRequestBuilder.eligible(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB), sourcev2, eligibleAmount, score, status, vulnerable);

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		RestHelper.postOffer(json);
	}

	public void seedFLEEligibleNullOfferAmount(String sourcev2, Double eligibleAmount, boolean vulnerable, int status) throws InterruptedException {
		int score = 0;

		// create and seed offer in offer service
		OfferRequest req = null;
		req = OfferServiceRequestBuilder.eligible(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB), sourcev2, null, score, status, vulnerable);

		// req.getOfferProducts()[0]

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		RestHelper.postOffer(json);
	}

	public void seedFLEEligibleOffer(boolean paidUp, Double eligibleAmount, boolean vulnerable) throws InterruptedException {
		int score = 500;
		String sourcev2;
		int offerPartyStatus;

		if (paidUp) {
			sourcev2 = "PS";
			offerPartyStatus = OfferPartyStatus.PAID_UP;
		} else {
			sourcev2 = "SA";
			offerPartyStatus = OfferPartyStatus.ACTIVE;
		}

		log.info(gsDOB);
		Thread.sleep(500);
		// create and seed offer in offer service
		OfferRequest req = null;
		req = OfferServiceRequestBuilder.eligible(gsFirstname, gsSurname, dateFromStringMultipleFormat(gsDOB), sourcev2, eligibleAmount, score, offerPartyStatus, vulnerable);
		Thread.sleep(200);
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.serializeNulls();
		Gson gson = gsonBuilder.create();

		String json = gson.toJson(req);

		RestHelper.postOffer(json);
		Thread.sleep(5000);
	}

	public void seedFLEEligibleOffer(boolean paidUp, Double eligibleAmount) throws InterruptedException {
		Thread.sleep(1000);
		seedFLEEligibleOffer(paidUp, eligibleAmount, false);
	}

	private Date dateFromStringMultipleFormat(String dateIn) {
		SimpleDateFormat sdfyyyymmdd = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat sdfmmddyyyy = new SimpleDateFormat("dd/MM/yyyy");
		Date dateOut = null;
		try {
			dateOut = sdfyyyymmdd.parse(dateIn);
		} catch (ParseException e) {
			try {
				dateOut = sdfmmddyyyy.parse(dateIn);
			} catch (ParseException f) {
				e.printStackTrace();
			}
		}

		Assert.assertNotNull(dateOut);
		return dateOut;
	}

	public void selectContactPrefs(boolean contactByEmail, boolean contactBySMS, boolean contactByPost, boolean contactByPhone) throws InterruptedException {
		Thread.sleep(500);
		scrollToElement(getDriver().findElement((By.cssSelector("label[for='ContactPreferencesNo']"))));
		waitForVisibilityOfElement(By.cssSelector("label[for='ContactPreferencesNo']"));
		waitForClickableElement(By.cssSelector("label[for='ContactPreferencesNo']"));

		// if all contact prefs are false, just click no
		if (contactByEmail && contactBySMS && contactByPost && contactByPhone) {
			getDriver().findElement(By.cssSelector("label[for='ContactPreferencesNo']")).click();
		} else {
			// if not then click yes and then selectively choose the right
			// options
			getDriver().findElement(By.cssSelector("label[for='ContactPreferencesYes']")).click();

			scrollToElement(getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']")));
			waitForVisibilityOfElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']"));
			waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']"));

			if (contactByEmail) {
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']")).click();
			} else {
				waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']"));
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByEmailYes']")).click();
			}

			scrollToElement(getDriver().findElement(By.cssSelector("label[for='OptInToMarketingBySmsYes']")));
			waitForVisibilityOfElement(By.cssSelector("label[for='OptInToMarketingBySmsYes']"));
			waitForClickableElement(By.cssSelector("label[for='OptInToMarketingBySmsYes']"));

			if (contactBySMS) {
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingBySmsYes']")).click();
			} else {
				waitForClickableElement(By.cssSelector("label[for='OptInToMarketingBySmsNo']"));
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingBySmsNo']")).click();
			}

			scrollToElement(getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByTelephoneYes']")));
			waitForVisibilityOfElement(By.cssSelector("label[for='OptInToMarketingByTelephoneYes']"));
			waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByTelephoneYes']"));

			if (contactByPhone) {
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByTelephoneYes']")).click();
			} else {
				waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByTelephoneNo']"));
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByTelephoneNo']")).click();
			}

			scrollToElement(getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByPostYes']")));
			waitForVisibilityOfElement(By.cssSelector("label[for='OptInToMarketingByPostYes']"));
			waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByPostYes']"));

			if (contactByPost) {
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByPostYes']")).click();
			} else {
				waitForClickableElement(By.cssSelector("label[for='OptInToMarketingByPostNo']"));
				getDriver().findElement(By.cssSelector("label[for='OptInToMarketingByPostNo']")).click();
			}

		}
	}
}
