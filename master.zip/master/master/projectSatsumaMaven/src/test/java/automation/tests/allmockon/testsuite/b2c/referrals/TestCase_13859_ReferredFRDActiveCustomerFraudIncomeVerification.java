package automation.tests.allmockon.testsuite.b2c.referrals;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;

public class TestCase_13859_ReferredFRDActiveCustomerFraudIncomeVerification extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_ReferActiveApplicantFraudIncomeVerification() throws Exception {

		// Capture current Url
		gsCurrentUrl = getDriver().getCurrentUrl();

		// Data Preparation
		// ================

		// Get a application profile for a mocked whose's affordability is
		// flagged as being max'd out
		// Applicant Miss Jadzia FRDACTFIV
		gcb.prGetApplicantProfile(144);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
			// " found, but not half paid up, please remove and re-try test");
			log.warn("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, but not half paid up, please remove and re-try test");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);

			// try to add agreement after removal
			// Seed a 50% paid up for this person in PAN
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

			log.info("Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of half paid agreement for this test failed.");
			}

		} else {

			// Seed a 50% paid up for this person in PAN
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

			log.info("Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of half paid agreement for this test failed.");
			}
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		if (gcb.gsQuickApply.equals("true")) {
			// Your Finances Page
			// ==================

			gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

			// Invoke Next action: Next: Change Loan Amount
			gcb.prClickForNextAction();

		}

		// CV - 08.03.2016 - now includes the Change Loan Amount screen despite
		// the fact that loan requested is within limits

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Loan Amount Slider defaulted to £200 as this is the maximum amount
		// the customer is offered as his previous request was higher
		Assert.assertEquals("200", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		gcb.prConfirmLVA();

		gcb.prClickForNextAction();

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// // Do you currently have, or have you previously had a Satsuma Loan?
		// -
		// // Default click is Yes
		// if
		// (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected())
		// {
		// getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		// }
		//
		// getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(gcb.gsPANAgreementNumber);
		//
		// // How much would you like to borrow ?
		// // Loan Amount
		//
		// String gsTmp;
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// gsTmp = "FormCalc.setAmount(" + gcb.gsRequestedLoanAmount + ")";
		// js.executeScript(gsTmp);
		// // Requested Loan Repayment Frequency
		// if (gcb.gsRepaymentFrequency.equals("Monthly")) {
		// if
		// (!getDriver().findElement(By.id("TermTypeFormCalcMonthlyLabel")).isSelected())
		// {
		// getDriver().findElement(By.id("TermTypeFormCalcMonthlyLabel")).click();
		// }
		// }
		// if (gcb.gsRepaymentFrequency.equals("Weekly")) {
		// if
		// (!getDriver().findElement(By.id("TermTypeFormCalcWeeklyLabel")).isSelected())
		// {
		// getDriver().findElement(By.id("TermTypeFormCalcWeeklyLabel")).click();
		// }
		// }
		// // Requested Term
		// gsTmp = "FormCalc.setTerm(" + gcb.gsRequestedTerm + ")";
		//
		// js.executeScript(gsTmp);
		//
		// Select dropdown;
		// // On which day of the week would you like to make your repayments,
		// only
		// // applicable for Weekly Frequency
		//
		// if (gcb.gsRepaymentFrequency.equals("Weekly")) {
		// dropdown = new
		// Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// dropdown.selectByVisibleText(gcb.gsPreferredPaymentDow);
		// }
		//
		// // On which day of the week would you like to make your repayments
		// dropdown = new
		// Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// dropdown.selectByVisibleText(gcb.gsPreferredPaymentDow);
		//
		// // What will you use your loan for?*
		// dropdown = new
		// Select(getDriver().findElement(By.id("LoanPurposeValue")));
		// dropdown.selectByVisibleText(gcb.gsLoanPurpose);
		//
		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today?* Default to £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("�" + gcb.gsRequestedLoanAmount);
		//
		// // Please read our website cookie policy and tick this box to agree -
		// // Tick please
		// getDriver().findElement(By.id("CookieAccepted")).click();
		//
		// // Personal Details
		// // ----------------
		//
		// // Applicants Title
		// dropdown = new
		// Select(getDriver().findElement(By.id("CustomerTitle")));
		// dropdown.selectByVisibleText(gcb.gsTitle);
		// // Applicants Firstname
		// getDriver().findElement(By.id("Forename")).sendKeys(gcb.gsFirstname);
		// // Applicants Surname
		// getDriver().findElement(By.id("Surname")).sendKeys(gcb.gsSurname);
		// // Applicants DOB - Day
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		// dropdown.selectByVisibleText(gcb.gsDOB.substring(0, 2));
		// // Applicants DOB - Month
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		// dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gcb.gsDOB.substring(3,
		// 5)));
		// // Applicants DOB - Year
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		// dropdown.selectByVisibleText(gcb.gsDOB.substring(6, 10));
		// // Applicants Marital Status
		// dropdown = new
		// Select(getDriver().findElement(By.id("MaritalStatusValue")));
		// dropdown.selectByVisibleText(gcb.gsMaritalStatus);
		// // Applicants Number Of Dependants
		// dropdown = new
		// Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		// dropdown.selectByVisibleText(gcb.gsNumberOfDependants);
		//
		// // Your Address
		// // ------------
		//
		// // Applicants Residential Status
		// dropdown = new
		// Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		// dropdown.selectByVisibleText(gcb.gsResidentialStatus);
		//
		// // Applicants Current Address Moved In Date
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		// dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gcb.gsCurrentHouseMovedInDate.substring(3,
		// 5)));
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		// dropdown.selectByVisibleText(gcb.gsCurrentHouseMovedInDate.substring(6,
		// 10));
		//
		// // Use QAS with non-existence postcode to force manual entry of
		// address
		// // details
		// getDriver().findElement(By.id("houseNameOrNumberSearch")).sendKeys(gcb.gsBuildingNumber);
		// getDriver().findElement(By.id("PostCode")).sendKeys("ZZ1 1ZZ");
		// getDriver().findElement(By.id("search")).click();
		//
		// WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-addresssearch-manualentryoption=' ']")));
		// getDriver().findElement(By.linkText("Or enter your address manually")).click();
		//
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentAddress_FlatNumber")));
		// // Flat number
		// getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys(gcb.gsFlatNumber);
		// // House/Building name
		// getDriver().findElement(By.id("CurrentAddress_BuildingName")).sendKeys(gcb.gsBuildingName);
		// // House Number
		// getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys(gcb.gsBuildingNumber);
		// // Street
		// getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys(gcb.gsStreet);
		// // District
		// getDriver().findElement(By.id("CurrentAddress_District")).sendKeys(gcb.gsDistrict);
		// // Town/City
		// getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys(gcb.gsTownCity);
		// // County
		// getDriver().findElement(By.id("CurrentAddress_County")).sendKeys(gcb.gsCounty);
		// // Postcode
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(gcb.gsPostcode);
		//
		// // Your Contact Details
		// // --------------------
		//
		// // Applicant Mobile Phone
		// getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(gcb.gsMobileNumber);
		// // Applicant Email Address
		// getDriver().findElement(By.id("EmailAddress")).sendKeys(gcb.gsEmailAddress);
		//
		// // Invoke Next action: Next: Your finances
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();
		//
		// // Your Finances Page
		// // ==================
		//
		// // Landed on finances page
		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsSatsumaSiteUrl + "Apply/IncomeAndOutgoings",
		// gsCurrentUrl);
		// Assert.assertTrue(getDriver().getTitle().contains("Your Finances | Satsuma Loans"));
		//
		// // Income source
		// dropdown = new
		// Select(getDriver().findElement(By.id("EmploymentStatusValue")));
		// dropdown.selectByVisibleText(gcb.gsSourceOfIncome);
		//
		// // Income
		// getDriver().findElement(By.id("Income")).clear();
		// getDriver().findElement(By.id("Income")).sendKeys(gcb.gsIncome);
		//
		// // Income Frequency
		// dropdown = new
		// Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		// dropdown.selectByVisibleText(gcb.gsIncomeFrequency);
		//
		// // Income Method
		// dropdown = new
		// Select(getDriver().findElement(By.id("IncomeMethodValue")));
		// dropdown.selectByVisibleText(gcb.gsIncomePaymentMethod);
		//
		// // Housing costs amount
		// getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(gcb.gsHousingCosts);
		//
		// // Has Credit cards
		// if (gcb.gsHasCreditCards.equals("true") &&
		// !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).isSelected())
		// {
		// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).click();
		// // Monthly Creditcard and Loan Repayments
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(gcb.gsMonthlyLoanRepayments);
		// } else if (gcb.gsHasCreditCards.equals("false") &&
		// !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected())
		// {
		// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
		// }
		//
		// // Has Other Loans
		// if (gcb.gsHasExistingLoans.equals("true") &&
		// !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).isSelected())
		// {
		// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).click();
		// } else if (gcb.gsHasExistingLoans.equals("false") &&
		// !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected())
		// {
		// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
		// }
		//
		// // Other outgoings
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(gcb.gsMonthlyOtherOutgoings);
		//
		// // Consents and Use of Personal Information
		// // Declaration
		// getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).click();
		// // Using my personal information
		// getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).click();
		// // Sharing my personal information
		// getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).click();
		// // Credit reference agencies
		// getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).click();
		// // Verifying my identity and fraud checks
		// getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).click();
		// // Access to information
		// getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).click();
		// // Marketing
		// getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).click();
		//
		// // Have agreed to bureau search - Must tick to progress
		// if (gcb.gsConsentToCreditSearch.equals("true") &&
		// !getDriver().findElement(By.xpath("//input[@id='AgreedToBureauSearch']")).isSelected())
		// {
		// getDriver().findElement(By.id("AgreedToBureauSearch")).click();
		// }
		//
		// // Invoke Next action: Next: Review Your Quote
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();
		//
		// // Your Quote page
		// // ==============
		//
		// // Landed on Your Quote page
		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsSatsumaSiteUrl + "Apply/Quote", gsCurrentUrl);
		// Assert.assertTrue(getDriver().getTitle().contains("Your Loan Offer | Satsuma Loans"));
		//
		// // Invoke Next action: Next: Bank Details
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();
		//
		// // Your Bank Details page
		// // ======================
		//
		// // Landed on Your Bank Details page
		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsSatsumaSiteUrl + "Apply/BankDetails",
		// gsCurrentUrl);
		// //
		// assertTrue(getDriver().getTitle().contains("Your Bank Details | Satsuma Loans"));
		//
		// // Account Holder
		// getDriver().findElement(By.id("AccountHolder")).sendKeys(gcb.gsBankAccountName);
		//
		// // Account Sort Code
		// getDriver().findElement(By.id("SortCodePart1")).sendKeys(gcb.gsBankSortcode.substring(0,
		// 2));
		// getDriver().findElement(By.id("SortCodePart2")).sendKeys(gcb.gsBankSortcode.substring(2,
		// 4));
		// getDriver().findElement(By.id("SortCodePart3")).sendKeys(gcb.gsBankSortcode.substring(4,
		// 6));
		//
		// // Account Number
		// getDriver().findElement(By.id("AccountNumber")).sendKeys(gcb.gsBankAccountNumber);
		//
		// // When did you open your account with the bank?
		// dropdown = new
		// Select(getDriver().findElement(By.id("AccountOpenMonth")));
		// dropdown.selectByVisibleText(gcb.gsBankAccountOpenDate.substring(3,
		// 5).replaceFirst("^0*", ""));
		// dropdown = new
		// Select(getDriver().findElement(By.id("AccountOpenYear")));
		// dropdown.selectByVisibleText(gcb.gsBankAccountOpenDate.substring(6,
		// 10));
		//
		// // Invoke Next action: Next: Payment Details
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();
		//
		// // WorldPay Test Page
		// // =======================
		//
		// // Landed on WorldPay page
		// Assert.assertTrue(getDriver().getTitle().contains("Welcome to WorldPay"));
		//
		// // Has Mastercard, Visa Debit or Maestro
		// if (gcb.gsCreditCardType.equals("Mastercard")) {
		// getDriver().findElement(By.xpath("//input[@name='op-DPChoose-ECMC^SSL']")).click();
		// } else if (gcb.gsCreditCardType.equals("Visa Debit")) {
		// getDriver().findElement(By.xpath("//input[@name='op-DPChoose-VISA^SSL']")).click();
		// } else if (gcb.gsCreditCardType.equals("Maestro")) {
		// getDriver().findElement(By.xpath("//input[@name='op-DPChoose-MAESTRO^SSL']")).click();
		// } else {
		// Assert.fail("Aborted: Applicant Profile used must define CreditCardType as either Mastercard, Visa Debit or Maestro");
		// }
		//
		// Thread.sleep(1000);
		//
		// getDriver().findElement(By.xpath("//input[@id='cardNoInput']")).sendKeys(gcb.gsCreditCardNumber);
		// getDriver().findElement(By.xpath("//input[@id='cardCVV']")).sendKeys(gcb.gsCreditCardCVS);
		// dropdown = new
		// Select(getDriver().findElement(By.name("cardExp.month")));
		// dropdown.selectByVisibleText(gcb.gsCreditCardExpiryDate.substring(0,
		// 2));
		// dropdown = new
		// Select(getDriver().findElement(By.name("cardExp.year")));
		// dropdown.selectByVisibleText(gcb.gsCreditCardExpiryDate.substring(3,
		// 7));
		// getDriver().findElement(By.xpath("//input[@id='name']")).sendKeys(gcb.gsBankAccountName);
		//
		// // Invoke Next action: Simulator Test Page
		// getDriver().findElement(By.xpath("//input[@name='op-PMMakePayment']")).click();
		//
		// Thread.sleep(1000);
		// // Landed on WorldPay Simulator Response page
		// Assert.assertTrue(getDriver().getTitle().contains("Simulator page"));
		//
		// // Simulate Approved response - Postcode and address matched
		// dropdown = new Select(getDriver().findElement(By.name("PaRes")));
		// dropdown.selectByVisibleText("Authorised");
		// dropdown = new Select(getDriver().findElement(By.name("CVCRes")));
		// dropdown.selectByVisibleText("Approved");
		// dropdown = new Select(getDriver().findElement(By.name("AVSRes")));
		// dropdown.selectByVisibleText("Postcode and address matched");
		//
		// // Invoke Next action: ?
		// getDriver().findElement(By.xpath("//input[@name='continue']")).click();
		//
		// // (new WebDriverWait(getDriver(),
		// //
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));
		//
		// // Credit Agreement page
		// // ======================
		//
		// // Landed on correct page
		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsSatsumaSiteUrl + "Apply/Agreement",
		// gsCurrentUrl);
		// Assert.assertTrue(getDriver().getTitle().contains("Your credit agreement | Satsuma Loans"));
		//
		// // Credit Agreement
		// // ----------------
		//
		// // Product Explanation - Read acknowledged
		//
		// getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).click();
		//
		// getDriver().findElement(By.xpath("//input[@id='ReadProductExplanation']")).click();
		//
		// // Pre-Contract Credit Information
		// // -------------------------------
		//
		// // 1. Contact details - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();
		//
		// // 2. Key features of the credit product - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();
		//
		// // 3. Costs of the credit - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();
		//
		// // 4. Other important legal aspects - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();
		//
		// // 5. Additional information innthe case of distance marketing of
		// // financial services - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();
		//
		// // Contractual Terms and Conditions
		// // --------------------------------
		//
		// // 6. Terms and conditions - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();
		//
		// // 7. Marketing - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();
		//
		// // Confirm above sections read
		// getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).click();
		//
		// // Credit Agreement and E-Signature
		// // Fixed Sum Loan Agreement
		// // --------------------------------
		//
		// // Parties to the Agreement - Contact details - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();
		//
		// // Check name on agreement
		// getDriver().getPageSource().contains(gcb.gsTitle + " " +
		// gcb.gsFirstname + " " + gcb.gsSurname);
		//
		// // Key features of the credit product - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features-credit-product']")).click();
		//
		// // Costs of the credit - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();
		//
		// // Right of withdrawal - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();
		//
		// // Other important information - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();
		//
		// // Terms and conditions - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();
		//
		// // Marketing - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();
		//
		// // Confirm above section read
		// getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).click();
		//
		// // Signature of Customer
		// // ---------------------
		//
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname);
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname);
		//
		// // Capture Agreement Number
		// // ------------------------
		//
		// String sAgreementNumber;
		// sAgreementNumber =
		// getDriver().findElement(By.xpath("//p[@id='CreditAgreementHeader']/span[2]")).getText();
		// log.info("Agreement Created: " + sAgreementNumber);
		//
		// // Invoke Next action: Next: Complete your application
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		// // Your application is now being processed and verified Completion
		// page
		// //
		// =====================================================================
		//
		// // Landed on correct completion page - This specific completion page
		// is
		// // identified with id=Result12
		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsCurrentUrl.toLowerCase(), gsSatsumaSiteUrl +
		// "apply/complete");
		// if (getDriver().findElements(By.id("Result11")).size() == 0) {
		// Assert.fail("Completion Page: Not Result11 page - Your application is now being processed and verified");
		// }

		// Shows mysatsuma with agreement in review
		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// // rename surname to remove agreement from customer
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		// Navigate to the newly created agreement in PAN
		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred for fraud 708 - Callcredit GRO
		// Deceased (Primary reason for referral)
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Referral Queue");
		Assert.assertTrue(getDriver().getPageSource().contains("Callcredit GRO Deceased"));
		// Expected agreement to also be referred for Income Verification 904 -
		// Income Verification Referral (Secondary reason for referral)
		Assert.assertTrue(getDriver().getPageSource().contains("Income Verification Referral"));
		// Do not expect agreement to be referred for customer vulnerability
		Assert.assertFalse(getDriver().getPageSource().contains("Vulnerable Customer"));

		// Rename applicant's surname
		// gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
