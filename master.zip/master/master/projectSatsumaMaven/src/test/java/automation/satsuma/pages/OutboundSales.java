package automation.satsuma.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class OutboundSales extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	private String testName;
	private String outboundSalesServer;
	private String outboundSalesUrl;
	private int screenShotNumber;

	public OutboundSales(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public OutboundSales(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public String getOutboundSalesUrl() {
		return outboundSalesUrl;
	}

	public void setOutboundSalesUrl(String outboundSalesUrl) {
		this.outboundSalesUrl = outboundSalesUrl;
	}

	public String getOutboundSalesServer() {
		return outboundSalesServer;
	}

	public void setOutboundSalesServer(String outboundSalesServer) {
		this.outboundSalesServer = outboundSalesServer;
	}

	public void navigateToHomePage() {
		log.debug("outbound url " + outboundSalesUrl);
		getDriver().get(outboundSalesUrl);
	}

	public void prAssertOnPageFinishedIDResult5(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "sales/finished";

		// Landed on Finished page of type Result5 > Thank you for your interest
		// in another Satsuma Loan. Unfortunately we're unable to process your
		// application for a further loan today.
		log.info("prAssertOnPageFinishedIDResult5: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result5")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult5: Finished Page: Thank you for your interest in another Satsuma Loan. Unfortunately we're unable to process your application for a further loan today.");
		}
	}

	public void prAssertOnPageFinishedIDResult8(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "sales/finished";

		// Landed on Finished page of type Result8 > Decline - You have
		// previously been declined for a Satsuma loan.
		// We can see that you have previously submitted an application for a
		// Satsuma Loan, which was unfortunately declined
		log.info("prAssertOnPageFinishedIDResult8: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result8")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult8: Finished Page: Not Result8 page - We can see that you have previously submitted an application for a Satsuma Loan, which was unfortunately declined");
		}
	}

	public void assertOnPageHome(String satsumaSiteUrl) {
		By byLblOutboundHeader = By.cssSelector(".container h1");
		waitForUrl(satsumaSiteUrl + "/sales");
		waitForTitle("Outbound Sales Entry | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byLblOutboundHeader).getText(), "Customer loan application ...");
	}

	public void assertOnPageAboutYou(String psSatsumaSiteUrl) {
		By byLblHeaderOutboundAboutYou = By.cssSelector(".central h1");
		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/about-you";

		// Landed on About You page
		log.info("prAssertOnPageAboutYou: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		waitForTitle("Apply for a short term loan | Satsuma Loans");
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		Assert.assertEquals(getDriver().findElement(byLblHeaderOutboundAboutYou).getText(), "Sales Customer Satsuma Loan application…");
	}

	public void assertOnPageYourFinances(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/income-and-outgoings";

		// Landed on Your Finances page
		log.info("prAssertOnPageYourFinances: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		waitForTitle("Your finances | Satsuma Loans");
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

	}

	public void prAssertOnPageQuote(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/quote";

		// Landed on Quote page
		log.info("prAssertOnPageQuote: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageBankDetails(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/bank-details";

		// Landed on Bank Details page
		log.info("prAssertOnPageBankDetails: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void assertOnPageOutboundAgreementSummary(String gsSatsumaSiteUrl) {
		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase().replace("https", "http") + "/sales/agreement";

		// Landed on Bank Details page
		log.info("AssertOnOutboundAgreementSummary: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

	}

	public void prAssertOnPageFinishedIDResult25(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "sales/finished";

		log.info("prAssertOnPageFinishedIDResult25: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result25")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult25: Finished Page");
		}
	}

	// at the moment this method uses terrible selectors because the html code
	// does not have anything useful to use for picking up elements
	public void assertOutboundCreditAgreement(String loanAmount, String loanTerm, String frequency, String APR, String repaymentAmount, String TAP, String email) throws Exception {

		String frequencyTerm;

		if (frequency.equalsIgnoreCase("Weekly")) {
			frequencyTerm = "weeks";
		} else {
			frequencyTerm = "months";
		}

		By byLblLoanValue = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(1) > td:nth-child(2)");
		By byLblLoanTerm = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(2) > td:nth-child(2)");
		By byLblAPR = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(3) > td:nth-child(2)");
		By byLblRepaymentAmount = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(4) > td:nth-child(2)");
		By byLblTAP = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(5) > td:nth-child(2)");
		By byLblRepaymentDay = By.cssSelector("body > div.container.wrapper > section > table > tbody > tr:nth-child(6) > td:nth-child(2)");

		By byLblEmail = By.cssSelector("body > div.container.wrapper > section > p:nth-child(7)");
		By byLblAgreementNumber = By.cssSelector("body > div.container.wrapper > section > p:nth-child(11)");

		Assert.assertEquals(getDriver().findElement(byLblLoanValue).getText(), loanAmount);
		Assert.assertEquals(getDriver().findElement(byLblLoanTerm).getText(), loanTerm + " " + frequencyTerm);
		Assert.assertEquals(getDriver().findElement(byLblAPR).getText(), APR + "%");
		Assert.assertEquals(getDriver().findElement(byLblRepaymentAmount).getText(), repaymentAmount);
		Assert.assertEquals(getDriver().findElement(byLblTAP).getText(), TAP);
		Assert.assertEquals(getDriver().findElement(byLblEmail).getText(), email);

		log.debug("Agreement number " + getDriver().findElement(byLblAgreementNumber).getText());
	}

	public void fillInPageOutboundConfirmDOBPostcode(String gsDOB, String gsPostcode) throws ParseException {
		By byDDDOBDay = By.id("CustomerDateOfBirthVerify_Day");
		By byDDDOBMonth = By.id("CustomerDateOfBirthVerify_Month");
		By byDDDOBYear = By.id("CustomerDateOfBirthVerify_Year");
		By byTextPostcode = By.id("CustomerPostcodeVerify");

		SimpleDateFormat dateFormatIn = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormatOutYear = new SimpleDateFormat("yyyy");
		SimpleDateFormat dateFormatOutMonth = new SimpleDateFormat("MMMM");
		SimpleDateFormat dateFormatOutDay = new SimpleDateFormat("dd");

		Date date = dateFormatIn.parse(gsDOB);
		String month = dateFormatOutMonth.format(date);
		String year = dateFormatOutYear.format(date);
		String day = dateFormatOutDay.format(date);

		log.debug("day " + day);
		log.debug("month " + month);
		log.debug("year " + year);

		(new Select(getDriver().findElement(byDDDOBDay))).selectByVisibleText(day);
		(new Select(getDriver().findElement(byDDDOBMonth))).selectByVisibleText(month);
		(new Select(getDriver().findElement(byDDDOBYear))).selectByVisibleText(year);
		getDriver().findElement(byTextPostcode).clear();
		getDriver().findElement(byTextPostcode).sendKeys(gsPostcode);

	}

	public void assertOnPageOutboundConfirmAgreement(String gsSatsumaSiteUrl) {
		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase() + "/salescustomer?key=";

		// Landed on outbound customer confirm page
		log.info("AssertOnOutboundConfirmAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForTitle("Thank you for choosing Satsuma | Satsuma Loans");
		getDriver().getCurrentUrl().toString().contains(sExpectedPageUrl);
	}

	// NOTE: currently this page goes to http and not https
	public void assertOnPageOutboundCreditAgreement(String gsSatsumaSiteUrl) {
		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase() + "salescustomer/agreement";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");

		// Landed on outbound customer confirm page
		log.info("AssertOnOutboundCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		waitForTitle("Your credit agreement | Satsuma Loans");
	}

	public void prAssertOnPageCompletionIDResult19(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");

		// Landed on Completion page of type Result20 > Great news! Your next
		// Satsuma Loan has been approved
		log.info("prAssertOnPageCompletionIDResult19: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result19")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result19 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageCompletionIDResult11(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");

		// Landed on Completion page of type Result11 > Your application is now
		// being processed and verified.
		// Within 24 hours customer care team will contact you whether your
		// application has been accepted.
		log.info("prAssertOnPageCompletionIDResult11: Am I on expected landing page url - " + sExpectedPageUrl);
		Thread.sleep(500);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result11")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult11: Completion Page: Not Result11 page - Your application is now being processed and verified. Within 24 hours customer care team will contact you whether your application has been accepted.");
		}
	}

	public void prAssertOnPagePayslip(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/payslip";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		// Landed on Payslip page
		log.info("prAssertOnPagePayslip: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageHomeCredit(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "home-credit";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");

		// Landed on Credit Agreement page
		log.info("prAssertOnPageHomeCredit: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		// Check that HCR page does not default the forename and Surname of the
		// applying Satsuma applicant
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerFirstnameSignature")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerSurnameSignature")).getAttribute("value"));
	}

	public void prAssertOnPageCompletionIDResult16(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		// Landed on Completion page of type Result16 > Waiting for your email
		log.info("prAssertOnPageCompletionIDResult16: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result16")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult16: Completion Page: Not Result16 page - Expecting page in context of Waiting for your email.");
		}
	}

	public void prAssertOnPageCompletionIDResult20(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		// Landed on Completion page of type Result16 > Waiting for your email
		log.info("prAssertOnPageCompletionIDResult20: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result20")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult20: Completion Page: Not Result20 page - Expecting page in context of Waiting for your email.");
		}

	}

	public void prAssertOnPageLoanValueAdjustment(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/change-loan-amount";
		// change url to plain http
		// sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		// Landed on Customer Authentication page
		log.info("prAssertOnPageLoanValueAdjustment: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();
		}
	}

	public void prAssertOnPageCompletionIDResult12(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";

		// Landed on Completion page of type Result12 > Great news! Your next
		// Satsuma Loan has been approved in principle
		log.info("prAssertOnPageCompletionIDResult12: Am I on expected landing page url - " + sExpectedPageUrl);
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result12")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult12: Completion Page: Not Result12 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved in principle.");
		}
	}

	public void assertOnPageSorryCouldNotMatchDetails(String psSatsumaSiteUrl) {
		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/finished";

		// Landed on Completion page of type Result12 > Great news! Your next
		// Satsuma Loan has been approved in principle
		log.info("prAssertOnPageCompletionIDResult12: Am I on expected landing page url - " + sExpectedPageUrl);
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");
		waitForUrl(sExpectedPageUrl);
		waitForTitle("Authentication failed | Satsuma Loans");
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageCompletionIDResult13(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "salescustomer/complete";
		// change url to plain http
		sExpectedPageUrl = sExpectedPageUrl.replace("https", "http");

		// Landed on Completion page of type Result13 > Great news! Your next
		// Satsuma Loan has been approved
		log.info("prAssertOnPageCompletionIDResult13: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result13")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult13: Completion Page: Not Result13 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageAuthentication(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "/sales/authentication";

		// Landed on Customer Authentication page
		log.info("prAssertOnPageAuthentication: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}
}
