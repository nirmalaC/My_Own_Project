package automation.rules;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScreenshotOnFailRule extends TestWatcher {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	WebDriver driver;

	public ScreenshotOnFailRule(WebDriver driver) {
		this.driver = driver;
	}

	@Override
	public void failed(Throwable t, Description test) {

		// removed temporarily for new custom report
		// String testClassNameTrunc =
		// test.getTestClass().getSimpleName().substring(9, 14);
		// String testNameTrunc = test.getMethodName().substring(5,
		// test.getMethodName().length());
		// String destination = getDestinationFile(testClassNameTrunc + "-" +
		// testNameTrunc);

		// modified to allow new customised report
		String destination = "target/surefire-reports/screenshots/" + test.getClassName().substring((test.getClassName().lastIndexOf(".")) + 1) + "_" + test.getMethodName() + ".png";
		takeScreenshot(destination);

	}

	public void takeScreenshot(String relativePathScreenshot) {
		if (driver instanceof TakesScreenshot) {
			File tempFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				File file = new File(relativePathScreenshot);
				FileUtils.copyFile(tempFile, file);
				log.info("Screenshot taken: " + file.getPath());
			} catch (IOException e) {
				log.info(e.getStackTrace().toString());
			}
		}
	}

	private String getDestinationFile(String testname) {
		String fileName = testname + ".png";
		return "target/surefire-reports/screenshots" + "/" + fileName;
	}

}