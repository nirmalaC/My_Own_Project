package automation.tools;

import java.util.Date;

import automation.test.offerservice.entities.OfferParty;
import automation.test.offerservice.entities.OfferProducts;
import automation.test.offerservice.entities.OfferRequest;
import automation.test.offerservice.entities.PartyVulnerabilityStatus;
import automation.test.offerservice.enums.OfferPartyStatus;

public class OfferServiceRequestBuilder {

	// new customer is always eligible
	public static OfferRequest eligible(String forename, String surname, Date dob, String sourceV2, Double amount, int score, int status, boolean isVulnerable) {

		boolean isExistingCustomer = false;
		if ((status == OfferPartyStatus.ACTIVE) || (status == OfferPartyStatus.PAID_UP) || (status == OfferPartyStatus.FROZEN_DEFAULTED))
			isExistingCustomer = true;

		SourceEligibilityReasonCode sourceEligibilityReasonCode = new SourceEligibilityReasonCode().withSourceV2(sourceV2).withOfferPartyStatus(status).setSourceFromSourceV2();

		String source = sourceEligibilityReasonCode.getSource();
		int eligibilityReasonCode = sourceEligibilityReasonCode.getEligibilityReasonCode();

		String matchKey = MatchKeyHelper.generateMatchKey(forename, surname, dob);

		OfferParty party = new OfferParty();
		party.setId(matchKey);
		party.setIsExistingCustomer(isExistingCustomer);
		party.setOfferPartyStatus(status);
		party.setPartyVulnerabilityStatus(new PartyVulnerabilityStatus(isVulnerable));
		party.setMatchKey(matchKey);

		OfferProducts[] products = new OfferProducts[1];
		products[0] = new OfferProducts();
		products[0].set$type("Pfg.OfferService.DataContracts.Products.HighCostShortTermCredit, Pfg.OfferService.DataContracts");
		products[0].setOfferProductName(0);
		products[0].setLendingMaxAmount(amount);
		products[0].setLendingMinAmount(100);
		products[0].setRiskScore(score);
		products[0].setIsEligibleForLending(true);
		products[0].setSource(source);
		products[0].setSourcev2(sourceV2);
		products[0].setId(matchKey + "HighCostShortTermCredit");
		products[0].setMatchKey(matchKey);
		products[0].setCreatedDateTime("2017-05-24T15:57:57.0148325+01:00");
		if (amount != null) {
			if (amount > 0)
				products[0].setHasOffer(true);
			else
				products[0].setHasOffer(false);
		} else {
			products[0].setHasOffer(false);
		}
		products[0].setEligibilityReasonCode(eligibilityReasonCode);

		OfferRequest req = new OfferRequest();
		req.setOfferParty(party);
		req.setOfferProducts(products);

		return req;
	}

	public static OfferRequest eligible(String forename, String surname, Date dob, String sourceV2, int offerPartyStatus) {

		return eligible(forename, surname, dob, sourceV2, 750d, 0, 4, false);
	}

	public static OfferRequest ineligible(String forename, String surname, Date dob, String sourceV2, int score, int offerPartyStatus, boolean isVulnerable) {

		boolean isExistingCustomer = false;
		if ((offerPartyStatus == OfferPartyStatus.ACTIVE) || (offerPartyStatus == OfferPartyStatus.PAID_UP) || (offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED))
			isExistingCustomer = true;

		String matchKey = MatchKeyHelper.generateMatchKey(forename, surname, dob);

		SourceEligibilityReasonCode sourceEligibilityReasonCode = new SourceEligibilityReasonCode().withSourceV2(sourceV2).withOfferPartyStatus(offerPartyStatus).setSourceFromSourceV2();

		String source = sourceEligibilityReasonCode.getSource();
		int eligibilityReasonCode = sourceEligibilityReasonCode.getEligibilityReasonCode();

		OfferParty party = new OfferParty();
		party.setId(matchKey);
		party.setIsExistingCustomer(isExistingCustomer);
		party.setOfferPartyStatus(offerPartyStatus);
		party.setPartyVulnerabilityStatus(new PartyVulnerabilityStatus(isVulnerable));
		party.setMatchKey(matchKey);

		OfferProducts[] products = new OfferProducts[1];
		products[0] = new OfferProducts();
		products[0].set$type("Pfg.OfferService.DataContracts.Products.HighCostShortTermCredit, Pfg.OfferService.DataContracts");
		products[0].setOfferProductName(0);
		// ineligible set offer amount to zero
		products[0].setLendingMaxAmount(0d);
		products[0].setLendingMinAmount(100);
		products[0].setRiskScore(score);
		products[0].setIsEligibleForLending(false);
		products[0].setSource(source);
		products[0].setSourcev2(sourceV2);
		products[0].setId(matchKey + "HighCostShortTermCredit");
		products[0].setMatchKey(matchKey);
		products[0].setCreatedDateTime("2017-05-24T15:57:57.0148325+01:00");
		products[0].setHasOffer(false);
		products[0].setEligibilityReasonCode(eligibilityReasonCode);

		OfferRequest req = new OfferRequest();
		req.setOfferParty(party);
		req.setOfferProducts(products);

		return req;
	}

	public static OfferRequest ineligible(String forename, String surname, Date dob, String sourceV2, int offerPartyStatus) {
		return ineligible(forename, surname, dob, sourceV2, 0, 4, false);
	}
}

class SourceEligibilityReasonCode {
	String source;
	String sourceV2;
	int eligibilityReasonCode;
	int offerPartyStatus;

	public int getOfferPartyStatus() {
		return offerPartyStatus;
	}

	public void setOfferPartyStatus(int offerPartyStatus) {
		this.offerPartyStatus = offerPartyStatus;
	}

	public SourceEligibilityReasonCode withOfferPartyStatus(int offerPartyStatus) {
		setOfferPartyStatus(offerPartyStatus);
		return this;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public SourceEligibilityReasonCode withSource(String source) {
		setSource(source);
		return this;
	}

	public String getSourceV2() {
		return sourceV2;
	}

	public void setSourceV2(String sourceV2) {
		this.sourceV2 = sourceV2;
	}

	public SourceEligibilityReasonCode withSourceV2(String sourceV2) {
		setSourceV2(sourceV2);
		return this;
	}

	public int getEligibilityReasonCode() {
		return eligibilityReasonCode;
	}

	public SourceEligibilityReasonCode withEligibilityReasonCode(int eligibilityReasonCode) {
		setEligibilityReasonCode(eligibilityReasonCode);
		return this;
	}

	public void setEligibilityReasonCode(int eligibilityReasonCode) {
		this.eligibilityReasonCode = eligibilityReasonCode;
	}

	public SourceEligibilityReasonCode setSourceFromSourceV2() {
		/*
		 * case "HA": if (this.offerPartyStatus == 1)
		 * setEligibilityReasonCode(0); else setEligibilityReasonCode(1);
		 * setSource(""); break;
		 */

		switch (this.sourceV2) {
		case "HA":
			setEligibilityReasonCode(0);
			setSource("HA");
			break;
		case "HE":
			setEligibilityReasonCode(0);
			setSource("HE");
			break;
		case "HP":
			setEligibilityReasonCode(0);
			setSource("HP");
			break;
		case "HQ":
			setEligibilityReasonCode(0);
			setSource("HQ");
			break;
		case "HR":
			setEligibilityReasonCode(0);
			setSource("HR");
			break;
		case "HX":
			setEligibilityReasonCode(0);
			setSource("HX");
			break;
		case "HY":
			setEligibilityReasonCode(0);
			setSource("HY");
			break;
		case "HZ":
			setEligibilityReasonCode(0);
			setSource("HZ");
			break;
		case "OO":
			setEligibilityReasonCode(0);
			setSource("OO");
			break;
		case "PA":
			setEligibilityReasonCode(0);
			setSource("PA");
			break;
		case "PL":
			setEligibilityReasonCode(0);
			setSource("PL");
			break;
		case "PN":
			setEligibilityReasonCode(0);
			setSource("PN");
			break;
		case "PO":
			setEligibilityReasonCode(0);
			setSource("PO");
			break;
		case "PP":
			setEligibilityReasonCode(0);
			setSource("PP");
			break;
		case "PS":
			if (this.offerPartyStatus == OfferPartyStatus.PAID_UP)
				setEligibilityReasonCode(9);
			else
				setEligibilityReasonCode(0);
			setSource("PS");
			break;
		case "SA":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE)
				setEligibilityReasonCode(4);
			else
				setEligibilityReasonCode(0);
			setSource("SA");
			break;
		case "CM":
		case "TA":
			if (this.offerPartyStatus == OfferPartyStatus.PAID_UP || this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SD");
			break;
		case "CF":
			if (this.offerPartyStatus == OfferPartyStatus.PAID_UP || this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SF");
			break;
		case "SE":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SP");
			break;
		case "SI":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SP");
			break;
		case "SQ":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP)
				setEligibilityReasonCode(2);
			setSource("SP");
			break;
		case "WW":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP)
				setEligibilityReasonCode(2);
			else
				setEligibilityReasonCode(0);
			setSource("SP");
			break;
		case "CD":
		case "CV":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP || this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SR");
			break;
		case "SB":
		case "SD":
		case "SN":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SR");
			break;
		case "SR":
			if (this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SR");
			break;
		case "BA":
		case "BB":
		case "BC":
		case "BD":
		case "BE":
		case "BR":
		case "BF":
		case "BG":
		case "CX":
		case "OL":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP || this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SX");
			break;
		case "LM":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE || this.offerPartyStatus == OfferPartyStatus.PAID_UP || this.offerPartyStatus == OfferPartyStatus.FROZEN_DEFAULTED)
				setEligibilityReasonCode(8);
			else
				setEligibilityReasonCode(0);
			setSource("SX");
			break;
		case "SC":
			if (this.offerPartyStatus == OfferPartyStatus.ACTIVE)
				setEligibilityReasonCode(8);
			else
				setEligibilityReasonCode(0);
			setSource("SX");
			break;
		case "SX":
			setEligibilityReasonCode(5);
			setSource("SX");
			break;
		case "YO":
			setEligibilityReasonCode(0);
			setSource("SX");
			break;
		case "VR":
			setEligibilityReasonCode(0);
			setSource("VR");
			break;
		case "SM":
			if (this.offerPartyStatus == OfferPartyStatus.PAID_UP)
				setEligibilityReasonCode(7);
			else
				setEligibilityReasonCode(0);
			setSource("SR");
			break;
		case "PE":
			setEligibilityReasonCode(0);
			setSource("PE");
			break;
		default:
			System.err.println("error invalid source");
		}
		return this;
	}
}
