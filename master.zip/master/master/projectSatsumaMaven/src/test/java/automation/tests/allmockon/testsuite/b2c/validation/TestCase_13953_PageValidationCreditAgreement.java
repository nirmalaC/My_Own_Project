package automation.tests.allmockon.testsuite.b2c.validation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;
import automation.dao.CustomerType;

public class TestCase_13953_PageValidationCreditAgreement extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");
		// Goto Satsuma site
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database

	}

	@AfterMethod
	public void tearDown() throws Exception {

		// Disconnect from TestShed database

	}

	@Test
	public void test_PageValidation() throws Exception {

		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		gcb.prGetApplicantProfile(5);
		gcb.prCreateUniquePerson();

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// This has now changed in S3 so most of the below validation is now
		// defunct.
		// Assert that the Product Explanation confirmation is unticked
		final By byChkReadLoanAgreement = By.id("ReadLoanAgreement");
		Assert.assertFalse(getDriver().findElement(byChkReadLoanAgreement).isSelected());

		// you cannot click on checkbox without reading agreement
		getDriver().findElement(byChkReadLoanAgreement).sendKeys(Keys.SPACE);
		By bySpanReadLoanAgreement = By.xpath("//span[@data-valmsg-for='ReadLoanAgreement']");
		Assert.assertEquals(getDriver().findElement(bySpanReadLoanAgreement).getText(), "Please read the whole agreement above and accept to proceed");

		// Scroll down to bottom of the page.
		gcb.scrollToBottomOfElement(getDriver().findElement(By.cssSelector(".loan-agreement")));

		// now you can check the checkbox
		getDriver().findElement(byChkReadLoanAgreement).sendKeys(Keys.SPACE);
		Assert.assertEquals(getDriver().findElement(bySpanReadLoanAgreement).getText(), "");

		//
		// // Assert that Pre-Contract Credit confirmation is unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Assert that Fixed Sum Loan Agreement confirmation is unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page without reading or signing agreement
		// // getDriver().findElement(By.id("ContinueButton")).click();
		// getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);
		//
		// // // Assert that Confirmation sections have not been read with error
		// // prompts
		// Assert.assertEquals("Please accept to proceed",
		// getDriver().findElement(By.xpath("//span[@for='ReadProductExplanation']")).getText());
		// Assert.assertEquals("Please accept to proceed",
		// getDriver().findElement(By.xpath("//span[@for='ReadPreContract']")).getText());
		// Assert.assertEquals("Please accept to proceed",
		// getDriver().findElement(By.xpath("//span[@for='ReadFixedSumLoanAgreement']")).getText());
		//
		// // Assert that Forename is required
		// Assert.assertEquals("The Forename field is required.",
		// getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());
		// // Assert that Surname is required
		// Assert.assertEquals("The Surname field is required.",
		// getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());
		//
		// // Assert that the Product Explanation confirmation is remains
		// unticked
		// // and prompts too read if user trys to tick
		// Assert.assertFalse(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// getDriver().findElement(By.id("ReadProductExplanation")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// Assert.assertEquals("Please read all sections above and accept to proceed",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='ReadProductExplanation']")).getText());
		//
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// Assert.assertEquals("Please read all sections above and accept to proceed",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='ReadPreContract']")).getText());
		//
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// //
		// Assert.assertEquals("Please read all sections above and accept to proceed",
		// //
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='ReadFixedSumLoanAgreement']")).getText());
		// Assert.assertEquals("Please accept to proceed",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='ReadFixedSumLoanAgreement']")).getText());
		//
		// // PRODUCT EXPLANATION
		// // ===================
		//
		// // Read and confirm Product Explanation read
		// getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// getDriver().findElement(By.id("ReadProductExplanation")).click();
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // PRE-CONTRACT
		// // ============
		//
		// // Read only 1. Contact Details and confirm Pre-Contract read remain
		// // unticked if selection attempted
		// // 1. Contact details - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 2. Key features of the credit product and confirm
		// // Pre-Contract read remain unticked if selection attempted
		// // 2. Key features of the credit product - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 3. Costs of the credit and confirm Pre-Contract read
		// // remain unticked if selection attempted
		// // 3. Costs of the credit - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 4. Other important legal aspects and confirm
		// // Pre-Contract read remain unticked if selection attempted
		// // 4. Other important legal aspects - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 5. Additional information in the case of distance
		// // marketing of financial services and confirm Pre-Contract read
		// remain
		// // unticked if selection attempted
		// // 5. Additional information in the case of distance marketing of
		// // financial services - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 6. Terms and conditions in the case of distance
		// // marketing of financial services and confirm Pre-Contract read
		// remain
		// // unticked if selection attempted
		// // 6. Terms and conditions - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read now only 7. Marketing and confirm Pre-Contract read remain
		// // unticked if selection attempted
		// // 7. Marketing - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// getDriver().findElement(By.id("ReadPreContract")).click();
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // FIXED SUM LOAN AGREEMENT
		// // ========================
		//
		// // Read only Parties to the Agreement - Contact details read remain
		// // unticked if selection attempted
		// // Parties to the Agreement - Contact details - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Key features of the credit product read remain unticked
		// if
		// // selection attempted
		// // Key features of the credit product - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features-credit-product']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Costs of the credit read remain unticked if selection
		// // attempted
		// // Costs of the credit - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Right of withdrawal read remain unticked if selection
		// // attempted
		// // Right of withdrawal - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Other important information read remain unticked if
		// // selection attempted
		// // Other important information - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Terms and conditions read remain unticked if selection
		// // attempted
		// // Terms and conditions - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Read only Marketing read remain unticked if selection attempted
		// // Marketing - Read acknowledged
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();
		// Assert.assertFalse(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		// getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).click();
		// Assert.assertTrue(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());
		//
		// // Submit page having only read the Product Explanation
		// getDriver().findElement(By.id("ContinueButton")).click();
		//
		// // Assert that the Product Explanation confirmation remains ticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadProductExplanation")).isSelected());
		// // Assert that Pre-Contract Credit confirmation is remains unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadPreContract")).isSelected());
		// // Assert that Fixed Sum Loan Agreement confirmation is remains
		// unticked
		// Assert.assertTrue(getDriver().findElement(By.id("ReadFixedSumLoanAgreement")).isSelected());

		// Added by CV

		// Assert that you cannot proceed without scrolling through text

		// Assert that having scrolled you can now click the checkbox

		// E-SIGNATURE
		// ===========

		// Forename checks

		// Assert that entered Forename does not match applicants previously
		// entered forename
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys("Joey");
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Forename does not match the previously entered forename", getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());
		// Submit page with incorrect forename
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Forename does not match the previously entered forename", getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());

		// Assert that entered Forename does not exceed 25 characters
		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys("abcdefghijklmnopqrstuvwxyz");
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Forename must be a maximum length of 25 characters", getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());

		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter your forename", getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());

		// Assert that entered Forename allows 25 characters
		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys("abcdefghijklmnopqrstuvwxy");
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Forename does not match the previously entered forename", getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")).getText());

		// Assert that leading whitespaces are not used during client side
		// validation

		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(" " + gcb.gsFirstname);
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());

		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname + " ");
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());

		// getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB
		// + gcb.gsFirstname);
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());
		//
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname
		// + Keys.TAB);
		// getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());

		// Assert non case sensitivity on Forename and Surname
		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		;
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname.toLowerCase());
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());

		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname.toUpperCase());
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerFirstnameSignature']")).size());

		// Surname checks

		// Assert that entered Surname does not match applicants previously
		// entered Surname
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys("Apollo");
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Surname does not match the previously entered surname", getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());
		// Submit page with incorrect Surname
		getDriver().findElement(By.id("ContinueButton")).click();
		Assert.assertEquals("Surname does not match the previously entered surname", getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());

		// Assert that entered Surname does not exceed 40 characters was 25
		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz");
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Surname must be a maximum length of 40 characters", getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());

		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter your surname", getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());

		// Assert that entered Surname allows 25 characters
		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys("abcdefghijklmnopqrstuvwxy");
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals("Surname does not match the previously entered surname", getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")).getText());

		// Assert that leading whitespaces are not used during client side
		// validation

		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(" " + gcb.gsSurname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());

		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname + " ");
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());

		// getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB
		// + gcb.gsSurname);
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());
		//
		// getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname
		// + Keys.TAB);
		// getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		// Assert.assertEquals(0,
		// getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());

		// Assert non case sensitivity on Forename and Surname
		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname.toLowerCase());
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());

		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname.toUpperCase());
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(Keys.TAB);
		Assert.assertEquals(0, getDriver().findElements(By.xpath("//span[@for='CustomerSurnameSignature']")).size());
	}

}
