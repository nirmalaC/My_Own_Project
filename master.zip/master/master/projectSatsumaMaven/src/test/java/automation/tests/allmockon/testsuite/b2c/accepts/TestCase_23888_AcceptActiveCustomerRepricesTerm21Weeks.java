package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23888_AcceptActiveCustomerRepricesTerm21Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice21weeks1020() throws Exception {
		existingCustomerAccepts("1020", "21", "Weekly", "680", 133);
	}

	@Test
	public void test_Reprice21weeks1200() throws Exception {
		existingCustomerAccepts("1200", "21", "Weekly", "800", 133);
	}

	@Test
	public void test_Reprice21weeks1140() throws Exception {
		existingCustomerAccepts("1140", "21", "Weekly", "1000", 133);
	}

}
