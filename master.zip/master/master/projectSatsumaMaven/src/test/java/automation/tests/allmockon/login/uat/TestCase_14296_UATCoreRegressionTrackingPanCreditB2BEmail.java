package automation.tests.allmockon.login.uat;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;

import com.eviware.soapui.model.testsuite.TestCase;

public class TestCase_14296_UATCoreRegressionTrackingPanCreditB2BEmail extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		// Get Applicant Profile 109 from TestshedDB
		gcb.prGetApplicantProfile(109);

		// create unique person
		gcb.prCreateUniquePerson();
		// call broker API
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "G2F");

		// capture return values from SOAPUI TestCase
		String sAPR = new String("");
		String sLoanAmount;
		String sTAP;

		sAPR = testCase.getPropertyValue("ptcAPR");
		sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(gsSatsumaBrokerUrl);

		// Loan Amount & Term
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[1]")).getText(), "£" + gcb.gsRequestedLoanAmount + ".00", "loan amount");

		// Loan term
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[2]")).getText(), gcb.gsRequestedTerm + " weeks", "loan term");

		// Interest
		// Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsExpectedInterest));
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[4]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), "interest");

		// TAP
		// Assert.assertTrue(getDriver().getPageSource().contains("£" +
		// gcb.gsExpectedTAP));
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[6]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), "tap");

		// Weekly Repayment Amount
		// Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsExpectedRepayment));
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[3]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment) + " / week", "weekly repayment amount");

		// APR
		// Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsExpectedAPR
		// + "%"));
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[5]")).getText(), gcb.gsExpectedAPR + "%", "apr");

		// Firstpayment Day of the week LOV picker

		// What will you use your loan for?
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Monday");
		dropdown.selectByVisibleText("Tuesday");
		dropdown.selectByVisibleText("Wednesday");
		dropdown.selectByVisibleText("Thursday");
		dropdown.selectByVisibleText("Friday");

		// Validate no more items listed than above - Expect 9 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(6, l.size());

		// website cookie policy radio button

		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Select preferred payment date & check the website cookie policy
		// button
		dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// Complete Details
		// ==================

		// Select the Cookie Radio button
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CookieAccepted")).click();

		// Seems to have changed
		// Click Your Bank Details button
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageB2BCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// takeScreenshot( "target/temp-screenshots/" +
		// this.getClass().getName() + "/8.png");

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsCurrentUrl, gsSatsumaSiteUrl +
		// "referral/complete");

		gcb.prAssertOnPageB2BCompletionIDResult19(gsSatsumaSiteUrl);

		// Pancredit
		// =========

		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		gcb.prOpenAdditionalDetails();

		// Internet Affiliate Sub ID = Subaffiliate reference field from
		// original .xml e.g. sandhurs_xml
		// Internet Campaign = same as above e.g. sandhurs_xml
		// Internet Device MOBI / DESK
		// Internet IP Address
		// Internet Search Ad Group
		// Internet Search Campaign
		// Internet Search Term
		// Internet Source = Introducer reference field from original .xml e.g.
		// g2f_xml
		// Internet Type = Affiliate
		// Marketing Channel = Internet
		// Marketing Company = Satsuma

		gcb.prVerifyAffiliate("g2f_xml", "g2f_xml", "DESK", "", "", "", "aspire_xml", "Affiliate", "Internet", "Satsuma");

		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
