package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;

import com.eviware.soapui.support.SoapUIException;

public class TestSuite_4743_MobileApiUpdateContactPrefsTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	// 31892 - fetch content
	@Test
	public void testCase_31413_updateContactPrefsIOS() throws Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);

		// myaccount
		myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all()
				.extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	// 31892 - fetch content
	@Test
	public void testCase_31414_updateContactPrefsAndroid() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "Android";
		satsumaCustomer = addNewAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);


		// myaccount
		myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all()
				.extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	// 31892 - no date header
	@Test
	public void testCase_31416_noDateHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// update contact prefs
		String jsonBody = "{ \"Online\": \"true\" }";
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + accessToken).body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));

	}

	// 31892 - invalid app version header
	@Test
	public void testCase_32697_invalidAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// update contact prefs
		String jsonBody = "{ \"Online\": \"true\" }";
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all()
				.statusCode(400).body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));
	}

	// 31892 - no app version header
	@Test
	public void testCase_31417_noAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// update contact prefs
		String jsonBody = "{ \"Online\": \"true\" }";
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31419_invalidPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// update contact prefs
		String jsonBody = "{ \"Online\": \"true\" }";
		given().log().all().contentType("application/json").header("platform", "Windows").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then()
				.log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_31418_noPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// update contact prefs
		String jsonBody = "{ \"Online\": \"true\" }";
		given().log().all().contentType("application/json").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'Platform'"));

	}

//This test is been commented as it is no more a valid test case, because the consents are been handeled by PartyAPI.
//	@Test
//	public void testCase_31421_noTokenHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
//		final String PLATFORM = "iOS";
//
//		String emailAddress = satsumaCustomer.getEmailAddress();
//		System.out.println(emailAddress);
//
//		// login
//		String responseString =
//				given()
//				.contentType("application/x-www-form-urlencoded")
//						.log()
//						.all()
//						.header("platform", PLATFORM)
//						.header("appVersionNumber", APP_VERSION_NO)
//						.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT")
//						.param("grant_type", "password")
//						.param("client_id", "12345678")
//				        .param("username", satsumaCustomer.getEmailAddress())
//						.param("password", encodedPassword)
//						.when()
//						.post(TOKEN_URL)
//						.then()
//						.log()
//						.all()
//						.body("token_type", equalTo("bearer"))
//						.statusCode(200)
//						.extract()
//						.response()
//						.asString();
//
//		// extract tokens
//		accessToken = from(responseString).get("access_token");
//		refreshToken = from(responseString).get("refresh_token");
//		log.info("access_token: " + accessToken);
//		log.info("refresh_token: " + refreshToken);
//
//		// update contact prefs
//		String jsonBody = "{ \"Online\": \"true\" }";
//		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + "").body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all()
//				.statusCode(401);
//
//	}
}
