package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnIDVReferralTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CReferral909OFAAddressMismatchLowAccountMatchConfidence extends B2CAllMocksOnIDVReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC = "OFA Address Mismatch Low Confidence";
	private static final String OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE = "909";
	private static final int WEEKLY_APPPLICANT_ID = 228;
	private static final int NEW_BUS_WEEKLY_APPPLICANT_ID = 303;
	private static final int MONTHLY_APPPLICANT_ID = 251;
	private static final int NEW_BUS_MONTHLY_APPPLICANT_ID = 304;

	@Test
	public void testB2cNbReferralWeekly() throws Exception {
		b2CNewBusinessReferral(WEEKLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@Test
	public void testB2cNbReferralMonthly() throws Exception {
		b2CNewBusinessReferral(MONTHLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@Test
	public void testB2cFlReferralWeekly() throws Exception {
		b2CFLReferral(WEEKLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@Test
	public void testB2cFlReferralMonthly() throws Exception {
		b2CFLReferral(MONTHLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@Test
	public void testB2cLoginReferralWeekly() throws Exception {
		b2CLoginFLReferral(WEEKLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@Test
	public void testB2cLoginReferralMonthly() throws Exception {
		b2CLoginFLReferral(MONTHLY_APPPLICANT_ID, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_CODE, OFA_ADDRESS_MISMATCH_LOW_MATCH_CONF_DESC);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
