package automation.tests.outboundsales;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnOutboundTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class ObsDecline203IVA extends AllMocksOnOutboundTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	String pancode = "203";
	private final static int WEEKLY_APPLICANT_ID = 365;

	@Test
	public void ObsNbWeeklyDecline() throws Exception {
		ObsNbAtQuoteDeclineTest(pancode, WEEKLY_APPLICANT_ID);
	}

	@Test
	public void ObsLoginWeeklyDecline() throws Exception {
		ObsLoginAtQuoteDeclineTest(pancode, WEEKLY_APPLICANT_ID);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();

		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
