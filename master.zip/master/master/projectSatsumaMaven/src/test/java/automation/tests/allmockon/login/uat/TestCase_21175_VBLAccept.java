package automation.tests.allmockon.login.uat;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.dao.CustomerType;

import com.eviware.soapui.model.testsuite.TestCase;

public class TestCase_21175_VBLAccept extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		// Get Applicant Profile 154 from TestshedDB
		gcb.prGetApplicantProfile(154);

		// create unique person
		gcb.prCreateUniquePerson();

		// call broker API
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_VBL", "TestCase_21175_Satsuma B2B: VBL", "vbl", "");

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge("Weekly", 26, 500);

		// VBL test case is for loan amount of 500 over 26 weeks
		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(testCase.getPropertyValue("ptcAPR"), gcb.gsExpectedAPR);
		Assert.assertEquals(testCase.getPropertyValue("ptcTAP"), gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);

		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(gsSatsumaBrokerUrl);

		gcb.assertB2BVBLPage();

		// select repayment date
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Monday");
		dropdown.selectByVisibleText("Tuesday");
		dropdown.selectByVisibleText("Wednesday");
		dropdown.selectByVisibleText("Thursday");
		dropdown.selectByVisibleText("Friday");

		// Validate no more items listed than above - Expect 9 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(6, l.size());

		// website cookie policy radio button
		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Select preferred payment date & check the website cookie policy
		// button
		dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// Complete Details
		// ==================

		// Select the Cookie Radio button
		getDriver().findElement(By.id("CookieAccepted")).click();

		// Seems to have changed
		// Click Your Bank Details button
		// getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageVBLYourFinances(gsSatsumaSiteUrl);

		// fill in page
		// ==================

		gcb.prFillInPageYourFinances(CustomerType.B2B_CUSTOMER);
		gcb.prClickForNextAction();

		// Bank Account
		// ==================

		gcb.prAssertOnPageVBLBankDetails(gsSatsumaSiteUrl);

		gcb.prFillInPageBankDetailsRandom();
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageVBLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// takeScreenshot( "target/temp-screenshots/" +
		// this.getClass().getName() + "/8.png");

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// gsCurrentUrl = getDriver().getCurrentUrl();
		// Assert.assertEquals(gsCurrentUrl, gsSatsumaSiteUrl +
		// "referral/complete");

		gcb.prAssertOnPageVBLCompletionIDResult19(gsSatsumaSiteUrl);

		// Pancredit
		// =========

		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		gcb.prOpenAdditionalDetails();

		// Internet Affiliate Sub ID BLANK
		// Internet Campaign 0
		// Internet Device = MOBI / DESK
		// NOT_CHECKED Internet IP Address
		// Internet Search Ad Group BLANK
		// Internet Search Campaign BLANK
		// Internet Search Term BLANK
		// Internet Source = vbl_xml
		// Internet Type Affiliate
		// Marketing Channel Internet
		// Marketing Company Satsuma

		gcb.prVerifyAffiliate("", "0", "DESK", "", "", "", "vbl_xml", "Affiliate", "Internet", "Satsuma");

		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
