package automation.tests.sandpiper.mockson.b2b.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.satsuma.pages.ApplicationType;
import automation.test.offerservice.enums.OfferPartyStatus;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

public class B2BDecline107OfferService extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 399;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "107";

	@Test
	public void b2bSourceHY() throws Exception {

		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);
		gcb.prCreateUniquePerson();
		gcb.seedFLEIneligibleOffer("HY", OfferPartyStatus.UNKNOWN, false);
		test107(PAN_CODE + "HY");
	}

	@Test
	public void b2bSourceHX() throws Exception {
		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);
		gcb.prCreateUniquePerson();
		gcb.seedFLEIneligibleOffer("HX", OfferPartyStatus.UNKNOWN, false);
		test107(PAN_CODE + "HX");
	}

	@Test
	public void b2bSourceHZ() throws Exception {
		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);
		gcb.prCreateUniquePerson();
		gcb.seedFLEIneligibleOffer("HZ", OfferPartyStatus.UNKNOWN, false);
		test107(PAN_CODE + "HZ");
	}

	@Test
	public void b2bSourceCF() throws Exception {
		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);
		gcb.prCreateUniquePerson();
		gcb.seedFLEIneligibleOffer("CF", OfferPartyStatus.ACTIVE, false);
		test107(PAN_CODE + "CF");
	}

	private void test107(String pancode) throws Exception {

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.B2B), "Group Code");

	}

	private void testFL107(int applicantId) throws Exception {

		gcb.prGetApplicantProfile(applicantId);
		gcb.prCreateUniquePerson();

		// seed agreement
		gcb.prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// seed eligible offer
		gcb.seedFLEEligibleOffer(false, 2000d);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// clear history again
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");

	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
