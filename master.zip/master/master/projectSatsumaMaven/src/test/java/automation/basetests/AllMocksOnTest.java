package automation.basetests;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class AllMocksOnTest extends PageValidationTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public Map<String, String> getStatusMap(String strMockStatus) {
		String[] mockStatuses = strMockStatus.split("\n");
		Map<String, String> mockStatusMap = new HashMap<String, String>();

		for (String mockStatus : mockStatuses) {
			String[] keyValue = mockStatus.split(":");
			mockStatusMap.put(keyValue[0].trim().toLowerCase(), keyValue[1].trim().toLowerCase());
		}
		return mockStatusMap;
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

		getDriver().manage().deleteAllCookies();
		getDriver().get(gsSatsumaSiteUrl + "/development/backend/killsession");

		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);
		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		// Invoke Next action: Apply now
		final By byBtnStartYourApplication = By.linkText("Start your application");

		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
		// Invoke Next action: Start your application

		// try to click button if page times out try again.
		gcb.clickStartYourApplicationRetryIfNeeded();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

	}

	@AfterMethod
	public void tearDown() throws Exception {
	}

	public void removeAgreementAndReturnToAboutYou(String agreementNumber) throws Exception {

		// // rename surname to remove agreement from customer
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		// Navigate to the newly created agreement in PAN
		gcb.prNavigateToPANCreditAgreement(agreementNumber);

		// Rename applicant's surname
		gcb.prPANRenameAgreementsApplicantSurname(agreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

		// navigate back to where we were
		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

	}
}
