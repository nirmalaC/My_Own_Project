package automation.satsuma.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class Login extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private String testName;
	private int screenShotNumber;

	public Login(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public Login(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public By byBtnContactLogin = By.id("eligibilityCheck");
	public By byLblCanSeeEligibilty = By.cssSelector(".card__text p");
	// public By byLblEligibleAmount = By.cssSelector(".eligible-amount span");
	// public By byLblEligibleAmount =
	// By.cssSelector(".eligibility-widget__further-lending-amount");
	public By byLblEligibleAmount = By.cssSelector(".card__text p strong");
	public By byBtnApply = By.cssSelector("a[class='PrimaryLink button-apply button block center-align']");
	public By byLblFurtherLendingMessage = By.cssSelector(".central p");

	public void activateAndAssertEligibility(String eligibleAmount) {
		// verify that the customer has NOT yet opted into showing eligibility
		// on mysatsuma
		Assert.assertEquals(getDriver().findElement(byLblCanSeeEligibilty).getText(), "Sorry, we don't currently have permission to show you this!");
		// reveal eligibility on screen
		scrollToElement(getDriver().findElement(byBtnContactLogin));
		getDriver().findElement(byBtnContactLogin).click();
		Assert.assertEquals(getDriver().findElement(byLblEligibleAmount).getText(), eligibleAmount, "check eligible amount");
	}

	public void clickApplyStartSecondLoan() {
		getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
		getDriver().findElement(byBtnApply).click();

	}

	public void assertOnPageAboutYou(String satsumaSiteUrl, String firstname, String amount) {

		waitForUrl(satsumaSiteUrl + "further-lending/about-you");
		waitForTitle("Your new Satsuma Loan application... | Satsuma Loans");
		// log.debug(getDriver().findElement(byLblFurtherLendingMessage).getText());
		// log.debug(firstname +
		// ", today you're currently eligible to apply for up to " +
		// formatCurrencyToDisplay(amount) + ", subject to affordability.");

		// Assert.assertEquals(getDriver().findElement(byLblFurtherLendingMessage).getText().toLowerCase(),
		// "hi " + firstname.toLowerCase() +
		// ", today you're currently eligible to apply for up to " +
		// formatCurrencyToDisplay(amount) + ", subject to affordability.",
		Assert.assertEquals(getDriver().findElement(byLblFurtherLendingMessage).getText().toLowerCase(), "your provisional limit is", "check sub heading on further lending about you page");
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".provisional-limit div")).getText().toLowerCase(), formatCurrencyToDisplayNoDP(amount), "check eligible amount");
	}

	By byLblLoanAmountAndDate = By.cssSelector("h2[class='card__title']");
	By byLblAgreementNumber = By.cssSelector(".card__header .card__subtitle");

	public void assertAgreementInfo(String loanAmount, String month, String year, String agreementNo) {
		// Assert.assertEquals(getDriver().findElement(byLblLoanAmountAndDate).getText(),
		// formatCurrencyToDisplayNoDP(loanAmount) + " borrowed in " + month +
		// " " + year, "check loan amount and date");
		Assert.assertTrue(getDriver().findElement(byLblLoanAmountAndDate).getText().contains(formatCurrencyToDisplayNoDP(loanAmount) + " borrowed in "), "check loan summary line text '" + formatCurrencyToDisplayNoDP(loanAmount) + " borrowed in " + "'");
		Assert.assertEquals(getDriver().findElement(byLblAgreementNumber).getText(), "Agreement no: " + agreementNo, "check agreement number");

	}

	By byLblFLHeader = By.cssSelector(".central h1");
	By byLblFLEligibleAmount = By.cssSelector(".central p strong");

	public void assertOnPageFL(String satsumaSiteUrl, String eligibleAmount) {
		waitForUrl(satsumaSiteUrl + "further-lending/about-you");
		waitForTitle("Your new Satsuma Loan application... | Satsuma Loans");
		Assert.assertTrue(getDriver().findElement(byLblFLHeader).getText().toLowerCase().contains("your pre-completed loan application"), "check header");
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".provisional-limit div")).getText(), eligibleAmount);
	}

	By byDdLoanPurpose = By.id("LoanPurposeValue");
	By byDdRepaymentDay = By.id("PreferredPaymentDayValue");

	public void confirmDetailsAboutYou(String loanPurpose, String loanAmount, String requestedTerm, String repaymentFrequency, String repaymentDow, boolean contactByEmail, boolean contactBySMS, boolean contactByPhone, boolean contactByPost) throws Exception {

		// 3 divs
		// id personal-details
		// just confirm

		scrollToTopOfPage();

		if (repaymentFrequency.equals("Weekly")) {
			waitForClickableElement(By.id("TermTypeAboutYouCalcWeekly"));
			getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();
		} else if (repaymentFrequency.equals("Monthly")) {
			waitForClickableElement(By.id("TermTypeAboutYouCalcMonthly"));
			getDriver().findElement(By.id("TermTypeAboutYouCalcMonthly")).click();
		} else {
			log.error("Invalid repayment frequency");
		}

		scrollToElement(getDriver().findElement(By.cssSelector("#personal-details h3 a")));
		waitForVisibilityOfElement(By.cssSelector("#personal-details h3 a"));
		waitForClickableElement(By.cssSelector("#personal-details h3 a"));
		getDriver().findElement(By.cssSelector("#personal-details h3 a")).click();

		scrollToElement(getDriver().findElement(By.id("SectionOneContinueButton")));
		waitForVisibilityOfElement(By.id("SectionOneContinueButton"));
		waitForClickableElement(By.id("SectionOneContinueButton"));
		getDriver().findElement(By.id("SectionOneContinueButton")).click();

		scrollToElement(getDriver().findElement(By.cssSelector("#update-information h3 a")));
		waitForVisibilityOfElement(By.cssSelector("#update-information h3 a"));
		waitForClickableElement(By.cssSelector("#update-information h3 a"));

		// id update-information
		// just confirm
		getDriver().findElement(By.cssSelector("#update-information h3 a")).click();

		// select contact prefs
		selectContactPrefs(contactByEmail, contactBySMS, contactByPost, contactByPhone);

		scrollToElement(getDriver().findElement(By.id("SectionTwoContinueButton")));
		waitForVisibilityOfElement(By.id("SectionTwoContinueButton"));
		waitForClickableElement(By.id("SectionTwoContinueButton"));
		getDriver().findElement(By.id("SectionTwoContinueButton")).click();

		waitForVisibilityOfElement(By.cssSelector("#product-preferences h3 a"));
		waitForClickableElement(By.cssSelector("#product-preferences h3 a"));

		// id product-preferences
		// day of loan, loan purpose, confirm, cma
		getDriver().findElement(By.cssSelector("#product-preferences h3 a")).click();

		Select dropdown;
		// scrollToTopOfPage();

		String termType = "";
		String firstRepaymentDate = "";
		String lastRepaymentDate = "";
		String preferredPaymentDay = "";

		if (repaymentFrequency.equals("Weekly")) {

			waitForVisibilityOfElement(By.id("PreferredPaymentDayValue"));
			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
			scrollToElement(getDriver().findElement(By.id("PreferredPaymentDayValue")));
			dropdown.selectByVisibleText(repaymentDow);
			termType = "weeks";

		} else if (repaymentFrequency.equals("Monthly")) {

			waitForVisibilityOfElement(By.id("PreferredPaymentDayOfMonthValue"));
			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayOfMonthValue")));
			scrollToElement(getDriver().findElement(By.id("PreferredPaymentDayOfMonthValue")));
			// dropdown.selectByVisibleText("28th");
			// changed to 27th, as 28th causes instalmentfrequencydescription to
			// be set to Various instead of monthly

			if ((gsPreferredPaymentDom == null) || (gsPreferredPaymentDom == null)) {
				gsPreferredPaymentDom = "20th";
			}

			// dropdown.selectByVisibleText("2nd");
			dropdown.selectByVisibleText(gsPreferredPaymentDom);

			termType = "months";
		} else {
			log.error("Invalid repayment frequency");
		}

		// select loan purpose
		new Select(getDriver().findElement(byDdLoanPurpose)).selectByVisibleText(loanPurpose);

		// select same new loan as previous loan so APR, TAP, Term and Amount
		// are the same as previous loan

		dropdown = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown")));
		dropdown.selectByVisibleText(loanAmount);

		dropdown = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")));
		dropdown.selectByVisibleText(requestedTerm + " " + termType);

		// added for affordability
		getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.SPACE);

		// for new customers verify that summary of borrowing email is available
		// and then check it
		By byChkOptInSummaryOfBorrowing = By.id("OptInToSummaryOfBorrowingEmail");
		Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
		getDriver().findElement(byChkOptInSummaryOfBorrowing).sendKeys(Keys.TAB);
		getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
		Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");

		By byChkAckSummaryOfBorrowing = By.id("SummaryOfBorrowingAcknowledged");
		Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == false, "check ack summary of borrowing is unchecked");

		// now check it and continue
		getDriver().findElement(byChkAckSummaryOfBorrowing).click();
		Assert.assertTrue(getDriver().findElement(byChkAckSummaryOfBorrowing).isSelected() == true, "check ack summary of borrowing is now checked");

		scrollToElement(getDriver().findElement(By.id("SectionThreeContinueButton")));
		waitForVisibilityOfElement(By.id("SectionThreeContinueButton"));
		waitForClickableElement(By.id("SectionThreeContinueButton"));
		getDriver().findElement(By.id("SectionThreeContinueButton")).click();
	}

	public void assertOnPageFLYourFinances(String satsumaSiteUrl) {
		waitForUrl(satsumaSiteUrl + "further-lending/income-and-outgoings");
		waitForTitle("Has anything changed? | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byLblFLHeader).getText(), "Has anything changed?");

	}

	By byBtnConfirm = By.cssSelector("a[class='primary-button form__btn visible']");
	By byBtnConfirmRegularIncome = By.cssSelector("a[class='primary-button form__btn']");

	public void confirmDetailsYourFinances() {
		// employment status

		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(byBtnConfirm));
		getDriver().findElement(byBtnConfirm).sendKeys(Keys.ENTER);

		// how often
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(byBtnConfirmRegularIncome));
		getDriver().findElement(byBtnConfirmRegularIncome).sendKeys(Keys.ENTER);

		// which day of the week you receive this income
		// select you income day
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.elementToBeClickable(By.id("WeeklyIncomeDay")));

		new Select(getDriver().findElement(By.id("WeeklyIncomeDay"))).selectByVisibleText("Monday"); // selects
																										// monday
																										// every
																										// time
																										// temporarily

		if (!(new Select(getDriver().findElement(By.id("WeeklyIncomeDay")))).getFirstSelectedOption().getText().equalsIgnoreCase("Monday")) {
			new Select(getDriver().findElement(By.id("WeeklyIncomeDay"))).selectByVisibleText("Monday");
		}
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(By.id("confirm-weekly-income-day")));
		getDriver().findElement(By.id("confirm-weekly-income-day")).sendKeys(Keys.ENTER);

		// regular income
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(By.id("confirm-regular-income-amount")));
		getDriver().findElement(By.id("confirm-regular-income-amount")).sendKeys(Keys.ENTER);

		// income method

		By bySubBtn1 = By.id("confirm-income-method");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn1));
		// (new WebDriverWait(getDriver(),
		// 3)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form__field:nth-child(4) > div:nth-child(2) > div:nth-child(5) > a:nth-child(1)")));
		getDriver().findElement(bySubBtn1).sendKeys(Keys.ENTER);

		// employment status
		By bySubBtn2 = By.id("confirm-house-cost-amount");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn2));
		// (new WebDriverWait(getDriver(),
		// 3)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form__field:nth-child(5) > div:nth-child(2) > div:nth-child(4) > a:nth-child(1)")));
		getDriver().findElement(bySubBtn2).sendKeys(Keys.ENTER);

		// mortgage amount
		By bySubBtn3 = By.id("confirm-has-credit-cards");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn3));
		// (new WebDriverWait(getDriver(),
		// 3)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form__field:nth-child(6) > div:nth-child(2) > div:nth-child(4) > a:nth-child(1)")));
		getDriver().findElement(bySubBtn3).sendKeys(Keys.ENTER);

		// change credit cards to true
		if (getDriver().findElement(By.id("HasCreditCardsNo")).isSelected()) {
			getDriver().findElement(By.id("HasCreditCardsYes")).click();
		}

		// other loans
		By bySubBtn4 = By.id("confirm-has-other-loans");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn4));
		getDriver().findElement(bySubBtn4).sendKeys(Keys.ENTER);

		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.elementToBeClickable(By.id("LoansRepaymentsAmount")));
		// set loan repayments to 10 per month, temporarily put in to fix
		// test
		waitForVisibilityOfElement(By.id("LoansRepaymentsAmount"));
		getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("10");

		By byConfirmLoanRepayment = By.id("confirm-loans-repayment-amount");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(byConfirmLoanRepayment));
		getDriver().findElement(byConfirmLoanRepayment).sendKeys(Keys.ENTER);

		// other outgoings
		By bySubBtn5 = By.id("confirm-other-outgoings");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn5));
		// (new WebDriverWait(getDriver(),
		// 3)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#has-other-loans-field > div:nth-child(2) > div:nth-child(2) > a:nth-child(1)")));
		getDriver().findElement(bySubBtn5).sendKeys(Keys.ENTER);

		// total monthly outgoings
		By bySubBtn6 = By.id("confirm-total-monthly-income-outgoings");
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOfElementLocated(bySubBtn6));
		getDriver().findElement(bySubBtn6).sendKeys(Keys.ENTER);

	}

	By byLblAcceptCompleteHeader = By.cssSelector("[class='central first']");

	public void assertOnPageFLAcceptComplete(String satsumaSiteUrl) {
		waitForUrl(satsumaSiteUrl + "further-lending/complete");
		waitForTitle("Great news! Your next Satsuma Loan has been approved. | Satsuma Loans");
		Assert.assertTrue(getDriver().findElement(byLblAcceptCompleteHeader).getText().contains("Great news! Your next Satsuma Loan has been approved."), "check header is for accept page");
	}

	By byLblApplyForALoanHeader = By.cssSelector(".card__header h2");

	public void assertOnPageFLApplyForALoan(String satsumaSiteUrl) {
		waitForUrl(satsumaSiteUrl + "my-satsuma/apply-for-a-new-loan");
		waitForTitle("Can I apply for a new loan? | Satsuma Loans");
		Assert.assertTrue(getDriver().findElement(byLblApplyForALoanHeader).getText().contains("Can I have another loan?"));
	}

	public void assertFLBankDetailsPage(String accountHolder, String accountNumber, String sortCode, String monthOpened, String yearOpened) {
		// assert bank details are returned from login
		By byTxtAccountHolder = By.id("BankAccountReadOnly_AccountHolder");
		By byTxtAccountNumber = By.id("BankAccountReadOnly_AccountNumber");
		By byTxtSortCode = By.id("BankAccountReadOnly_SortCode");
		By byTxtBankDateOpened = By.id("BankAccountReadOnly_DateOpened");

		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byTxtAccountHolder)));
		(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.elementToBeClickable(byTxtAccountHolder));

		Assert.assertEquals(getDriver().findElement(byTxtAccountHolder).getAttribute("value"), accountHolder, "check account holder: " + accountHolder);
		Assert.assertEquals(getDriver().findElement(byTxtAccountHolder).getAttribute("readonly"), "true", "check account holder readonly");
		Assert.assertTrue(getDriver().findElement(byTxtAccountNumber).getAttribute("value").contains(accountNumber.substring(4, 8)), "check account number: " + accountNumber.substring(4, 8));
		Assert.assertEquals(getDriver().findElement(byTxtAccountNumber).getAttribute("readonly"), "true", "check account number readonly");
		Assert.assertTrue(getDriver().findElement(byTxtSortCode).getAttribute("value").contains(sortCode.substring(4, 6)), "check sort code: " + sortCode.substring(4, 6));
		Assert.assertEquals(getDriver().findElement(byTxtSortCode).getAttribute("readonly"), "true", "check sort code readonly");
		Assert.assertTrue(getDriver().findElement(byTxtBankDateOpened).getAttribute("value").contains(monthOpened), "check month opened: " + monthOpened + " actual: " + getDriver().findElement(byTxtBankDateOpened).getAttribute("value"));
		Assert.assertTrue(getDriver().findElement(byTxtBankDateOpened).getAttribute("value").contains(yearOpened), "check year opened: " + yearOpened);
		Assert.assertEquals(getDriver().findElement(byTxtBankDateOpened).getAttribute("readonly"), "true", "check bank open date readonly");
	}

	public void prAssertOnPageFinishedIDResult25(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "further-lending/finished";

		// Landed on Finished page of type Result5 > Thank you for your interest
		// in another Satsuma Loan. Unfortunately we're unable to process your
		// application for a further loan today.
		log.info("prAssertOnPageFinishedIDResult25: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result25")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult5: Finished Page: Thank you for your interest in another Satsuma Loan. Unfortunately we're unable to process your application for a further loan today.");
		}
	}

	public void changeFLBankDetails(String accountHolder, String accountNumber, String sortCode, String accountOpenDate) {
		// open card to enter bank details
		By byArrowNewBankDetails = By.cssSelector("#new-bank-details .card__header h3");
		javascriptClick(getDriver().findElement(byArrowNewBankDetails));

		By byDdAccountOpenMonth = By.id("DisplayAccountOpened_Month");
		By byDdAccountOpenYear = By.id("DisplayAccountOpened_Year");

		// Fill in Applicants bank details with stored applicant profile data
		log.info("prFillInPageBankDetails: Applicant profile data used to fill in page attribues.");

		Select dropdown;

		// Account Holder
		getDriver().findElement(By.id("AccountHolder")).clear();
		getDriver().findElement(By.id("AccountHolder")).sendKeys(accountHolder);

		// Account Sort Code
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys(sortCode.substring(0, 2));
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys(sortCode.substring(2, 4));
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys(sortCode.substring(4, 6));

		// Account Number
		getDriver().findElement(By.id("AccountNumber")).sendKeys(accountNumber);

		// When did you open your account with the bank?
		getDriver().findElement(byDdAccountOpenMonth).sendKeys(Keys.TAB);
		dropdown = new Select(getDriver().findElement(byDdAccountOpenMonth));
		String sMM = accountOpenDate.substring(3, 5).replaceFirst("^0*", "");
		dropdown.selectByValue(sMM);

		getDriver().findElement(byDdAccountOpenYear).sendKeys(Keys.TAB);
		dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		dropdown.selectByVisibleText(accountOpenDate.substring(6, 10));

		// needed as 2 submit buttons have same id
		By byBtn2ndContinueButton = By.cssSelector("#JourneyForm button[class='button primary-button']");
		getDriver().findElement(byBtn2ndContinueButton).sendKeys(Keys.TAB);
		getDriver().findElement(byBtn2ndContinueButton).click();
	}

	public void selectLoanAndTerm(String amount, String term, String frequency, String preferredPaymentDOW) throws Exception {
		log.debug("loan amount: " + amount + " loan term: " + term + " repayment frequency " + frequency);

		Select dropdown;

		// How much would you like to borrow ?
		// Loan Amount

		dropdown = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown")));
		dropdown.selectByValue(amount);

		String termText = "";

		if (!(monthlyOff.equalsIgnoreCase("true"))) {
			if (frequency.equals("Weekly")) {
				// click weekly tab
				getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();
				termText = "weeks";
			} else if (frequency.equals("Monthly")) {
				// click monthly tab
				getDriver().findElement(By.id("TermTypeAboutYouCalcMonthly")).click();
				termText = "months";
			} else {
				Assert.fail("Invalid loan frequency " + frequency);
			}
		} else {
			termText = "weeks";
		}
		// Requested Term
		dropdown = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")));

		// try to select term, if can't find element try again after 0.5 second
		// up to 3 times
		int retries = 2;
		while (true)
			try {
				dropdown.selectByVisibleText(term + " " + termText);
				break;
			} catch (ElementNotFoundException e) {
				if (retries > 0) {
					log.warn("Couldn't find the term option '" + term + " " + termText + "' trying again, retries: " + retries);
					Thread.sleep(500);
					retries--;
				} else {
					throw e;
				}
			}

		prGetACurrentSatsumaLoanCharge(frequency, Integer.parseInt(term), Integer.parseInt(amount));

		// Validate selected pricing details
		String actualRepayment = getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText();
		String actualTap = getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText();
		String actualInterest = getDriver().findElement(By.id("TotalInterestAboutYouCalcText")).getText();

		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedRepayment), actualRepayment);
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedTAP), actualTap);
		Assert.assertEquals(formatCurrencyToDisplay(gsExpectedInterest), actualInterest);

		// // On which day of the week would you like to make your repayments,
		// only
		// // applicable for Weekly Frequency
		//
		// if (frequency.equals("Weekly")) {
		// getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB,
		// Keys.SHIFT));
		// getDriver().findElement(By.linkText(preferredPaymentDOW)).click();
		// } else if (frequency.equals("Monthly")) {
		// getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB,
		// Keys.SHIFT));
		//
		// // temporary fix for monthly choose 1st.
		// getDriver().findElement(By.linkText("1st")).click();
		//
		// } else {
		// log.error("Invalid repayment frequency");
		// }
	}

	public void prAssertOnPageQuote(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "further-lending/quote";

		// Landed on Quote page
		log.info("prAssertOnPageQuote: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageCompletionIDResult11(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "further-lending/complete";

		// Landed on Completion page of type Result11 > Your application is now
		// being processed and verified.
		// Within 24 hours customer care team will contact you whether your
		// application has been accepted.
		log.info("prAssertOnPageCompletionIDResult11: Am I on expected landing page url - " + sExpectedPageUrl);
		Thread.sleep(500);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result11")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult11: Completion Page: Not Result11 page - Your application is now being processed and verified. Within 24 hours customer care team will contact you whether your application has been accepted.");
		}
	}

	public void assertOnPageIDVReferral(String sExpectedUrl) {
		takeIncrementScreenshot();

		waitForUrl(sExpectedUrl + "further-lending/complete");
		waitForTitle("Thank you, we will be in touch | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(By.cssSelector("div[class='main-content col-md-12'] h1")).getText(), "You’re just a few clicks away", "page main header on idv complete page");
	}

}
