package automation.tests.allmockon.login.uat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class TestCase_17194_UATCoreRegressionLinkStabilityDesktop extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test(enabled = false)
	public void test() {

	}
}
