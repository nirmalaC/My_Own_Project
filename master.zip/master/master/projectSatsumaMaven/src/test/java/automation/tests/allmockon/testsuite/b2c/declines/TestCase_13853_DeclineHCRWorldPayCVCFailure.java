package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_13853_DeclineHCRWorldPayCVCFailure extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// static WebDriver getDriver();
	// public String gsSatsumaSiteUrl; // Satsuma Site
	// public String gsdbTESTSHEDConnectionString; // TestShed database
	// connection
	// // string
	//
	// CookBook gcb = new CookBook();
	// ToolBox gtb = new ToolBox();

	//
	// @BeforeClass
	// public static void setUpBeforeClass() throws Exception {
	//
	// // Read config.properties for firefox proxy settings
	// Properties prop = new Properties();
	// String sProxyIP;
	// String sProxyPort;
	// String sNoProxyOn;
	// String sZoralAppServerStatusUrl;
	// InputStream input = null;
	//
	// input = new FileInputStream("config.properties");
	// // load a properties file
	// prop.load(input);
	//
	// // get the property value
	// sProxyIP = prop.getProperty("ProxyIP");
	// if (sProxyIP.isEmpty())
	// fail("BeforeClass: config.properties ProxyIP missing");
	// else
	// log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);
	//
	// sProxyPort = prop.getProperty("ProxyPort");
	// if (sProxyPort.isEmpty())
	// fail("BeforeClass: config.properties ProxyPort missing");
	// else
	// log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);
	//
	// sNoProxyOn = prop.getProperty("NoProxyOn");
	// if (sProxyPort.isEmpty())
	// fail("BeforeClass: config.properties NoProxyOn missing");
	// else
	// log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);
	//
	// sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
	// if (sZoralAppServerStatusUrl.isEmpty())
	// fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
	// else
	// log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" +
	// sZoralAppServerStatusUrl);
	//
	// input.close();
	//
	// // Setup Browser with proxy
	// FirefoxProfile profile = new FirefoxProfile();
	// profile.setPreference("network.proxy.type", 1);
	// profile.setPreference("network.proxy.http", sProxyIP);
	// profile.setPreference("network.proxy.http_port",
	// Integer.parseInt(sProxyPort));
	// profile.setPreference("network.proxy.ssl", sProxyIP);
	// profile.setPreference("network.proxy.ssl_port",
	// Integer.parseInt(sProxyPort));
	// profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
	// getDriver() = new FirefoxDriver(profile);
	// getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	// getDriver().manage().window().maximize();
	//
	// // Check Satsuma mock status - Abort test if inconsistent status found
	// //
	// // Mock Requirements for these tests are
	// // 1. PanCredit mock : Off
	//
	// getDriver().get(sZoralAppServerStatusUrl);
	//
	// assertEquals("Satsuma services", getDriver().getTitle());
	// //
	// assertEquals("PanCredit mock: Off",getDriver().findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[3]")).getText());
	//
	// }
	//
	// @AfterClass
	// public static void tearDownAfterClass() throws Exception {
	// // Terminate Browser
	// getDriver().quit();
	// }
	//
	// @Before
	// public void setUpBefore() throws Exception {
	//
	// gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
	// gsdbTESTSHEDConnectionString =
	// gcb._getConfigProperty("TestShedDBConnection");
	// gcb.gsSOAPUIProjectFolder =
	// gcb._getConfigProperty("SOAPUIProjectFolder");
	// gcb.gsPanCreditServiceServer =
	// gcb._getConfigProperty("PanCreditServiceServer");
	// gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
	// gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
	// gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
	//
	// // Goto Satsuma site
	// getDriver().get(this.gsSatsumaSiteUrl);
	//
	// // Home page
	// // ==============
	//
	// gcb.prAssertOnPageHome( gsSatsumaSiteUrl);
	//
	// if (gcb.gsQuickApply.toLowerCase().equals("true")) {
	// // Force navigation for the quick-apply page
	// getDriver().get(this.gsSatsumaSiteUrl + "quick-apply");
	// } else {
	// // Invoke Next action: Apply now
	// getDriver().findElement(By.id("SubmitHomeCalc")).click();
	// }
	// ;
	//
	// // Your Application page
	// // =====================
	//
	// gcb.prAssertOnPageYourApplication( gsSatsumaSiteUrl);
	//
	// // Invoke Next action: Start your application
	// getDriver().findElement(By.linkText("Start your application")).click();
	//
	// // About You page
	// // ==============
	//
	// gcb.prAssertOnPageAboutYou( gsSatsumaSiteUrl);
	//
	// // Connect to TestShed database
	// 
	// }
	//
	// @After
	// public void tearDown() throws Exception {
	//
	// // Disconnect from TestShed database
	// 
	// }

	@Test(enabled = false)
	public void test_WorldPayCVCFailureApplicantReferredToHomeCredit() throws Exception {

		// Initialise Agreement Number for new applicant
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer
		gcb.prGetApplicantProfile(4);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		//
		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a CVC
		// Failure i.e. 2nd response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Failed", "Postcode and address matched", gsSatsumaSiteUrl);

		// Home Credit page
		// ================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check that no new proposal agreement is created in PAN to record
		// decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Fail test if an agreement is found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Fail: An agreement found in PAN, should not have been created.");
		}

	}

}
