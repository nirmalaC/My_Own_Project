package automation.tests.allmockon.testsuite.b2b.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;

import com.eviware.soapui.model.testsuite.TestCase;

public class TestCase_15656_AcceptHappyPath1000Over13 extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {

		// Get Applicant Profile 167 from TestshedDB
		gcb.prGetApplicantProfile(167);

		// create unique person
		gcb.prCreateUniquePerson();

		// call broker API
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = new String("");
		String sLoanAmount;
		String sTAP;

		sAPR = testCase.getPropertyValue("ptcAPR");
		sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		String agreementNo = b2bAcceptJourney(gsSatsumaBrokerUrl);

	}
}
