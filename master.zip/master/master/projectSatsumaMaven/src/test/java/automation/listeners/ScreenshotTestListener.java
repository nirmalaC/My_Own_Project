package automation.listeners;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.velocity.VelocityContext;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IConfigurationListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.uncommons.reportng.HTMLReporter;

import automation.basetests.ScreenshottingTest;

public class ScreenshotTestListener extends HTMLReporter implements ITestListener, IConfigurationListener {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected static final CustomReportNgUtils REPORT_NG_UTILS = new CustomReportNgUtils();

	@Override
	protected VelocityContext createContext() {
		VelocityContext context = super.createContext();
		context.put("utils", REPORT_NG_UTILS);
		return context;
	}

	@Override
	public void onFinish(ITestContext context) {
		log.debug("In OnTestFinish");
	}

	@Override
	public void onStart(ITestContext result) {
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult testResult) {

		SimpleDateFormat sdf = new SimpleDateFormat("ssSSS");

		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String testMethodNameTemp = testResult.getMethod().toString();
		String testMethodName = testMethodNameTemp.substring(testMethodNameTemp.indexOf('.') + 1, testMethodNameTemp.indexOf('('));
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_" + testMethodName + sdf.format(new Date()) + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + "_" + testMethodName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
		testResult.setStatus(ITestResult.FAILURE);
	}

	@Override
	public void onTestFailure(ITestResult testResult) {

		SimpleDateFormat secondsFormatter = new SimpleDateFormat("ssSSS");

		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String testMethodNameTemp = testResult.getMethod().toString();
		String testMethodName = testMethodNameTemp.substring(testMethodNameTemp.indexOf('.') + 1, testMethodNameTemp.indexOf('('));
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_" + testMethodName + secondsFormatter.format(new Date()) + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + "_" + testMethodName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
	}

	@Override
	public void onTestSkipped(ITestResult testResult) {

		SimpleDateFormat secondsFormatter = new SimpleDateFormat("ssSSS");

		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String testMethodNameTemp = testResult.getMethod().toString();
		String testMethodName = testMethodNameTemp.substring(testMethodNameTemp.indexOf('.') + 1, testMethodNameTemp.indexOf('('));
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_" + testMethodName + secondsFormatter.format(new Date()) + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + "_" + testMethodName + ", screenshot captured successfully, but retrying");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
	}

	@Override
	public void onTestStart(ITestResult result) {
	}

	@Override
	public void onTestSuccess(ITestResult result) {
	}

	public Screenshot takeScreenshot(WebDriver driver, String relativePathScreenshot) {
		File file = null;
		URL url = null;
		if (driver instanceof TakesScreenshot) {
			File tempFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				file = new File(relativePathScreenshot);
				FileUtils.copyFile(tempFile, file);
				if (driver.getCurrentUrl().equalsIgnoreCase("about:blank")) {
					log.debug("URL is blank for screenshot");
					url = new URL("");
				} else {
					url = new URL(driver.getCurrentUrl());
				}
				log.info("Screenshot taken: " + file.getPath() + " with URL: " + url);
			} catch (IOException e) {
				log.error("IOException,", e);
			}
			return new Screenshot(file, url, file.getPath());
		}
		return null;
	}

	@Override
	public void onConfigurationFailure(ITestResult testResult) {

		SimpleDateFormat sdf = new SimpleDateFormat("ssSSS");

		// attach a screenshot if the before method fails
		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_before" + sdf.format(new Date()) + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
	}

	@Override
	public void onConfigurationSkip(ITestResult arg0) {

	}

	@Override
	public void onConfigurationSuccess(ITestResult arg0) {

	}

}
