package automation.tests.pancredit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.tools.EntityHubHelper;

public class RenameAllAgreements extends AllMocksOnTest {

	@Override
	@BeforeMethod
	public void setUpBefore() throws Exception {
	}

	@DataProvider(name = "test1")
	public Object[][] createData() {
		return new Object[][] { { "MOHAMMED", "INCE" }, { "WILLIAM", "RAJARATNAN" }, { "CAROL", "KIFFF" } };
	}

	@Test(dataProvider = "test1")
	public void test(String forename, String surname) throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, forename, surname);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(forename, surname, "*", "AutoDel" + surname);
		gcb.prPANRenameAgreementsApplicantSurname();
		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
