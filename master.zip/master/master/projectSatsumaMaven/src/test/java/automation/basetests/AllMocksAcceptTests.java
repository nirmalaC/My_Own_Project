package automation.basetests;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.w3c.dom.DOMException;

import automation.dao.CustomerType;
import automation.satsuma.pages.TimeHackHelper;
import automation.tools.XmlKnowledgeBase;

import com.eviware.soapui.support.SoapUIException;

public class AllMocksAcceptTests extends AllMocksOnTest {

	public void existingCustomerAccepts(String psPaidUpLoanAmount, int applicantId) throws Exception {
		// Data Preparation
		// ================
		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(133);
		existingCustomerAccepts(psPaidUpLoanAmount);
	}

	public void existingCustomerAccepts(String psLoanAmount, String psLoanTerm, String psRepaymentFrequency, String psPaidUpLoanAmount, int applicantId) throws Exception {
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(133);
		// Overwrite applicant profile requested loan terms
		gcb.gsRequestedLoanAmount = psLoanAmount;
		gcb.gsRequestedTerm = psLoanTerm;
		gcb.gsRepaymentFrequency = psRepaymentFrequency;
		existingCustomerAccepts(psPaidUpLoanAmount);
	}

	public void existingCustomerAccepts(String psPaidUpLoanAmount) throws Exception {

		String sAgreementNumber = "";

		// save current loan info temporarily
		String tempLoanAmount = gcb.gsRequestedLoanAmount;

		// set data for paid up loan
		gcb.gsRequestedLoanAmount = psPaidUpLoanAmount;
		// gcb.gsRequestedTerm = psLoanTerm;
		// gcb.gsRepaymentFrequency = psRepaymentFrequency;

		gcb.setRandomBankDetails();

		gcb.prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN(gcb.gsPanCreditServiceServer);

		log.debug("Active 50% Paid Up Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of active 50% paid agreement for this test failed. ");
		}

		// reset loan amount
		gcb.gsRequestedLoanAmount = tempLoanAmount;

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);
		log.debug("INFO: Repricing check for loan term " + gcb.gsRequestedLoanAmount + " " + gcb.gsRequestedTerm + " " + gcb.gsRepaymentFrequency);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// calculate eligible amount
		float eligibleAmount = gcb.calcEligibleAmount(Float.parseFloat(psPaidUpLoanAmount), 0f);

		gcb.seedFLEEligibleOffer(false, (double) eligibleAmount);

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: ?
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// confirm LVA values are correct
		gcb.prConfirmLVA();

		// Invoke Next action: Next: ? Your Quote if Quick Apply else Your
		// Finances
		gcb.prClickForNextAction();

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result13 in context Great news!
		// Your
		// // next Satsuma Loan has been approved (For existing customer)
		// gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		if (gcb.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
			String expectedStartDate = gcb.getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Weekly", gcb.gsPreferredPaymentDow);
			String expectedEndDate = gcb.getLastRepaymentDate("Weekly", expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));

			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);

		} else if (gcb.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
			String expectedStartDate = gcb.getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Monthly", gcb.gsPreferredPaymentDom);
			String expectedEndDate = gcb.getLastRepaymentDate("Monthly", expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));
			// get expected date
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);
		} else {
			Assert.fail("Error invalid frequency");
		}

		// gcb.assertFLEESigOffer();

	}

	public void newCustomerAccept(String psLoanAmount, String psLoanTerm, String psRepaymentFrequency, int applicantProfileId, String gsPreferredPaymentDom) throws Exception {
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantProfileId);
		gcb.prCreateUniquePerson();

		gcb.gsPreferredPaymentDom = gsPreferredPaymentDom;
		// Overwrite applicant profile requested loan terms
		gcb.gsRequestedLoanAmount = psLoanAmount;
		gcb.gsRequestedTerm = psLoanTerm;
		gcb.gsRepaymentFrequency = psRepaymentFrequency;
		newCustomerAccept();
	}

	public void newCustomerAccept(String psLoanAmount, String psLoanTerm, String psRepaymentFrequency, int applicantProfileId) throws Exception {
		newCustomerAccept(psLoanAmount, psLoanTerm, psRepaymentFrequency, applicantProfileId, "1st");
	}

	public void newCustomerAccept(int applicantProfileId) throws Exception {
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantProfileId);
		gcb.prCreateUniquePerson();
		newCustomerAccept();
	}

	public void newCustomerAccept() throws Exception {

		String sAgreementNumber;

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result19 in context Great news!
		// Your
		// // Satsuma Loan has been approved (For new customer)
		// gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		if (gcb.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
			String expectedStartDate = gcb.getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Weekly", gcb.gsPreferredPaymentDow);
			String expectedEndDate = gcb.getLastRepaymentDate("Weekly", expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));

			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);

		} else if (gcb.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
			String expectedStartDate = gcb.getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Monthly", gcb.gsPreferredPaymentDom);
			String expectedEndDate = gcb.getLastRepaymentDate("Monthly", expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));
			// get expected date
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);
		} else {
			Assert.fail("Error invalid frequency");
		}

		// gcb.assertFLEESigOffer();

	}

	public void verifyKnowledgeBaseAgainstCustomer(XmlKnowledgeBase xmlKB) throws DOMException, ParseException {
		log.debug("properties from xml knowledge base");
		log.debug("forename " + xmlKB.getDoc().getElementsByTagName("Forenames").item(0).getTextContent());
		log.debug("surname " + xmlKB.getDoc().getElementsByTagName("Surname").item(0).getTextContent());
		log.debug("DateOfBirth " + gcb.formatDate(xmlKB.getDoc().getElementsByTagName("DateOfBirth").item(0).getTextContent(), "yyyy-MM-dd'T'hh:mm:ss"));
		log.debug("Dependants " + xmlKB.getDoc().getElementsByTagName("Dependants").item(0).getTextContent());
		log.debug("CurrentMovingInDate " + gcb.formatDate(xmlKB.getDoc().getElementsByTagName("CurrentMovingInDate").item(0).getTextContent(), "yyyy-MM-dd'T'hh:mm:ss"));
		log.debug("CurrentHouseNumber " + xmlKB.getDoc().getElementsByTagName("CurrentHouseNumber").item(0).getTextContent());
		log.debug("CurrentStreet " + xmlKB.getDoc().getElementsByTagName("CurrentStreet").item(0).getTextContent());
		log.debug("CurrentPostTown " + xmlKB.getDoc().getElementsByTagName("CurrentPostTown").item(0).getTextContent());
		log.debug("CurrentCounty " + xmlKB.getDoc().getElementsByTagName("CurrentCounty").item(0).getTextContent());
		log.debug("CurrentPostcode " + xmlKB.getDoc().getElementsByTagName("CurrentPostcode").item(0).getTextContent());
		log.debug("EmailAddress " + xmlKB.getDoc().getElementsByTagName("EmailAddress").item(0).getTextContent());

		log.debug("RequestedLoanValue " + formatExpToIntString(xmlKB.getDoc().getElementsByTagName("RequestedLoanValue").item(0).getTextContent()));
		log.debug("RequestedLoanTerm " + xmlKB.getDoc().getElementsByTagName("RequestedLoanTerm").item(0).getTextContent());
		log.debug("Income " + xmlKB.getDoc().getElementsByTagName("Income").item(0).getTextContent());
		log.debug("CreditCards " + xmlKB.getDoc().getElementsByTagName("CreditCards").item(0).getTextContent());
		log.debug("Loans " + xmlKB.getDoc().getElementsByTagName("Loans").item(0).getTextContent());

		log.debug("OtherMonthlyOutgoings " + xmlKB.getDoc().getElementsByTagName("OtherMonthlyOutgoings").item(0).getTextContent());
		log.debug("Title " + xmlKB.getDoc().getElementsByTagName("Title").item(0).getTextContent());
		log.debug("MaritalStatus " + xmlKB.getDoc().getElementsByTagName("MaritalStatus").item(0).getTextContent());
		log.debug("CurrentAddressStatus " + xmlKB.getDoc().getElementsByTagName("CurrentAddressStatus").item(0).getTextContent());

		log.debug("PaymentFrequency " + xmlKB.getDoc().getElementsByTagName("PaymentFrequency").item(0).getTextContent());
		log.debug("LoanPurpose " + xmlKB.getDoc().getElementsByTagName("LoanPurpose").item(0).getTextContent());
		log.debug("EmploymentStatus " + xmlKB.getDoc().getElementsByTagName("EmploymentStatus").item(0).getTextContent());
		log.debug("IncomeFrequency " + xmlKB.getDoc().getElementsByTagName("IncomeFrequency").item(0).getTextContent());
		log.debug("IncomePaymentMethod " + xmlKB.getDoc().getElementsByTagName("IncomePaymentMethod").item(0).getTextContent());
		log.debug("MobileTelephoneUpper " + xmlKB.getDoc().getElementsByTagName("MobileTelephoneUpper").item(0).getTextContent());

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Forenames").item(0).getTextContent(), gcb.gsFirstname, "forename");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Surname").item(0).getTextContent(), gcb.gsSurname, "surname");
		Assert.assertEquals(gcb.formatDate(xmlKB.getDoc().getElementsByTagName("DateOfBirth").item(0).getTextContent(), "yyyy-MM-dd'T'hh:mm:ss"), gcb.gsDOB, "DateOfBirth");

		String numDependants = gcb.gsNumberOfDependants;
		switch (numDependants) {
		case "3+":
			numDependants = "3";
			break;
		}

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Dependants").item(0).getTextContent(), numDependants, "Dependants");
		Assert.assertEquals(gcb.formatDate(xmlKB.getDoc().getElementsByTagName("CurrentMovingInDate").item(0).getTextContent(), "yyyy-MM-dd'T'hh:mm:ss"), gcb.gsCurrentHouseMovedInDate, "CurrentMovingInDate");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentHouseNumber").item(0).getTextContent(), gcb.gsBuildingNumber, "CurrentHouseNumber");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentStreet").item(0).getTextContent(), gcb.gsStreet, "CurrentStreet");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentPostTown").item(0).getTextContent(), gcb.gsTownCity, "CurrentPostTown");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentCounty").item(0).getTextContent(), gcb.gsCounty, "CurrentCounty");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentPostcode").item(0).getTextContent(), gcb.gsPostcode, "CurrentPostcode");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("EmailAddress").item(0).getTextContent(), gcb.gsEmailAddress, "EmailAddress");

		Assert.assertEquals(formatExpToIntString(xmlKB.getDoc().getElementsByTagName("RequestedLoanValue").item(0).getTextContent()), gcb.gsRequestedLoanAmount, "RequestedLoanValue");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("RequestedLoanTerm").item(0).getTextContent(), gcb.gsRequestedTerm, "RequestedLoanTerm");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Income").item(0).getTextContent(), gcb.gsIncome, "Income");

		String hasCreditCards = ((gcb.gsHasCreditCards.equalsIgnoreCase("true")) ? "1" : "0");
		String hasExistingLoans = ((gcb.gsHasExistingLoans.equalsIgnoreCase("true")) ? "1" : "0");

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CreditCards").item(0).getTextContent(), hasCreditCards, "CreditCards");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Loans").item(0).getTextContent(), hasExistingLoans, "Loans");

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("MonthlyHousingCosts").item(0).getTextContent(), gcb.gsHousingCosts + ".00", "MonthlyHousingCosts");

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("OtherMonthlyOutgoings").item(0).getTextContent(), gcb.gsMonthlyOtherOutgoings + ".00", "OtherMonthlyOutgoings");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("Title").item(0).getTextContent(), gcb.gsTitle, "Title");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("MaritalStatus").item(0).getTextContent().toLowerCase(), gcb.gsMaritalStatus.toLowerCase(), "MaritalStatus");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("CurrentAddressStatus").item(0).getTextContent().toLowerCase(), gcb.gsResidentialStatus.toLowerCase(), "CurrentAddressStatus");

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("PaymentFrequency").item(0).getTextContent().toLowerCase(), gcb.gsRepaymentFrequency.toLowerCase(), "PaymentFrequency");

		String loanPurpose = gcb.gsLoanPurpose.toLowerCase();
		switch (loanPurpose) {
		case "home improvement":
			loanPurpose = "home improvements";
			break;
		case "family occasion":
			loanPurpose = "family";
			break;
		case "personal spend":
			loanPurpose = "personal";
			break;
		case "general living expenses":
			loanPurpose = "subsistence";
			break;
		}

		String sourceOfIncome = gcb.gsSourceOfIncome.toLowerCase();
		switch (sourceOfIncome) {
		case "retired ( pension)":
			sourceOfIncome = "pension";
			break;
		case "unemployed":
			sourceOfIncome = "benefits";
			break;
		case "home maker":
			sourceOfIncome = "benefits";
			break;
		case "student":
			sourceOfIncome = "part time employment only";
			break;
		}

		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("LoanPurpose").item(0).getTextContent().toLowerCase(), loanPurpose, "LoanPurpose");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("EmploymentStatus").item(0).getTextContent().toLowerCase(), sourceOfIncome, "EmploymentStatus");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("IncomeFrequency").item(0).getTextContent().toLowerCase(), gcb.gsIncomeFrequency.toLowerCase(), "IncomeFrequency");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("IncomePaymentMethod").item(0).getTextContent().toLowerCase(), gcb.gsIncomePaymentMethod.toLowerCase(), "IncomePaymentMethod");
		Assert.assertEquals(xmlKB.getDoc().getElementsByTagName("MobileTelephoneUpper").item(0).getTextContent(), gcb.gsMobileNumber, "MobileTelephoneUpper");
	}

	private String formatExpToIntString(String exp) {
		String pattern = "#";
		DecimalFormat myFormatter = new DecimalFormat(pattern);

		// String loanAmount = "1.000000000000000e+002";
		String output = myFormatter.format(Double.parseDouble(exp));
		return output;
	}

	private void seedAndRegisterLogin(float originalLoanAmount, String originalLoanTerm, String originalLoanFrequency, boolean paidUp) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, originalLoanFrequency);
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, originalLoanFrequency);

			outstandingAmount = 0f;
		}

		float eligibleLoanAmount = gcb.calcEligibleAmount(originalLoanAmount, outstandingAmount);

		gcb.seedFLEEligibleOffer(paidUp, (double) eligibleLoanAmount);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(eligibleLoanAmount));

	}

	protected void loginAndApplyFL(String newLoanAmount, String newLoanTerm, String newLoanFrequency) throws Exception {
		// seed and register a full paid up agreement agreement
		// added new loan term to old loan as a temporary fix to various coming
		// back as payment frequency when mixed loans are applied for.
		seedAndRegisterLogin(1000f, newLoanTerm, newLoanFrequency, true);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();
		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(1000f, 0f)));

		// apply for different loan amount
		gcb.gsRequestedLoanAmount = newLoanAmount;
		gcb.gsRequestedTerm = newLoanTerm;
		gcb.gsRepaymentFrequency = newLoanFrequency;
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// verify you cannot amend bank details
		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(Float.toString(gcb.calcEligibleAmount(1000f, 0f)))));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDPNoComma(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		gcb.waitForClickableElement(By.id("ContinueButtonStep1"));
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.gsPreferredPaymentDom = login.gsPreferredPaymentDom;

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		if (gcb.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		} else if (gcb.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
			if (TimeHackHelper.getPanDate() == null) {
				Assert.fail("Pan System Date is null");
			}

			String expectedStartDate = gcb.getScheduleStartDateForMonthly(27, TimeHackHelper.getPanDate());
			String expectedEndDate = gcb.getScheduleEndDateForMonthly(expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));
			// get expected date
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);
		} else {
			Assert.fail("Error invalid frequency");
		}

		// gcb.assertFLEESigOffer();
	}

}
