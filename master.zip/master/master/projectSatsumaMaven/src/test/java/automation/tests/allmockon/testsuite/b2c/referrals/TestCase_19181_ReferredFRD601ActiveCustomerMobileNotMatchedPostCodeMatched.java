package automation.tests.allmockon.testsuite.b2c.referrals;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_19181_ReferredFRD601ActiveCustomerMobileNotMatchedPostCodeMatched extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// test was not really completed properly is this tests still revelant?
	@Test(enabled = false)
	public void test_ReferIfApplicant() throws Exception {

		String sAgreementNumber;

		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.

		gcb.prGetApplicantProfile(5);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page
		// ===============

		// Landed on completion page type Result19 in context Great news! Your
		// Satsuma Loan has been approved (For new customer)
		gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		getDriver().get(gsSatsumaSiteUrl + "/development/backend/killsession");

		// Re-attempt Application, change in post code, same mobile number
		// different postcode should trigger a 601
		gcb.gsPostcode = "BD7 4BG";

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		/*
		 * // WorldPay Test Page // ==================
		 * 
		 * // Fill in applicants card details from the profile and trigger a
		 * Approved response gcb.prFillInTestWorldPayAndRespond( "Authorised",
		 * "Approved", "Postcode and address matched");
		 * 
		 * // Credit Agreement page // ======================
		 * 
		 * (new WebDriverWait(
		 * 60)).until(ExpectedConditions.presenceOfElementLocated
		 * (By.id("agreement-product-explanation")));
		 * 
		 * gcb.prAssertOnPageCreditAgreement( gsSatsumaSiteUrl);
		 * 
		 * // Read and Sign the Credit Agreement
		 * gcb.prReadAndSignCreditAgreement();
		 * 
		 * // Capture Agreement Number from the Credit Agreement page
		 * sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
		 * 
		 * // Invoke Next action: Next: Complete Your Agreement
		 * gcb.prClickForNextAction();
		 * 
		 * // Completion page // ===============
		 * 
		 * // Landed on completion page type Result11 in context Your
		 * application is now being processed and verified. // Within 24 hours
		 * customer care team will contact you whether your application has been
		 * accepted. gcb.prAssertOnPageCompletionIDResult11( gsSatsumaSiteUrl);
		 * 
		 * 
		 * // In PanCredit try and remove test subject agreement, so that we can
		 * re-run the test next time using same subject // but also check that
		 * the correct decline on "Callcredit HALO Match" reason is recorded //
		 * ==
		 * ====================================================================
		 * =========================================
		 * 
		 * // Log into PanCredit Front Office
		 * gcb.prLogIntoPanCreditFrontOffice();
		 * 
		 * gcb.prNavigateToPANCreditAgreement( sAgreementNumber);
		 * 
		 * // Expect agreement to be referred with a 709 - Callcredit HALO Match
		 * Assert.assertEquals(getDriver().findElement(By.xpath(
		 * "//form[@id='PanForm']//span[@class='spanHeadingLeft']"
		 * )).getText(),"Decision Referred");
		 * Assert.assertEquals(getDriver().findElement(By.
		 * xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']"
		 * )).getText(),"Queue Referral Queue");
		 * assertTrue(getDriver().getPageSource
		 * ().contains("Callcredit HALO Match"));
		 * 
		 * getDriver().findElement(By.xpath(
		 * "//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']"
		 * )).click();
		 * 
		 * Select dropdown; dropdown = new
		 * Select(getDriver().findElement(By.id("title")));
		 * dropdown.selectByVisibleText(gcb.gsTitle);
		 * 
		 * String tmpStr =
		 * getDriver().findElement(By.id("surname")).getAttribute("value"); if
		 * (!(tmpStr.contains("AutoDel"))) {
		 * getDriver().findElement(By.id("surname")).clear();
		 * getDriver().findElement(By.id("surname")).sendKeys("AutoDel" +
		 * tmpStr); } getDriver().findElement(By.id("PanLinkSubmit_5")).click();
		 * 
		 * // Log out of PanCredit Front Office
		 * gcb.prLogoutFromPanCreditFrontOffice();
		 */
	}

}
