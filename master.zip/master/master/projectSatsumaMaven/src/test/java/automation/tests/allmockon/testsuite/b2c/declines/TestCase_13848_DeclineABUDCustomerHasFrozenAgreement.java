package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.test.offerservice.enums.OfferPartyStatus;

public class TestCase_13848_DeclineABUDCustomerHasFrozenAgreement extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_HasFrozenLoanDecline() throws Exception {

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);

		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		// created is created for an unique person, generated dynamically.
		gcb.prSeedUniqueFrozenAgreementInPAN(gcb.gsPanCreditServiceServer, "90119");

		log.debug("Frozen Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		gcb.seedFLEIneligibleOffer("SR", OfferPartyStatus.FROZEN_DEFAULTED, false);

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// Have we landed on the ABUD Decline page with message in context of
		// Your application has been unsuccessful on this occasion
		// Assert.assertEquals(gsSatsumaSiteUrl + "apply/finished",
		// getDriver().getCurrentUrl().toLowerCase());
		// Assert.assertTrue(getDriver().getPageSource().contains("Unfortunately your application has not been successful on this occasion"));

		// Have we landed on the ABUD Decline page with message in context of
		// Thank you for your interest in another satsuma loan
		gcb.prAssertOnPageFinishedIDResult5(gsSatsumaSiteUrl);

	}

}
