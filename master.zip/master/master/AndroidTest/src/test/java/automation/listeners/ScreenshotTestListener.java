package automation.listeners;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.velocity.VelocityContext;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IConfigurationListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.uncommons.reportng.HTMLReporter;

import automation.basetests.ScreenshottingTest;

public class ScreenshotTestListener extends HTMLReporter implements ITestListener, IConfigurationListener {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected static final CustomReportNgUtils REPORT_NG_UTILS = new CustomReportNgUtils();

	@Override
	protected VelocityContext createContext() {
		VelocityContext context = super.createContext();
		context.put("utils", REPORT_NG_UTILS);
		return context;
	}

	@Override
	public void onFinish(ITestContext context) {
		log.debug("In OnTestFinish");
		Iterator<ITestResult> failedTestCases = context.getFailedTests().getAllResults().iterator();
		while (failedTestCases.hasNext()) {

			ITestResult failedTestCase = failedTestCases.next();
			ITestNGMethod method = failedTestCase.getMethod();
			if (context.getFailedTests().getResults(method).size() > 1) {
				log.debug("failed test case remove as dup:" + failedTestCase.getTestClass().toString());
				failedTestCases.remove();
			} else {

				if (context.getPassedTests().getResults(method).size() > 0) {
					log.debug("failed test case remove as pass retry:" + failedTestCase.getTestClass().toString());
					failedTestCases.remove();
				}
			}
		}
	}

	@Override
	public void onStart(ITestContext result) {

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult testResult) {
		log.debug("In OnTestFailureButWithinSuccessPercentage");

		if (testResult.getMethod().getRetryAnalyzer() != null) {
			Retry retry = (Retry) testResult.getMethod().getRetryAnalyzer();

			if (retry.isRetryAvailable()) {
				testResult.setStatus(ITestResult.SKIP);
			} else {
				testResult.setStatus(ITestResult.FAILURE);
			}
			Reporter.setCurrentTestResult(testResult);
		}

		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String testMethodNameTemp = testResult.getMethod().toString();
		String testMethodName = testMethodNameTemp.substring(testMethodNameTemp.indexOf('.') + 1, testMethodNameTemp.indexOf('('));
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_" + testMethodName + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + "_" + testMethodName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
		testResult.setStatus(ITestResult.FAILURE);
	}

	@Override
	public void onTestFailure(ITestResult testResult) {
		log.debug("In OnTestFailure");

		if (testResult.getMethod().getRetryAnalyzer() != null) {
			Retry retry = (Retry) testResult.getMethod().getRetryAnalyzer();

			if (retry.isRetryAvailable()) {
				testResult.setStatus(ITestResult.SKIP);
			} else {
				testResult.setStatus(ITestResult.FAILURE);
			}
			Reporter.setCurrentTestResult(testResult);
		}

		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String testMethodNameTemp = testResult.getMethod().toString();
		String testMethodName = testMethodNameTemp.substring(testMethodNameTemp.indexOf('.') + 1, testMethodNameTemp.indexOf('('));
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_" + testMethodName + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + "_" + testMethodName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		log.debug("In OnTestSkipped");
		if (result.getMethod().getRetryAnalyzer() != null) {
			Retry retry = (Retry) result.getMethod().getRetryAnalyzer();
			if (retry.isRetryAvailable()) {
				result.setStatus(ITestResult.SKIP);
			} else {
				result.setStatus(ITestResult.FAILURE);
			}
		}
	}

	@Override
	public void onTestStart(ITestResult result) {
	}

	@Override
	public void onTestSuccess(ITestResult result) {
	}

	public Screenshot takeScreenshot(WebDriver driver, String relativePathScreenshot) {
		File file = null;
		URL url = null;
		if (driver instanceof TakesScreenshot) {
			File tempFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				file = new File(relativePathScreenshot);
				FileUtils.copyFile(tempFile, file);
				url = new URL(driver.getCurrentUrl());
				log.info("Screenshot taken: " + file.getPath() + " with URL: " + url);
			} catch (IOException e) {
				log.error(e.getStackTrace().toString());
			}
			return new Screenshot(file, url, file.getPath());
		}
		return null;
	}

	@Override
	public void onConfigurationFailure(ITestResult testResult) {
		log.debug("In onConfigurationFailure");

		// attach a screenshot if the before method fails
		Object currentClass = testResult.getInstance();
		String testClassName = testResult.getTestClass().getName().substring(testResult.getTestClass().getName().lastIndexOf('.') + 1);
		String destination = "target/surefire-reports/html/screenshots/" + testClassName + "_before" + ".png";
		Screenshot testScreenshot = takeScreenshot(((ScreenshottingTest) currentClass).getDriver(), destination);

		if (testScreenshot == null) {
			log.error("Could not take screenshot");
		} else {
			log.error("Test failed: " + testClassName + ", screenshot captured successfully");
		}

		testResult.setAttribute(Screenshot.KEY, testScreenshot);
	}

	@Override
	public void onConfigurationSkip(ITestResult arg0) {

	}

	@Override
	public void onConfigurationSuccess(ITestResult arg0) {

	}

}
