package automation.tests.allmockon.testsuite.b2c.accepts;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileTest;

public class MobileTest_11299_AcceptLVANewCustomerSaidTheyWereExistingNotInLoanLimits extends MobileTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_AcceptLVANewCustomerSaidTheyWereExistingNotInLoanLimits() throws Exception {

		String sAgreementNumber = "";

		// Capture current Url
		gsCurrentUrl = getDriver().getCurrentUrl();

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer and are asking for more than £1000.

		gcb.prGetApplicantProfile(6);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Applicant pretends to be existing enters invalid agreement number
		gcb.gsPANAgreementNumber = "999999999999";

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYouMobile();

		if (gcb.gsQuickApply.equals("true")) {
			// Fill in applicants finance details from the profile
			gcb.prFillInPageYourFinances();
		}

		// Invoke Next action:
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is new and can only borrow up to £1000
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("As you’re new to Satsuma Loans, you can currently borrow up to £1,000.00"));

		// Loan Amount Slider defaulted to £1000
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("min"));
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("max"));
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to £1000
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		Assert.assertEquals("£1000", dropdown.getFirstSelectedOption().getText());

		// Loan Term defaulted to 13 weeks
		Assert.assertEquals("0", getDriver().findElement(By.id("TermLVACalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermLVACalc")).getAttribute("max"));
		Assert.assertEquals("0", getDriver().findElement(By.id("TermLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to 13 weeks
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		Assert.assertEquals("13 weeks", dropdown.getFirstSelectedOption().getText());

		// User accepts the defaulted limit, adjust the requested loan term
		gcb.gsRequestedTerm = "13";
		gcb.gsRequestedLoanAmount = "1000";

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// Assert that Interest, Weekly repayments and TAP are displayed
		// correctly
		// Pricing for £1000 13 weeks - Defaulted correctly
		Assert.assertEquals("£" + gcb.gsExpectedInterest, getDriver().findElement(By.id("TotalInterestLVACalcText")).getText());
		Assert.assertEquals("£" + gcb.gsExpectedRepayment, getDriver().findElement(By.id("RepaymentAmountLVACalcText")).getText());
		Assert.assertEquals("£" + gcb.gsExpectedTAP, getDriver().findElement(By.id("TotalAmountLVACalcText")).getText());

		// Invoke only if we have not switched on quick application
		// functionality, by directly navigating to
		// the next page i.e. Your Finances otherwise this is combined page
		// journey
		if (!gcb.gsQuickApply.equals("true")) {
			// Invoke Next action: Next: Your Finances
			gcb.prClickForNextAction();

			// Your Finances Page
			// ==================

			gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

			// Fill in applicants finance details from the profile
			gcb.prFillInPageYourFinances();
		}

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/2.png");

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/3.png");

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/4.png");

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/5.png");

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", this.getClass().getName());

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/7.png");
		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/8.png");

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		takeScreenshot("target/temp-screenshots/" + this.getClass().getName() + "/9.png");

		// Completion page
		// ===============

		// Landed on completion page type Result19 in context Great news! Your
		// Satsuma Loan has been approved (For new customer)
		gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP, gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}

	public void takeScreenshot(String path) {
		try {
			File scrFile = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(path));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
