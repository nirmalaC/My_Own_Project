package automation.tests.mobile.android;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import automation.pages.mobile.login.Register;

public class TestDroid {

	@Test
	public void test1() throws MalformedURLException {

		// Create object of DesiredCapabilities class and specify android
		// platform
		DesiredCapabilities capabilities = DesiredCapabilities.android();

		// set the capability to execute test in chrome browser
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.CHROME);

		// set the capability to execute our test in Android Platform
		capabilities.setCapability(MobileCapabilityType.PLATFORM, Platform.ANDROID);

		// we need to define platform name
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");

		// Set the device name as well (you can give any name)
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "my phone");

		// set the android version as well
		capabilities.setCapability(MobileCapabilityType.VERSION, "5.0.1");

		// Create object of URL class and specify the appium server address
		URL url = new URL("http://127.0.0.1:4723/wd/hub");

		// Create object of AndroidDriver class and pass the url and capability
		// that we created
		WebDriver driver = new AndroidDriver(url, capabilities);

		// print the title
		System.out.println("Title " + driver.getTitle());

		// Open url
		driver.get("http://satzorapp6.ho.pfgroup.provfin.com/register");

		driver.findElement(Register.byTextForename).sendKeys("Chi");
		driver.findElement(Register.byTextSurname).sendKeys("Voong");
		driver.findElement(Register.byTextDateOfBirth).clear();
		driver.findElement(Register.byTextDateOfBirth).sendKeys("19/08/1981");
		driver.findElement(Register.byTextPostCode).sendKeys("LS81LD");
		driver.findElement(Register.byTextAgreementNumber).sendKeys("999999999999999");
		driver.findElement(Register.byBtnRegister).sendKeys(Keys.TAB);
		driver.findElement(Register.byBtnRegister).click();

		// print the title
		System.out.println("Title " + driver.getTitle());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.close();
	}

	@Test
	public void DefaultBrowserRemoteTest() throws MalformedURLException {

		// Create object of DesiredCapabilities class and specify android
		// platform
		DesiredCapabilities capabilities = DesiredCapabilities.android();

		// // set the capability to execute test in chrome browser
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");

		// set the capability to execute our test in Android Platform
		capabilities.setCapability(MobileCapabilityType.PLATFORM, Platform.ANDROID);

		// we need to define platform name
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");

		// Set the device name as well (you can give any name)
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "SAMSUNGNOTE3");

		// set the android version as well
		capabilities.setCapability(MobileCapabilityType.VERSION, "4.4.2");

		// Create object of URL class and specify the appium server address
		// URL url = new URL("http://127.0.0.1:4723/wd/hub");
		URL url = new URL("http://127.0.0.1:4444/wd/hub");

		// Create object of AndroidDriver class and pass the url and capability
		// that we created
		RemoteWebDriver driver = new RemoteWebDriver(url, capabilities);

		// Open url
		driver.get("http://satzorapp6.ho.pfgroup.provfin.com/register");

		// print the title
		System.out.println("Title " + driver.getTitle());

		driver.findElement(Register.byTextForename).sendKeys("Jenkins");
		driver.findElement(Register.byTextSurname).sendKeys("DoevkQAPE");
		driver.findElement(Register.byTextDateOfBirth).clear();
		driver.findElement(Register.byTextDateOfBirth).sendKeys("27/04/1970");
		driver.findElement(Register.byTextPostCode).sendKeys("LS81LD");
		driver.findElement(Register.byTextAgreementNumber).sendKeys("800000027186");
		driver.findElement(Register.byBtnRegister).sendKeys(Keys.TAB);
		driver.findElement(Register.byBtnRegister).click();

		// print the title
		System.out.println("Title " + driver.getTitle());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.close();
	}

}