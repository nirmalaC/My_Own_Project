package automation.tests.mobile.ios;

import io.appium.java_client.ios.IOSDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import automation.pages.mobile.login.Register;

public class TestIOS {

	@Test
	public void test1() throws MalformedURLException {

		// Create object of DesiredCapabilities class and specify android
		// platform
		DesiredCapabilities capabilities = DesiredCapabilities.iphone();

		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("platformVersion", "8.2");
		capabilities.setCapability("deviceName", "iPhone 6");
		capabilities.setCapability("browser", "safari");
		WebDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// print the title
		System.out.println("Title " + driver.getTitle());

		// Open url
		driver.get("http://satzorapp6.ho.pfgroup.provfin.com/register");

		driver.findElement(Register.byTextForename).sendKeys("Chi");
		driver.findElement(Register.byTextSurname).sendKeys("Voong");
		driver.findElement(Register.byTextDateOfBirth).clear();
		driver.findElement(Register.byTextDateOfBirth).sendKeys("19/08/1981");
		driver.findElement(Register.byTextPostCode).sendKeys("LS81LD");
		driver.findElement(Register.byTextAgreementNumber).sendKeys("999999999999999");
		driver.findElement(Register.byBtnRegister).sendKeys(Keys.TAB);
		driver.findElement(Register.byBtnRegister).click();

		// print the title
		System.out.println("Title " + driver.getTitle());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.close();
	}
}