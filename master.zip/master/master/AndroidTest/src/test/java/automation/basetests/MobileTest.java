package automation.basetests;

import io.appium.java_client.remote.MobileCapabilityType;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.ProxySelector;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import automation.satsuma.pages.MobileCookBook;
import automation.tools.ToolBox;

public class MobileTest extends ScreenshottingTest {
	public static final int IMPLICIT_TIMEOUT = 30;
	public static final int EXPLICIT_TIMEOUT = 60;
	public static final int PAGE_TIMEOUT = 180;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected ThreadLocal<RemoteWebDriver> threadDriver = null;

	protected String gsSatsumaSiteUrl; // Satsuma Site
	protected String gsdbTESTSHEDConnectionString; // TestShed database
													// connection
													// string

	public static ProxySelector defaultProxySelector = null;
	protected String gsCurrentUrl;

	protected MobileCookBook gcb;
	protected ToolBox gtb = new ToolBox();

	public WebDriver getDriver() {
		return threadDriver.get();
	}

	@BeforeSuite
	public void beforeSuite() {
		log.debug("BeforeSuite: get default proxy selector");
		defaultProxySelector = ProxySelector.getDefault();
	}

	protected void startAndroidChromeBrowser(String sProxyIP, String sProxyPort, String sNoProxyOn) throws MalformedURLException {
		// Create object of DesiredCapabilities class and specify android
		// platform
		DesiredCapabilities capabilities = DesiredCapabilities.android();
		// // set the capability to execute test in chrome browser
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");

		// set the capability to execute our test in Android Platform
		capabilities.setCapability(MobileCapabilityType.PLATFORM, Platform.ANDROID);

		// we need to define platform name
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");

		// Set the device name as well (you can give any name)
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "SAMSUNGNOTE3");

		// set the android version as well
		capabilities.setCapability(MobileCapabilityType.VERSION, "4.4.2");
		// Create object of URL class and specify the appium server address
		URL url = new URL("http://localhost:4444/wd/hub");

		// threadDriver = new ThreadLocal<WebDriver>();
		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				threadDriver.set(new RemoteWebDriver(url, capabilities));

				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	protected void startChromeDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) {

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		System.setProperty("webdriver.chrome.driver", "c://chromedriver//chromedriver.exe");

		// threadDriver = new ThreadLocal<WebDriver>();
		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				threadDriver.set(new ChromeDriver(capabilities));
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	protected void startFirefoxDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) {

		// Setup Browser with proxy
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", sProxyIP);
		profile.setPreference("network.proxy.http_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.ssl", sProxyIP);
		profile.setPreference("network.proxy.ssl_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
		// File pathToBinary = new
		// File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		// FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);

		// Setup desired capabilities for firefox
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		capabilities.setPlatform(Platform.WINDOWS);
		capabilities.setCapability(FirefoxDriver.PROFILE, profile);
		// capabilities.setCapability(FirefoxDriver.BINARY, ffBinary);

		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				// threadDriver.set(new FirefoxDriver(ffBinary, profile));
				try {
					threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
				} catch (MalformedURLException e) {
					log.error("Invalid hub url");
				}
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	@BeforeClass
	public void setUpBeforeClass() throws Exception {

		// Read config.properties for firefox proxy settings
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		InputStream input = null;
		String sZoralAppServerStatusUrl;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sProxyIP = prop.getProperty("ProxyIP");
		if (sProxyIP.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyIP missing");
		else
			log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);

		sProxyPort = prop.getProperty("ProxyPort");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyPort missing");
		else
			log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);

		sNoProxyOn = prop.getProperty("NoProxyOn");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties NoProxyOn missing");
		else
			log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);

		sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
		if (sZoralAppServerStatusUrl.isEmpty())
			Assert.fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
		else
			log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" + sZoralAppServerStatusUrl);

		input.close();

		// startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
		// startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
		startAndroidChromeBrowser(sProxyIP, sProxyPort, sNoProxyOn);

		// // Setup Browser with proxy
		// FirefoxProfile profile = new FirefoxProfile();
		// profile.setPreference("network.proxy.type", 1);
		// profile.setPreference("network.proxy.http", sProxyIP);
		// profile.setPreference("network.proxy.http_port",
		// Integer.parseInt(sProxyPort));
		// profile.setPreference("network.proxy.ssl", sProxyIP);
		// profile.setPreference("network.proxy.ssl_port",
		// Integer.parseInt(sProxyPort));
		// profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
		// File pathToBinary = new
		// File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		// FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
		// threadDriver = new ThreadLocal<FirefoxDriver>();
		// //
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// // loop to make sure browser opens successfully, allows 3 retries
		// int retries = 2;
		// while (true) {
		// try {
		// log.debug("BeforeClass: set default proxy selector before calling webdriver");
		// ProxySelector.setDefault(defaultProxySelector);
		// threadDriver.set(new FirefoxDriver(ffBinary, profile));
		// break;
		// } catch (UnreachableBrowserException e) {
		// log.warn("Browser startup failed, remaining retries: " + retries);
		// if (retries < 1)
		// throw e;
		//
		// } catch (WebDriverException e) {
		// log.warn("Browser startup failed, remaining retries: " + retries);
		// if (retries < 1)
		// throw e;
		// }
		// retries--;
		// }
		gcb = new MobileCookBook(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		// driver = ThreadGuard.protect(new FirefoxDriver(profile));
		getDriver().manage().timeouts().implicitlyWait(IMPLICIT_TIMEOUT, TimeUnit.SECONDS);
		// getDriver().manage().window().maximize();
		// set page load timeout to 1 min
		getDriver().manage().timeouts().pageLoadTimeout(PAGE_TIMEOUT, TimeUnit.SECONDS);

		// // Check Satsuma mock status - Abort test if inconsistent status
		// found
		// //
		// // Mock Requirements for these tests are
		// // 1. Experian mock : On
		// // 2. CallCredit mock : On
		// // 3. PanCredit mock : Off
		// // 4. Affordability mock: On
		// // 5. Statistical calculations mock: On
		// // 6. CifasService mock: On (if off the test data used could trigger
		// a
		// // Potential Fraud on sortcode bankaccount, if CIFAS database
		// contains
		// // the offending item)
		//
		// getDriver().get(sZoralAppServerStatusUrl);
		//
		// // fetch all the mocks information and put it into a hashmap
		//
		// String strMockStatus =
		// getDriver().findElement(By.xpath("//div[@class='panel-body']//div/ul")).getText();
		// Map<String, String> mockStatusMap = getStatusMap(strMockStatus);
		//
		// Assert.assertEquals("Satsuma services", getDriver().getTitle());
		// Assert.assertEquals(mockStatusMap.get("experian mock"), "on",
		// "experian mock");
		// Assert.assertEquals(mockStatusMap.get("callcredit mock"), "on",
		// "callcredit mock");
		// Assert.assertEquals(mockStatusMap.get("statistical calculations mock"),
		// "on", "statistical calculations mock");
		// Assert.assertEquals(mockStatusMap.get("affordability mock"), "on",
		// "affordability mock");
		// Assert.assertEquals(mockStatusMap.get("cifasservice mock"), "on",
		// "cifasservice mock");
		//
		// log.info("Testing against: " +
		// getDriver().findElement(By.cssSelector(".panel-heading > ul:nth-child(1) > li:nth-child(1) > h3:nth-child(1)")).getText()
		// + " " +
		// getDriver().findElement(By.cssSelector(".panel-heading > ul:nth-child(1) > li:nth-child(2) > h3:nth-child(1)")).getText());
		//
		// log.info("WARNING: Automated tests require 301 - Duplicate IP Address Fraud alert suppressed");
		// log.info("INFO: Amend StasumaStandardWebFinalDecisionWorkflow Global Variable <add name='IpCheckMaxAllowedTimes\' value='999999' />");
		//
		// // log.debug("Hashcode of webDriver instance = " +
		// // getDriver().hashCode());
	}

	public Map<String, String> getStatusMap(String strMockStatus) {
		String[] mockStatuses = strMockStatus.split("\n");
		Map<String, String> mockStatusMap = new HashMap<String, String>();

		for (String mockStatus : mockStatuses) {
			String[] keyValue = mockStatus.split(":");
			mockStatusMap.put(keyValue[0].trim().toLowerCase(), keyValue[1].trim().toLowerCase());
		}
		return mockStatusMap;
	}

	@AfterClass
	public void tearDownAfterClass() throws Exception {
		log.debug("Closing browser");
		// Terminate Browser
		getDriver().manage().deleteAllCookies();
		getDriver().quit();
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		if (gcb.gsQuickApply.toLowerCase().equals("true")) {
			// Force navigation for the quick-apply page
			getDriver().get(this.gsSatsumaSiteUrl + "quick-apply");
		} else {
			// Invoke Next action: Apply now
			gcb.takeIncrementScreenshot();

			final By byBtnApply = By.id("SubmitHomeCalc");
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnApply)));
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnApply)));
			getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
			getDriver().findElement(byBtnApply).click();

			// getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.ENTER);
		}

		// // Your Application page
		// // =====================
		//
		// gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
		//
		// final By byBtnStartYourApplication =
		// By.linkText("Start your application");
		// (new WebDriverWait(getDriver(),
		// EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
		// (new WebDriverWait(getDriver(),
		// EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
		// // Invoke Next action: Start your application
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.linkText("Start your application")).click();
		// //
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.ENTER);

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		// Connect to TestShed database
		gcb.DBConnectTESTSHED(gsdbTESTSHEDConnectionString);
	}

	@AfterMethod
	public void tearDown() throws Exception {

		// Disconnect from TestShed database
		gcb.DBDisconnectTESTSHED();
	}

	public void removeAgreementAndReturnToAboutYou(String agreementNumber) throws Exception {

		// // rename surname to remove agreement from customer
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		// Navigate to the newly created agreement in PAN
		gcb.prNavigateToPANCreditAgreement(agreementNumber);

		// Rename applicant's surname
		gcb.prRenameAgreementsApplicantSurname(agreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

		// navigate back to where we were
		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		if (gcb.gsQuickApply.toLowerCase().equals("true")) {
			// Force navigation for the quick-apply page
			getDriver().get(this.gsSatsumaSiteUrl + "quick-apply");
		} else {
			// Invoke Next action: Apply now
			getDriver().findElement(By.id("SubmitHomeCalc")).click();
		}
		;

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

	}

}
