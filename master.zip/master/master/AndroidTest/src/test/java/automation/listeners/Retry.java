package automation.listeners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private int retryCount = 0;
	private int maxRetryCount = 2; // retry a failed test 2 additional times

	@Override
	public boolean retry(ITestResult result) {
		if (retryCount < maxRetryCount) {
			retryCount++;
			log.debug("Retrying test, remaining retries: " + (maxRetryCount - retryCount));
			return true;
		}
		return false;
	}

	public boolean isRetryAvailable() {
		return (retryCount > 0);
	}

	public boolean hasTestBeenRetried() {
		return (retryCount != 0);
	}
}