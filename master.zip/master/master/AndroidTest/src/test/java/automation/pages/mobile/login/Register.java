package automation.pages.mobile.login;

import org.openqa.selenium.By;

public class Register {
	public static final By byTextForename = By.id("Forename");
	public static final By byTextDateOfBirth = By.id("DateOfBirth");
	public static final By byTextSurname = By.id("Surname");
	public static final By byTextPostCode = By.id("PostCode");
	public static final By byTextAgreementNumber = By.id("AgreementNumber");
	public static final By byBtnRegister = By.id("SubmitHomeCalc");

}
