package automation.pages.mobile.login;

public class CreditAgreement {

}
