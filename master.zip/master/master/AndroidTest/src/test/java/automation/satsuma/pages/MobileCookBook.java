package automation.satsuma.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ProxySelector;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import automation.tools.ToolBox;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.support.SoapUIException;
import com.google.common.base.Function;

public class MobileCookBook {

	public static final int EXPLICIT_TIMEOUT = 60;
	public static final int IMPLICIT_TIMEOUT = 30;
	public static final int PAGE_TIMEOUT = 180;
	private int screenshotNumber;
	private String testName;
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	public MobileCookBook() {
	}

	ThreadLocal<?> threadDriver = null;

	public MobileCookBook(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public MobileCookBook(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		screenshotNumber = 1;
	}

	public WebDriver getDriver() {
		return (WebDriver) threadDriver.get();
	}

	ToolBox gtb = new ToolBox();

	// Database connection to the testing frame database
	public Connection gdbConnTESTSHED;

	// Applicant Profile Data Set
	public String gsApplicantProfileId;
	public String gsCustomerId;
	public String gsMaritalStatus;
	public String gsNumberOfDependants;
	public String gsResidentialStatus;
	public String gsEmploymentStatus;
	public String gsSourceOfIncome;
	public String gsIncome;
	public String gsIncomeFrequency;
	public String gsIncomePaymentMethod;
	public String gsHasCreditCards;
	public String gsHasExistingLoans;
	public String gsMortgageCosts;
	public String gsRentCosts;
	public String gsMonthlyLoanRepayments;
	public String gsMonthlyOtherOutgoings;
	public String gsCurrentHouseMovedInDate;
	public String gsBankAccountName;
	public String gsBankAccountNumber;
	public String gsBankSortcode;
	public String gsBankAccountOpenDate;
	public String gsCreditCardNumber;
	public String gsCreditCardType;
	public String gsCreditCardExpiryDate;
	public String gsCreditCardCVS;
	public String gsRequestLoanProduct;
	public String gsRequestedLoanAmount;
	public String gsRequestedTerm;
	public String gsLoanPurpose;
	public String gsRepaymentFrequency;
	public String gsConsentToCreditSearch;
	public String gsMarketingOptInPost;
	public String gsMarketingOptInSMS;
	public String gsMarketingOptInEmail;
	public String gsMarketingOptInPhone;
	public String gsPreferredContactMethod;
	public String gsPreferredContactDetails;
	public String gsProfileBriefNote;
	public String gsDataSource;
	public String gsTitle;
	public String gsFirstname;
	public String gsMiddlename;
	public String gsSurname;
	public String gsSurnameTemp;
	public String gsDOB;
	public String gsGender;
	public String gsMobileNumber;
	public String gsHomeNumber;
	public String gsWorkNumber;
	public String gsFlatNumber;
	public String gsBuildingName;
	public String gsBuildingNumber;
	public String gsStreet;
	public String gsDistrict;
	public String gsTownCity;
	public String gsCounty;
	public String gsPostcode;
	public String gsCountry;
	public String gsEmailAddress;
	public String gsHousingCosts;
	public String gsPreferredPaymentDow;
	// End of Data Set

	// Quick Apply
	public String gsQuickApply;

	// SOAPUI Projects Data Set
	public String gsSOAPUIProjectFolder;

	// PAN Data Set
	public String gsPanCreditServiceServer;
	public String gsPANSystemDate;
	public String gsPANAgreementStartDate;
	public String gsPANAgreementNumber;
	public String gsPANAgreementStatus;
	public String gsPANAgreementSecondaryStatus;
	public String gsPANPersonAgreementStatus;
	public String gsPANPersonAgreementStatusDesc;
	public String gsPANPersonId;
	public String gsPANApplicantFound;
	public String gsPANDecisionReasonId;
	public String gsPANPaidUpAmount;
	public String gsPANStopCategoryId;
	public String gsPANLendingMaxAmount;
	public String gsPANLendingMinAmount;
	public String gsPANLendingMaxTerm;
	public String gsPANRefinanceCount;
	public String gsPANConcurrentLoanCount;
	public String gsPANFrontOfficeUid;
	public String gsPANFrontOfficePwd;
	public String gsPANAgreementFound;
	public String gsPANFurtherLendingAgreementNumber;
	public String gsPANInArrearsAmount;
	// End of Data Set

	// Pricing
	public String gsExpectedInterest;
	public String gsExpectedRepayment;
	public String gsExpectedTAP;
	public String gsExpectedAPR;
	public String gsExpectedDailyRate;
	public String gsExpectedFlatRate;
	// End of Data Set

	// Invalid National Insurance Numbers
	public String AInvalidNINO_FA400737D = "FA400737D";
	public String AInvalidNINO_IA400737D = "IA400737D";
	public String AInvalidNINO_QA400737D = "QA400737D";
	public String AInvalidNINO_UA400737D = "UA400737D";
	public String AInvalidNINO_VA400737D = "VA400737D";
	public String AInvalidNINO_ND400737D = "ND400737D";
	public String AInvalidNINO_NF400737D = "NF400737D";
	public String AInvalidNINO_NI400737D = "NI400737D";
	public String AInvalidNINO_NQ400737D = "NQ400737D";
	public String AInvalidNINO_NU400737D = "NU400737D";
	public String AInvalidNINO_NV400737D = "NV400737D";
	public String AInvalidNINO_NO400737D = "NO400737D";
	public String AInvalidNINO_BG400737D = "BG400737D";
	public String AInvalidNINO_GB400737D = "GB400737D";
	public String AInvalidNINO_NK400737D = "NK400737D";
	public String AInvalidNINO_KN400737D = "KN400737D";
	public String AInvalidNINO_TN400737D = "TN400737D";
	public String AInvalidNINO_ZZ400737D = "ZZ400737D";
	public String AInvalidNINO_NA400737E = "NA400737E";
	public String AInvalidNINO_NA400737F = "NA400737F";
	public String AInvalidNINO_NA400737G = "NA400737G";
	public String AInvalidNINO_NA400737H = "NA400737H";
	public String AInvalidNINO_NA400737I = "NA400737I";
	public String AInvalidNINO_NA400737J = "NA400737J";
	public String AInvalidNINO_NA400737K = "NA400737K";
	public String AInvalidNINO_NA400737L = "NA400737L";
	public String AInvalidNINO_NA400737M = "NA400737M";
	public String AInvalidNINO_NA400737N = "NA400737N";
	public String AInvalidNINO_NA400737 = "NA400737";
	public String AInvalidNINO_NA400737DA = "NA400737DA";
	public String AInvalidNINO_NAX00737D = "NAX00737D";
	public String AInvalidNINO_NA4X0737D = "NA4X0737D";
	public String AInvalidNINO_NA40X737D = "NA40X737D";
	public String AInvalidNINO_NA400X37D = "NA400X37D";
	public String AInvalidNINO_NA4007X7D = "NA4007X7D";
	public String AInvalidNINO_NA40073XD = "NA40073XD";
	public String AInvalidNINO_NA400737O = "NA400737O";
	public String AInvalidNINO_NA400737P = "NA400737P";
	public String AInvalidNINO_NA400737Q = "NA400737Q";
	public String AInvalidNINO_NA400737R = "NA400737R";
	public String AInvalidNINO_NA400737S = "NA400737S";
	public String AInvalidNINO_NA400737T = "NA400737T";
	public String AInvalidNINO_NA400737U = "NA400737U";
	public String AInvalidNINO_NA400737V = "NA400737V";
	public String AInvalidNINO_NA400737W = "NA400737W";
	public String AInvalidNINO_NA400737X = "NA400737X";
	public String AInvalidNINO_NA400737Z = "NA400737Z";
	public String AInvalidNINO_NA4007370 = "NA4007370";
	public String AInvalidNINO_NA4007371 = "NA4007371";
	public String AInvalidNINO_NA4007372 = "NA4007372";
	public String AInvalidNINO_NA4007373 = "NA4007373";
	public String AInvalidNINO_NA4007374 = "NA4007374";
	public String AInvalidNINO_NA4007375 = "NA4007375";
	public String AInvalidNINO_NA4007376 = "NA4007376";
	public String AInvalidNINO_NA4007377 = "NA4007377";
	public String AInvalidNINO_NA4007378 = "NA4007378";
	public String AInvalidNINO_NA4007379 = "NA4007379";

	// End of Invalid NINO's

	public void DBConnectTESTSHED(String psConnectionString) throws SQLException {

		String sdbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		try {
			Class.forName(sdbClass);
			gdbConnTESTSHED = DriverManager.getConnection(psConnectionString);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void DBDisconnectTESTSHED() throws SQLException {
		if (gdbConnTESTSHED != null) {
			try {
				gdbConnTESTSHED.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void prGetApplicantProfile(int piApplicantProfileId) throws SQLException {

		CallableStatement SQLStmt = null;

		try {
			SQLStmt = gdbConnTESTSHED.prepareCall("{call [dbo].[pr_GetApplicantProfile] (?)}");
			SQLStmt.setInt(1, piApplicantProfileId);

			ResultSet rs = SQLStmt.executeQuery();
			while (rs.next()) {
				gsApplicantProfileId = rs.getString(1);
				gsCustomerId = rs.getString(2);
				gsMaritalStatus = rs.getString(3);
				gsNumberOfDependants = rs.getString(4);
				gsResidentialStatus = rs.getString(5);
				gsEmploymentStatus = rs.getString(6);
				gsSourceOfIncome = rs.getString(7);
				gsIncome = rs.getString(8);
				gsIncomeFrequency = rs.getString(9);
				gsIncomePaymentMethod = rs.getString(10);
				gsHasCreditCards = rs.getString(11);
				gsHasExistingLoans = rs.getString(12);
				gsMortgageCosts = rs.getString(13);
				gsRentCosts = rs.getString(14);
				gsMonthlyLoanRepayments = rs.getString(15);
				gsMonthlyOtherOutgoings = rs.getString(16);
				gsCurrentHouseMovedInDate = rs.getString(17);
				gsBankAccountName = rs.getString(18);
				gsBankAccountNumber = rs.getString(19);
				gsBankSortcode = rs.getString(20);
				gsBankAccountOpenDate = rs.getString(21);
				gsCreditCardNumber = rs.getString(22);
				gsCreditCardType = rs.getString(23);
				gsCreditCardExpiryDate = rs.getString(24);
				gsCreditCardCVS = rs.getString(25);
				gsRequestLoanProduct = rs.getString(26);
				gsRequestedLoanAmount = rs.getString(27);
				gsRequestedTerm = rs.getString(28);
				gsLoanPurpose = rs.getString(29);
				gsRepaymentFrequency = rs.getString(30);
				gsConsentToCreditSearch = rs.getString(31);
				gsMarketingOptInPost = rs.getString(32);
				gsMarketingOptInSMS = rs.getString(33);
				gsMarketingOptInEmail = rs.getString(34);
				gsMarketingOptInPhone = rs.getString(35);
				gsPreferredContactMethod = rs.getString(36);
				gsPreferredContactDetails = rs.getString(37);
				gsProfileBriefNote = rs.getString(38);
				gsCustomerId = rs.getString(39);
				gsDataSource = rs.getString(40);
				gsTitle = rs.getString(41);
				gsFirstname = rs.getString(42);
				gsMiddlename = rs.getString(43);
				gsSurname = rs.getString(44);
				gsDOB = rs.getString(45);
				gsGender = rs.getString(46);
				gsMobileNumber = rs.getString(47);
				gsHomeNumber = rs.getString(48);
				gsWorkNumber = rs.getString(49);
				gsFlatNumber = rs.getString(50);
				gsBuildingName = rs.getString(51);
				gsBuildingNumber = rs.getString(52);
				gsStreet = rs.getString(53);
				gsDistrict = rs.getString(54);
				gsTownCity = rs.getString(55);
				gsCounty = rs.getString(56);
				gsPostcode = rs.getString(57);
				gsCountry = rs.getString(58);
				gsEmailAddress = rs.getString(59);
				gsHousingCosts = rs.getString(60);
				gsPreferredPaymentDow = rs.getString(61);
				log.info("prGetApplicantProfile: Found Applicant Profile: " + gsApplicantProfileId);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (SQLStmt != null) {
				try {
					SQLStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public String fn_PreferredPaymentDate(String psDoW) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		int iDoW;
		int iReqDoW = 0;

		switch (psDoW.toUpperCase()) {
		case "SATURDAY":
			iReqDoW = 0;
			break;
		case "SUNDAY":
			iReqDoW = 1;
			break;
		case "MONDAY":
			iReqDoW = 2;
			break;
		case "TUESDAY":
			iReqDoW = 3;
			break;
		case "WEDNESDAY":
			iReqDoW = 4;
			break;
		case "THURSDAY":
			iReqDoW = 5;
			break;
		case "FRIDAY":
			iReqDoW = 6;
			break;
		}
		// Get todays date
		Calendar now = Calendar.getInstance();
		// add 7 days to current date using Calendar.add method
		now.add(Calendar.DATE, 7);
		iDoW = now.get(Calendar.DAY_OF_WEEK);
		while (iDoW != iReqDoW) {
			now.add(Calendar.DATE, 1);
			iDoW = now.get(Calendar.DAY_OF_WEEK);
		}
		return sdf.format(now.getTime());
	}

	public String fnGetPreferredPaymentDateForMonthly() {

		// Function: to return the preferred payment date as today's date + 31
		// days

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Today date.
		c.add(Calendar.DATE, 31); // Adding 31 days
		String output = sdf.format(c.getTime());
		log.info(output);
		return output;
	}

	public void prIsApplicantKnownToPAN(String psPanServiceServer, String psFirstname, String psSurname, String psDoB) throws XmlException, SoapUIException, Exception {

		log.info("prIsApplicantKnownToPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		gsPANSystemDate = null;
		gsPANAgreementStartDate = "";
		gsPANAgreementNumber = "";
		gsPANAgreementStatus = "";
		gsPANPersonAgreementStatus = "1";
		gsPANPersonAgreementStatusDesc = "Person has no agreements";
		gsPANApplicantFound = "No";
		gsPANPersonId = "";

		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectPanCredit-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("RESTTestSuite_Exploratory_ToolSet");
		TestCase testCase = testSuite.getTestCaseByName("TestCase: IsApplicantKnownToPAN");

		log.info("IsApplicantKnownToPan: " + psPanServiceServer + ": " + psFirstname + " " + psSurname + " " + psDoB);
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServer", psPanServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDoB", psDoB);
		testCase.setPropertyValue("ptcAgreementStartDate", gsPANAgreementStartDate);
		testCase.setPropertyValue("ptcAgreementNumber", gsPANAgreementNumber);
		testCase.setPropertyValue("ptcAgreementStatus", gsPANAgreementStatus);
		testCase.setPropertyValue("ptcPersonAgreementStatus", gsPANPersonAgreementStatus);
		testCase.setPropertyValue("ptcPersonAgreementStatusDesc", gsPANPersonAgreementStatusDesc);
		testCase.setPropertyValue("ptcApplicantFound", gsPANApplicantFound);
		testCase.setPropertyValue("ptcPersonId", gsPANPersonId);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		// Assert.assertEquals(TestRunner.Status.FINISHED,runner.getStatus());

		gsPANSystemDate = testCase.getPropertyValue("ptcProcessDate");
		gsPANAgreementStartDate = testCase.getPropertyValue("ptcAgreementStartDate");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANAgreementStatus = testCase.getPropertyValue("ptcAgreementStatus");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANApplicantFound = testCase.getPropertyValue("ptcApplicantFound");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Pan System Date: " + gsPANSystemDate);
		log.info("Applicant Found: " + gsPANApplicantFound);
		log.info("Person Agreement Status: " + gsPANPersonAgreementStatus);
		log.info("Person Agreement Status Description: " + gsPANPersonAgreementStatusDesc);
		log.info("Agreement Number: " + gsPANAgreementNumber);
		log.info("Agreement Status: " + gsPANAgreementStatus);
		log.info("Person Id: " + gsPANPersonId);
	}

	public void prCreateUniquePerson() throws XmlException, SoapUIException, IOException, Exception {

		log.info("prCreateUniquePerson: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		ProxySelector.setDefault(proxy);

		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePerson");
		ProxySelector.setDefault(proxy);

		// Set attributes before submission
		testCase.setPropertyValue("ptcFirstname", gsFirstname);

		TestRunner runner = testCase.run(new PropertiesMap(), false);
		ProxySelector.setDefault(proxy);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB);

		project = null;
		testSuite = null;
		testCase = null;
		runner = null;
	}

	public void prCreateBySurnameUniquePersonContactInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prCreatebySurnameUniquePersonContactInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateBySurnameUniquePersonContact");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", "");
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);
		testCase.setPropertyValue("ptcHomeNumber", gsHomeNumber);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsSurnameTemp = testCase.getPropertyValue("ptcSurname");

		log.info("Dynamic Unique By Surname Person Contact: " + gsFirstname + " " + gsSurnameTemp + " " + gsDOB);
	}

	public void prSeedUniqueActiveAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueActiveAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + "PANAgreement: " + gsPANAgreementNumber);
	}

	public void prSeedUniqueActiveAgreementInArrangementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueActiveAgreementInArrangementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreementInTemporaryArrangement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + "PANAgreement: " + gsPANAgreementNumber);
	}

	public void prPersonHasOnlyOneAgreement(String psPanCreditServiceServer, String psPersonId) throws XmlException, SoapUIException, Exception {

		// Use the called SOAPUI script to check if supplied PAN person only has
		// one agreement.
		// SOAPUI pass assumes Person has only one agreement
		log.info("prPersonHasOnlyOneAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_PersonHasOnlyOneAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPersonId", psPersonId);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prApplicantKnownNoCreate(String psPanCreditServiceServer, String psFirstname, String psSurname, String psDOB) throws XmlException, SoapUIException, Exception {

		// Use the called SOAPUI script to return Applicant Known response for
		// supplied person
		log.info("prApplicantKnownNoCreate: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_ApplicantKnownNoCreate");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDOB", psDOB);
		TestRunner runner = testCase.run(new PropertiesMap(), false);

		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANLendingMaxAmount = testCase.getPropertyValue("ptcLendingMaxAmount");
		gsPANLendingMinAmount = testCase.getPropertyValue("ptcLendingMinAmount");
		gsPANLendingMaxTerm = testCase.getPropertyValue("ptcLendingMaxTerm");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANRefinanceCount = testCase.getPropertyValue("ptcRefinanceCount");
		gsPANConcurrentLoanCount = testCase.getPropertyValue("ptcConcurrentLoanCount");
		gsPANApplicantFound = testCase.getPropertyValue("ptcPersonFound");

		log.info("PersonId: " + gsPANPersonId);
		log.info("LendingMaxAmount: " + gsPANLendingMaxAmount);
		log.info("LendingMinAmount: " + gsPANLendingMinAmount);
		log.info("LendingMaxTerm: " + gsPANLendingMaxTerm);
		log.info("PersonAgreemenStatus: " + gsPANPersonAgreementStatus);
		log.info("PersonAgreemenStatusDesc: " + gsPANPersonAgreementStatusDesc);
		log.info("RefinanceCount: " + gsPANRefinanceCount);
		log.info("ConcurrentLoanCount: " + gsPANConcurrentLoanCount);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prSeedUniqueReferredAgreementInPAN(String psPanCreditServiceServer, String psPanDecisionReasonID) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueReferredAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonReferredAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPANDecisionReasonID", psPanDecisionReasonID);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANDecisionReasonId = testCase.getPropertyValue("ptcPANDecisionReasonID");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Referred Decision: " + gsPANDecisionReasonId);
	}

	public void prSeedUniqueRejectedAgreementInPAN(String psPanCreditServiceServer, String psPanDecisionReasonID) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueRejectedAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonDeclinedAgreement");

		log.info(psPanCreditServiceServer);
		log.info(psPanDecisionReasonID);
		log.info(gsFirstname);
		log.info(gsStreet);
		log.info(gsTownCity);
		log.info(gsPostcode);
		log.info(gsNumberOfDependants);
		log.info(gsResidentialStatus);
		log.info(gsMaritalStatus);
		log.info(gsCurrentHouseMovedInDate);

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcPANDecisionReasonID", psPanDecisionReasonID);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANDecisionReasonId = testCase.getPropertyValue("ptcPANDecisionReasonID");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Referred Decision: " + gsPANDecisionReasonId);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prSeedUniqueHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement50PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueThirdPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueThirdPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN(String psPanCreditServiceServer, String psRequestedLoanAmount, String psRequestedLoanFrequency, String psRequestedLoanTerm) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonWithSpecifiedLoanActiveAgreement50PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", psRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedLoanFrequency", psRequestedLoanFrequency);
		testCase.setPropertyValue("ptcRequestedLoanTerm", psRequestedLoanTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueSpecifiedLoanThirdPaidUpAgreementInPAN(String psPanCreditServiceServer, String psRequestedLoanAmount, String psRequestedLoanFrequency, String psRequestedLoanTerm) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueSpecifiedLoanHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonWithSpecifiedLoanActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", psRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedLoanFrequency", psRequestedLoanFrequency);
		testCase.setPropertyValue("ptcRequestedLoanTerm", psRequestedLoanTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement100PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueFrozenAgreementInPAN(String psPanCreditServiceServer, String psPanStopCategoryId) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUniqueFrozenAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreementAndFreeze");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcStopCategoryID", psPanStopCategoryId);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANStopCategoryId = testCase.getPropertyValue("ptcStopCategoryID");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " Stop Category: " + gsPANStopCategoryId);
	}

	public void prSeedUnique100PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique100PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonAgreement100PercentPaidUpSpecifiedLoanTerms");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonAgreement50PercentPaidUpSpecifiedLoanTerms");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUnique33PCntPaidUpSpecifiedLoanTermAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedUnique33PCntPaidUpSpecifiedLoanTermAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonActiveAgreement33PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);
		testCase.setPropertyValue("ptcRequestedLoanAmount", gsRequestedLoanAmount);
		testCase.setPropertyValue("ptcRequestedTerm", gsRequestedTerm);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prGetPersonsLatestAgreementStatusInPAN(String psPanCreditServiceServer, String psFirstname, String psSurname, String psDOB) throws XmlException, SoapUIException, Exception {
		log.info("prGetPersonsLatestAgreementStatusInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_GetPersonsLatestAgreementStatus");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcDOB", psDOB);

		log.info("Find Person: " + gsFirstname + " " + gsSurname + " " + gsDOB);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementFound = testCase.getPropertyValue("ptcAgreementFound");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANAgreementStatus = testCase.getPropertyValue("ptcAgreementPrimaryStatus");
		gsPANAgreementSecondaryStatus = testCase.getPropertyValue("ptcAgreementSecondaryStatus");
		gsPANPersonAgreementStatus = testCase.getPropertyValue("ptcPersonAgreementStatus");
		gsPANPersonAgreementStatusDesc = testCase.getPropertyValue("ptcPersonAgreementStatusDesc");
		gsPANConcurrentLoanCount = testCase.getPropertyValue("ptcConcurrentLoanCount");
		gsPANFurtherLendingAgreementNumber = testCase.getPropertyValue("ptcFurtherLendingAgreementNumber");
		gsPANInArrearsAmount = testCase.getPropertyValue("ptcInArrearsAmount");
		gsPANLendingMaxAmount = testCase.getPropertyValue("ptcLendingMaxAmount");

		log.info("PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PrimaryStatus: " + gsPANAgreementStatus + " SecondaryStatus: " + gsPANAgreementSecondaryStatus + " ConcurrentLoansCount: " + gsPANConcurrentLoanCount + " FurtherLendingAgreementNumber: " + gsPANFurtherLendingAgreementNumber + " FurtherLendingMaxAmount: " + gsPANLendingMaxAmount + " InArrearsAmount: " + gsPANInArrearsAmount);
	}

	public String _getConfigProperty(String psName) throws Exception {

		Properties prop = new Properties();
		String sTmp;
		InputStream input = null;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sTmp = prop.getProperty(psName);
		log.info("_getConfigProperty: " + psName + "=" + sTmp);
		return sTmp;
	}

	public void prGetACurrentSatsumaLoanCharge(String psFrequency, int piTerm, int piLoanAmount

	) throws SQLException {

		log.info("prGetACurrentSatsumaLoanCharge: Frequency=" + psFrequency + ",Term=" + Integer.toString(piTerm) + ",LoanAmount=" + Integer.toString(piLoanAmount));

		CallableStatement SQLStmt = null;
		ResultSet rs = null;
		try {
			SQLStmt = gdbConnTESTSHED.prepareCall("{call [dbo].[prGetACurrentSatsumaLoanCharge] (?,?,?)}");
			SQLStmt.setString(1, psFrequency);
			SQLStmt.setInt(2, piTerm);
			SQLStmt.setInt(3, piLoanAmount);

			rs = SQLStmt.executeQuery();
			while (rs.next()) {
				gsExpectedTAP = rs.getString(3);
				gsExpectedInterest = rs.getString(4);
				gsExpectedRepayment = rs.getString(5);
				gsExpectedAPR = rs.getString(6);
				gsExpectedFlatRate = rs.getString(7);
				gsExpectedDailyRate = rs.getString(8);
				log.info("prGetACurrentSatsumaLoanCharge: TAP=" + gsExpectedTAP + ",Interest=" + gsExpectedInterest + ",Repayment=" + gsExpectedRepayment + ",ExpectedAPR=" + gsExpectedAPR + ",ExpectedDailyRate=" + gsExpectedDailyRate + ",ExpectedFlatRate=" + gsExpectedFlatRate);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (SQLStmt != null) {
				try {
					SQLStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void prAssertNewNonBrokeredAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psPreferredDoW:" + psPreferredDoW);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		log.debug("proxy changed = " + ProxySelector.getDefault());
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreement");
		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcPreferredDOW", psPreferredDoW);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);
		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prAssertNewNonBrokeredAgreementForPaidUpCustomer(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreementForPaidCustomer: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreementForPaidUpCustomer");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreementForPaidUpCustomer");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prAssertNewNonBrokeredAgreementForActiveCustomer(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created PAN
		// agreement
		log.info("DEBUG: prAssertNewNonBrokeredAgreementForActiveCustomer: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredAgreementForActiveCustomer");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredAgreementForActiveCustomer");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prAssertNewNonBrokeredReferredAgreement(String psPanCreditServiceServer, String psAgreementNumber, String psRepaymentFrequency, String psTerm, String psRepaymentAmount, String psLoanAmount, String psAPR, String psFlatRate, String psDailyRate, String psTAP, String psPreferredDoW, String psFirstname, String psSurname, String psMobileNumber, String psEmailAddress, String psStreetName, String psPostcode) throws XmlException, SoapUIException, Exception {
		// Use the called SOAPUI script to validate the newly created referred
		// proposal PAN agreement
		log.info("DEBUG: prAssertNewNonBrokeredReferredAgreement: SOAPUI project - location " + gsSOAPUIProjectFolder);
		log.info("DEBUG: projectSatsuma-soapui-project.xml");
		log.info("DEBUG: TestSuite_PanChecks");
		log.info("DEBUG: TestCase_AssertNewNonBrokeredReferredAgreement");
		log.info("DEBUG: psPanCreditServiceServer:" + psPanCreditServiceServer);
		log.info("DEBUG: psAgreementNumber:" + psAgreementNumber);
		log.info("DEBUG: psRepaymentFrequency:" + psRepaymentFrequency);
		log.info("DEBUG: psTerm:" + psTerm);
		log.info("DEBUG: psRepaymentAmount:" + psRepaymentAmount);
		log.info("DEBUG: psLoanAmount:" + psLoanAmount);
		log.info("DEBUG: psAPR:" + psAPR);
		log.info("DEBUG: psFlatRate:" + psFlatRate);
		log.info("DEBUG: psDailyRate:" + psDailyRate);
		log.info("DEBUG: psTAP:" + psTAP);
		log.info("DEBUG: psFirstname:" + psFirstname);
		log.info("DEBUG: psSurname:" + psSurname);
		log.info("DEBUG: psMobileNumber:" + psMobileNumber);
		log.info("DEBUG: psEmailAddress:" + psEmailAddress);
		log.info("DEBUG: psStreetName:" + psStreetName);
		log.info("DEBUG: psPostcode:" + psPostcode);
		ProxySelector proxy = ProxySelector.getDefault();

		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanChecks");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_AssertNewNonBrokeredReferredAgreement");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcAgreementNumber", psAgreementNumber);
		testCase.setPropertyValue("ptcRepaymentFrequency", psRepaymentFrequency);
		testCase.setPropertyValue("ptcTerm", psTerm);
		testCase.setPropertyValue("ptcRepaymentAmount", psRepaymentAmount);
		testCase.setPropertyValue("ptcLoanAmount", psLoanAmount);
		testCase.setPropertyValue("ptcAPR", psAPR);
		testCase.setPropertyValue("ptcFlatRate", psFlatRate);
		testCase.setPropertyValue("ptcDailyRate", psDailyRate);
		testCase.setPropertyValue("ptcTAP", psTAP);
		testCase.setPropertyValue("ptcFirstname", psFirstname);
		testCase.setPropertyValue("ptcSurname", psSurname);
		testCase.setPropertyValue("ptcMobileNumber", psMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", psEmailAddress);
		testCase.setPropertyValue("ptcStreetName", psStreetName);
		testCase.setPropertyValue("ptcPostcode", psPostcode);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("DEBUG: Runner Reason: " + runner.getReason());
		log.info("DEBUG: Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

	}

	public void prFillCreditAgreementPage(WebDriver driver) {

		// Credit Agreement
		// ----------------

		// Product Explanation - Read acknowledged

		getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).click();

		getDriver().findElement(By.xpath("//input[@id='ReadProductExplanation']")).click();

		// Pre-Contract Credit Information
		// -------------------------------

		// 1. Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();

		// 2. Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();

		// 3. Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();

		// 4. Other important legal aspects - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();

		// 5. Additional information innthe case of distance marketing of
		// financial services - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();

		// Contractual Terms and Conditions
		// --------------------------------

		// 6. Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();

		// 7. Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();

		// Confirm above sections read
		getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).click();

		// Credit Agreement and E-Signature
		// Fixed Sum Loan Agreement
		// --------------------------------

		// Parties to the Agreement - Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();

		// Check name on agreement
		getDriver().getPageSource().contains(gsTitle + " " + gsFirstname + " " + gsSurname);

		// Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features-credit-product']")).click();

		// Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();

		// Right of withdrawal - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();

		// Other important information - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();

		// Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();

		// Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();

		// Confirm above section read
		getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).click();

		// Signature of Customer
		// ---------------------

		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gsFirstname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gsSurname);
	}

	public void prSeedSpecifiedPersonActiveAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedPersonActiveAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonActiveAgreement");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedPersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedSpecifiedPersonFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonAgreement100PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);
		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedVulnerablePersonAgreement100PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsTitle + " " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedPersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedPersonActiveAgreement50PercentPaidUp");

		log.info(psPanCreditServiceServer);
		log.info(gsTitle);
		log.info(gsFirstname);
		log.info(gsSurname);
		log.info(gsDOB);
		;
		log.info(gsStreet);
		log.info(gsTownCity);
		log.info(gsPostcode);

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedUniqueFullPaidUpVulnerableAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {

		log.info("prSeedUniqueFullPaidUpVulnerableAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateUniquePersonVulnerableAgreement100PercentPaidUp");

		// Set attributes before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcDependants", gsNumberOfDependants);
		testCase.setPropertyValue("ptcResidentialStatus", gsResidentialStatus);
		testCase.setPropertyValue("ptcMaritalStatus", gsMaritalStatus);
		testCase.setPropertyValue("ptcMovingInDate", gsCurrentHouseMovedInDate);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsFirstname = testCase.getPropertyValue("ptcFirstname");
		gsSurname = testCase.getPropertyValue("ptcSurname");
		gsDOB = testCase.getPropertyValue("ptcDOB");
		gsMobileNumber = testCase.getPropertyValue("ptcMobileNumber");
		gsHomeNumber = testCase.getPropertyValue("ptcHomeNumber");
		gsEmailAddress = testCase.getPropertyValue("ptcEmailAddress");
		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Dynamic Unique Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(String psPanCreditServiceServer) throws XmlException, SoapUIException, Exception {
		log.info("prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN: SOAPUI project - location " + gsSOAPUIProjectFolder);
		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + "projectSatsuma-soapui-project.xml");
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName("TestSuite_PanCreditDataSeeding");
		TestCase testCase = testSuite.getTestCaseByName("TestCase_CreateSpecifiedVulnerablePersonActiveAgreement50PercentPaidUp");

		// Set attributes to specify the person for which the agreement is to be
		// associated too, before submission
		testCase.setPropertyValue("ptcPanCreditServiceServer", psPanCreditServiceServer);
		testCase.setPropertyValue("ptcTitle", gsTitle);
		testCase.setPropertyValue("ptcFirstname", gsFirstname);
		testCase.setPropertyValue("ptcSurname", gsSurname);
		testCase.setPropertyValue("ptcDOB", gsDOB);
		testCase.setPropertyValue("ptcBuildingNumber", gsBuildingNumber);
		testCase.setPropertyValue("ptcStreet", gsStreet);
		testCase.setPropertyValue("ptcTownCity", gsTownCity);
		testCase.setPropertyValue("ptcPostcode", gsPostcode);
		testCase.setPropertyValue("ptcMobileNumber", gsMobileNumber);
		testCase.setPropertyValue("ptcEmailAddress", gsEmailAddress);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());
		Assert.assertEquals(TestRunner.Status.FINISHED, runner.getStatus());

		gsPANAgreementNumber = testCase.getPropertyValue("ptcAgreementNumber");
		gsPANPersonId = testCase.getPropertyValue("ptcPersonId");
		gsPANPaidUpAmount = testCase.getPropertyValue("ptcPaidUp");

		log.info("Specified Person: " + gsFirstname + " " + gsSurname + " " + gsDOB + " PANPersonID: " + gsPANPersonId + " PANAgreement: " + gsPANAgreementNumber + " PaidUpAmount: " + gsPANPaidUpAmount);
	}

	public void prLogIntoPanCreditFrontOffice() throws Exception {

		// Log into PanCredit front office
		log.info("prLogIntoPanCreditFrontOffice: Logging into PanCredit Front Office: " + gsPanCreditServiceServer);

		getDriver().get(gsPanCreditServiceServer + "/panCoreSaas/app");

		// Check page attributes
		Assert.assertTrue(getDriver().getTitle().contains("pancredit"));

		getDriver().findElement(By.id("username")).sendKeys(gsPANFrontOfficeUid);
		getDriver().findElement(By.id("password")).sendKeys(gsPANFrontOfficePwd);

		getDriver().findElement(By.id("PanLinkSubmit")).click();

		// Landed successfully
		// Assert.assertTrue(getDriver().getCurrentUrl().toLowerCase().contains(gsPanCreditServiceServer.toLowerCase()
		// + "/pancoresaas/app"));

	}

	public void prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(String psFirstname, String psSurname, String psPostcode, String psSurnameRename) throws Exception {

		// Log into PanCredit front office
		log.info("prSearchForCustomerInPanCreditFrontOffice: Searching for customer: " + psFirstname + " " + psSurname + " " + psPostcode + " and renaming to " + psSurnameRename);

		getDriver().findElement(By.id("surname")).sendKeys(psSurname);
		getDriver().findElement(By.id("forename")).sendKeys(psFirstname);
		getDriver().findElement(By.id("postcode")).sendKeys(psPostcode);

		// Search now
		getDriver().findElement(By.id("PanLinkSubmit")).click();

		// Landed successfully
		Assert.assertEquals(gsPanCreditServiceServer.toLowerCase() + "/pancoresaas/app", getDriver().getCurrentUrl().toLowerCase());

		// View customer
		getDriver().findElement(By.xpath("//div[@class='results']/table/tbody/tr[2]/td[7]/a")).click();

		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("title")));
		dropdown.selectByVisibleText("Mr");
		getDriver().findElement(By.id("surname")).clear();
		getDriver().findElement(By.id("surname")).sendKeys(psSurnameRename);

		getDriver().findElement(By.id("PanLinkSubmit_6")).click();

	}

	public void prLogoutFromPanCreditFrontOffice() throws Exception {

		// Logout of PanCredit Front Office
		log.info("prLogoutFromPanCreditFrontOffice: Logging out from PanCredit Front Office: " + gsPanCreditServiceServer);

		getDriver().get(gsPanCreditServiceServer + "/panCoreSaas/app?component=%24PanDirectLink_48&page=HomePage&service=direct&session=T&state:HomePage=BrO0ABXcSAAAAAQAAC2N1cnJlbnRQYWdlc3IAEWphdmEubGFuZy5JbnRlZ2VyEuKgpPeBhzgCAAFJAAV2YWx1ZXhyABBqYXZhLmxhbmcuTnVtYmVyhqyVHQuU4IsCAAB4cAAAAAE%3D");

	}

	public void prNavigateToPANCreditAgreement(String psAgreementNumber) throws Exception {

		// Navigate to PAN Credit agreement
		log.info("prNavigateToPANCreditAgreement : Navigating to agreement " + psAgreementNumber);

		getDriver().findElement(By.id("agreementNumber")).sendKeys(psAgreementNumber);
		getDriver().findElement(By.id("PanLinkSubmit_0")).click();
		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?component=%24PanDirectLink&page=HomeExistingAgreements&service=direct&session=T&sp=S" + psAgreementNumber + "']")).click();

	}

	public void prRenameAgreementsApplicantSurname(String psAgreementNumber) throws Exception {

		// By renaming the applicant surname with prefix "AutoDel" we are
		// logically removing the agreement from the target test applicant
		// This technique is used to allow us to repeat the test using the same
		// test subject.
		log.info("prRenameAgreementsApplicantSurname: Renaming applicants surname on agreement " + psAgreementNumber);

		// getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=AgrServicing%2FASNameAndAddresses&service=page']")).click();
		getDriver().findElement(By.linkText("Name & Address")).click();

		String tmpStr = getDriver().findElement(By.id("surname")).getAttribute("value");
		if (!(tmpStr.contains("AutoDel"))) {
			getDriver().findElement(By.id("surname")).clear();
			getDriver().findElement(By.id("surname")).sendKeys("AutoDel" + tmpStr);
		}
		// getDriver().findElement(By.id("continue")).click();
		boolean foundButton = false;
		try {
			new WebDriverWait(getDriver(), 3).until(ExpectedConditions.elementToBeClickable(By.linkText("Continue")));
			getDriver().findElement(By.linkText("Continue")).click();
			foundButton = true;
		} catch (TimeoutException e) {
			log.warn("Couldn't find continue button, going to look for save button instead");
		}
		if (!foundButton) {
			new WebDriverWait(getDriver(), 3).until(ExpectedConditions.elementToBeClickable(By.id("continue")));
			getDriver().findElement(By.id("continue")).click();
		}

	}

	public void prAssertOnPageHome(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase();

		// Landed on Home page
		log.info("prAssertOnPageHome: Am I on expected landing page url - " + sExpectedPageUrl);

		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageYourApplication(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply";
		}

		// Landed on Your Application page
		log.info("prAssertOnPageYourApplication: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageAboutYou(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/about-you";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/about-you";
		}

		// Landed on About You page
		log.info("prAssertOnPageAboutYou: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageLoanValueAdjustment(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/change-loan-amount";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/change-loan-amount";
		}

		// Landed on Customer Authentication page
		log.info("prAssertOnPageLoanValueAdjustment: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageAuthentication(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/authentication";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/authentication";
		}

		// Landed on Customer Authentication page
		log.info("prAssertOnPageAuthentication: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageYourFinances(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/income-and-outgoings";

		if (gsQuickApply.toLowerCase().equals("true")) {
			log.info("prAssertOnPageYourFinances: Quick Apply journey detected, By passing this check");
		} else {
			// Landed on Your Finances page
			log.info("prAssertOnPageYourFinances: Am I on expected landing page url - " + sExpectedPageUrl);
			waitForUrl(sExpectedPageUrl);
			Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		}
	}

	public void prAssertOnPageQuote(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/quote";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/quote";
		}

		// Landed on Quote page
		log.info("prAssertOnPageQuote: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageBankDetails(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/bank-details";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/bank-details";
		}

		// Landed on Bank Details page
		log.info("prAssertOnPageBankDetails: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageCreditAgreement(String psSatsumaSiteUrl) throws Exception {

		By byCreditAgreementHeader = By.cssSelector("#JourneyForm > h2:nth-child(1)");
		(new WebDriverWait(getDriver(), 180)).until(ExpectedConditions.presenceOfElementLocated(byCreditAgreementHeader));

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "Credit agreement", "check credit agreement header");

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/agreement";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/agreement";
		}

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageHomeCredit(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "home-credit";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageHomeCredit: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		// Check that HCR page does not default the forename and Surname of the
		// applying Satsuma applicant
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerFirstnameSignature")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CustomerSurnameSignature")).getAttribute("value"));
	}

	public void prAssertOnPagePayslip(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/payslip";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/payslip";
		}

		// Landed on Payslip page
		log.info("prAssertOnPagePayslip: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageFinishedIDResult2(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result2 > Decline - We're sorry,
		// We’ve had a quick look at your Satsuma Loans account and based on
		// what we know we’ll be unable to continue with your application for a
		// further loan today
		// This is because you have reached the outstanding loan limit on your
		// account
		log.info("prAssertOnPageFinishedIDResult2: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result2")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult2: Finished Page: Not Result2 page - We're sorry, This is because you have reached the outstanding loan limit on your account.");
		}
	}

	public void prAssertOnPageFinishedIDResult3(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result3 > Decline - We can see that
		// you have already submitted an application for a Satsuma Loan
		log.info("prAssertOnPageFinishedIDResult3: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result3")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult3: Finished Page: Not Result3 page - We can see that you have already submitted an application for a Satsuma Loan");
		}
	}

	public void prAssertOnPageFinishedIDResult4(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result4 > Unfortunately, we are
		// unable to proceed with your application as we have been unable to
		// verify the agreement number you have entered and confirm your
		// identity
		log.info("prAssertOnPageFinishedIDResult4: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result4")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult4: Finished Page: Not Result4 page - Unfortunately, we are unable to proceed with your application as we have been unable to verify the agreement number you have entered and confirm your identity");
		}
	}

	public void prAssertOnPageFinishedIDResult5(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result5 > Thank you for your interest
		// in another Satsuma Loan. Unfortunately we're unable to process your
		// application for a further loan today.
		log.info("prAssertOnPageFinishedIDResult5: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result5")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult5: Finished Page: Thank you for your interest in another Satsuma Loan. Unfortunately we're unable to process your application for a further loan today.");
		}
	}

	public void prAssertOnPageFinishedIDResult25(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result5 > Thank you for your interest
		// in another Satsuma Loan. Unfortunately we're unable to process your
		// application for a further loan today.
		log.info("prAssertOnPageFinishedIDResult25: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result25")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult5: Finished Page: Thank you for your interest in another Satsuma Loan. Unfortunately we're unable to process your application for a further loan today.");
		}
	}

	public void prAssertOnPageFinishedIDResult7(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result7 > Generic Decline Thank you
		// for applying for a Satsuma Loan. Unfortunately your application has
		// not been successful on this occasion.
		log.info("prAssertOnPageFinishedIDResult7: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result7")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult7: Finished Page: Not Result7 page - Generic Decline - Thank you for applying for a Satsuma Loan. Unfortunately your application has not been successful on this occasion.");
		}
	}

	public void prAssertOnPageFinishedIDResult8(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result8 > Decline - You have
		// previously been declined for a Satsuma loan.
		// We can see that you have previously submitted an application for a
		// Satsuma Loan, which was unfortunately declined
		log.info("prAssertOnPageFinishedIDResult8: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result8")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult8: Finished Page: Not Result8 page - We can see that you have previously submitted an application for a Satsuma Loan, which was unfortunately declined");
		}
	}

	public void prAssertOnPageFinishedIDResult9(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Result9 > Thank you for applying for
		// a Satsuma Loan. Unfortunately your application has not been
		// successful on this occasion.
		log.info("prAssertOnPageFinishedIDResult9: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result9")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result9 page - Thank you for applying for a Satsuma Loan. Unfortunately your application has not been successful on this occasion.");
		}
	}

	public void prAssertOnPageFinishedIDResult22(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Resul22 > Thank you for applying for
		// a Satsuma Loan, We're sorry but we're unable to continue with your
		// application for a Satsuma Loan this time. Our checks at the Credit
		// Reference Agency have revealed information relating to you that has
		// contributed to our decision not to proceed with your application.
		log.info("prAssertOnPageFinishedIDResult22: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result22")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result22 page - Thank you for applying for a Satsuma Loan, We're sorry but we're unable to continue with your application for a Satsuma Loan this time. Our checks at the Credit Reference Agency have revealed information relating to you that has contributed to our decision not to proceed with your application.");
		}
	}

	public void prAssertOnPageFinishedIDResult23(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Resul23 > We're sorry but we can't
		// help today, We can see that you are currently a Home Credit Customer
		log.info("prAssertOnPageFinishedIDResult23: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result23")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result23 page -  We're sorry be can't help today, We can see that you are currently a Home Credit Customer.");
		}
	}

	public void prAssertOnPageFinishedIDResult24(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/finished";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/finished";
		}

		// Landed on Finished page of type Resul24 > Thank you for applying for
		// a Satsuma Loan, Unfortunately your application
		// has not been successful on this occasion, Please note we've not
		// carried out a credit check as part of your application
		// todays and your credit record will not be affected.
		log.info("prAssertOnPageFinishedIDResult24: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result24")).size() == 0) {
			Assert.fail("prAssertOnPageFinishedIDResult: Finished Page: Not Result24 page -  We're sorry be can't help today, Please note we've not carried out a credit check as part of your application today and your credit record will not be affected.");
		}
	}

	public void prAssertOnPageCompletionIDResult11(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result11 > Your application is now
		// being processed and verified.
		// Within 24 hours customer care team will contact you whether your
		// application has been accepted.
		log.info("prAssertOnPageCompletionIDResult11: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result11")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult11: Completion Page: Not Result11 page - Your application is now being processed and verified. Within 24 hours customer care team will contact you whether your application has been accepted.");
		}
	}

	public void prAssertOnPageCompletionIDResult12(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result12 > Great news! Your next
		// Satsuma Loan has been approved in principle
		log.info("prAssertOnPageCompletionIDResult12: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result12")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult12: Completion Page: Not Result12 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved in principle.");
		}
	}

	public void prAssertOnPageCompletionIDResult13(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result13 > Great news! Your next
		// Satsuma Loan has been approved
		log.info("prAssertOnPageCompletionIDResult13: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result13")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult13: Completion Page: Not Result13 page - Expecting page in context of Great news! Your next Satsuma Loan has been approved.");
		}
	}

	public void prAssertOnPageCompletionIDResult15(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result15 > Lets have a chat. We
		// will call you in the next 4 hours.
		log.info("prAssertOnPageCompletionIDResult15: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result15")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult15: Completion Page: Not Result15 page - Expecting page in context of Lets have a chat. We will call you in the next 4 hours.");
		}
	}

	public void prAssertOnPageCompletionIDResult16(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result16 > Waiting for your email
		log.info("prAssertOnPageCompletionIDResult16: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result16")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult16: Completion Page: Not Result16 page - Expecting page in context of Waiting for your email.");
		}
	}

	public void prAssertOnPageCompletionIDResult17(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result17 > Great news! Your loan
		// with Satsuma has been approved in principle. We just need to verify
		// your income. We will call you in the next 4 hours.
		log.info("prAssertOnPageCompletionIDResult17: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result17")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult17: Completion Page: Not Result17 page - Expecting page in context of Great news! Your loan with Satsuma has been approved in principle. We just need to verify your income. We will call you in the next 4 hours.");
		}
	}

	public void prAssertOnPageCompletionIDResult18(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result18 > Great news! Your loan
		// with Satsuma Loans has been approved in principle
		log.info("prAssertOnPageCompletionIDResult18: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
		if (getDriver().findElements(By.id("Result18")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult18: Completion Page: Not Result18 page - Expecting page in context of Great news! Your loan with Satsuma Loans has been approved in principle");
		}
	}

	public void prAssertOnPageCompletionIDResult19(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl;

		if (gsQuickApply.toLowerCase().equals("true")) {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "quick-apply/complete";
		} else {
			sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply/complete";
		}

		// Landed on Completion page of type Result19 > Great news! Your Satsuma
		// Loan has been approved
		log.info("prAssertOnPageCompletionIDResult19: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

		if (getDriver().findElements(By.id("Result19")).size() == 0) {
			Assert.fail("prAssertOnPageCompletionIDResult19: Completion Page: Not Result19 page - Expecting page in context of Great news! Your Satsuma Loan has been approved.");
		}
	}

	public void prFillInPageAboutYouMobile() throws Exception {

		String sABUPreferredPaymentDate;
		Select dropdown;

		if (gsPANAgreementNumber.isEmpty()) {
			// Do you currently have, or have you previously had a Satsuma Loan?
			// - Default click is No
			if (!getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected()) {
				getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
			}
		} else {
			if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
				getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
			}
			getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(gsPANAgreementNumber);
		}

		// How much would you like to borrow ?
		// Loan Amount

		// String gsTmp;
		// JavascriptExecutor js = (JavascriptExecutor) psWebDriver;
		// gsTmp = "AboutYouCalc.setAmount("+gsRequestedLoanAmount+")";
		// js.executeScript(gsTmp);
		dropdown = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown")));
		// waitForOptionsToLoad(psWebDriver, dropdown, 190);
		// dropdown.selectByVisibleText("£" + gsRequestedLoanAmount);
		dropdown.selectByValue(gsRequestedLoanAmount);

		try {
			getDriver().findElement(By.id("TermTypeAboutYouCalcMonthlyLabel"));

			// Requested Loan Repayment Frequency
			if (gsRepaymentFrequency.equals("Monthly")) {
				if (!getDriver().findElement(By.id("TermTypeAboutYouCalcMonthlyLabel")).isSelected()) {
					getDriver().findElement(By.id("TermTypeAboutYouCalcMonthlyLabel")).click();
				}
			}
			if (gsRepaymentFrequency.equals("Weekly")) {
				if (!getDriver().findElement(By.id("TermTypeAboutYouCalcWeeklyLabel")).isSelected()) {
					getDriver().findElement(By.id("TermTypeAboutYouCalcWeeklyLabel")).click();
				}
			}
		} catch (NoSuchElementException e) {
			if (gsRepaymentFrequency.equals("Monthly")) {
				Assert.fail("Aborted: Applicant profile data requesting Monthly, Monthly slider version is switched off.");
			}
		}

		// Requested Term
		// gsTmp = "AboutYouCalc.setTerm("+gsRequestedTerm+")";
		// js.executeScript(gsTmp);
		dropdown = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown")));
		dropdown.selectByVisibleText(gsRequestedTerm + " weeks");

		// Validate selected pricing details

		// log.debug(getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText());
		// log.debug(getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText());

		// String actualRepayment =
		// getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText().substring(1,
		// getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText().length());
		// String actualTap =
		// getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText().substring(1,
		// getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText().length());

		String actualRepayment = getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText();
		String actualTap = getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText();

		// Assert.assertEquals(gsExpectedRepayment, actualRepayment);
		// Assert.assertEquals(gsExpectedTAP, actualTap);

		Assert.assertEquals("£" + gsExpectedRepayment, actualRepayment);
		Assert.assertEquals("£" + gsExpectedTAP, actualTap);

		// On which day of the week would you like to make your repayments, only
		// applicable for Weekly Frequency

		if (gsRepaymentFrequency.equals("Weekly")) {
			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
			dropdown.selectByVisibleText(gsPreferredPaymentDow);
			sABUPreferredPaymentDate = getDriver().findElement(By.id("preferredPaymentDateLabel")).getText();
		} else {
			sABUPreferredPaymentDate = fnGetPreferredPaymentDateForMonthly();
		}

		log.info("DEBUG: Calculated Payment Date> " + sABUPreferredPaymentDate);

		// On which day of the week would you like to make your repayments
		dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText(gsPreferredPaymentDow);

		// What will you use your loan for?*
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText(gsLoanPurpose);

		// For our own research, please tell us the minimum loan amount you
		// would find useful today?* Default to Â£100
		dropdown = new Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£" + gsRequestedLoanAmount);
		dropdown.selectByValue(gsRequestedLoanAmount);

		// Please read our website cookie policy and tick this box to agree -
		// Tick please
		// getDriver().findElement(By.id("CookieAccepted")).click();
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Personal Details
		// ----------------

		// Applicants Title
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText(gsTitle);
		// Applicants Firstname
		getDriver().findElement(By.id("Forename")).sendKeys(gsFirstname);
		// Applicants Surname
		getDriver().findElement(By.id("Surname")).sendKeys(gsSurname);

		log.info(gsDOB.replace("-", ""));

		// getDriver().findElement(By.id("DateOfBirth_DateOfBirth")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("DateOfBirth_DateOfBirth")).click();

		// set value of native date picker
		selectDateAndroidDatePicker("DateOfBirth_DateOfBirth", gsDOB.substring(6, 10) + "-" + gsDOB.substring(3, 5) + "-" + gsDOB.substring(0, 2));

		// // Applicants DOB - Day
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		// dropdown.selectByVisibleText(gsDOB.substring(0, 2));
		// // Applicants DOB - Month
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		// dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gsDOB.substring(3,
		// 5)));
		// // Applicants DOB - Year
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		// dropdown.selectByVisibleText(gsDOB.substring(6, 10));
		// Applicants Marital Status
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText(gsMaritalStatus);
		// Applicants Number Of Dependants
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText(gsNumberOfDependants);

		// Your Address
		// ------------

		// Applicants Residential Status
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText(gsResidentialStatus);

		// getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_DisplayDateMovedIn")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_DisplayDateMovedIn")).click();

		// set value of date picker for moved in date
		selectDateAndroidDatePicker("CurrentAddress_DisplayDateMovedIn_DisplayDateMovedIn", gsCurrentHouseMovedInDate.substring(6, 10) + "-" + gsCurrentHouseMovedInDate.substring(3, 5));

		// // Applicants Current Address Moved In Date
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		// dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(gsCurrentHouseMovedInDate.substring(3,
		// 5)));
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		// dropdown.selectByVisibleText(gsCurrentHouseMovedInDate.substring(6,
		// 10));

		// getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")).sendKeys(Keys.TAB);

		// Use QAS with non-existence postcode to force manual entry of address
		// details
		// getDriver().findElement(By.id("houseNameOrNumberSearch")).sendKeys(gsBuildingNumber);
		// getDriver().findElement(By.id("PostCode")).sendKeys("ZZ1 1ZZ");
		// getDriver().findElement(By.id("search")).click();

		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-addresssearch-manualentryoption=' ']")));
		// getDriver().findElement(By.linkText("or enter your address manually")).click();

		WebElement linkCurrentAddressManualEntry = getDriver().findElement(By.id("CurrentAddressManualEntry"));
		// scrolling didn't work so commented out for now
		// scrollToElementAndClick(psWebDriver, linkCurrentAddressManualEntry);
		// linkCurrentAddressManualEntry.click();

		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);

		// tab house number to get manual address element on screen
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).sendKeys(Keys.TAB);

		// tab house number to get manual address element on screen
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys(Keys.TAB);

		// sendkeys instead of click as element is not clickable exception keeps
		// happening in chrome
		linkCurrentAddressManualEntry.sendKeys(Keys.SPACE);

		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentAddress_FlatNumber")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentAddress_FlatNumber")));

		// Flat number
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_FlatNumber")), gsFlatNumber);

		// House/Building name
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_BuildingName")), gsBuildingName);

		// House Number
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_HouseNumber")), gsBuildingNumber);

		// Street
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_Street")), gsStreet);

		// District
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_District")), gsDistrict);

		// Town/City
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_TownCity")), gsTownCity);

		// County
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_County")), gsCounty);

		// Postcode
		sendKeysIfNotNull(getDriver().findElement(By.id("CurrentAddress_Postcode")), gsPostcode);

		/*
		 * getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys(
		 * gsFlatNumber); // House/Building name
		 * getDriver().findElement(By.id("CurrentAddress_BuildingName"
		 * )).sendKeys( gsBuildingName); // House Number
		 * getDriver().findElement(
		 * By.id("CurrentAddress_HouseNumber")).sendKeys( gsBuildingNumber); //
		 * Street
		 * getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys(
		 * gsStreet); // District
		 * getDriver().findElement(By.id("CurrentAddress_District")).sendKeys(
		 * gsDistrict); // Town/City
		 * getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys(
		 * gsTownCity); // County
		 * getDriver().findElement(By.id("CurrentAddress_County")).sendKeys(
		 * gsCounty); // Postcode
		 * getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(
		 * gsPostcode);
		 */

		Boolean bCheck;
		try {
			getDriver().findElement(By.id("PreviousAddressMessage"));
			bCheck = true;
		} catch (org.openqa.selenium.NoSuchElementException e) {
			bCheck = false;
		}

		// May want to specify a previous address if moved in date is less than
		// 3 years
		if (bCheck) {

			// Postcode BD1 2SU should only return 1 address at No 1 Godwin
			// Street
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).clear();
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
			getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD1 2SU");
			// Search now
			getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();

			dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_PreviousAddressChosenAddress")));
			if (dropdown.getOptions().size() != 2) {
				Assert.fail("Failed: Expecting only 1 address to be listed");
			}

			// Assert that the single address found is selected automatically
			Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", dropdown.getFirstSelectedOption().getText());
		}

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(gsMobileNumber);
		// Applicant Email Address
		getDriver().findElement(By.id("EmailAddress")).sendKeys(gsEmailAddress);

		// Marketing Options

		if (!getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected() && gsMarketingOptInPost.toLowerCase().equals("false")) {
			getDriver().findElement(By.id("OptOutOfMarketingByPost")).click();
		}
		if (getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected() && gsMarketingOptInPost.toLowerCase().equals("true")) {
			getDriver().findElement(By.id("OptOutOfMarketingByPost")).click();
		}

		if (!getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected() && gsMarketingOptInEmail.toLowerCase().equals("false")) {
			getDriver().findElement(By.id("OptOutOfMarketingByEmail")).click();
		}
		if (getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected() && gsMarketingOptInEmail.toLowerCase().equals("true")) {
			getDriver().findElement(By.id("OptOutOfMarketingByEmail")).click();
		}

		if (!getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected() && gsMarketingOptInSMS.toLowerCase().equals("false")) {
			getDriver().findElement(By.id("OptOutOfMarketingBySMS")).click();
		}
		if (getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected() && gsMarketingOptInSMS.toLowerCase().equals("true")) {
			getDriver().findElement(By.id("OptOutOfMarketingBySMS")).click();
		}

		if (!getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected() && gsMarketingOptInPhone.toLowerCase().equals("false")) {
			getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).click();
		}
		if (getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected() && gsMarketingOptInPhone.toLowerCase().equals("true")) {
			getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).click();
		}
	}

	private void waitForOptionsToLoad(final Select dropdown, final int expectedNoOptions) {
		WebDriverWait wait = new WebDriverWait(getDriver(), 10);
		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver arg0) {
				return dropdown.getOptions().size() > expectedNoOptions;
			}
		});
		log.debug("Waited for " + expectedNoOptions + " options on dropdown " + dropdown.toString());
	}

	public void prFillInPageYourFinances() throws Exception {

		// Fill in Applicants finance details with stored applicant profile data
		log.info("prFillInPageYourFinances: Applicant profile data used to fill in page attribues.");

		Select dropdown;

		log.debug("Before source of employment dropdown");

		// Income source
		dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
		dropdown.selectByVisibleText(gsSourceOfIncome);

		log.debug("Before source of income dropdown");

		// Income
		getDriver().findElement(By.id("Income")).clear();
		getDriver().findElement(By.id("Income")).sendKeys(gsIncome);

		log.debug("Before source of income freq dropdown");

		// Income Frequency
		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText(gsIncomeFrequency);

		log.debug("Before source of income method dropdown");

		// Income Method
		dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
		dropdown.selectByVisibleText(gsIncomePaymentMethod);

		// Housing costs amount
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(gsHousingCosts);

		// Has Credit cards
		if (gsHasCreditCards.equals("true") && !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasCreditCardsYes']")).sendKeys(Keys.SPACE);
			// Monthly Creditcard and Loan Repayments
			getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(gsMonthlyLoanRepayments);
		} else if (gsHasCreditCards.equals("false") && !getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).sendKeys(Keys.SPACE);
		}

		// Has Other Loans
		if (gsHasExistingLoans.equals("true") && !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasOtherLoansYes']")).sendKeys(Keys.SPACE);
		} else if (gsHasExistingLoans.equals("false") && !getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected()) {
			// getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
			getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).sendKeys(Keys.SPACE);
		}

		// Other outgoings
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(gsMonthlyOtherOutgoings);

		// Consents and Use of Personal Information
		// Declaration
		// getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).sendKeys(Keys.SPACE);
		// Using my personal information
		// getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).sendKeys(Keys.SPACE);
		// Sharing my personal information
		// getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).sendKeys(Keys.SPACE);
		// Credit reference agencies
		// getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).sendKeys(Keys.SPACE);
		// Verifying my identity and fraud checks
		// getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).sendKeys(Keys.SPACE);
		// Access to information
		// getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).sendKeys(Keys.SPACE);
		// Marketing
		// getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).click();
		getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).sendKeys(Keys.SPACE);

		// Have agreed to bureau search - Must tick to progress
		if (gsConsentToCreditSearch.equals("true") && !getDriver().findElement(By.xpath("//input[@id='AgreedToBureauSearch']")).isSelected()) {
			// getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			getDriver().findElement(By.id("AgreedToBureauSearch")).sendKeys(Keys.SPACE);
		}
	}

	public void prAssertQuoteOfferAsPerRequest() throws Exception {

		// String actualRequestedLoanAmount =
		// getDriver().findElement(By.id("LoanAmountCell")).getText().substring(1,
		// getDriver().findElement(By.id("LoanAmountCell")).getText().length());
		// String actualRepayment =
		// getDriver().findElement(By.id("InstalmentAmountCell")).getText().substring(1,
		// getDriver().findElement(By.id("InstalmentAmountCell")).getText().length()).replace(",",
		// "");
		// String actualTap =
		// getDriver().findElement(By.id("TotalAmountPayableCell")).getText().substring(1,
		// getDriver().findElement(By.id("TotalAmountPayableCell")).getText().length()).replace(",",
		// "");

		String actualRequestedLoanAmount = getDriver().findElement(By.id("LoanAmountCell")).getText();
		String actualRepayment = getDriver().findElement(By.id("InstalmentAmountCell")).getText().replace(",", "");
		String actualTap = getDriver().findElement(By.id("TotalAmountPayableCell")).getText().replace(",", "");

		// Check offer as requested

		// assertEquals("£" + gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountCell")).getText());
		// assertEquals(gsRequestedTerm + " weeks",
		// getDriver().findElement(By.id("LoanTermCell")).getText());
		// assertEquals("£" + gsExpectedRepayment,
		// getDriver().findElement(By.id("InstalmentAmountCell")).getText().replace(",",
		// ""));
		// assertEquals("£" + gsExpectedTAP,
		// getDriver().findElement(By.id("TotalAmountPayableCell")).getText().replace(",",
		// ""));
		// assertEquals(gsExpectedAPR + "%",
		// getDriver().findElement(By.id("AprCell")).getText());

		Assert.assertEquals("£" + gsRequestedLoanAmount, actualRequestedLoanAmount);
		Assert.assertEquals(gsRequestedTerm + " weeks", getDriver().findElement(By.id("LoanTermCell")).getText());
		Assert.assertEquals("£" + gsExpectedRepayment, actualRepayment);
		Assert.assertEquals("£" + gsExpectedTAP, actualTap);
		Assert.assertEquals(gsExpectedAPR + "%", getDriver().findElement(By.id("AprCell")).getText());

		// Assert.assertEquals(sABUPreferredPaymentDate,getDriver().findElement(By.xpath("//form[@class='blockOnSubmit']//table/tbody/tr[7]/td[2]")).getText());
	}

	public void prFillInPageBankDetails() throws Exception {

		// override account number with random
		String gsBankSortcode = Integer.toString(ThreadLocalRandom.current().nextInt(100000, 999999 + 1));
		String gsBankAccountNumber = Integer.toString(ThreadLocalRandom.current().nextInt(10000000, 99999999 + 1));

		// Fill in Applicants bank details with stored applicant profile data
		log.info("prFillInPageBankDetails: Applicant profile data used to fill in page attribues.");

		Select dropdown;

		// Account Holder
		getDriver().findElement(By.id("AccountHolder")).sendKeys(gsBankAccountName);

		// Account Sort Code
		getDriver().findElement(By.id("SortCode_Part1")).sendKeys(gsBankSortcode.substring(0, 2));
		getDriver().findElement(By.id("SortCode_Part2")).sendKeys(gsBankSortcode.substring(2, 4));
		getDriver().findElement(By.id("SortCode_Part3")).sendKeys(gsBankSortcode.substring(4, 6));

		// Account Number
		getDriver().findElement(By.id("AccountNumber")).sendKeys(gsBankAccountNumber);

		getDriver().findElement(By.id("DisplayAccountOpened_DisplayAccountOpened")).sendKeys(Keys.TAB);

		// // // When did you open your account with the bank?

		// set value of date picker for moved in date
		selectDateAndroidDatePicker("DisplayAccountOpened_DisplayAccountOpened", gsBankAccountOpenDate.substring(6, 10) + "-" + gsBankAccountOpenDate.substring(3, 5));

		// // // dropdown = new
		// // //
		// //
		// Select(getDriver().findElement(By.id("DisplayAccountOpened_Month")));
		// // dropdown = new
		// Select(getDriver().findElement(byDdAccountOpenMonth));
		// // String sMMM = "NotSet";
		// // String sMM = gsBankAccountOpenDate.substring(3,
		// // 5).replaceFirst("^0*", "");
		// /*
		// * switch (sMM) { case "1" : sMMM = "January"; break; case "2" : sMMM
		// =
		// * "February"; break; case "3" : sMMM = "March"; break; case "4" :
		// sMMM
		// * = "April"; break; case "5" : sMMM = "May"; break; case "6" : sMMM =
		// * "June"; break; case "7" : sMMM = "July"; break; case "8" : sMMM =
		// * "August"; break; case "9" : sMMM = "September"; break; case "10" :
		// * sMMM = "October"; break; case "11" : sMMM = "November"; break; case
		// * "12" : sMMM = "December"; break; }
		// * dropdown.selectByVisibleText(sMMM);
		// */
		// // dropdown.selectByValue(sMM);
		// // dropdown = new
		// //
		// Select(getDriver().findElement(By.id("DisplayAccountOpened_Year")));
		// dropdown = new Select(getDriver().findElement(byDdAccountOpenYear));
		// dropdown.selectByVisibleText(gsBankAccountOpenDate.substring(6, 10));
	}

	public void prFillInTestWorldPayAndRespond(String psPaRes, String psCVCRes, String psAVSRes) throws Exception {
		prFillInTestWorldPayAndRespond(psPaRes, psCVCRes, psAVSRes, "");
	}

	public void prFillInTestWorldPayAndRespond(String psPaRes, String psCVCRes, String psAVSRes, String testName) throws Exception {

		// Fill in WorldPay pages with applicant profile and respond with
		// required WorldPay Card response
		log.info("prFillInTestWorldPayAndRespond: Applicant profile data used to fill in page attributes. Response required PaRes:" + psPaRes + " CVCRes:" + psCVCRes + " AVSRes:" + psAVSRes);

		Select dropdown;

		// Landed on WorldPay page
		// Assert.assertTrue(getDriver().getTitle().contains("Welcome to WorldPay"),
		// "check on worldpay title page");
		waitForTitle("Welcome to WorldPay");

		// Has Mastercard, Visa Debit or Maestro
		if (gsCreditCardType.equals("Mastercard")) {
			getDriver().findElement(By.xpath("//input[@name='op-DPChoose-ECMC^SSL']")).click();
		} else if (gsCreditCardType.equals("Visa Debit")) {
			getDriver().findElement(By.xpath("//input[@name='op-DPChoose-VISA^SSL']")).click();
		} else if (gsCreditCardType.equals("Maestro")) {
			getDriver().findElement(By.xpath("//input[@name='op-DPChoose-MAESTRO^SSL']")).click();
		} else {
			Assert.fail("Aborted: Applicant Profile used must define CreditCardType as either Mastercard, Visa Debit or Maestro");
		}

		Thread.sleep(1000);

		getDriver().findElement(By.xpath("//input[@id='cardNoInput']")).sendKeys(gsCreditCardNumber);
		getDriver().findElement(By.xpath("//input[@id='cardCVV']")).sendKeys(gsCreditCardCVS);
		dropdown = new Select(getDriver().findElement(By.name("cardExp.month")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(0, 2));
		dropdown = new Select(getDriver().findElement(By.name("cardExp.year")));
		dropdown.selectByVisibleText(gsCreditCardExpiryDate.substring(3, 7));
		getDriver().findElement(By.xpath("//input[@id='name']")).sendKeys(gsBankAccountName);

		// Invoke Next action: Simulator Test Page
		By byBtnMakePayment = By.xpath("//input[@name='op-PMMakePayment']");
		waitForClickableElement(byBtnMakePayment);
		getDriver().findElement(byBtnMakePayment).click();

		// log.debug("simulator page");

		// Thread.sleep(1000);
		// Landed on WorldPay Simulator Response page
		// Assert.assertTrue(getDriver().getTitle().contains("Simulator page"),
		// "check on simulator title page");

		// title changed for mobile?
		// Assert.assertEquals(getDriver().getTitle(), "Simulator page",
		// "Assert we are on the simulator page");

		// wait for elements to be clickable
		// WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		// wait.until(ExpectedConditions.elementToBeClickable(By.name("PaRes")));
		// wait.until(ExpectedConditions.elementToBeClickable(By.name("CVCRes")));
		// wait.until(ExpectedConditions.elementToBeClickable(By.name("AVSRes")));

		try {

			// wait for elements to be clickable
			waitForClickableElement(By.name("PaRes"));
			waitForClickableElement(By.name("CVCRes"));
			waitForClickableElement(By.name("AVSRes"));

			// Simulate Approved response - Postcode and address matched
			dropdown = new Select(getDriver().findElement(By.name("PaRes")));
			dropdown.selectByVisibleText(psPaRes);
			dropdown = new Select(getDriver().findElement(By.name("CVCRes")));
			dropdown.selectByVisibleText(psCVCRes);
			dropdown = new Select(getDriver().findElement(By.name("AVSRes")));
			dropdown.selectByVisibleText(psAVSRes);

		} catch (TimeoutException e) {
			log.error("Timed out waiting for URL: " + getDriver().getCurrentUrl());
			throw new TimeoutException(e);
		}

		// Invoke Next action:
		final By byWorldPayContinueButton = By.xpath("//input[@name='continue']");
		waitForClickableElement(byWorldPayContinueButton);
		// getDriver().findElement(byWorldPayContinueButton).click();
		getDriver().findElement(byWorldPayContinueButton).sendKeys(Keys.ENTER);

		log.debug("going to next page after worldpay");
	}

	public void prReadAndSignCreditAgreement() throws Exception {

		By byChkReadAgreement = By.id("ReadLoanAgreement");

		// // Read and Sign Credit Agreement
		// // ------------------------------
		//
		// // Product Explanation - Read acknowledged
		//
		// // getDriver().findElement(
		// // By.xpath("//a[@href='#agreement-product-explanation']"))
		// // .click();
		//
		// getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).sendKeys(Keys.SPACE);
		//
		// WebElement radReadProductExplanation =
		// getDriver().findElement(By.xpath("//input[@id='ReadProductExplanation']"));
		// // ((JavascriptExecutor)
		// // psWebDriver).executeScript("arguments[0].scrollIntoView(true);",
		// // radReadProductExplanation );
		// // radReadProductExplanation .click();
		// radReadProductExplanation.sendKeys(Keys.SPACE);
		//
		// // Pre-Contract Credit Information
		// // -------------------------------
		//
		// // 1. Contact details - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).sendKeys(Keys.SPACE);
		//
		// // 2. Key features of the credit product - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).sendKeys(Keys.SPACE);
		//
		// // 3. Costs of the credit - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).sendKeys(Keys.SPACE);
		//
		// // 4. Other important legal aspects - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).sendKeys(Keys.SPACE);
		//
		// // 5. Additional information in the case of distance marketing of
		// // financial services - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).sendKeys(Keys.SPACE);
		//
		// // Contractual Terms and Conditions
		// // --------------------------------
		//
		// // 6. Terms and conditions - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).sendKeys(Keys.SPACE);
		//
		// // 7. Marketing - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).sendKeys(Keys.SPACE);
		//
		// // Confirm above sections read
		// //
		// getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).click();
		// getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).sendKeys(Keys.SPACE);
		//
		// // Credit Agreement and E-Signature
		// // Fixed Sum Loan Agreement
		// // --------------------------------
		//
		// // Parties to the Agreement - Contact details - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).sendKeys(Keys.SPACE);
		//
		// // Key features of the credit product - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#key-features']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#key-features']")).sendKeys(Keys.SPACE);
		//
		// // Costs of the credit - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).sendKeys(Keys.SPACE);
		//
		// // Right of withdrawal - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).sendKeys(Keys.SPACE);
		//
		// // Other important information - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).sendKeys(Keys.SPACE);
		//
		// // Terms and conditions - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).sendKeys(Keys.SPACE);
		//
		// // Marketing - Read acknowledged
		// //
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();
		// getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).sendKeys(Keys.SPACE);
		//
		// // Confirm above section read
		// //
		// getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).click();
		// getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).sendKeys(Keys.SPACE);

		// changed since S3, now a single checkbox, select read agreement
		scrollToBottomOfElement(getDriver().findElement(By.cssSelector(".loan-agreement")));
		By bySpanReadLoanAgreement = By.xpath("//span[@data-valmsg-for='ReadLoanAgreement']");

		// checkbox
		getDriver().findElement(byChkReadAgreement).sendKeys(Keys.SPACE);

		// keep trying to select checkbox 3 times until successful
		int retries = 2;
		while (true) {
			try {
				Thread.sleep(500); // needs to wait to allow message to appear
				(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.elementToBeSelected(byChkReadAgreement));
				break;
			} catch (TimeoutException e) {
				log.warn("Didn't click read agreement checkbox successfully, retries: " + retries);
				scrollToBottomOfElement(getDriver().findElement(By.cssSelector(".loan-agreement")));
				getDriver().findElement(byChkReadAgreement).sendKeys(Keys.SPACE);
				if (retries < 1)
					throw e;
			}
			retries--;
		}

		Assert.assertEquals(getDriver().findElement(bySpanReadLoanAgreement).getText(), "");

		// Signature of Customer
		// ---------------------
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gsFirstname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gsSurname);

	}

	public void scrollToBottomOfElement(WebElement element) {
		// scroll div to the bottom, measured 13 key presses to get to the
		// bottom
		for (int i = 0; i < 25; i++) {
			element.sendKeys(Keys.PAGE_DOWN);
		}
	}

	public void prClickForNextAction() throws Exception {

		// Invoke Next action
		// scrollToElement(
		// getDriver().findElement(By.id("ContinueButton")));
		// getDriver().findElement(By.id("ContinueButton")).click();
		takeIncrementScreenshot();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);
	}

	public String fnCaptureCreditAgreementNumber() throws Exception {

		// Capture the agreement number displayed in the Credit Agreement page
		gsPANAgreementNumber = getDriver().findElement(By.xpath("//div[@id='CreditAgreementHeader']/span[2]")).getText();
		log.info("fnCaptureCreditAgreementNumber: Agreement Number> " + gsPANAgreementNumber);
		return gsPANAgreementNumber;
	}

	public void prAssertCreditAgreement() throws Exception {

		// Check agreement content coincides with the customer requested loan
		// application details
		// --------------------------------------------------------------------------------------

		// Check name on agreement

		getDriver().getPageSource().contains(gsTitle + " " + gsFirstname + " " + gsSurname);

		// Product Explanation

		// log.debug(getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).getText());

		// WebElement cellActualRequestedLoanAmount =
		// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[1]/td"));
		WebElement cellActualRequestedLoanAmount = getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)"));
		// String actualRequestedLoanAmount =
		// cellActualRequestedLoanAmount.getText().substring(1,
		// cellActualRequestedLoanAmount.getText().length());
		String actualRequestedLoanAmount = cellActualRequestedLoanAmount.getText();

		// Assert.assertEquals("£ " + gsRequestedLoanAmount + ".00",
		// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[1]/td")).getText());
		// Assert.assertEquals("£ " + gsRequestedLoanAmount + ".00",
		// actualRequestedLoanAmount);
		Assert.assertEquals("£ " + gsRequestedLoanAmount + ".00", actualRequestedLoanAmount);

		// WebElement cellActualTap =
		// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[4]/td"));
		WebElement cellActualTap = getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)"));
		// String actualTap = cellActualTap.getText().substring(1,
		// cellActualTap.getText().length());
		String actualTap = cellActualTap.getText();

		log.debug("Comparing £ " + gsExpectedTAP + " vs " + actualTap);

		Assert.assertEquals("£ " + gsExpectedTAP, actualTap);
		// Assert.assertEquals(" " + gsExpectedTAP, actualTap);

		if (gsRepaymentFrequency.equals("Weekly")) {
			// Assert.assertEquals("£" + gsExpectedRepayment + " each week",
			// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[2]/td")).getText());
			// Assert.assertEquals(gsRequestedTerm + " weeks",
			// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[3]/td")).getText());
			Assert.assertEquals("£" + gsExpectedRepayment + " each week", getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " weeks", getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2)")).getText());
		}
		if (gsRepaymentFrequency.equals("Monthly")) {
			// Assert.assertEquals("£" + gsExpectedRepayment + " each month",
			// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']/table/tbody/tr[2]/td")).getText());
			// Assert.assertEquals(gsRequestedTerm + " months",
			// getDriver().findElement(By.xpath("//div[@id='agreement-product-explanation-content']//table/tbody/tr[3]/td")).getText());
			Assert.assertEquals("£" + gsExpectedRepayment + " each month", getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " months", getDriver().findElement(By.cssSelector(".loan-agreement > div:nth-child(2) > table:nth-child(6) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2)")).getText());
		}

		// 2. Key features of the credit product

		// log.info(getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).getText());
		log.info(getDriver().findElement(By.cssSelector("#agreement-key-features")).getText());

		Assert.assertEquals("£ " + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());
		Assert.assertEquals("£ " + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());
		if (gsRepaymentFrequency.equals("Weekly")) {
			Assert.assertEquals(gsRequestedTerm + " weeks.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " weekly payments of £ " + gsExpectedRepayment + " starting on the first " + gsPreferredPaymentDow + " to follow seven days after the transfer of funds.", getDriver().findElement(By.cssSelector("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());
		}
		if (gsRepaymentFrequency.equals("Monthly")) {
			Assert.assertEquals(gsRequestedTerm + " months.", getDriver().findElement(By.xpath("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " monthly payments of £ " + gsExpectedRepayment + " starting 31 days after the start of the agreement.", getDriver().findElement(By.xpath("#agreement-key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());
		}

		// 3. Costs of the credit

		// log.info(getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).getText());
		log.info(getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit")).getText());

		Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.", getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());
		Assert.assertEquals(gsExpectedAPR + " % APR.", getDriver().findElement(By.cssSelector("#agreement-costs-of-the-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

		// Parties to the Agreement - Contact details

		String sTmp;
		sTmp = "";
		if (gsFlatNumber != null && !gsFlatNumber.isEmpty())
			sTmp = gsFlatNumber;
		if (gsBuildingName != null && !gsBuildingName.isEmpty())
			sTmp = sTmp + " " + gsBuildingName;
		sTmp = sTmp.trim();
		if (gsBuildingNumber != null && !gsBuildingNumber.isEmpty())
			sTmp = sTmp + " " + gsBuildingNumber;
		sTmp = sTmp.trim();
		if (gsStreet != null && !gsStreet.isEmpty())
			sTmp = sTmp + " " + gsStreet;
		sTmp = sTmp.trim();
		if (gsDistrict != null && !gsDistrict.isEmpty())
			sTmp = sTmp + ", " + gsDistrict;
		sTmp = sTmp.trim();
		if (gsTownCity != null && !gsTownCity.isEmpty())
			sTmp = sTmp + ", " + gsTownCity;
		sTmp = sTmp.trim();
		if (gsCounty != null && !gsCounty.isEmpty())
			sTmp = sTmp + ", " + gsCounty;
		sTmp = sTmp.trim();
		if (gsPostcode != null && !gsPostcode.isEmpty())
			sTmp = sTmp + ", " + gsPostcode + ".";
		sTmp = sTmp.trim();
		sTmp = gsTitle + " " + gsFirstname + " " + gsSurname + ",\n" + sTmp;

		Assert.assertEquals(sTmp, getDriver().findElement(By.cssSelector("#agreement-parties-to-agreement > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());

		// Key features of the credit product

		// log.info(getDriver().findElement(By.xpath("//div[@id='accordian-agreement-esig']//a[@href='#key-features']")).getText());
		log.info(getDriver().findElement(By.cssSelector("#key-features")).getText());

		Assert.assertEquals("£ " + gsRequestedLoanAmount + ".00.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());
		if (gsRepaymentFrequency.equals("Weekly")) {
			Assert.assertEquals(gsRequestedTerm + " weeks.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " weekly payments of £ " + gsExpectedRepayment + " starting on the first " + gsPreferredPaymentDow + " to follow seven days after the transfer of funds.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());
		}
		if (gsRepaymentFrequency.equals("Monthly")) {
			Assert.assertEquals(gsRequestedTerm + " months.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(2)")).getText());
			Assert.assertEquals(gsRequestedTerm + " monthly payments of £ " + gsExpectedRepayment + " starting 31 days after the start of the agreement.", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(5) > td:nth-child(2)")).getText());
		}
		Assert.assertEquals("£ " + gsExpectedTAP + ".", getDriver().findElement(By.cssSelector("#key-features > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2)")).getText());

		// Costs of the credit

		Assert.assertEquals("The flat rate of interest is " + gsExpectedFlatRate + " % per annum (fixed). This rate will apply for the duration of the credit agreement. Interest has been pre-calculated and applied at the commencement of the credit agreement.", getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2)")).getText());
		Assert.assertEquals(gsExpectedAPR + " % APR calculated on the assumption that you make all repayments on the agreed dates.", getDriver().findElement(By.cssSelector("#agreement-costs-of-credit > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2)")).getText());

		// Deliberately not checking for daily rate in Right of withdrawal due
		// to Pan possible being ahead on time
		// ========================================================================================================

	}

	@SuppressWarnings("static-access")
	public String fnGetApproxRepaymentDateCalculation(int piWeeklyTerm) throws Exception {

		String sDaySuffix;
		String sRepaymentDate;
		int iSkipWeekend;

		// Get todays date
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());

		int dayOfTheWeek = cal.get(cal.DAY_OF_WEEK);

		log.info("Day: " + dayOfTheWeek);

		// find out difference between today and monday, as end repayment date
		// is on a monday
		switch (dayOfTheWeek) {
		case Calendar.SUNDAY:
			iSkipWeekend = 1;
			break;
		case Calendar.SATURDAY:
			iSkipWeekend = 2;
			break;
		case Calendar.FRIDAY:
			iSkipWeekend = 3;
			break;
		case Calendar.THURSDAY:
			iSkipWeekend = 4;
			break;
		case Calendar.WEDNESDAY:
			iSkipWeekend = 5;
			break;
		case Calendar.TUESDAY:
			iSkipWeekend = 6;
			break;
		case Calendar.MONDAY:
			iSkipWeekend = 0;
			break;
		default: // every other day
			iSkipWeekend = 0;
		}

		cal.add(cal.DAY_OF_MONTH, iSkipWeekend + (piWeeklyTerm * 7));
		int dayOfTheMonth = cal.get(Calendar.DATE);

		log.debug("day of the month " + dayOfTheMonth);

		switch (dayOfTheMonth) {
		case 1:
		case 21:
		case 31:
			sDaySuffix = "st";
			break;
		case 2:
		case 22:
			sDaySuffix = "nd";
			break;
		case 3:
		case 23:
			sDaySuffix = "rd";
			break;
		default:
			sDaySuffix = "th";
			break;
		}

		log.debug("day suffix " + sDaySuffix);

		// sRepaymentDate = new SimpleDateFormat("dd'"+ sDaySuffix
		// +"' MMMM yyyy").format(cal.getTime());
		sRepaymentDate = new SimpleDateFormat("d'" + sDaySuffix + "' MMMM yyyy").format(cal.getTime());
		log.info("fnGetApproxRepaymentDateCalculation: WeeklyTerm=" + piWeeklyTerm + " RepaymentDate=" + sRepaymentDate);
		return (sRepaymentDate);
	}

	public void waitForTitle(WebDriver driver, String title) {
		int i = 1;
		while (!getDriver().getTitle().equals(title)) {
			i++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (i > 10) {
				break;
			}
		}
	}

	public void waitForUrl(String expectedUrl) {
		(new WebDriverWait(getDriver(), PAGE_TIMEOUT)).until(ExpectedConditions.urlToBe(expectedUrl));

	}

	public void waitForTitle(String title) {
		(new WebDriverWait(getDriver(), PAGE_TIMEOUT)).until(ExpectedConditions.titleIs(title));
	}

	public void scrollToElementAndClick(WebDriver driver, WebElement element) {
		scrollToElement(element);
		while (true) {
			try {
				log.info("Trying to click");
				// try to click
				element.click();
				// if clickable go to next step
				break;
			} catch (WebDriverException e) {
				// scroll up if element is not clickable yet
				scrollDown();
			}
		}

	}

	public void scrollToElement(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void scrollUp() {
		log.info("scrolling up");
		((JavascriptExecutor) getDriver()).executeScript("window.scroll(0,-250);");
	}

	public void scrollDown() {
		log.info("scrolling down");
		((JavascriptExecutor) getDriver()).executeScript("window.scroll(0,250);");
	}

	public void sendKeysIfNotNull(WebElement element, String textString) {

		// if entry is not null
		if (textString != null) {
			element.sendKeys(textString);
		} else {
			// otherwise just tab to the next element
			element.sendKeys(Keys.TAB);
		}
	}

	public void prAssertOnPageExistingCustomer(String psSatsumaSiteUrl) throws Exception {

		String sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "existing-customers";

		// Landed on About You page
		log.info("prAssertOnPageAboutYou: Am I on expected landing page url - " + sExpectedPageUrl);

		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void prAssertOnPageWorldPayPaymentCancelled(String psSatsumaSiteUrl) throws Exception {
		Assert.assertEquals(getDriver().findElement(By.xpath("//td[@class='banner']/span")).getText(), "Thank you, your payment has been cancelled.");
		Assert.assertTrue(getDriver().getTitle().contains("Your payment has been cancelled."));

	}

	public void takeScreenshot(String path) {
		try {
			File scrFile = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(path));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForVisibilityOfElement(By by) {
		int retries = 2;
		while (true) {
			try {
				WebDriverWait wait = new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT);
				wait.until(ExpectedConditions.visibilityOf(getDriver().findElement(by)));
				break;
			} catch (StaleElementReferenceException e) {
				log.warn("Found stale element retrying, retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	public void waitForClickableElement(By by) {
		int retries = 2;
		while (true) {
			try {
				WebDriverWait wait = new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT);
				wait.until(ExpectedConditions.elementToBeClickable(getDriver().findElement(by)));
				break;
			} catch (StaleElementReferenceException e) {
				log.warn("Found stale element retrying, retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}

	}

	public void waitForDropdownSelectedText(final By by, final String textToWaitFor) {
		// wait for dropdown to have the right value which we selected, if true
		// returns immediately if false returns after 5 seconds
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getDriver()).withTimeout(5, TimeUnit.SECONDS).pollingEvery(1, TimeUnit.SECONDS).ignoring(TimeoutException.class, StaleElementReferenceException.class);
		wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				return (new Select(driver.findElement(by)).getFirstSelectedOption().getText().equalsIgnoreCase(textToWaitFor));
			}
		});
	}

	public void selectDateAndroidDatePicker(String elementId, String dateValue) {
		((JavascriptExecutor) getDriver()).executeScript("document.getElementById('" + elementId + "').value='" + dateValue + "';");
		log.debug("datepicker set command: document.getElementById('" + elementId + "').value='" + dateValue + "';");
	}

	public void takeIncrementScreenshot() {
		log.debug("Taking screenshot to " + "target/surefire-reports/screenshots/" + testName + "/" + screenshotNumber + ".png");
		takeScreenshot("target/surefire-reports/screenshots/" + testName + "/" + screenshotNumber + ".png");
		screenshotNumber++;
	}

}
