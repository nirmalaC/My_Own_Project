package automation.satsuma.pages;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class SatsumaHome extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	protected String testName;
	protected int screenshotNumber;

	public SatsumaHome(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	// header
	public static final By byImgSatsumaLoansLogo = By.id("satsuma-logo-desktop");
	public static final By byLnkHeaderFAQ = By.id("header-link-faqs");
	public static final By byLnkHeaderContactUs = By.id("header-link-contact-us");
	public static final By byLnkHeaderExistingCustomer = By.id("header-link-existing-customers");

	public static final By byWarningStatement = By.cssSelector("div[class='riskStatement sticky'] div p");
	public static final By byWarningStatementLink = By.cssSelector("div[class='riskStatement sticky'] div p a");

	// main nav
	public static final By byLnkHowOurLoansWork = By.id("mainnav-how-our-loans-work");
	public static final By byLnkLoansExplained = By.id("mainnav-loans-explained");
	public static final By byLnkToolsAndTips = By.id("mainnav-tools-and-tips");
	public static final By byLnkAboutUs = By.id("mainnav-about-us");

	// body
	public static final By byLnk135Years = By.linkText("135 years' experience");
	public static final By byLnkSayYes = By.cssSelector("a[title='Instant Decision']");
	public static final By byLnkPayOutsBetween = By.linkText("pay-outs between 6am-11pm");
	public static final By byLnkManageable = By.linkText("the manageable way");
	public static final By byLnkAmountAgree = By.linkText("amount we agree upfront");
	public static final By byLnkFromAmount = By.linkText("from £100 to £1,000");
	public static final By byLnkPercentOfCustomer = By.linkText("rate us");
	//public static final By byLnkFindOutMore = By.cssSelector("a[class='644']");
	public static final By byLnkFindOutMore = By.xpath("//a[@class='644'][@href='/about-us/']");
	//public static final By byLnkFindOutMore = By.linkText("Find out more about us ");
	public static final By byLnkMoreReasons = By.xpath("//a[@class='644'][@href='/about-us/a-trusted-lender']");
	//public static final By byLnkMoreReasons = By.linkText("Find out more reasons to trust us ");
	public static final By byLnkWeeklyRepayments = By.linkText("weekly repayments");
	public static final By byLnkSeeAllReviews = By.linkText("See all reviews ");

	// footer
	public static final By byLnkFooterHome = By.id("footer-link-home");
	public static final By byLnkFooterCookies = By.id("footer-link-about-our-cookies");
	public static final By byLnkFooterAffiliates = By.id("footer-link-affiliates");
	public static final By byLnkFooterTerms = By.id("footer-link-terms-and-conditions");
	public static final By byLnkFooterAccessibility = By.id("footer-link-accessibility");
	public static final By byLnkFooterSiteMap = By.id("footer-link-sitemap");
	public static final By byLnkFooterPrivacy = By.id("footer-link-privacy");
	public static final By byLnkFooterReadAllFAQs = By.linkText("Read all FAQs");
	
	
	public static final By byLnkContactUsEmail = By.linkText("onlinecustomercare@satsuma-loans.co.uk");
	public static final By byOtherWaysToContactUs = By.linkText("Other ways to contact us ");
	
	

	public void assertComplianceWording() {
		Assert.assertEquals(getDriver().findElement(byWarningStatement).getText(), "Warning: Late repayment can cause you serious money problems. For help, go to moneyadviceservice.org.uk");
		Assert.assertEquals(getDriver().findElement(byWarningStatementLink).getText(), "moneyadviceservice.org.uk");
		Assert.assertEquals(getDriver().findElement(byWarningStatementLink).getAttribute("href"), "https://www.moneyadviceservice.org.uk/");
	}
}
