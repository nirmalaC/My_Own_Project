package automation.satsuma.pages;

public enum ApplicationType {
	B2C, B2B, OBS;
}
