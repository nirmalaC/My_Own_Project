package automation.satsuma.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class SmartCheck extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private String testName;
	private int screenShotNumber;

	public SmartCheck(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public SmartCheck(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public void clickSmartCheckButton() {
		// By bySmartCheckBtn = By.linkText("Try Smart Check now!");
		By bySmartCheckBtn = By.cssSelector(".smartcheck-button");
		scrollToElement(getDriver().findElement(bySmartCheckBtn));
		waitForClickableElement(bySmartCheckBtn);
		getDriver().findElement(bySmartCheckBtn).click();
	}

	// break down fill in pages

	// break down assert on pages

	public void assertOnPageSatsumaSmartCheck(String satsumaSiteUrl) {
		// assert url
		String sExpectedPageUrl = satsumaSiteUrl.toLowerCase() + "smart-check/your-details";
		log.info("prAssertOnPageSmartCheck: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void fillInPageSmartCheckYourDetails() throws InterruptedException {

		// select title from buttons

		getDriver().findElement((By.cssSelector("label[for='"+ gsTitle +"']"))).click();

		// enter firstname surname
		getDriver().findElement(By.id("FirstName")).sendKeys(gsFirstname);
		getDriver().findElement(By.id("LastName")).sendKeys(gsSurname);

		String dob_day = gsDOB.substring(0, 2);
		String dob_month = gsDOB.substring(3, 5);
		String dob_year = gsDOB.substring(6, 10);

		// dob
		new Select(getDriver().findElement(By.id("DateOfBirth_Day"))).selectByVisibleText(dob_day);
		new Select(getDriver().findElement(By.id("DateOfBirth_Month"))).selectByVisibleText(gtb.fn_GetMonthFullWording(dob_month));
		new Select(getDriver().findElement(By.id("DateOfBirth_Year"))).selectByValue(dob_year);

		// fill in address
		enterAddressManually();

		getDriver().findElement(By.id("EmailAddress")).sendKeys(gsEmailAddress);
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(gsMobileNumber);

		selectContactPrefs(Boolean.parseBoolean(gsMarketingOptInEmail), Boolean.parseBoolean(gsMarketingOptInSMS), Boolean.parseBoolean(gsMarketingOptInPost), Boolean.parseBoolean(gsMarketingOptInPhone));

	}

	public void enterAddressManually() {
		scrollToElement(getDriver().findElement(By.id("Addresses_0__Postcode")));
		getDriver().findElement(By.id("Addresses_0__Postcode")).sendKeys(gsPostcode);
		getDriver().findElement(By.id("your-details-enter-address-manually")).click();

		new Select(getDriver().findElement(By.id("ResidencyTypeValue"))).selectByVisibleText(gsResidentialStatus);

		getDriver().findElement(By.id("FlatNumber")).sendKeys(gsFlatNumber);
		getDriver().findElement(By.id("BuildingName")).sendKeys(gsBuildingName);
		getDriver().findElement(By.id("HouseNumber")).sendKeys(gsBuildingNumber);
		getDriver().findElement(By.id("Street")).sendKeys(gsStreet);
		getDriver().findElement(By.id("District")).sendKeys(gsDistrict);
		getDriver().findElement(By.id("TownCity")).sendKeys(gsTownCity);
		getDriver().findElement(By.id("County")).sendKeys(gsCounty);
		getDriver().findElement(By.id("Postcode")).clear();
		getDriver().findElement(By.id("Postcode")).sendKeys(gsPostcode);

		new Select(getDriver().findElement(By.id("Month"))).selectByVisibleText(gtb.fn_GetMonthFullWording(gsCurrentHouseMovedInDate.substring(3, 5)));
		new Select(getDriver().findElement(By.id("Year"))).selectByValue(gsCurrentHouseMovedInDate.substring(6, 10));

		getDriver().findElement(By.id("save-edited-address-btn")).click();
	}

	public void assertOnPageSmartCheckYourFinances(String gsSatsumaSiteUrl) {
		// assert url
		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase() + "smart-check/your-finances";
		log.info("prAssertOnPageSmartCheck: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());

	}

	public void fillInPageSmartCheckYourFinances() {
		getDriver().findElement((By.cssSelector("label[for='"+ gsIncomeFrequency +"']"))).click();

		scrollToElement(getDriver().findElement(By.id("Income")));
		getDriver().findElement(By.id("Income")).sendKeys(gsIncome);

		scrollToElement(getDriver().findElement(By.id("HousingCostsAmount")));
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(gsHousingCosts);

		if (gsHasCreditCards.equals("true"))
			getDriver().findElement(By.cssSelector("label[for='HasCreditCardsYes']")).click();
		else
			getDriver().findElement(By.cssSelector("label[for='HasCreditCardsNo']")).click();

		if (gsHasExistingLoans.equals("true"))
			getDriver().findElement(By.cssSelector("label[for='HasOtherLoansYes']")).click();
		else
			getDriver().findElement(By.cssSelector("label[for='HasOtherLoansNo']")).click();

		getDriver().findElement(By.id("OtherOutgoings")).sendKeys(gsMonthlyOtherOutgoings);

		// check if confirm button appears and click it?
		scrollToElement(getDriver().findElement(By.cssSelector("label[for='HasDependentsYes']")));

		if (Integer.parseInt(gsNumberOfDependants) > 0) {
			getDriver().findElement(By.cssSelector("label[for='HasDependentsYes']")).click();
			if (Integer.parseInt(gsNumberOfDependants) < 3)
				getDriver().findElement(By.cssSelector("label[for='" + gsNumberOfDependants + "']")).click();
			else
				getDriver().findElement(By.cssSelector("label[for='NumberOfDependents3Plus']")).click();
		} else {
			getDriver().findElement(By.cssSelector("label[for='HasDependentsNo']")).click();
		}

		scrollToElement(getDriver().findElement(By.id("IncomeConfirmed")));
		// confirm income
		getDriver().findElement(By.id("IncomeConfirmed")).sendKeys(Keys.SPACE);
	}

	public void assertOnPageSmartCheckDecision(String gsSatsumaSiteUrl) {
		// assert url
		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase() + "smart-check/select-your-loan";
		log.info("prAssertOnPageSmartCheck: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void closePopup() {
		getDriver().findElement(By.cssSelector(".mfp-close")).click();

	}

	public void assertQuoteAmount(String amount) {
		Assert.assertTrue(getDriver().findElement(By.cssSelector(".content")).getText().contains(formatCurrencyToDisplayNoDPNoComma(amount)), "check amount offer is correct");
	}

	// temp function to get button Id
	private String getButtonId() {
		String buttonId = "";
		String tempString = "";
		if (gsRepaymentFrequency.equals("Monthly")) {
			switch (gsRequestedTerm) {
				case "12":
					tempString = "0";
					break;
				case "11":
					tempString = "1";
					break;
				case "10":
					tempString = "2";
					break;
				case "9":
					tempString = "3";
					break;
				case "8":
					tempString = "4";
					break;
				case "7":
					tempString = "5";
					break;
				case "6":
					tempString = "6";
					break;
				case "5":
					tempString = "7";
					break;
				case "4":
					tempString = "8";
					break;
				case "3":
					tempString = "9";
					break;
			}

			buttonId = "btn-view-offer-" + tempString + "-" + gsRequestedLoanAmount + "-" + gsRequestedTerm + "-months";

		} else {
			switch (gsRequestedTerm) {
				case "52":
					tempString = "0";
					break;
				case "47":
					tempString = "1";
					break;
				case "43":
					tempString = "2";
					break;
				case "39":
					tempString = "3";
					break;
				case "34":
					tempString = "4";
					break;
				case "30":
					tempString = "5";
					break;
				case "26":
					tempString = "6";
					break;
				case "21":
					tempString = "7";
					break;
				case "17":
					tempString = "8";
					break;
				case "13":
					tempString = "9";
					break;
			}
			buttonId = "btn-view-offer-" + tempString + "-" + gsRequestedLoanAmount + "-" + gsRequestedTerm + "-weeks";

		}

		return buttonId;
	}

	public void selectLoanAmountAndTerm() throws Exception {
		new Select(getDriver().findElement(By.id("offer__slider__dropdown"))).selectByValue(gsRequestedLoanAmount);

		if (gsRepaymentFrequency.equals("Monthly")) {
			getDriver().findElement(By.id("TermTypeHomeCalcMonthly")).click();
			scrollToElement(getDriver().findElement(By.id(getButtonId())));
			getDriver().findElement(By.id(getButtonId())).click();
		} else if (gsRepaymentFrequency.equals("Weekly")) {
			getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();
			scrollToElement(getDriver().findElement(By.id(getButtonId())));
			getDriver().findElement(By.id(getButtonId())).click();
		} else {
			throw new Exception("Invalid loan frequency" + gsRepaymentFrequency);
		}
	}

	public void assertLoanInfo() {

		String termText = "";
		switch (gsRepaymentFrequency) {
			case "Monthly":
				termText = "month";
				break;
			case "Weekly":
				termText = "week";
				break;
		}

		// assert repayment amount
		Assert.assertEquals(getDriver().findElement(By.id("repayment-amount-display")).getText(), formatCurrency2DP(Float.parseFloat(gsExpectedRepayment)) + " a " + termText);

		// assert rate of interest
		Assert.assertEquals(getDriver().findElement(By.id("interest-display")).getText(), gsExpectedFlatRate + "% p.a. fixed");

		// assert apr
		Assert.assertEquals(getDriver().findElement(By.id("apr-display")).getText(), gsExpectedAPR + "%");

		// assert tap
		Assert.assertEquals(getDriver().findElement(By.id("total-amount-payable-display")).getText(), formatCurrencyNoComma2DP(Float.parseFloat(gsExpectedTAP)));

	}

	public void confirmContinueWithLoan() {
		getDriver().findElement(By.id("AffordableRepaymentsCheckbox")).click();
		getDriver().findElement(By.id("continue-with-loan")).click();
	}

	private String getRandomDOW() {
		String[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

		Random myrand = new Random();

		int i = myrand.nextInt(days.length);

		return days[i];
	}

	public void fillInPageFinalQuestions() {
		String firstRepaymentDate = "";
		String lastRepaymentDate = "";
		String preferredPaymentDay = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if (gsIncomeFrequency.equals("Weekly")) {
			new Select(getDriver().findElement(By.id("WeeklyIncomeDay"))).selectByVisibleText(getRandomDOW());
		} else {
			new Select(getDriver().findElement(By.id("MonthlyIncomeDay"))).selectByVisibleText("1st");
		}

		if (gsRepaymentFrequency.equals("Weekly")) {
			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Weekly", gsPreferredPaymentDow);
			lastRepaymentDate = getLastRepaymentDate("Weekly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDow;
			new Select(getDriver().findElement(By.id("PreferredPaymentDayValue"))).selectByVisibleText(gsPreferredPaymentDow);
		} else {
			firstRepaymentDate = getFirstRepaymentDate(TimeHackHelper.getPanDate(), "Monthly", gsPreferredPaymentDom);
			lastRepaymentDate = getLastRepaymentDate("Monthly", firstRepaymentDate, Integer.parseInt(gsRequestedTerm));
			preferredPaymentDay = gsPreferredPaymentDom;
			new Select(getDriver().findElement(By.id("PreferredPaymentDayValue"))).selectByVisibleText("1st");
		}

		// verify first payment date and last payment date
		By byFirstPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(1)");
		By bySelectedPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(2)");
		By byLastPaymentDateText = By.cssSelector(".frequency-selected__payments p:nth-child(3)");

		waitForRefresh(byFirstPaymentDateText);

		String[] temp = getDriver().findElement(byFirstPaymentDateText).getText().split(" ");
		String actualFirstPaymentDate = null;
		try {
			actualFirstPaymentDate = formatDate(temp[6].substring(0, temp[6].length() - 2) + " " + temp[7] + " " + temp[8], "dd MMMM yyyy", "dd/MM/yyyy");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String actualSelectedPaymentDate = getDriver().findElement(bySelectedPaymentDateText).getText().split(" ")[2];

		temp = getDriver().findElement(byLastPaymentDateText).getText().split(" ");
		String actualLastPaymentDate = null;
		try {
			actualLastPaymentDate = formatDate(temp[6].substring(0, temp[6].length() - 2) + " " + temp[7] + " " + temp[8], "dd MMMM yyyy", "dd/MM/yyyy");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertEquals(actualFirstPaymentDate, firstRepaymentDate);
		Assert.assertEquals(actualSelectedPaymentDate.replace(".", ""), preferredPaymentDay);
		Assert.assertEquals(actualLastPaymentDate, lastRepaymentDate);

		// // verify first payment date and last payment date
		// By byFirstPaymentDateText = By.id("FirstPaymentDateCell");
		//
		// String actualFirstPaymentDate =
		// getDriver().findElement(byFirstPaymentDateText).getText();
		//
		// // format date as on website
		//
		// Date dateFirstRepaymentDate = null;
		// try {
		// dateFirstRepaymentDate = sdf.parse(firstRepaymentDate);
		// } catch (ParseException e) {
		// Assert.fail("date format correct dd/MM/yyyy: " + firstRepaymentDate);
		// }
		// Calendar calFirstRepaymentDate = Calendar.getInstance();
		// calFirstRepaymentDate.setTime(dateFirstRepaymentDate);
		//
		// SimpleDateFormat dateFormatQuote = new
		// SimpleDateFormat("EEEEE 'the' d'%s' 'of' MMMMM yyyy");
		// String strFirstRepaymentDate =
		// String.format(dateFormatQuote.format(calFirstRepaymentDate.getTime()),
		// dateSuffix(calFirstRepaymentDate));
		//
		// Assert.assertEquals(actualFirstPaymentDate, strFirstRepaymentDate);

		getDriver().findElement(By.id("OptInToSummaryOfBorrowingEmail")).click();
	}

	public void assertOnPageFinalQuestions(String satsumaSiteUrl) {
		String sExpectedPageUrl = satsumaSiteUrl.toLowerCase() + "apply-smart-check/apply?key=";
		log.info("prAssertOnPageSmartCheck: Am I on expected landing page url - " + sExpectedPageUrl);
		Assert.assertTrue(getDriver().getCurrentUrl().toLowerCase().contains(sExpectedPageUrl), "verify we are on final steps smart check page");

	}

	@Override
	public void prAssertOnPageBankDetails(String sExpectedUrl) throws Exception {
		takeIncrementScreenshot();
		waitForUrl(sExpectedUrl + "apply-smart-check/bank-details");
		waitForTitle("Bank Details | Satsuma Loans");
		Assert.assertEquals(getDriver().getCurrentUrl(), sExpectedUrl + "apply-smart-check/bank-details");
	}

	@Override
	public void assertOnPageMySatsumaAccount(String sExpectedUrl) {
		takeIncrementScreenshot();
		waitForUrl(sExpectedUrl + "apply-smart-check/agreement");
		waitForTitle("Agreement | Satsuma Loans");
		Assert.assertEquals(getDriver().findElement(byHeaderMySatsuma).getText(), "Your MySatsuma account");
	}

	public void prAssertOnPageCreditAgreement(String psSatsumaSiteUrl) throws Exception {

		By byCreditAgreementHeader = By.cssSelector("[id=loan-agreement-container] .central h1");
		(new WebDriverWait(getDriver(), 180)).until(ExpectedConditions.presenceOfElementLocated(byCreditAgreementHeader));

		Assert.assertEquals(getDriver().findElement(byCreditAgreementHeader).getText(), "And finally...!", "check credit agreement header");

		String sExpectedPageUrl;

		sExpectedPageUrl = psSatsumaSiteUrl.toLowerCase() + "apply-smart-check/agreement";

		// Landed on Credit Agreement page
		log.info("prAssertOnPageCreditAgreement: Am I on expected landing page url - " + sExpectedPageUrl);
		waitForUrl(sExpectedPageUrl);
		Assert.assertEquals(sExpectedPageUrl, getDriver().getCurrentUrl().toLowerCase());
	}

	public void assertOnPageDeclineCreditRefAgencyInfo(String gsSatsumaSiteUrl) {

		String sExpectedPageUrl = gsSatsumaSiteUrl.toLowerCase() + "smart-check/done";
		waitForUrl(sExpectedPageUrl);

		// check header on page
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".container h1")).getText(), "We're really sorry, we can't offer you a loan right now");

		// We use a credit reference agency to help us make our decisions and we
		// can't offer you a loan based on the information they've given us.

	}
}
