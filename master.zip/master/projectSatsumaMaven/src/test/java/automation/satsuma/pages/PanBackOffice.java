package automation.satsuma.pages;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import org.openqa.selenium.JavascriptExecutor;

public class PanBackOffice {

	public static final int EXPLICIT_TIMEOUT = 60;

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	public PanBackOffice() {
	}

	protected int screenshotNumber;

	ThreadLocal<?> threadDriver = null;

	private String testName;

	public PanBackOffice(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public PanBackOffice(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		screenshotNumber = 1;
	}

	public WebDriver getDriver() {
		return (WebDriver) threadDriver.get();
	}

}
