package automation.satsuma.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class TimeHackHelper extends CookBook {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private static String panDate = "";

	protected String testName;
	protected int screenshotNumber;

	public static String getPanDate() {
		return panDate;
	}

	public static void setPanDate(String panDate) {
		TimeHackHelper.panDate = panDate;
	}

	public TimeHackHelper(ThreadLocal<?> threadDriver, String testName) {
		this.threadDriver = threadDriver;
		this.testName = testName;
		int screenshotNumber = 1;
	}

	public void setTimeHack(String satsumaSiteUrl, String dateToSet) {
		try {
			// validate that date is in the right format
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			sdf.parse(dateToSet);
		} catch (ParseException e) {
			Assert.fail("Invalid date " + e.getStackTrace().toString());
		}

		getDriver().get(satsumaSiteUrl + "/development/backend/timehack");
		getDriver().findElement(By.id("baseDate")).sendKeys(dateToSet);
		getDriver().findElement(By.cssSelector("button[class='button primary-button inline']")).click();
		setPanDate(dateToSet);
		log.debug("Set Pan Date to " + dateToSet);
	}
}
