package automation.listeners;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;

public class RetryResultsListener extends TestListenerAdapter {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Override
	public void onFinish(ITestContext context) {
		Iterator<ITestResult> failedTestCases = context.getFailedTests().getAllResults().iterator();
		while (failedTestCases.hasNext()) {

			ITestResult failedTestCase = failedTestCases.next();
			ITestNGMethod method = failedTestCase.getMethod();
			if (context.getFailedTests().getResults(method).size() > 1) {
				log.debug("failed test case remove as dup:" + failedTestCase.getTestClass().toString());
				failedTestCases.remove();
			} else {

				if (context.getPassedTests().getResults(method).size() > 0) {
					log.debug("failed test case remove as pass retry:" + failedTestCase.getTestClass().toString());
					failedTestCases.remove();
				}
			}
		}
	}

	@Override
	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {

		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailure(ITestResult result) {
		if (result.getMethod().getRetryAnalyzer() != null) {
			Retry retry = (Retry) result.getMethod().getRetryAnalyzer();

			if (retry.isRetryAvailable(result)) {
				result.setStatus(ITestResult.SKIP);
			} else {
				result.setStatus(ITestResult.FAILURE);
			}
			Reporter.setCurrentTestResult(result);
		}
	}

	@Override
	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestStart(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestSuccess(ITestResult arg0) {
		// TODO Auto-generated method stub

	}
}
