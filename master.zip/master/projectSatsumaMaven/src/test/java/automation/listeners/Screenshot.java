package automation.listeners;

import java.io.File;
import java.net.URL;

public class Screenshot {
	static final String KEY = "screenshot";

	public Screenshot(File file, URL url, String relativePath) {
		this.file = file;
		this.url = url;
		this.relativePath = relativePath;
	}

	/** File in which is the screenshot stored. */
	private File file;

	/** URL of a web application's page the screenshot captures. */
	private URL url;

	private String relativePath;

	public File getFile() {
		return file;
	}

	public URL getUrl() {
		return url;
	}

	public String getRelativePath() {
		return relativePath;
	}
}
