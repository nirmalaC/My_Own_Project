package automation.listeners;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import org.uncommons.reportng.ReportNGUtils;

public class CustomReportNgUtils extends ReportNGUtils {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Override
	public List<String> getTestOutput(ITestResult testResult) {
		List<String> output = super.getTestOutput(testResult);
		if (testResult.getStatus() == ITestResult.FAILURE) {

		} else if (testResult.getStatus() == ITestResult.SKIP) {

		}

		if (testResult.getAttribute(Screenshot.KEY) != null) {
			Screenshot screenshot = (Screenshot) testResult.getAttribute(Screenshot.KEY);

			if (screenshot != null) {
				if ((screenshot.getFile() != null) && (screenshot.getUrl() != null))
					output.add("<BR>Screenshot with URL: " + screenshot.getUrl().toString() + "<br/><a href='" + "screenshots/" + screenshot.getFile().getName() + "'><img src='" + "screenshots/" + screenshot.getFile().getName() + "' width='200'></>");
			}
		}

		return output;
	}
}
