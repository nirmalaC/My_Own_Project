package automation.basetests;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.ProxySelector;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import automation.satsuma.pages.CookBook;
import automation.satsuma.pages.HomeCredit;
import automation.satsuma.pages.Login;
import automation.satsuma.pages.MakeAPayment;
import automation.satsuma.pages.SatsumaHome;
import automation.satsuma.pages.SmartCheck;
import automation.satsuma.pages.TimeHackHelper;
import automation.tools.ToolBox;

public class BrowserTest extends ScreenshottingTest {
	public static final int IMPLICIT_TIMEOUT = 30;
	public static final int EXPLICIT_TIMEOUT = 60;
	public static final int PAGE_TIMEOUT = 180;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected ThreadLocal<RemoteWebDriver> threadDriver = null;

	protected String gsSatsumaSiteUrl; // Satsuma Site
	protected String gsdbTESTSHEDConnectionString; // TestShed database
													// connection
													// string

	public static ProxySelector defaultProxySelector = null;
	protected String gsCurrentUrl;

	// page objects
	protected CookBook gcb;
	protected HomeCredit hc;
	protected SatsumaHome sHome;
	protected Login login;
	protected MakeAPayment map;
	protected TimeHackHelper timeHack;
	protected SmartCheck smartcheck;
	protected ToolBox gtb = new ToolBox();

	public static String TOKEN_URL;
	public static String ACCOUNT_URL;
	public static String JOURNEY_LINK_FL_URL;
	public static String JOURNEY_LINK_APPLY_URL;
	public static String UPDATE_CONTACT_PREF_URL;
	public static String MOBILE_CONFIG_URL;
	public static String CONTENT_URL;

	public WebDriver getDriver() {
		return threadDriver.get();
	}

	@BeforeSuite
	public final void beforeSuite() {
		log.debug("BeforeSuite: get default proxy selector");
		defaultProxySelector = ProxySelector.getDefault();
	}

	@Parameters("browser")
	@BeforeClass
	public void setUpBeforeClass(@Optional("firefox") String browser) throws Exception {
		// Read config.properties for firefox proxy settings
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		InputStream input = null;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sProxyIP = prop.getProperty("ProxyIP");
		if (sProxyIP.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyIP missing");
		else
			log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);

		sProxyPort = prop.getProperty("ProxyPort");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyPort missing");
		else
			log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);

		sNoProxyOn = prop.getProperty("NoProxyOn");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties NoProxyOn missing");
		else
			log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);

		input.close();

		if (browser != null) {
			if (browser.equalsIgnoreCase("firefox")) {
				// startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
				startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else if (browser.equalsIgnoreCase("chrome")) {
				startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else if (browser.equalsIgnoreCase("ie")) {
				startIEDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else if (browser.equalsIgnoreCase("htmlunit")) {
				startHTMLUnitDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else {
				startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
			}
		} else {
			startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
		}
		// page objects required
		gcb = new CookBook(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		hc = new HomeCredit(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		sHome = new SatsumaHome(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		login = new Login(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		timeHack = new TimeHackHelper(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		map = new MakeAPayment(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		smartcheck = new SmartCheck(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));

		gtb = new ToolBox(threadDriver);

		// driver = ThreadGuard.protect(new FirefoxDriver(profile));
		getDriver().manage().timeouts().implicitlyWait(IMPLICIT_TIMEOUT, TimeUnit.SECONDS);
		getDriver().manage().window().maximize();
		// set page load timeout to 1 min
		getDriver().manage().timeouts().pageLoadTimeout(PAGE_TIMEOUT, TimeUnit.SECONDS);
		getDriver().manage().timeouts().implicitlyWait(IMPLICIT_TIMEOUT, TimeUnit.SECONDS);

		log.warn("Resolution of screen is " + getDriver().manage().window().getSize().getWidth() + " x " + getDriver().manage().window().getSize().getHeight());
		// set page load timeout to 1 min
		getDriver().manage().timeouts().pageLoadTimeout(PAGE_TIMEOUT, TimeUnit.SECONDS);

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");
		gcb.powercurveDB = gcb._getConfigProperty("PowerCurveBPSDB");
		gcb.entityHubDB = gcb._getConfigProperty("EntityHubDB");
		gcb.entitySearchDB = gcb._getConfigProperty("EntitySearchDB");

		String mobileServiceApiUrl = gcb._getConfigProperty("MobileApiUrl");
		String mobileServiceApiVersion = gcb._getConfigProperty("MobileApiVersion");
		log.info("mobile service api url: " + mobileServiceApiUrl);
		log.info("mobile service api version: " + mobileServiceApiVersion);
		TOKEN_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/Token";
		ACCOUNT_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/Account";
		JOURNEY_LINK_FL_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/journeylink/furtherlending";
		JOURNEY_LINK_APPLY_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/journeylink/newbusiness";
		UPDATE_CONTACT_PREF_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/contactpreference";
		MOBILE_CONFIG_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/MobileAppConfig";
		CONTENT_URL = mobileServiceApiUrl + "/" + mobileServiceApiVersion + "/content";

		if (TimeHackHelper.getPanDate().equals("")) {
			int retries = 2;
			while (true) {
				try {
					gcb.fetchPanDate();
					break;
				} catch (Exception e) {
					log.warn("Error whilst trying to fetch pan date");
					log.warn(e.getStackTrace().toString());
					log.warn("Trying again, retries: " + retries);
					if (retries == 0) {
						log.warn("Error whilst trying to fetch pan date, not retrying");
						break;
					}
					retries--;

				}
			}
			timeHack.setTimeHack(gsSatsumaSiteUrl, TimeHackHelper.getPanDate());
		}

	}

	@AfterClass
	public final void tearDownAfterClass() throws Exception {
		// Terminate Browser
		getDriver().manage().deleteAllCookies();
		getDriver().quit();
	}

	public void startChromeDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) throws MalformedURLException {

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		System.setProperty("webdriver.chrome.driver", "c://chromedriver//chromedriver.exe");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		// threadDriver = new ThreadLocal<WebDriver>();
		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				// ProxySelector.setDefault(defaultProxySelector);
				// threadDriver.set(new ChromeDriver(capabilities));
				threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));

				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	public void startFirefoxDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) {

		// Setup Browser with proxy
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", sProxyIP);
		profile.setPreference("network.proxy.http_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.ssl", sProxyIP);
		profile.setPreference("network.proxy.ssl_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);

		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(true);

		// Setup desired capabilities for firefox
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		capabilities.setPlatform(Platform.WINDOWS);
		capabilities.setCapability(FirefoxDriver.PROFILE, profile);
		// capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability("acceptInsecureCerts", true);

		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				// threadDriver.set(new FirefoxDriver(ffBinary, profile));
				try {
					threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
				} catch (MalformedURLException e) {
					log.error("Invalid hub url");
				}
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	public void startGeckoDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) {

		System.setProperty("webdriver.gecko.driver", "c://geckodriver//geckodriver.exe");

		// Setup Browser with proxy
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", sProxyIP);
		profile.setPreference("network.proxy.http_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.ssl", sProxyIP);
		profile.setPreference("network.proxy.ssl_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);

		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(true);

		// Setup desired capabilities for firefox
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		capabilities.setPlatform(Platform.WINDOWS);
		capabilities.setCapability(FirefoxDriver.PROFILE, profile);
		// capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability("acceptInsecureCerts", true);
		capabilities.setCapability("marionette", true);

		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				// threadDriver.set(new FirefoxDriver(ffBinary, profile));
				try {
					threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
				} catch (MalformedURLException e) {
					log.error("Invalid hub url");
				}
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	public void startIEDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) throws MalformedURLException {

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		System.setProperty("webdriver.ie.driver", "C:\\InternetExplorerDriver\\IEDriverServer.exe");

		// threadDriver = new ThreadLocal<WebDriver>();
		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				// ProxySelector.setDefault(defaultProxySelector);
				// threadDriver.set(new InternetExplorerDriver(capabilities));
				threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
				getDriver().manage().window().maximize();
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1)
					throw e;
			}
			retries--;
		}
	}

	protected void startHTMLUnitDriver(String sProxyIP, String sProxyPort, String sNoProxyOn) throws MalformedURLException {
		DesiredCapabilities capabilities = DesiredCapabilities.htmlUnitWithJs();
		capabilities.setJavascriptEnabled(true);
		// threadDriver = new ThreadLocal<WebDriver>();
		threadDriver = new ThreadLocal<RemoteWebDriver>();
		// ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
		// loop to make sure browser opens successfully, allows 3 retries
		int retries = 2;
		while (true) {
			try {
				log.debug("BeforeClass: set default proxy selector before calling webdriver");
				ProxySelector.setDefault(defaultProxySelector);
				threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
				getDriver().manage().window().maximize();
				break;
			} catch (UnreachableBrowserException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1) {
					e.printStackTrace();
					throw e;
				}

			} catch (WebDriverException e) {
				log.warn("Browser startup failed, remaining retries: " + retries);
				if (retries < 1) {
					e.printStackTrace();
					throw e;
				}
			}
			retries--;
		}
	}
}
