package automation.basetests;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;

import org.apache.xmlbeans.XmlException;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import automation.satsuma.pages.ApplicationType;
import automation.tools.PowerCurveDBHelper;
import automation.tools.SatsumaApplicationDatabaseHelper;
import automation.tools.XmlWorkflowGlobalVariables;
import automation.tools.ZoralScoreDatabaseHelper;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.support.SoapUIException;

public class B2BAllMocksOnTest extends BrowserTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected void b2bFurtherLendingLoginDeclineTest(String PAN_CODE, int applicantId) throws Exception, XmlException, IOException, SoapUIException, SQLException {

		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// seed agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		// seed eligible offer
		gcb.seedFLEEligibleOffer(false, 2000d);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// clear history again
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");
	}

	protected void b2bDeclineTest(String PAN_CODE, int applicantId) throws Exception, XmlException, IOException, SoapUIException, SQLException {
		// Data Preparation
		// ================
		// Get a Experian application profile for Bureau result 203 - Applicant
		// Has IVA = btob iva
		gcb.prGetApplicantProfile(applicantId);

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");
	}

	public String b2bAcceptJourney(String gsSatsumaBrokerUrl, boolean registered) throws Exception {

		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(gsSatsumaBrokerUrl);

		// S14 added continue button - Selector doesnt work for now
		By byContinueButton = By.cssSelector("a[class='btn primary-button block center-align show-hide-trigger']");

		gcb.scrollToElement(getDriver().findElement(byContinueButton));
		gcb.waitForVisibilityOfElement(byContinueButton);
		gcb.waitForClickableElement(byContinueButton);
		getDriver().findElement(byContinueButton).click();

		// Check Details on Broker Landing Page

		// Loan Amount & Term
		Assert.assertEquals(getDriver().findElement(By.cssSelector(".loan-amount")).getText(), gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), "loan amount");

		// Loan term
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[1]")).getText(), gcb.gsRequestedTerm + " weeks", "loan term");

		// Interest S4 has changed from total interest to rate of interest
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[4]")).getText(), gcb.gsExpectedFlatRate + "% p.a. fixed", "flat rate interest");

		// TAP
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[5]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), "tap");

		// Weekly Repayment Amount
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[2]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment) + " / week", "weekly repayment amount");

		// APR
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[3]")).getText(), gcb.gsExpectedAPR + "%", "apr");

		// //
		// getDriver().findElement(By.linkText("Continue")).sendKeys(Keys.PAGE_DOWN);
		// gcb.scrollToElement(getDriver().findElement(By.linkText("Continue")));
		//
		// getDriver().findElement(By.linkText("Continue")).click();

		// tab to buttons
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);

		// Firstpayment Day of the week LOV picker

		Select dropdown;

		if (gcb.gsRepaymentFrequency.equals("Weekly")) {

			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
			dropdown.selectByVisibleText("Friday");
			dropdown.selectByVisibleText(gcb.gsPreferredPaymentDow);
			// Validate no more items listed than above - Expect 5 items
			List<WebElement> l = dropdown.getOptions();
			Assert.assertEquals(l.size(), 6);

		} else if (gcb.gsRepaymentFrequency.equals("Monthly")) {

			dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayOfMonthValue")));
			dropdown.selectByVisibleText("2nd");
			dropdown.selectByVisibleText("28th");

		} else {
			log.error("Invalid repayment frequency");
		}

		// get to right position on the page.
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));

		// // DOW now set of buttons
		// getDriver().findElement(By.linkText(gcb.gsPreferredPaymentDow)).click();

		// website cookie policy radio button
		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Complete Details
		// ==================

		// Select the Cookie Radio button
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CookieAccepted")).click();

		// for new customers verify that summary of borrowing email is
		// available
		// and then check it
		By byChkOptInSummaryOfBorrowing = By.id("OptInToSummaryOfBorrowingEmail");

		Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == false, "check summary of borrowing is unchecked");
		getDriver().findElement(byChkOptInSummaryOfBorrowing).click();
		Assert.assertTrue(getDriver().findElement(byChkOptInSummaryOfBorrowing).isSelected() == true, "check summary of borrowing is now checked");

		gcb.selectContactPrefs(Boolean.parseBoolean(gcb.gsMarketingOptInEmail), Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPost), Boolean.parseBoolean(gcb.gsMarketingOptInPhone));

		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// if not an existing customer then
		if (registered == false) {

			gcb.assertOnPageB2BMySatsumaAccount(gsSatsumaSiteUrl);
			gcb.fillInPageMySatsumaAccount("Password1");
		}

		gcb.prAssertOnPageB2BCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		if (!registered) {

			// gcb.prAssertOnPageB2BCompletionIDResult19(gsSatsumaSiteUrl);
			gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);
		} else {
			gcb.prAssertOnPageB2BCompletionIDResult13(gsSatsumaSiteUrl);
		}

		// should add pan verification for agreement in here.
		// gcb.assertFLEESigOffer();

		return sAgreementNumber;
	}

	public String b2bAcceptJourney(String gsSatsumaBrokerUrl) throws Exception {
		return b2bAcceptJourney(gsSatsumaBrokerUrl, false);
	}

	public void verifyPreDipFilterScore(String satsumaApplicationDbServer, String zoralDbServer, String agreementNo, String expectedScore) throws Exception {
		XmlWorkflowGlobalVariables workflowGlobalVariables = new XmlWorkflowGlobalVariables(ZoralScoreDatabaseHelper.getWorkflowGlobalVariablesFromDecisionRef(zoralDbServer, SatsumaApplicationDatabaseHelper.getDecisionReferenceFromAgreement(satsumaApplicationDbServer, agreementNo)));
		DecimalFormat decimalFormat = new DecimalFormat("#.########");
		String preDipFilterScore = decimalFormat.format((Double.valueOf(workflowGlobalVariables.getValue("PreDipFilterScore"))));
		Log.info("PreDipFilterScore: " + preDipFilterScore);
		Assert.assertEquals(preDipFilterScore, expectedScore, "verify pre dip filter score");
	}

	public void verifyPreDipFilterScoreFromDecisionRef(String zoralDbServer, String decisionRef, String expectedScore) throws Exception {
		XmlWorkflowGlobalVariables workflowGlobalVariables = new XmlWorkflowGlobalVariables(ZoralScoreDatabaseHelper.getWorkflowGlobalVariablesFromDecisionRef(zoralDbServer, decisionRef));
		DecimalFormat decimalFormat = new DecimalFormat("#.########");
		String preDipFilterScore = decimalFormat.format((Double.valueOf(workflowGlobalVariables.getValue("PreDipFilterScore"))));
		Log.info("PreDipFilterScore: " + preDipFilterScore);
		Assert.assertEquals(preDipFilterScore, expectedScore, "verify pre dip filter score");
	}

	public void verifyXmlScoreFromDecisionRef(String zoralDbServer, String decisionRef, String expectedScore) throws Exception {
		XmlWorkflowGlobalVariables workflowGlobalVariables = new XmlWorkflowGlobalVariables(ZoralScoreDatabaseHelper.getWorkflowGlobalVariablesFromDecisionRef(zoralDbServer, decisionRef));
		DecimalFormat decimalFormat = new DecimalFormat("#.#######");
		String xmlScore = decimalFormat.format((Double.valueOf(workflowGlobalVariables.getValue("XmlScore"))));
		Log.info("XmlScore: " + xmlScore);
		Assert.assertEquals(xmlScore, expectedScore, "verify xml score");
	}

	public String preDipScoreBrokerLeadSoapUi() throws XmlException, IOException, SoapUIException, SQLException, Exception {
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30708_Satsuma B2B: Accept Happy Path", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = testCase.getPropertyValue("ptcAPR");
		String sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		String sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.debug("Customer Link: " + gsSatsumaBrokerUrl);
		log.debug("APR is: " + sAPR);
		log.debug("Returned Loan Amount is: " + sLoanAmount);

		return gsSatsumaBrokerUrl;
	}

	public String preDipScoreBrokerSomeNullLeadSoapUi() throws XmlException, IOException, SoapUIException, SQLException, Exception {
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30708_Satsuma B2B: Accept But Some Nulls", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = testCase.getPropertyValue("ptcAPR");
		String sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		String sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.debug("Customer Link: " + gsSatsumaBrokerUrl);
		log.debug("APR is: " + sAPR);
		log.debug("Returned Loan Amount is: " + sLoanAmount);

		return gsSatsumaBrokerUrl;
	}

	public String extractDipIdFromLink(String link) {
		// https://satzorapp6.ho.pfgroup.provfin.com/referral/start?key=fc7cf8a5-ab4e-451e-938b-8fa45fa1460f&red=1&ref=aspire_xml&affid=0&cmpid=affiliate-aspire_xml-aspire_xml-xml_proof&dipId=7c899b9c-0b5f-e611-88f8-005056ae561b
		String dipId = link.substring(link.indexOf("dipId=") + 6);
		return dipId;

	}
}
