package automation.basetests;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import automation.satsuma.pages.ApplicationType;
import automation.satsuma.pages.TimeHackHelper;
import automation.test.offerservice.enums.OfferPartyStatus;
import automation.tools.PowerCurveDBHelper;

public class SmartCheckBaseTest extends PageValidationTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {
		getDriver().manage().deleteAllCookies();
		getDriver().get(gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to smart check
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// check on home page
		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		// click on smart check button
		smartcheck.clickSmartCheckButton();

		smartcheck.assertOnPageSatsumaSmartCheck(gsSatsumaSiteUrl);

	}

	@AfterMethod
	public void tearDown() throws Exception {
	}

	public void newCustFLEDeclineTest(int applicantId, String pancode, String sourceV2) throws Exception {

		smartcheck.prGetApplicantProfile(applicantId);

		smartcheck.prCreateUniquePerson();

		smartcheck.seedFLEIneligibleOffer(sourceV2, OfferPartyStatus.OTHER, false);

		smartcheck.fillInPageSmartCheckYourDetails();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckYourFinances(gsSatsumaSiteUrl);

		smartcheck.fillInPageSmartCheckYourFinances();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageDeclineCreditRefAgencyInfo(gsSatsumaSiteUrl);

		// // Log into PanCredit Front Office
		// gcb.prLogIntoPanCreditFrontOffice();
		//
		// gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(smartcheck.gsFirstname,
		// smartcheck.gsSurname, "*", "AutoDel" + smartcheck.gsSurname);
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
		// "Decision Rejected");
		//
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
		// "Queue Rejected Agreements");
		// //
		// Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));
		// Assert.assertTrue(getDriver().getPageSource().contains(pancode));
		//
		// // Log out of PanCredit Front Office
		// gcb.prLogoutFromPanCreditFrontOffice();

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode + sourceV2, ApplicationType.B2C), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode + sourceV2, ApplicationType.B2C), "Group Code");

	}

	public void newCustPCOAtBankDeclineTest(int applicantId, String pancode) throws Exception {

		smartcheck.prGetApplicantProfile(applicantId);

		// smartcheck.prCreateUniquePerson();
		smartcheck.setRandomDOB();
		smartcheck.setRandomEmail();

		smartcheck.fillInPageSmartCheckYourDetails();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckYourFinances(gsSatsumaSiteUrl);

		smartcheck.fillInPageSmartCheckYourFinances();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckDecision(gsSatsumaSiteUrl);

		smartcheck.assertQuoteAmount("1000");

		smartcheck.closePopup();

		smartcheck.selectLoanAmountAndTerm();

		smartcheck.prGetACurrentSatsumaLoanCharge(smartcheck.gsRepaymentFrequency, Integer.parseInt(smartcheck.gsRequestedTerm), Integer.parseInt(smartcheck.gsRequestedLoanAmount));

		// wait for continue with loan button to appear
		smartcheck.waitForVisibilityOfElement(By.id("continue-with-loan"));

		smartcheck.assertLoanInfo();

		smartcheck.assertOnPageFinalQuestions(gsSatsumaSiteUrl);

		smartcheck.fillInPageFinalQuestions();

		gcb.prClickForNextAction();

		smartcheck.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		smartcheck.prFillInPageBankDetailsRandom();

		gcb.prClickForNextAction();

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.B2C), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.B2C), "Group Code");

	}

	public void newCustPCODeclineTest(int applicantId, String pancode) throws Exception {

		smartcheck.prGetApplicantProfile(applicantId);

		// smartcheck.prCreateUniquePerson();
		smartcheck.setRandomDOB();
		smartcheck.setRandomEmail();

		smartcheck.fillInPageSmartCheckYourDetails();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckYourFinances(gsSatsumaSiteUrl);

		smartcheck.fillInPageSmartCheckYourFinances();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageDeclineCreditRefAgencyInfo(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, smartcheck.gsFirstname, smartcheck.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.B2C), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.B2C), "Group Code");

	}

	public void NewCustomerTest(int applicantId) throws Exception {

		smartcheck.prGetApplicantProfile(applicantId);

		smartcheck.prCreateUniquePerson();

		smartcheck.fillInPageSmartCheckYourDetails();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckYourFinances(gsSatsumaSiteUrl);

		smartcheck.fillInPageSmartCheckYourFinances();

		gcb.prClickForNextAction();

		smartcheck.assertOnPageSmartCheckDecision(gsSatsumaSiteUrl);

		smartcheck.assertQuoteAmount("1000");

		smartcheck.closePopup();

		smartcheck.selectLoanAmountAndTerm();

		smartcheck.prGetACurrentSatsumaLoanCharge(smartcheck.gsRepaymentFrequency, Integer.parseInt(smartcheck.gsRequestedTerm), Integer.parseInt(smartcheck.gsRequestedLoanAmount));

		// wait for continue with loan button to appear
		smartcheck.waitForVisibilityOfElement(By.id("continue-with-loan"));

		smartcheck.assertLoanInfo();

		smartcheck.confirmContinueWithLoan();

		smartcheck.assertOnPageFinalQuestions(gsSatsumaSiteUrl);

		if ((smartcheck.gsPreferredPaymentDom == null) || (smartcheck.gsPreferredPaymentDom == "")) {
			smartcheck.gsPreferredPaymentDom = "20th";
		}

		smartcheck.fillInPageFinalQuestions();

		gcb.prClickForNextAction();

		smartcheck.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		smartcheck.prFillInPageBankDetailsRandom();

		gcb.prClickForNextAction();

		smartcheck.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		smartcheck.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		smartcheck.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		smartcheck.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		smartcheck.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		smartcheck.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		smartcheck.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result19 in context Great news!
		// Your
		// // Satsuma Loan has been approved (For new customer)
		// gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		if (smartcheck.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, smartcheck.gsRepaymentFrequency, smartcheck.gsRequestedTerm, smartcheck.gsExpectedRepayment,
					smartcheck.gsRequestedLoanAmount, smartcheck.gsExpectedAPR, smartcheck.gsExpectedFlatRate, smartcheck.gsExpectedDailyRate, smartcheck.gsExpectedTAP,
					smartcheck.gsPreferredPaymentDow, smartcheck.gsFirstname, smartcheck.gsSurname, smartcheck.gsMobileNumber, smartcheck.gsEmailAddress, smartcheck.gsStreet, smartcheck.gsPostcode);

		} else if (smartcheck.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
			String expectedStartDate = smartcheck.getScheduleStartDateForMonthly(1, TimeHackHelper.getPanDate());
			String expectedEndDate = smartcheck.getScheduleEndDateForMonthly(expectedStartDate, Integer.parseInt(smartcheck.gsRequestedTerm));
			// get expected date
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, smartcheck.gsRepaymentFrequency, smartcheck.gsRequestedTerm, smartcheck.gsExpectedRepayment,
					smartcheck.gsRequestedLoanAmount, smartcheck.gsExpectedAPR, smartcheck.gsExpectedFlatRate, smartcheck.gsExpectedDailyRate, smartcheck.gsExpectedTAP,
					smartcheck.gsPreferredPaymentDow, smartcheck.gsFirstname, smartcheck.gsSurname, smartcheck.gsMobileNumber, smartcheck.gsEmailAddress, smartcheck.gsStreet, smartcheck.gsPostcode,
					expectedStartDate, expectedEndDate);
		} else {
			Assert.fail("Error invalid frequency");
		}

	}
}
