package automation.basetests;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CAllMocksOnIDVReferralTest extends MySatsumaSliderBarTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public void b2CNewBusinessDecline(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();
		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();
		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// // Abort test if the agreement is not of Rejected status
		// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
		// Assert.fail("Aborted: Agreement not Rejected as expected.");
		// }

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "Invalid: Worst Status in last 6 months" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 403 - CallCredit Bank Account
		// Closed Detected
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
		// "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	public void b2CNewBusinessReferral(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for applicant on Mocked Callcredit test
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();

		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
			log.warn("Agreement " + gcb.gsPANAgreementNumber + " found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		gcb.assertOnPageIDVReferral(gsSatsumaSiteUrl);

		// goes to my satsuma
		gcb.prClickForNextAction();

		gcb.assertOnPageMySatsuma(gsSatsumaSiteUrl);

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	public void b2CFLReferral(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile for applicant on Mocked Callcredit test
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();

		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
			log.warn("Agreement " + gcb.gsPANAgreementNumber + " found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Seed a fully paid up agreement for this person in PAN
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of fully paid agreement for this test failed.");
		}

		gcb.seedFLEEligibleOffer(false, 1000d);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		gcb.prConfirmLVA();

		gcb.prClickForNextAction();
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.EXISTING_NOT_ACTIVE_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		gcb.assertOnPageIDVReferral(gsSatsumaSiteUrl);

		// goes to my satsuma
		gcb.prClickForNextAction();

		gcb.assertOnPageMySatsuma(gsSatsumaSiteUrl);

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription));
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	public void b2CLoginFLReferral(int applicantId, String expectedPanCode, String expectedDescription) throws Exception {
		// seed and register an agreement
		seedSpecifiedRegisterLogin(100f, "52", "Weekly", true, applicantId);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 0f)));

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.selectLoanAndTerm(gcb.gsRequestedLoanAmount, gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow);

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDPNoComma(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow,Boolean.parseBoolean(gcb.gsMarketingOptInEmail),Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		login.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", this.getClass().getName());

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		// login.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		login.assertOnPageIDVReferral(gsSatsumaSiteUrl);

		// theres no continue button displayed on this screen

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertTrue(getDriver().getPageSource().contains(expectedPanCode), "check for code " + expectedPanCode);
		Assert.assertTrue(getDriver().getPageSource().contains(expectedDescription), "check for text " + expectedDescription);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

}
