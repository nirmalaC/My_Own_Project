package automation.basetests;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import automation.dao.CustomerType;
import automation.dao.SatsumaCustomer;
import automation.tests.mobile.rest.RsaPasswordEncoder;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.support.SoapUIException;

public class MobileAPITest extends BrowserTest {

	public static final int NEW_LOAN_MOBILE_CREDIT_SCORE = 80;
	public static final int PAID_UP_LOAN_MOBILE_CREDIT_SCORE = 90;
	public static final int TEMP_ARRANGEMENT_LOAN_MOBILE_CREDIT_SCORE = 50;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected String accessToken;
	protected String refreshToken;
	public SatsumaCustomer satsumaCustomer;
	protected String agreementNumber;
	// String loginUsername = "TwdyVKziIoO@test.com";
	protected String loginPassword = "Password1";
	protected String encodedPassword;

	protected SatsumaCustomer addNewReferredAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueReferredAgreementInPAN(gcb.gsPanCreditServiceServer, "104199");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewReferredMonthlyAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		gcb.gsRepaymentFrequency = "Monthly";
		gcb.gsRequestedLoanAmount = "100";
		gcb.gsRequestedTerm = "12";

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueReferredAgreementInPAN(gcb.gsPanCreditServiceServer, "104199");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addTempArrangementAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueActiveAgreementInArrangementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addTempArrangementMonthlyAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		gcb.gsRepaymentFrequency = "Monthly";
		gcb.gsRequestedLoanAmount = "100";
		gcb.gsRequestedTerm = "12";

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueActiveAgreementInArrangementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addFrozenAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueFrozenAgreementInPAN(gcb.gsPanCreditServiceServer, "90119");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addFrozenMonthlyAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		gcb.gsRepaymentFrequency = "Monthly";
		gcb.gsRequestedLoanAmount = "100";
		gcb.gsRequestedTerm = "12";

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedUniqueFrozenAgreementInPAN(gcb.gsPanCreditServiceServer, "90119");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewAgreement(String amount, String term, String email) throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		gcb.gsRequestedTerm = term;
		gcb.gsEmailAddress = email;
		gcb.gsRequestedLoanAmount = amount;

		// set some default values for loan
		gcb.gsRequestLoanProduct = "Weekly";
		gcb.gsRepaymentFrequency = "Weekly";

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		// set some default values for loan
		gcb.gsRequestedLoanAmount = "500";
		gcb.gsRequestedTerm = "52";
		gcb.gsRequestLoanProduct = "Weekly";
		gcb.gsRepaymentFrequency = "Weekly";

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewMonthlyAgreement(String amount, String term, String email) throws SQLException, XmlException, SoapUIException, IOException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		gcb.gsEmailAddress = email;
		gcb.gsRequestedLoanAmount = amount;
		gcb.gsRequestedTerm = term;

		// set some default values for loan
		gcb.gsRequestLoanProduct = "Monthly";
		gcb.gsRepaymentFrequency = "Monthly";

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewMonthlyAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		// set some default values for loan
		gcb.gsRequestedLoanAmount = "500";
		gcb.gsRequestedTerm = "12";
		gcb.gsRequestLoanProduct = "Monthly";
		gcb.gsRepaymentFrequency = "Monthly";

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewOldMonthlyAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		// set some default values for loan
		gcb.gsRequestedLoanAmount = "500";
		gcb.gsRequestedTerm = "12";
		gcb.gsRequestLoanProduct = "OldMonthly";
		gcb.gsRepaymentFrequency = "OldMonthly";

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	public SatsumaCustomer addNewHalfPaidUpAgreement(String loanAmount, String loanTerm) throws XmlException, SoapUIException, Exception {
		return addNewHalfPaidUpAgreement(loanAmount, loanTerm, "Weekly");
	}

	public SatsumaCustomer addNewHalfPaidUpAgreement(String loanAmount, String loanTerm, String frequency) throws XmlException, SoapUIException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		gcb.gsRequestedLoanAmount = loanAmount;
		gcb.gsRequestedTerm = loanTerm;
		gcb.gsRepaymentFrequency = frequency;

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, loanAmount, loanTerm, frequency);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		float eligibleAmount = gcb.calcEligibleAmount(Float.parseFloat(loanAmount), 995.02f);

		gcb.seedFLEEligibleOffer(false, (double) eligibleAmount);

		log.debug(customer.toString());
		return customer;

	}

	protected SatsumaCustomer addNewHalfPaidUpAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		return addNewHalfPaidUpAgreement("100", "13");
	}

	protected SatsumaCustomer addNewPaidUpAgreement(String loanAmount, String loanTerm) throws XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		gcb.gsRequestedLoanAmount = loanAmount;
		gcb.gsRequestedTerm = loanTerm;

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, loanAmount, loanTerm);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewPaidUpMonthlyAgreement(String loanAmount, String loanTerm) throws XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		gcb.gsRepaymentFrequency = "Monthly";

		gcb.setRandomBankDetails();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, loanAmount, loanTerm, gcb.gsRepaymentFrequency);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		registerAgreement();

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addNewPaidUpAgreement() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		return addNewPaidUpAgreement("100", "13");
	}

	protected SatsumaCustomer addFurtherHalfPaidUpAgreement(String agreementNumber) throws SQLException, XmlException, SoapUIException, IOException, Exception {

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(gcb.gsPanCreditServiceServer, agreementNumber);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	protected SatsumaCustomer addFurtherHalfPaidUpMonthlyAgreement(String agreementNumber) throws SQLException, XmlException, SoapUIException, IOException, Exception {

		gcb.gsRepaymentFrequency = "Monthly";
		gcb.gsRequestedTerm = "12";
		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonFurtherActiveHalfPaidUpLoanInPAN(gcb.gsPanCreditServiceServer, agreementNumber, "100", "12");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		agreementNumber = gcb.gsPANAgreementNumber;
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, agreementNumber);

		log.debug(customer.toString());
		return customer;
	}

	private void registerAgreement() {

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
	}

	public Map<String, String> getStatusMap(String strMockStatus) {
		String[] mockStatuses = strMockStatus.split("\n");
		Map<String, String> mockStatusMap = new HashMap<String, String>();

		for (String mockStatus : mockStatuses) {
			String[] keyValue = mockStatus.split(":");
			mockStatusMap.put(keyValue[0].trim().toLowerCase(), keyValue[1].trim().toLowerCase());
		}
		return mockStatusMap;
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

	}

	@AfterMethod
	public void tearDown() throws Exception {

	}

	protected SatsumaCustomer addB2BAgreement() throws XmlException, SoapUIException, IOException, Exception {
		gcb.prGetApplicantProfile(164);

		// create unique person
		gcb.prCreateUniquePerson();

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = new String("");
		String sLoanAmount;
		String sTAP;

		sAPR = testCase.getPropertyValue("ptcAPR");
		sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================

		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(gsSatsumaBrokerUrl);

		// Check Details on Broker Landing Page
		// Loan Amount & Term
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[1]")).getText(), "£" + gcb.gsRequestedLoanAmount + ".00", "loan amount");

		// Loan term
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[2]")).getText(), gcb.gsRequestedTerm + " weeks", "loan term");

		// Interest
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[4]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), "interest");

		// TAP
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[6]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), "tap");

		// Weekly Repayment Amount
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[3]")).getText(), gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment) + " / week", "weekly repayment amount");

		// APR
		Assert.assertEquals(getDriver().findElement(By.xpath("(//td[@class='prominent'])[5]")).getText(), gcb.gsExpectedAPR + "%", "apr");

		// Firstpayment Day of the week LOV picker

		// What will you use your loan for?
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Monday");
		dropdown.selectByVisibleText("Tuesday");
		dropdown.selectByVisibleText("Wednesday");
		dropdown.selectByVisibleText("Thursday");
		dropdown.selectByVisibleText("Friday");

		// Validate no more items listed than above - Expect 9 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(6, l.size());

		// website cookie policy radio button

		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Select preferred payment date & check the website cookie policy
		// button
		dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// Complete Details
		// ==================

		// Select the Cookie Radio button
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("CookieAccepted")).click();

		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageB2BCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		gcb.prAssertOnPageB2BCompletionIDResult19(gsSatsumaSiteUrl);

		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber);
		registerAgreement();
		return customer;
	}

	// public void newCustomerAccept(String psLoanAmount, String psLoanTerm,
	// String psRepaymentFrequency, int applicantProfileId) throws Exception {
	//
	// setupTest();
	// // Data Preparation
	// // ================
	// gcb.prGetApplicantProfile(applicantProfileId);
	// gcb.prCreateUniquePerson();
	// // Overwrite applicant profile requested loan terms
	// gcb.gsRequestedLoanAmount = psLoanAmount;
	// gcb.gsRequestedTerm = psLoanTerm;
	// gcb.gsRepaymentFrequency = psRepaymentFrequency;
	// newCustomerAccept();
	// }

	public SatsumaCustomer newCustomerAccept(int applicantProfileId) throws Exception {
		setupTest();
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantProfileId);
		gcb.prCreateUniquePerson();
		return newCustomerAccept();
	}

	public SatsumaCustomer newCustomerAccept(String creditCardNo, String creditCardExpiry, String creditCardType, String creditCardCVS, int applicantProfileId) throws Exception {
		setupTest();
		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(applicantProfileId);
		gcb.prCreateUniquePerson();
		gcb.gsCreditCardNumber = creditCardNo;
		gcb.gsCreditCardExpiryDate = creditCardExpiry;
		gcb.gsCreditCardCVS = creditCardCVS;
		gcb.gsCreditCardType = creditCardType;
		return newCustomerAccept();
	}

	public SatsumaCustomer newCustomerAccept() throws Exception {

		String sAgreementNumber;

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============
		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		SatsumaCustomer customer = gcb.prSOAPUIGetCustomerDetailsFromAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber);
		return customer;
	}

	public void setupTest() throws Exception {
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		final By byBtnStartYourApplication = By.linkText("Start your application");
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
		// Invoke Next action: Start your application
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.ENTER);

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

	}

}
