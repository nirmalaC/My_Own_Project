package automation.basetests;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import automation.dao.CustomerType;
import automation.satsuma.pages.ApplicationType;
import automation.satsuma.pages.CookBook;
import automation.satsuma.pages.HomeCredit;
import automation.satsuma.pages.Login;
import automation.satsuma.pages.OutboundSales;
import automation.satsuma.pages.SatsumaHome;
import automation.satsuma.pages.TimeHackHelper;
import automation.tools.OutboundSalesHelper;
import automation.tools.PowerCurveDBHelper;

public class AllMocksOnOutboundTest extends BrowserTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	protected OutboundSales outbound;

	@Override
	public WebDriver getDriver() {
		return threadDriver.get();
	}

	@Override
	@Parameters("browser")
	@BeforeClass
	public void setUpBeforeClass(@Optional("chrome") String browser) throws Exception {

		// Read config.properties for firefox proxy settings
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		InputStream input = null;
		String sZoralAppServerStatusUrl;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sProxyIP = prop.getProperty("ProxyIP");
		if (sProxyIP.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyIP missing");
		else
			log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);

		sProxyPort = prop.getProperty("ProxyPort");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyPort missing");
		else
			log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);

		sNoProxyOn = prop.getProperty("NoProxyOn");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties NoProxyOn missing");
		else
			log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);

		sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
		if (sZoralAppServerStatusUrl.isEmpty())
			Assert.fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
		else
			log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" + sZoralAppServerStatusUrl);

		input.close();

		if (browser != null) {
			if (browser.equalsIgnoreCase("firefox")) {
				// startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
				startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else if (browser.equalsIgnoreCase("chrome")) {
				startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else if (browser.equalsIgnoreCase("ie")) {
				startIEDriver(sProxyIP, sProxyPort, sNoProxyOn);
			} else {
				startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
			}
		} else {
			startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
		}

		// page objects required
		gcb = new CookBook(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		hc = new HomeCredit(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		sHome = new SatsumaHome(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		login = new Login(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		outbound = new OutboundSales(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));
		timeHack = new TimeHackHelper(threadDriver, this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".") + 1));

		gsSatsumaSiteUrl = gcb._getConfigProperty("OutboundSalesServer");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");
		gcb.powercurveDB = gcb._getConfigProperty("PowerCurveBPSDB");
		gcb.entityHubDB = gcb._getConfigProperty("EntityHubDB");
		gcb.entitySearchDB = gcb._getConfigProperty("EntitySearchDB");

		// driver = ThreadGuard.protect(new FirefoxDriver(profile));
		getDriver().manage().timeouts().implicitlyWait(IMPLICIT_TIMEOUT, TimeUnit.SECONDS);
		// getDriver().manage().window().maximize();
		// set page load timeout to 1 min
		getDriver().manage().timeouts().pageLoadTimeout(PAGE_TIMEOUT, TimeUnit.SECONDS);

		if (TimeHackHelper.getPanDate().equals("")) {
			int retries = 2;
			while (true) {
				try {
					gcb.fetchPanDate();
					break;
				} catch (Exception e) {
					log.warn("Error whilst trying to fetch pan date");
					log.warn(e.getStackTrace().toString());
					log.warn("Trying again, retries: " + retries);
					if (retries == 0) {
						log.warn("Error whilst trying to fetch pan date, not retrying");
						break;
					}
					retries--;

				}
			}
			timeHack.setTimeHack(gsSatsumaSiteUrl, TimeHackHelper.getPanDate());
		}

	}

	public Map<String, String> getStatusMap(String strMockStatus) {
		String[] mockStatuses = strMockStatus.split("\n");
		Map<String, String> mockStatusMap = new HashMap<String, String>();

		for (String mockStatus : mockStatuses) {
			String[] keyValue = mockStatus.split(":");
			mockStatusMap.put(keyValue[0].trim().toLowerCase(), keyValue[1].trim().toLowerCase());
		}
		return mockStatusMap;
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		outbound.setOutboundSalesServer(gcb._getConfigProperty("OutboundSalesServer"));
		outbound.setOutboundSalesUrl(outbound.getOutboundSalesServer() + "/sales");

		gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");

		gcb.entityHubDB = gcb._getConfigProperty("EntityHubDB");
		gcb.entitySearchDB = gcb._getConfigProperty("EntitySearchDB");
		gcb.monthlyOff = gcb._getConfigProperty("MonthlyOff");
		gcb.powercurveDB = gcb._getConfigProperty("PowerCurveBPSDB");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);
	}

	@AfterMethod
	public void tearDown() throws Exception {

		// Disconnect from TestShed database
	}

	public void ObsLoginReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(OUTBOUND_URL + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

		gcb.seedFLEEligibleOffer(false, 2000d);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		outbound.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");

	}

	public void ObsIDVLoginReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(OUTBOUND_URL + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

		gcb.seedFLEEligibleOffer(false, 2000d);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		outbound.prAssertOnPageCompletionIDResult20(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");

	}

	public void ObsIDVFLReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		gcb.seedFLEEligibleOffer(false, 2000d);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		outbound.prAssertOnPageCompletionIDResult20(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");
	}

	public void ObsFLReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		gcb.seedFLEEligibleOffer(false, 2000d);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		outbound.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");
	}

	public void ObsNbReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		// referral page expected
		outbound.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");
	}

	public void ObsIDVNbReferralTest(String pancode, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		// referral page expected
		outbound.prAssertOnPageCompletionIDResult20(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.OBS), "Group Code");
	}

	public void ObsNbDeclineTest(String PAN_CODE, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		outbound.prAssertOnPageFinishedIDResult25(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Group Code");
	}

	public void ObsLoginDeclineTest(String PAN_CODE, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

		gcb.seedFLEEligibleOffer(false, 2000d);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details

		gcb.prClickForNextAction();

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetails();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		outbound.prAssertOnPageFinishedIDResult25(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Group Code");
	}

	public void ObsNbAtQuoteDeclineTest(String PAN_CODE, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageFinishedIDResult25(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Group Code");
	}

	public void ObsLoginAtQuoteDeclineTest(String PAN_CODE, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		String termFreq = "";
		if (gcb.gsRepaymentFrequency.toLowerCase().equals("weekly"))
			termFreq = "weeks";
		else
			termFreq = "months";
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " " + termFreq);
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageFinishedIDResult25(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Group Code");
	}

	public void ObsFLAtQuoteDeclineTest(String PAN_CODE, int applicantId) throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.setRandomDOB();
		gcb.setRandomEmail();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.prAssertOnPageLoanValueAdjustment(OUTBOUND_URL);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Assert.assertEquals(gcb.gsRequestedLoanAmount,
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		log.warn("Temporarily setting back to requested loan amount and term");
		// -- remove when bug fixed --
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.formatCurrencyToDisplayNoDPNoComma(gcb.gsRequestedLoanAmount));
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		dropdown.selectByVisibleText(gcb.gsRequestedTerm + " weeks");
		// -- remove when bug fixed --

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		gcb.prClickForNextAction();

		outbound.prAssertOnPageFinishedIDResult25(OUTBOUND_URL + "/");

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.OBS), "Group Code");
	}

	public void removeAgreementAndReturnToAboutYou(String agreementNumber) throws Exception {

		// // rename surname to remove agreement from customer
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		// Navigate to the newly created agreement in PAN
		gcb.prNavigateToPANCreditAgreement(agreementNumber);

		// Rename applicant's surname
		gcb.prPANRenameAgreementsApplicantSurname(agreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

		// navigate back to where we were
		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

	}
}
