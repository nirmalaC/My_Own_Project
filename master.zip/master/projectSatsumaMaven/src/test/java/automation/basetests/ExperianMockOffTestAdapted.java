package automation.basetests;


public class ExperianMockOffTestAdapted extends ParameterRenameTest {
	// public static final int IMPLICIT_TIMEOUT = 30;
	// public static final int EXPLICIT_TIMEOUT = 30;
	// public static final int PAGE_TIMEOUT = 180;
	// public final static Logger log = LoggerFactory.getLogger(new
	// Throwable().getStackTrace()[0].getClassName());
	//
	// protected ThreadLocal<RemoteWebDriver> threadDriver = null;
	//
	// protected String gsSatsumaSiteUrl; // Satsuma Site
	// protected String gsdbTESTSHEDConnectionString; // TestShed database
	// // connection
	// // string
	//
	// public static ProxySelector defaultProxySelector = null;
	// protected String gsCurrentUrl;
	//
	// // page objects
	// protected CookBook gcb;
	// protected HomeCredit hc;
	// protected SatsumaHome sHome;
	// protected Login login;
	// protected TimeHackHelper timeHack;
	// protected ToolBox gtb = new ToolBox();
	//
	// public WebDriver getDriver() {
	// return threadDriver.get();
	// }
	//
	// @BeforeSuite
	// public void beforeSuite() {
	// log.debug("BeforeSuite: get default proxy selector");
	// defaultProxySelector = ProxySelector.getDefault();
	// }
	//
	// protected void startChromeDriver(String sProxyIP, String sProxyPort,
	// String sNoProxyOn) throws MalformedURLException {
	//
	// DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	// System.setProperty("webdriver.chrome.driver",
	// "c://chromedriver//chromedriver.exe");
	//
	// // threadDriver = new ThreadLocal<WebDriver>();
	// threadDriver = new ThreadLocal<RemoteWebDriver>();
	// // ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
	// // loop to make sure browser opens successfully, allows 3 retries
	// int retries = 2;
	// while (true) {
	// try {
	// log.debug("BeforeClass: set default proxy selector before calling webdriver");
	// ProxySelector.setDefault(defaultProxySelector);
	// threadDriver.set(new RemoteWebDriver(new
	// URL("http://localhost:4444/wd/hub"), capabilities));
	// // threadDriver.set(new ChromeDriver(capabilities));
	// break;
	// } catch (UnreachableBrowserException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	//
	// } catch (WebDriverException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	// }
	// retries--;
	// }
	// }
	//
	// protected void startFirefoxDriver(String sProxyIP, String sProxyPort,
	// String sNoProxyOn) {
	//
	// // Setup Browser with proxy
	// FirefoxProfile profile = new FirefoxProfile();
	// profile.setPreference("network.proxy.type", 1);
	// profile.setPreference("network.proxy.http", sProxyIP);
	// profile.setPreference("network.proxy.http_port",
	// Integer.parseInt(sProxyPort));
	// profile.setPreference("network.proxy.ssl", sProxyIP);
	// profile.setPreference("network.proxy.ssl_port",
	// Integer.parseInt(sProxyPort));
	// profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
	//
	// // Setup desired capabilities for firefox
	// DesiredCapabilities capabilities = DesiredCapabilities.firefox();
	// capabilities.setBrowserName("firefox");
	// capabilities.setPlatform(Platform.WINDOWS);
	// capabilities.setCapability(FirefoxDriver.PROFILE, profile);
	// // capabilities.setCapability(FirefoxDriver.BINARY, ffBinary);
	//
	// threadDriver = new ThreadLocal<RemoteWebDriver>();
	// // ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
	// // loop to make sure browser opens successfully, allows 3 retries
	// int retries = 2;
	// while (true) {
	// try {
	// log.debug("BeforeClass: set default proxy selector before calling webdriver");
	// ProxySelector.setDefault(defaultProxySelector);
	// // threadDriver.set(new FirefoxDriver(ffBinary, profile));
	// try {
	// threadDriver.set(new RemoteWebDriver(new
	// URL("http://localhost:4444/wd/hub"), capabilities));
	// } catch (MalformedURLException e) {
	// log.error("Invalid hub url");
	// }
	// break;
	// } catch (UnreachableBrowserException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	//
	// } catch (WebDriverException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	// }
	// retries--;
	// }
	// }
	//
	// protected void startIEDriver(String sProxyIP, String sProxyPort, String
	// sNoProxyOn) {
	//
	// DesiredCapabilities capabilities =
	// DesiredCapabilities.internetExplorer();
	// System.setProperty("webdriver.ie.driver",
	// "C:\\InternetExplorerDriver\\IEDriverServer.exe");
	// capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
	// true);
	// capabilities.setCapability("requireWindowFocus", true);
	//
	// // threadDriver = new ThreadLocal<WebDriver>();
	// threadDriver = new ThreadLocal<RemoteWebDriver>();
	// // ProxySelector.setDefault(DefaultProxySelector.DEFAULT_PROXY_SELECTOR);
	// // loop to make sure browser opens successfully, allows 3 retries
	// int retries = 2;
	// while (true) {
	// try {
	// log.debug("BeforeClass: set default proxy selector before calling webdriver");
	// // ProxySelector.setDefault(defaultProxySelector);
	// threadDriver.set(new InternetExplorerDriver(capabilities));
	// // threadDriver.set(new RemoteWebDriver(new
	// // URL("http://localhost:4444/wd/hub"), capabilities));
	//
	// break;
	// } catch (UnreachableBrowserException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	//
	// } catch (WebDriverException e) {
	// log.warn("Browser startup failed, remaining retries: " + retries);
	// if (retries < 1)
	// throw e;
	// }
	// retries--;
	// }
	// }
	//
	// @Parameters({ "browser", "surname" })
	// @BeforeClass
	// public void setUpBeforeClass(@Optional("firefox") String browser,
	// @Optional("") String surname) throws Exception {
	//
	// // Read config.properties for firefox proxy settings
	// Properties prop = new Properties();
	// String sProxyIP;
	// String sProxyPort;
	// String sNoProxyOn;
	// InputStream input = null;
	// String sZoralAppServerStatusUrl;
	//
	// input = new FileInputStream("target/classes/config.properties");
	// // load a properties file
	// prop.load(input);
	//
	// // get the property value
	// sProxyIP = prop.getProperty("ProxyIP");
	// if (sProxyIP.isEmpty())
	// Assert.fail("BeforeClass: config.properties ProxyIP missing");
	// else
	// log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);
	//
	// sProxyPort = prop.getProperty("ProxyPort");
	// if (sProxyPort.isEmpty())
	// Assert.fail("BeforeClass: config.properties ProxyPort missing");
	// else
	// log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);
	//
	// sNoProxyOn = prop.getProperty("NoProxyOn");
	// if (sProxyPort.isEmpty())
	// Assert.fail("BeforeClass: config.properties NoProxyOn missing");
	// else
	// log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);
	//
	// sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
	// if (sZoralAppServerStatusUrl.isEmpty())
	// Assert.fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
	// else
	// log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" +
	// sZoralAppServerStatusUrl);
	//
	// input.close();
	//
	// if (browser != null) {
	// if (browser.equalsIgnoreCase("firefox")) {
	// // startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// } else if (browser.equalsIgnoreCase("chrome")) {
	// startChromeDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// } else if (browser.equalsIgnoreCase("ie")) {
	// startIEDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// } else {
	// startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// }
	// } else {
	// startFirefoxDriver(sProxyIP, sProxyPort, sNoProxyOn);
	// }
	//
	// String className = "";
	// if (!(surname.equalsIgnoreCase(""))) {
	// className =
	// this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".")
	// + 1) + "." + surname;
	// } else {
	// className =
	// this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".")
	// + 1);
	// }
	// // page objects required
	// gcb = new CookBook(threadDriver, className);
	// hc = new HomeCredit(threadDriver, className);
	// sHome = new SatsumaHome(threadDriver, className);
	// login = new Login(threadDriver, className);
	// timeHack = new TimeHackHelper(threadDriver, className);
	//
	// // driver = ThreadGuard.protect(new FirefoxDriver(profile));
	// getDriver().manage().timeouts().implicitlyWait(IMPLICIT_TIMEOUT,
	// TimeUnit.SECONDS);
	// getDriver().manage().window().maximize();
	// // set page load timeout to 1 min
	// getDriver().manage().timeouts().pageLoadTimeout(PAGE_TIMEOUT,
	// TimeUnit.SECONDS);
	//
	// // Check Satsuma mock status - Abort test if inconsistent status found
	// //
	// // Mock Requirements for these tests are
	// // 1. Experian mock : On
	// // 2. CallCredit mock : On
	// // 3. PanCredit mock : Off
	// // 4. Affordability mock: On
	// // 5. Statistical calculations mock: On
	// // 6. CifasService mock: On (if off the test data used could trigger a
	// // Potential Fraud on sortcode bankaccount, if CIFAS database contains
	// // the offending item)
	//
	// getDriver().get(sZoralAppServerStatusUrl);
	//
	// // fetch all the mocks information and put it into a hashmap
	//
	// String strMockStatus =
	// getDriver().findElement(By.xpath("//div[@class='panel-body']//div/ul")).getText();
	// Map<String, String> mockStatusMap = getStatusMap(strMockStatus);
	//
	// Assert.assertEquals("Satsuma services", getDriver().getTitle());
	// // experian mock should be off
	// Assert.assertEquals(mockStatusMap.get("experian mock"), "off",
	// "experian mock");
	// Assert.assertEquals(mockStatusMap.get("callcredit mock"), "on",
	// "callcredit mock");
	// Assert.assertEquals(mockStatusMap.get("statistical calculations mock"),
	// "on", "statistical calculations mock");
	// Assert.assertEquals(mockStatusMap.get("affordability mock"), "on",
	// "affordability mock");
	// Assert.assertEquals(mockStatusMap.get("cifasservice mock"), "on",
	// "cifasservice mock");
	//
	// log.info("Testing against: " +
	// getDriver().findElement(By.cssSelector(".panel-heading > ul:nth-child(1) > li:nth-child(1) > h3:nth-child(1)")).getText()
	// + " " +
	// getDriver().findElement(By.cssSelector(".panel-heading > ul:nth-child(1) > li:nth-child(2) > h3:nth-child(1)")).getText());
	//
	// log.info("WARNING: Automated tests require 301 - Duplicate IP Address Fraud alert suppressed");
	// log.info("INFO: Amend StasumaStandardWebFinalDecisionWorkflow Global Variable <add name='IpCheckMaxAllowedTimes\' value='999999' />");
	//
	// // log.debug("Hashcode of webDriver instance = " +
	// // getDriver().hashCode());
	//
	// gcb.gsPanCreditServiceServer =
	// gcb._getConfigProperty("PanCreditServiceServer");
	//
	// gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
	// gsdbTESTSHEDConnectionString =
	// gcb._getConfigProperty("TestShedDBConnection");
	// gcb.gsSOAPUIProjectFolder =
	// gcb._getConfigProperty("SOAPUIProjectFolder");
	// gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
	//
	// gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
	// gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
	//
	// gcb.applicationDB = gcb._getConfigProperty("ApplicationDB");
	//
	// gcb.entityHubDB = gcb._getConfigProperty("EntityHubDB");
	// gcb.monthlyOff = gcb._getConfigProperty("MonthlyOff");
	//
	// if (TimeHackHelper.getPanDate() != "") {
	// int retries = 2;
	// while (true) {
	// try {
	// gcb.fetchPanDate();
	// break;
	// } catch (Exception e) {
	// log.warn("Error whilst trying to fetch pan date");
	// log.warn(e.getStackTrace().toString());
	// log.warn("Trying again, retries: " + retries);
	// if (retries == 0) {
	// log.warn("Error whilst trying to fetch pan date, not retrying");
	// break;
	// }
	// retries--;
	//
	// }
	// }
	// timeHack.setTimeHack(gsSatsumaSiteUrl, TimeHackHelper.getPanDate());
	// }
	//
	// }
	//
	// public Map<String, String> getStatusMap(String strMockStatus) {
	// String[] mockStatuses = strMockStatus.split("\n");
	// Map<String, String> mockStatusMap = new HashMap<String, String>();
	//
	// for (String mockStatus : mockStatuses) {
	// String[] keyValue = mockStatus.split(":");
	// mockStatusMap.put(keyValue[0].trim().toLowerCase(),
	// keyValue[1].trim().toLowerCase());
	// }
	// return mockStatusMap;
	// }
	//
	// @AfterClass
	// public void tearDownAfterClass() throws Exception {
	// log.debug("Closing browser");
	// // Terminate Browser
	// getDriver().manage().deleteAllCookies();
	// getDriver().quit();
	// }
	//
	// @BeforeMethod
	// public void setUpBefore() throws Exception {
	//
	// getDriver().manage().deleteAllCookies();
	// getDriver().get(this.gsSatsumaSiteUrl +
	// "/development/backend/killsession");
	//
	// int errorCount = 0;
	// while (true) {
	// try {
	// // Goto Satsuma site
	// getDriver().get(gsSatsumaSiteUrl);
	// break; // if successful leave loop
	// } catch (TimeoutException e) {
	// // clear things down
	// getDriver().manage().deleteAllCookies();
	// getDriver().get(this.gsSatsumaSiteUrl +
	// "/development/backend/killsession");
	// if (errorCount > 2) {
	// Assert.fail("Error couldn't load homepage after 3 tries");
	// } else {
	// // warning
	// log.warn("Couldn't load homepage, for some reason trying again, remaining retries: "
	// + (2 - errorCount));
	// }
	// errorCount++;
	// }
	// }
	// // Home page
	// // ==============
	//
	// gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
	// gcb.takeIncrementScreenshot();
	//
	// // Invoke Next action: Apply now
	//
	// final By byBtnApply = By.id("SubmitHomeCalc");
	// final By byBtnStartYourApplication =
	// By.linkText("Start your application");
	//
	// (new WebDriverWait(getDriver(),
	// EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnApply)));
	// (new WebDriverWait(getDriver(),
	// EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnApply)));
	// getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
	// getDriver().findElement(byBtnApply).click();
	//
	// int retryCounter = 0;
	// while (true) {
	// try {
	// (new WebDriverWait(getDriver(),
	// EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
	// break;
	// } catch (NoSuchElementException e) {
	// if (retryCounter > 2)
	// Assert.fail("Couldn't click apply button");
	// log.warn("Couldn't find start you application button, trying again.");
	// getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
	// getDriver().findElement(byBtnApply).click();
	// retryCounter++;
	// }
	// }
	//
	// // Your Application page
	// // =====================
	//
	// gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
	// gcb.takeIncrementScreenshot();
	//
	// (new WebDriverWait(getDriver(),
	// EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
	// // Invoke Next action: Start your application
	// getDriver().findElement(byBtnStartYourApplication).click();
	//
	// // About You page
	// // ==============
	//
	// gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
	// gcb.takeIncrementScreenshot();
	// }
	//
	// @AfterMethod
	// public void tearDown() throws Exception {
	// }
	//
	// /*****************************************************************************************/
	//
	// public void existingCustomerAccepts(String psPaidUpLoanAmount, int
	// applicantId) throws Exception {
	// // Data Preparation
	// // ================
	// // Get a Mocked application profile as template for creating a dynamic
	// // unique person
	// gcb.prGetApplicantProfile(133);
	// existingCustomerAccepts(psPaidUpLoanAmount);
	// }
	//
	// public void existingCustomerAccepts(String psLoanAmount, String
	// psLoanTerm, String psRepaymentFrequency, String psPaidUpLoanAmount, int
	// applicantId) throws Exception {
	// // Data Preparation
	// // ================
	// gcb.prGetApplicantProfile(133);
	// // Overwrite applicant profile requested loan terms
	// gcb.gsRequestedLoanAmount = psLoanAmount;
	// gcb.gsRequestedTerm = psLoanTerm;
	// gcb.gsRepaymentFrequency = psRepaymentFrequency;
	// existingCustomerAccepts(psPaidUpLoanAmount);
	// }
	//
	// public void existingCustomerAccepts(String psPaidUpLoanAmount) throws
	// Exception {
	//
	// String sAgreementNumber = "";
	//
	// // save current loan info temporarily
	// String tempLoanAmount = gcb.gsRequestedLoanAmount;
	//
	// // set data for paid up loan
	// gcb.gsRequestedLoanAmount = psPaidUpLoanAmount;
	// // gcb.gsRequestedTerm = psLoanTerm;
	// // gcb.gsRepaymentFrequency = psRepaymentFrequency;
	//
	// gcb.prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN(gcb.gsPanCreditServiceServer);
	//
	// log.info("Active 50% Paid Up Agreement created: " +
	// gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);
	//
	// // Abort test is data preparation failed
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: Seeding of active 50% paid agreement for this test failed. ");
	// }
	//
	// // reset loan amount
	// gcb.gsRequestedLoanAmount = tempLoanAmount;
	//
	// log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " "
	// + gcb.gsDOB);
	// log.info("INFO: Repricing check for loan term " +
	// gcb.gsRequestedLoanAmount + " " + gcb.gsRequestedTerm + " " +
	// gcb.gsRepaymentFrequency);
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: ?
	// gcb.prClickForNextAction();
	//
	// // Assert that we have landed on the LVA page - Loan Value Adjustment
	// gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);
	//
	// gcb.prConfirmLVA();
	//
	// // Invoke Next action: Next: ? Your Quote if Quick Apply else Your
	// // Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Your Quote page
	// // ==============
	//
	// gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
	//
	// // Assert that quoted offer is representative of requested loan terms
	// gcb.prAssertQuoteOfferAsPerRequest();
	//
	// // Invoke Next action: Next: Bank Details
	// gcb.prClickForNextAction();
	//
	// // Bank Details page
	// // =================
	//
	// gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);
	//
	// // Fill in applicants bank details from the profile
	// gcb.prFillInPageBankDetailsRandom();
	//
	// // Invoke Next action: Next: Payment Details
	// gcb.prClickForNextAction();
	//
	// // WorldPay Test Page
	// // ==================
	//
	// // Fill in applicants card details from the profile and trigger a
	// // Approved response
	// gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved",
	// "Postcode and address matched", gsSatsumaSiteUrl);
	//
	// // Password screen Login Phase 2
	// // =====================
	//
	// // Fill in password box
	// gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
	// gcb.fillInPageMySatsumaAccount("Password1");
	//
	// // Credit Agreement page
	// // ======================
	//
	// // (new WebDriverWait(getDriver(),
	// //
	// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));
	//
	// gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);
	//
	// // Read and Sign the Credit Agreement
	// gcb.prReadAndSignCreditAgreement();
	//
	// // Capture Agreement Number from the Credit Agreement page
	// sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
	//
	// // Assert key content of the credit agreement page to ensure that
	// // details corresponds to the applicants loan request and personal
	// // details
	// gcb.prAssertCreditAgreement();
	//
	// // Invoke Next action: Next: Complete Your Agreement
	// gcb.prClickForNextAction();
	//
	// // Completion page - changed for login phase 2
	// // ===============
	//
	// gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);
	//
	// // // Landed on completion page type Result13 in context Great news!
	// // Your
	// // // next Satsuma Loan has been approved (For existing customer)
	// // gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);
	//
	// // Assert that the agreement is created in PANCredit as per the
	// // applicant's requested/quoted details
	// //
	// =================================================================================================
	//
	// gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer,
	// sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm,
	// gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR,
	// gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
	// gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname,
	// gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	//
	// }
	//
	// // public void newCustomerQuoteVerifyDownsell(String psLoanAmount, String
	// // psLoanTerm, String psRepaymentFrequency, int applicantProfileId,
	// boolean
	// // expectedAccept) throws Exception {
	// //
	// // gcb.gsRequestedLoanAmount = psLoanAmount;
	// // gcb.gsRequestedTerm = psLoanTerm;
	// // gcb.gsRepaymentFrequency = psRepaymentFrequency;
	// //
	// // String expectedRTScore =
	// // ExperianDataHelper.getExpectedRTScore(gcb.gsFirstname, gcb.gsSurname,
	// // gcb.gsRequestedTerm, gcb.gsRequestedLoanAmount);
	// // String expectedNPScore =
	// // ExperianDataHelper.getExpectedNPScore(gcb.gsFirstname, gcb.gsSurname,
	// // gcb.gsRequestedTerm, gcb.gsRequestedLoanAmount);
	// //
	// // log.debug("Expected RT Score: " + expectedRTScore);
	// // log.debug("Expected NP Score: " + expectedNPScore);
	// //
	// // int expectedDownsellAmount =
	// // Integer.parseInt(DbTestShedHelper.getDownsellAmount(expectedNPScore,
	// // expectedRTScore, gcb.gsRequestedTerm, gcb.gsRepaymentFrequency));
	// //
	// // Reporter.log("<BR>Expected RT Score: " + expectedRTScore);
	// // Reporter.log("<BR>Excepted NP Score: " + expectedNPScore);
	// // Reporter.log("<BR>Excepted Downsell: " + expectedDownsellAmount);
	// // Reporter.log("<BR>DOB: " + gcb.gsDOB);
	// //
	// // // if (expectedAccept == true)
	// // // newCustomerQuoteVerifyDownsellAccept();
	// // // else
	// // // newCustomerQuoteVerifyDownsellDecline();
	// //
	// // // if decline is expected
	// // if (expectedDownsellAmount == 0) {
	// // newCustomerQuoteVerifyDownsellDecline();
	// //
	// // // else if accept is expected
	// // } else {
	// // newCustomerQuoteVerifyDownsellAccept(expectedDownsellAmount);
	// // }
	// // }
	//
	// public String newCustomerAccept(String psLoanAmount, String psLoanTerm,
	// String psRepaymentFrequency, int applicantProfileId) throws Exception {
	// // Data Preparation
	// // ================
	// // gcb.prGetApplicantProfile(applicantProfileId);
	//
	// // gcb.prCreateUniquePerson();
	// // Overwrite applicant profile requested loan terms
	// gcb.gsRequestedLoanAmount = psLoanAmount;
	// gcb.gsRequestedTerm = psLoanTerm;
	// gcb.gsRepaymentFrequency = psRepaymentFrequency;
	// return newCustomerAccept();
	// }
	//
	// public void newCustomerAccept(int applicantProfileId) throws Exception {
	// // Data Preparation
	// // ================
	// gcb.prGetApplicantProfile(applicantProfileId);
	// gcb.prCreateUniquePerson();
	// newCustomerAccept();
	// }
	//
	// //
	// // public void newCustomerQuoteVerifyDownsellDecline() throws Exception {
	// //
	// // newCustomerQuoteVerifyDownsell();
	// //
	// // try {
	// // // decline page
	// // gcb.prAssertOnPageFinishedIDResult25(gsSatsumaSiteUrl);
	// // } catch (AssertionError e) {
	// //
	// log.warn("Didn't find decline page as expected, checking actual score");
	// //
	// Reporter.log("<BR>Didn't find decline page as expected, checking actual score");
	// // }
	// //
	// // // Find out what the downsell amount should be
	// // // ===========================================
	// //
	// // String decisionRef =
	// //
	// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
	// // gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	// // XmlKnowledgeBase xmlRTScore = new
	// //
	// XmlKnowledgeBase(ZoralScoreDatabaseHelper.getRetuneScoreFromDecisionRef(gcb.zoralDB,
	// // decisionRef));
	// // XmlKnowledgeBase xmlNPScore = new
	// //
	// XmlKnowledgeBase(ZoralScoreDatabaseHelper.getNonPayerScoreFromDecisionRef(gcb.zoralDB,
	// // decisionRef));
	// //
	// // String rtScore =
	// //
	// xmlRTScore.getDoc().getElementsByTagName("Score").item(0).getTextContent();
	// // String npScore =
	// //
	// xmlNPScore.getDoc().getElementsByTagName("Score").item(0).getTextContent();
	// //
	// // log.debug("RT Score: " + rtScore);
	// // log.debug("NP Score: " + npScore);
	// //
	// // int downsellAmount =
	// // Integer.parseInt(DbTestShedHelper.getDownsellAmount(npScore, rtScore,
	// // gcb.gsRequestedTerm, gcb.gsRepaymentFrequency));
	// //
	// // Reporter.log("<BR>Actual RT Score: " + rtScore);
	// // Reporter.log("<BR>Actual NP Score: " + npScore);
	// // Reporter.log("<BR>Actual downsell: " + downsellAmount);
	// //
	// // Assert.assertEquals(downsellAmount, 0,
	// // "check that expected downsell matches actual downsell");
	// //
	// //
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// // gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	// //
	// //
	// gcb.prAssertNewNonBrokeredRejectedAgreement(gcb.gsPanCreditServiceServer,
	// // gcb.gsPANAgreementNumber, gcb.gsRepaymentFrequency,
	// gcb.gsRequestedTerm,
	// // gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR,
	// // gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
	// // gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname,
	// // gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	// //
	// // }
	//
	// public void newCustomerQuoteVerifyDownsellAccept(int expectedDownsell)
	// throws Exception {
	//
	// newCustomerQuoteVerifyDownsell();
	//
	// try {
	// gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
	// } catch (AssertionError e) {
	// log.warn("Didn't find quote page as expected, getting actual score.");
	// Reporter.log("<BR>Didn't find quote page as expected, getting actual score.");
	// }
	//
	// // Find out what the downsell amount should be
	// // ===========================================
	//
	// String decisionRef =
	// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	// String sRTScore =
	// ZoralScoreDatabaseHelper.getRetuneScoreFromDecisionRef(gcb.zoralDB,
	// decisionRef);
	// String sNPScore =
	// ZoralScoreDatabaseHelper.getNonPayerScoreFromDecisionRef(gcb.zoralDB,
	// decisionRef);
	// XmlKnowledgeBase xmlRTScore = new XmlKnowledgeBase();
	// XmlKnowledgeBase xmlNPScore = new XmlKnowledgeBase();
	// if (sRTScore != null) {
	// xmlRTScore = new XmlKnowledgeBase(sRTScore);
	// } else {
	// Assert.fail("RT Score is not found");
	// Reporter.log("<BR>RT score is not found");
	// }
	//
	// if (sNPScore != null) {
	// xmlNPScore = new XmlKnowledgeBase(sNPScore);
	// } else {
	// Assert.fail("RT Score is not found");
	// Reporter.log("<BR>RT score is not found");
	// }
	//
	// String rtScore =
	// xmlRTScore.getDoc().getElementsByTagName("Score").item(0).getTextContent();
	// String npScore =
	// xmlNPScore.getDoc().getElementsByTagName("Score").item(0).getTextContent();
	//
	// log.debug("RT Score: " + rtScore);
	// log.debug("NP Score: " + npScore);
	//
	// int downsellAmount =
	// Integer.parseInt(DbTestShedHelper.getDownsellAmount(npScore, rtScore,
	// gcb.gsRequestedTerm, gcb.gsRepaymentFrequency));
	//
	// Reporter.log("<BR>Actual RT Score: " + rtScore);
	// Reporter.log("<BR>Actual NP Score: " + npScore);
	// Reporter.log("<BR>Actual downsell: " + downsellAmount);
	//
	// // check the downsell is the same as expected
	// Assert.assertEquals(downsellAmount, expectedDownsell,
	// "check that expected downsell matches actual downsell");
	//
	// // If requested amount is less than the downsell amount then proceed as
	// // planned.
	// if (downsellAmount == 0) {// zero means decline
	// log.info("downsell to decline");
	// Assert.fail("Not expected decline aborting test");
	// } else if (Integer.parseInt(gcb.gsRequestedLoanAmount) > downsellAmount)
	// {
	// log.info("downsell to maximum of " + downsellAmount);
	// // fetch the terms and amounts based on what the downsell should be.
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm), downsellAmount);
	// gcb.gsRequestedLoanAmount = Integer.toString(downsellAmount);
	// } else {
	// log.info("No downsell required");
	// }
	// // Assert that quoted offer is representative of requested loan terms
	// gcb.prAssertQuoteOfferAsPerRequest();
	//
	// // Invoke Next action: Next: Bank Details
	// gcb.prClickForNextAction();
	//
	// // Bank Details page
	// // =================
	//
	// gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);
	//
	// // Fill in applicants bank details from the profile
	// gcb.prFillInPageBankDetailsRandom();
	//
	// // Invoke Next action: Next: Payment Details
	// gcb.prClickForNextAction();
	//
	// // WorldPay Test Page
	// // ==================
	//
	// // Fill in applicants card details from the profile and trigger a
	// // Approved response
	// gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved",
	// "Postcode and address matched", gsSatsumaSiteUrl);
	//
	// // Password screen Login Phase 2
	// // =====================
	//
	// // Fill in password box
	// gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
	// gcb.fillInPageMySatsumaAccount("Password1");
	//
	// // Credit Agreement page
	// // ======================
	//
	// // (new WebDriverWait(
	// //
	// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));
	//
	// gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);
	//
	// // Read and Sign the Credit Agreement
	// gcb.prReadAndSignCreditAgreement();
	//
	// // Capture Agreement Number from the Credit Agreement page
	// String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
	//
	// // Assert key content of the credit agreement page to ensure that
	// // details corresponds to the applicants loan request and personal
	// // details
	// gcb.prAssertCreditAgreement();
	//
	// // Invoke Next action: Next: Complete Your Agreement
	// gcb.prClickForNextAction();
	//
	// // Completion page - changed for login phase 2
	// // ===============
	//
	// try {
	// gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);
	// } catch (AssertionError e) {
	// log.warn("My satsuma page was not found.");
	// // don't bother doing subsequent checks
	// return;
	// }
	// // // Landed on completion page type Result19 in context Great news!
	// // Your
	// // // Satsuma Loan has been approved (For new customer)
	// // gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);
	//
	// // Assert that the agreement is created in PANCredit as per the
	// // applicant's requested/quoted details
	// //
	// =================================================================================================
	//
	// if (gcb.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
	// gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer,
	// sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm,
	// gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR,
	// gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
	// gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname,
	// gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	//
	// } else if (gcb.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
	// String expectedStartDate = gcb.getScheduleStartDateForMonthly(1,
	// TimeHackHelper.getPanDate());
	// String expectedEndDate =
	// gcb.getScheduleEndDateForMonthly(expectedStartDate,
	// Integer.parseInt(gcb.gsRequestedTerm));
	// // get expected date
	// gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer,
	// sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm,
	// gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR,
	// gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
	// gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname,
	// gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode,
	// expectedStartDate, expectedEndDate);
	// } else {
	// Assert.fail("Error invalid frequency");
	// }
	//
	// }
	//
	// private void newCustomerQuoteVerifyDownsell() throws Exception {
	//
	// log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " "
	// + gcb.gsDOB);
	//
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// // Assert.fail("Aborted: An agreement is found, trying to remove");
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// gcb.gsLoanPurpose = gcb.getWebLoanPurpose(gcb.gsLoanPurpose);
	//
	// switch (gcb.gsLoanPurpose) {
	// case "Family":
	// gcb.gsLoanPurpose = "Family Occasion";
	// break;
	// case "Home Improvements":
	// gcb.gsLoanPurpose = "Home Improvement";
	// break;
	// case "Personal":
	// gcb.gsLoanPurpose = "Personal Spend";
	// break;
	// }
	//
	// switch (gcb.gsSourceOfIncome) {
	// case "Benefits and Full Time Employment":
	// gcb.gsSourceOfIncome = "Benefits And Full Time Employment";
	// break;
	// case "Benefits and Part Time Employment":
	// gcb.gsSourceOfIncome = "Benefits And Part Time Employment";
	// break;
	// }
	//
	// switch (gcb.gsResidentialStatus) {
	// case "Living with partner":
	// gcb.gsResidentialStatus = "Living With Partner";
	// break;
	// case "Living with Parents":
	// gcb.gsResidentialStatus = "Living With Parents";
	// break;
	// }
	//
	// switch (gcb.gsMaritalStatus) {
	// case "Living with partner":
	// gcb.gsMaritalStatus = "Living With Partner";
	// break;
	// }
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// By byChkAckSummaryOfBorrowing = By.id("SummaryOfBorrowingAcknowledged");
	// By byLblAckSummaryBorrowingPleaseAccept =
	// By.cssSelector("span[for=SummaryOfBorrowingAcknowledged]");
	//
	// try {
	// new WebDriverWait(getDriver(),
	// 2).until(ExpectedConditions.visibilityOfElementLocated(By.id("LoanAmountCell")));
	// } catch (TimeoutException e) {
	// log.warn("Quote page didnt appear, could be CMA bug when removing customer before test, clicking additional checkbox if its there");
	// // see if verify message appears
	// try {
	// new WebDriverWait(getDriver(),
	// 2).until(ExpectedConditions.visibilityOfElementLocated(byLblAckSummaryBorrowingPleaseAccept));
	// // now check it and continue
	// getDriver().findElement(byChkAckSummaryOfBorrowing).click();
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	// } catch (TimeoutException labelTimeout) {
	// log.warn("Didn't find CMA ack label either, continuing test");
	// }
	// }
	//
	// }
	//
	// public String newCustomerAccept() throws Exception {
	//
	// String sAgreementNumber;
	//
	// // // Data Preparation
	// // // ================
	// //
	// // gcb.prGetApplicantProfile(applicantProfileId);
	// // gcb.prCreateUniquePerson();
	// //
	// // // Overwrite applicant profile requested loan terms
	// // gcb.gsRequestedLoanAmount = psLoanAmount;
	// // gcb.gsRequestedTerm = psLoanTerm;
	// // gcb.gsRepaymentFrequency = psRepaymentFrequency;
	//
	// log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " "
	// + gcb.gsDOB);
	// // log.info("INFO: Repricing check for loan term " +
	// // gcb.gsRequestedLoanAmount + " " + gcb.gsRequestedTerm + " " +
	// // gcb.gsRepaymentFrequency);
	//
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
	// " found, please remove and re-try test");
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Your Quote page
	// // ==============
	//
	// gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
	//
	// // Assert that quoted offer is representative of requested loan terms
	// gcb.prAssertQuoteOfferAsPerRequest();
	//
	// // Invoke Next action: Next: Bank Details
	// gcb.prClickForNextAction();
	//
	// // Bank Details page
	// // =================
	//
	// gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);
	//
	// // Fill in applicants bank details from the profile
	// gcb.prFillInPageBankDetailsRandom();
	//
	// // Invoke Next action: Next: Payment Details
	// gcb.prClickForNextAction();
	//
	// // WorldPay Test Page
	// // ==================
	//
	// // Fill in applicants card details from the profile and trigger a
	// // Approved response
	// gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved",
	// "Postcode and address matched", gsSatsumaSiteUrl);
	//
	// // Password screen Login Phase 2
	// // =====================
	//
	// // Fill in password box
	// gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
	// gcb.fillInPageMySatsumaAccount("Password1");
	//
	// // Credit Agreement page
	// // ======================
	//
	// // (new WebDriverWait(
	// //
	// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));
	//
	// gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);
	//
	// // Read and Sign the Credit Agreement
	// gcb.prReadAndSignCreditAgreement();
	//
	// // Capture Agreement Number from the Credit Agreement page
	// sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
	//
	// // Assert key content of the credit agreement page to ensure that
	// // details corresponds to the applicants loan request and personal
	// // details
	// gcb.prAssertCreditAgreement();
	//
	// // Invoke Next action: Next: Complete Your Agreement
	// gcb.prClickForNextAction();
	//
	// // Completion page - changed for login phase 2
	// // ===============
	//
	// gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);
	//
	// // // Landed on completion page type Result19 in context Great news!
	// // Your
	// // // Satsuma Loan has been approved (For new customer)
	// // gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);
	//
	// // Assert that the agreement is created in PANCredit as per the
	// // applicant's requested/quoted details
	// //
	// =================================================================================================
	//
	// gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer,
	// sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm,
	// gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR,
	// gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
	// gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname,
	// gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	// // // rename surname to remove agreement from customer
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	// // Navigate to the newly created agreement in PAN
	// gcb.prNavigateToPANCreditAgreement(sAgreementNumber);
	// // Rename applicant's surname
	// gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	//
	// return sAgreementNumber;
	// }
	//
	// public void removeAgreementAndReturnToAboutYou(String agreementNumber)
	// throws Exception {
	//
	// // // rename surname to remove agreement from customer
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// // Navigate to the newly created agreement in PAN
	// gcb.prNavigateToPANCreditAgreement(agreementNumber);
	//
	// // Rename applicant's surname
	// gcb.prPANRenameAgreementsApplicantSurname(agreementNumber);
	//
	// gcb.prPANCheckNameChanged();
	//
	// gcb.prNavigateToPANHome();
	//
	// gcb.prLogoutFromPanCreditFrontOfficeWithButton();
	//
	// // // Log out of PanCredit Front Office
	// // gcb.prLogoutFromPanCreditFrontOffice();
	//
	// getDriver().manage().deleteAllCookies();
	// getDriver().get(this.gsSatsumaSiteUrl +
	// "/development/backend/killsession");
	// // navigate back to where we were
	// // Goto Satsuma site
	// getDriver().get(this.gsSatsumaSiteUrl);
	//
	// // Home page
	// // ==============
	//
	// gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
	//
	// if (gcb.gsQuickApply.toLowerCase().equals("true")) {
	// // Force navigation for the quick-apply page
	// getDriver().get(this.gsSatsumaSiteUrl + "quick-apply");
	// } else {
	// // Invoke Next action: Apply now
	// getDriver().findElement(By.id("SubmitHomeCalc")).click();
	// }
	// ;
	//
	// // Your Application page
	// // =====================
	//
	// gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
	//
	// // Invoke Next action: Start your application
	// getDriver().findElement(By.linkText("Start your application")).click();
	//
	// // About You page
	// // ==============
	//
	// gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
	//
	// }

}
