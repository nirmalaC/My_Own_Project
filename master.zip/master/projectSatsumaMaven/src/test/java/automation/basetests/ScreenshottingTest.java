package automation.basetests;

import java.io.File;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScreenshottingTest {

	protected ThreadLocal<RemoteWebDriver> threadDriver = null;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public boolean _switchWindowByTitle(String psTitle) throws Exception {

		log.info("_switchWindowByTitle: Parent " + getDriver().getCurrentUrl());
		log.info("_switchWindowByTitle: Attempt to switch to '" + psTitle + "'");

		// String currentWindow = driver.getWindowHandle();
		Set<String> availableWindows = getDriver().getWindowHandles();
		if (!availableWindows.isEmpty()) {
			for (String windowId : availableWindows) {
				if (getDriver().switchTo().window(windowId).getTitle().toLowerCase().contains(psTitle.toLowerCase())) {
					log.info("_switchWindowByTitle: Switched to " + getDriver().getCurrentUrl());
					return true;
				}
			}
		}
		log.info("_switchWindowByTitle: Window not found");
		return false;
	}

	public WebDriver getDriver() {
		return threadDriver.get();
	}

	public void takeScreenshot(String path) {
		try {

			File scrFile = ((TakesScreenshot) (new Augmenter().augment(getDriver()))).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(path));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
