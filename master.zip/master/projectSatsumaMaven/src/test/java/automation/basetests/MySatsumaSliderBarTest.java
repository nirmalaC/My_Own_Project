package automation.basetests;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.support.SoapUIException;

public class MySatsumaSliderBarTest extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private void selectOption(Select dropdown, String optionValue) {
		boolean found = false;
		for (WebElement option : dropdown.getOptions()) {
			if (option.getAttribute("value").equals(optionValue)) {
				option.click();
				found = true;
				break;
			}
		}
		if (!found)
			log.warn("Option " + optionValue + " was not found!");
	}

	public void seedAndRegisterLogin(float originalLoanAmount, String originalLoanTerm, boolean paidUp) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);
		gcb.setRandomBankDetails();
		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, "weekly");
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		float eligibleAmount = gcb.calcEligibleAmount(originalLoanAmount, outstandingAmount);

		gcb.seedFLEEligibleOffer(paidUp, (double) eligibleAmount);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(eligibleAmount));

	}

	public void seedAndRegisterLoginUat(float originalLoanAmount, String originalLoanTerm, boolean paidUp) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);
		gcb.setRandomBankDetails();
		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPANUat(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, "weekly");
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPANUat(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		float eligibleAmount = gcb.calcEligibleAmount(originalLoanAmount, outstandingAmount);

		gcb.seedFLEEligibleOffer(paidUp, (double) eligibleAmount);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(eligibleAmount));

	}

	public void seedSpecifiedRegisterLogin(float originalLoanAmount, String originalLoanTerm, String originalLoanFrequency, boolean paidUp, int applicantId) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomEmail();

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
		gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, originalLoanFrequency);
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			// seeds £100 agreement by default and is not yet configurable
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, originalLoanFrequency);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		float eligibleAmount = gcb.calcEligibleAmount(originalLoanAmount, outstandingAmount);

		gcb.seedFLEEligibleOffer(paidUp, (double) eligibleAmount);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(eligibleAmount));

	}

	public void seedUniqueRegisterLogin(float originalLoanAmount, String originalLoanTerm, boolean paidUp, int applicantId) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, "weekly");
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		float eligibleAmount = gcb.calcEligibleAmount(originalLoanAmount, outstandingAmount);

		gcb.seedFLEEligibleOffer(paidUp, (double) eligibleAmount);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(eligibleAmount));

	}
}
