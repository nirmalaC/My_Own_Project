package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23769_AcceptNewCustomerRepricesTerm43Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice43weeks100() throws Exception {
		newCustomerAccept("100", "43", "Weekly", 133);
	}

	@Test
	public void test_Reprice43weeks900() throws Exception {
		newCustomerAccept("900", "43", "Weekly", 133);
	}

	@Test
	public void test_Reprice43weeks1000() throws Exception {
		newCustomerAccept("1000", "43", "Weekly", 133);
	}

}
