package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnIDVReferralTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline720Referral906ApplicantIsNotVerified extends B2CAllMocksOnIDVReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Applicant Not Verified";
	private static final String EXPECTED_PAN_CODE = "906";
	private static final String EXPECTED_PAN_DECLINE_DESC = "Applicant is not verified";
	private static final String EXPECTED_PAN_DECLINE_CODE = "720";
	private static final int WEEKLY_APPLICANT_ID = 237;
	private static final int NEW_BUS_WEEKLY_APPLICANT_ID = 297;
	private static final int MONTHLY_APPLICANT_ID = 261;
	private static final int NEW_BUS_MONTHLY_APPLICANT_ID = 298;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		b2CNewBusinessDecline(NEW_BUS_WEEKLY_APPLICANT_ID, EXPECTED_PAN_DECLINE_CODE, EXPECTED_PAN_DECLINE_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		b2CNewBusinessDecline(NEW_BUS_MONTHLY_APPLICANT_ID, EXPECTED_PAN_DECLINE_CODE, EXPECTED_PAN_DECLINE_DESC);
	}

	@Test
	public void testB2cFLReferralWeekly() throws Exception {
		b2CFLReferral(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cFLReferralMonthly() throws Exception {
		b2CFLReferral(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cLoginReferralWeekly() throws Exception {
		b2CLoginFLReferral(WEEKLY_APPLICANT_ID, EXPECTED_PAN_DESC, EXPECTED_PAN_CODE);
	}

	@Test
	public void testB2cLoginReferralMonthly() throws Exception {
		b2CLoginFLReferral(MONTHLY_APPLICANT_ID, EXPECTED_PAN_DESC, EXPECTED_PAN_CODE);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();

		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
