package automation.tests.outboundsales;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnOutboundTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.OutboundSalesHelper;

public class TestCase_30835_Outbound_P1_ReferralIncomeVerificationPayslip903 extends AllMocksOnOutboundTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {

		final String OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		// Relies on affordability mocked file with income setting to low
		// outbound otheriv
		gcb.prGetApplicantProfile(289);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

			// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
			// " found, please remove and re-try test");
			log.warn("Agreement " + gcb.gsPANAgreementNumber + " found, trying to remove it");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		outbound.assertOnPageYourFinances(OUTBOUND_URL);

		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		outbound.prAssertOnPageQuote(OUTBOUND_URL);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		outbound.prAssertOnPageBankDetails(OUTBOUND_URL);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Agreement summary page for outbound

		outbound.assertOnPageOutboundAgreementSummary(OUTBOUND_URL);

		outbound.assertOutboundCreditAgreement(gcb.formatCurrencyToDisplay(gcb.gsRequestedLoanAmount), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsExpectedAPR, gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), gcb.gsEmailAddress);

		// complete agreement
		gcb.prClickForNextAction();

		// goes back to about you page for next customer
		outbound.assertOnPageHome(OUTBOUND_URL.replace("https", "http"));

		// wait for two seconds until the email appears in system logging
		// Thread.sleep(2000);

		// get email message from system logging database (uses integrated auth)
		String outboundLink = OutboundSalesHelper.extractUrlFromEmail(gcb._getConfigProperty("SatsumaSiteServer").toUpperCase(), gcb._getConfigProperty("SatsumaAppServer").toUpperCase(), gcb.gsEmailAddress);

		if (outboundLink == null) {
			Assert.fail("Couldn't find outbound link for customer aborting test");
		}

		// Go to customer url
		getDriver().get(outboundLink);

		outbound.assertOnPageOutboundConfirmAgreement(gsSatsumaSiteUrl);

		outbound.fillInPageOutboundConfirmDOBPostcode(gcb.gsDOB, gcb.gsPostcode);

		gcb.prClickForNextAction();

		outbound.assertOnPageOutboundCreditAgreement(gsSatsumaSiteUrl);

		gcb.prAssertCreditAgreement();

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// extra checkbox on credit agreement page versus standard journey
		getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.SPACE);

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		gcb.prClickForNextAction();

		gcb.takeIncrementScreenshot();

		// Payslip page
		// ============

		outbound.prAssertOnPagePayslip(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Continue
		gcb.prClickForNextAction();

		outbound.prAssertOnPageCompletionIDResult16(gsSatsumaSiteUrl);

		// verify income verification in PAN
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Verify Income:Payslip Expected");
		// Expected agreement to also be referred for income verification 903 -
		Assert.assertTrue(getDriver().getPageSource().contains("903"));
		Assert.assertTrue(getDriver().getPageSource().contains("Verify Income: Payslip Expected"));

		// must rename customer for reuse in next test run
		// gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
