package automation.tests.allmockon.testsuite.b2c.validation;

import java.net.ProxySelector;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;
import automation.satsuma.pages.TimeHackHelper;

public class TestCase_13948_PageValidationAboutYou extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		gcb.clickStartYourApplicationRetryIfNeeded();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// select weekly loan page for validation
		getDriver().findElement(By.id("SaysIsExistingCustomerNo")).sendKeys(Keys.TAB);
		// click weekly tab
		getDriver().findElement(By.id("TermTypeAboutYouCalcWeekly")).click();

		// Connect to TestShed database

	}

	public static ProxySelector defaultProxySelector = null;

	@Test
	public void test_PageDefaults() throws Exception {

		// Your Loan section
		// ==================

		// Do you currently have, or have you previously had a Satsuma Loan? -
		// Default is No
		//
		// Check if radio button defaults to No
		Assert.assertTrue(getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected());

		// How much would you like to borrow?
		//
		// Check if £1000 is default value
		String selectedOption = new Select(getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"))).getFirstSelectedOption().getText();
		Assert.assertEquals("£1000", selectedOption);
		//
		// Over
		selectedOption = new Select(getDriver().findElement(By.id("TermAboutYouCalcDropdown"))).getFirstSelectedOption().getText();
		Assert.assertEquals("26 weeks", selectedOption);

		// Loan Calculator Slider - Default loan amount is £1000 within range
		// £100 to £1000 over 26 weeks
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("value"));
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("min"));
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("max"));
		Assert.assertEquals("10", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("step"));

		Assert.assertEquals("3", getDriver().findElement(By.id("TermAboutYouCalc")).getAttribute("value"));
		Assert.assertEquals("0", getDriver().findElement(By.id("TermAboutYouCalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermAboutYouCalc")).getAttribute("max"));
		Assert.assertEquals("1", getDriver().findElement(By.id("TermAboutYouCalc")).getAttribute("step"));

		gcb.prGetACurrentSatsumaLoanCharge("Weekly", 26, 1000);

		// Pricing for £1000 26 weeks - Defaulted correctly
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), getDriver().findElement(By.id("TotalInterestAboutYouCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountAboutYouCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), getDriver().findElement(By.id("TotalAmountAboutYouCalcText")).getText());
		// Assert.assertEquals(gcb.gsExpectedAPR+"%",getDriver().findElement(By.id("AprAboutYouCalcText")).getText());

		// On which day of the week would you like to make your repayments -
		// Default is Please Select
		// is not a dropdown but a set of links to click instead
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// Assert.assertEquals("Please select",
		// dropdown.getFirstSelectedOption().getText());

		// What will you use your loan for - Default is Please Select
		Select dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - Default is Please Select
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// Assert.assertEquals("Please select",
		// dropdown.getFirstSelectedOption().getText());

		// Please read our web-site cookie policy and tick this box to agree -
		// Default is Unticked
		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Personal Details section
		// ========================

		// Applicants Title - Default is Please Select
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// Applicants Firstname - Default is blanked
		Assert.assertEquals("", getDriver().findElement(By.id("Forename")).getText());

		// Applicants Surname - Default is blanked
		Assert.assertEquals("", getDriver().findElement(By.id("Surname")).getText());

		// Applicants DOB - Day - Default is -- Day --
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		Assert.assertEquals("-- Day --", dropdown.getFirstSelectedOption().getText());
		// Applicants DOB - Month - Default is -- Month --
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		Assert.assertEquals("-- Month --", dropdown.getFirstSelectedOption().getText());
		// Applicants DOB - Year - Default is -- Year --
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		Assert.assertEquals("-- Year --", dropdown.getFirstSelectedOption().getText());

		// // Applicants NI Number - Default is blanked
		// Assert.assertEquals("",
		// getDriver().findElement(By.id("NiNumber")).getText());

		// Applicants Marital Status - Default is Please Select
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// Applicants Number Of Dependants - Default is Please Select
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// Your Address
		// ------------

		// Applicants Residential Status - Default is Please Select
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// Applicants Current Address Moved In Month- Default is blanked

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		Assert.assertEquals("-- Month --", dropdown.getFirstSelectedOption().getText());

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		Assert.assertEquals("-- Year --", dropdown.getFirstSelectedOption().getText());

		// Use QAS Search fields - Default is blanked
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).getText());
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).getText(), "");

		// Is address listing dropdown not visible
		Assert.assertFalse(gtb.fn_isElementPresent("CurrentAddress_CurrentAddressChosenAddress"));

		// QAS Search button is enabled
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddressAddressSearch")).isEnabled());
		// Manual address entry link is enabled
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddressManualEntry")).isEnabled());

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - Default is blanked
		Assert.assertEquals(getDriver().findElement(By.id("MobilePhoneNumber")).getText(), "");
		// Applicant Email Address - Default is blanked
		Assert.assertEquals(getDriver().findElement(By.id("EmailAddress")).getText(), "");

		// Marketing options - Default is Unticked
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected());
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected());
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected());
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected());

		// Your Finances bit for quick apply journey

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			// What is your current source of income - Default is Please Select
			dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
			Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

			// What is your regular income amount - Default is blanked
			Assert.assertEquals(getDriver().findElement(By.id("Income")).getText(), "");

			// How often do you receive this regular income - Default is Please
			// Select
			dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
			Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

			// How do you receive this income - Default is Please Select
			dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
			Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

			// What is you monthly rent/mortgage amount - Default is blanked
			Assert.assertEquals(getDriver().findElement(By.id("HousingCostsAmount")).getText(), "");

			// Do you have any Credit Cards - Default is un-ticked both Yes and
			// No
			Assert.assertFalse(getDriver().findElement(By.id("HasCreditCardsYes")).isSelected());
			Assert.assertFalse(getDriver().findElement(By.id("HasCreditCardsNo")).isSelected());

			// Do you have any other loans - Default is un-ticked both Yes and
			// No
			Assert.assertFalse(getDriver().findElement(By.id("HasOtherLoansYes")).isSelected());
			Assert.assertFalse(getDriver().findElement(By.id("HasOtherLoansNo")).isSelected());

			// If yes, what are your monthly loan and credit card repayments? -
			// Default no visible
			Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Excluding the above, what is the value of other significant
			// monthly outgoings - Default is blanked
			Assert.assertEquals(getDriver().findElement(By.id("OtherOutgoingsAmount")).getText(), "");

			// Please tick to confirm your have consented - Defaulted as
			// Un-ticked
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());

			// Check Consent and Use of Personal Information accordian not read
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[1]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[2]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[3]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[4]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[5]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[6]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[7]//a[@class='accordian-trigger']")).isDisplayed());

		}

		// ** End Of Test **
	}

	@Test
	public void test_AvailableLoanPurposeOptions() {

		// Loan Offer section
		// ==================

		// What will you use your loan for?
		Select dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Household Goods");
		dropdown.selectByVisibleText("Home Improvement");
		dropdown.selectByVisibleText("Family Occasion");
		dropdown.selectByVisibleText("Vehicle");
		dropdown.selectByVisibleText("Holiday");
		dropdown.selectByVisibleText("Debt Repayment");
		dropdown.selectByVisibleText("Personal Spend");
		dropdown.selectByVisibleText("Other");
		dropdown.selectByVisibleText("General Living Expenses");

		// Validate no more items listed than above - Expect 9 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(10, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableMaritalStatusOptions() {

		// Loan Offer section
		// ==================

		// What will you use your loan for?
		Select dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Divorced");
		dropdown.selectByVisibleText("Living With Partner");
		dropdown.selectByVisibleText("Married");
		dropdown.selectByVisibleText("Separated");
		dropdown.selectByVisibleText("Single");
		dropdown.selectByVisibleText("Widowed");
		dropdown.selectByVisibleText("Other");

		// Validate no more items listed than above - Expect 7 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(8, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableDaysOfTheWeekOptions() {

		// Your Loan section
		// ==================

		// // On which day of the week would you like to make your repayments?
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Monday");
		dropdown.selectByVisibleText("Tuesday");
		dropdown.selectByVisibleText("Wednesday");
		dropdown.selectByVisibleText("Thursday");
		dropdown.selectByVisibleText("Friday");

		// Validate no more items listed than above - Expect 6 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(5, l.size());

		// // Changed to links instead of dropdown
		//
		// getDriver().findElement(By.id("MinimumLoanValue")).sendKeys(Keys.TAB);
		//
		// getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB,
		// Keys.SHIFT));
		//
		// getDriver().findElement(By.linkText("Monday")).click();
		// getDriver().findElement(By.linkText("Tuesday")).click();
		// getDriver().findElement(By.linkText("Wednesday")).click();
		// getDriver().findElement(By.linkText("Thursday")).click();
		// getDriver().findElement(By.linkText("Friday")).click();
		// ** End Of Test **
	}

	@Test
	public void test_AvailableTitleOptions() {

		// Personal Details
		// ==================

		// Title
		Select dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Mr");
		dropdown.selectByVisibleText("Mrs");
		dropdown.selectByVisibleText("Miss");
		dropdown.selectByVisibleText("Ms");

		// Validate no more items listed than above - Expect 5 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(5, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableNumberOfDependantsOptions() {

		// Personal Details
		// ==================

		// How Many Dependants do you have?
		Select dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("0");
		dropdown.selectByVisibleText("1");
		dropdown.selectByVisibleText("2");
		dropdown.selectByVisibleText("3+");

		// Validate no more items listed than above - Expect 5 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(5, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableResidencyTypeOpti() {

		// Address section
		// ==================

		// What type of accommodation do you live in?
		Select dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Owner Occupier");
		dropdown.selectByVisibleText("Living With Parents");
		dropdown.selectByVisibleText("Tenant Unfurnished");
		dropdown.selectByVisibleText("Tenant Furnished");
		dropdown.selectByVisibleText("Council Tenant");
		dropdown.selectByVisibleText("Joint Owner");
		dropdown.selectByVisibleText("Other");

		// Validate no more items listed than above - Expect 7 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(8, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableMonthsForMovedInDate() {

		// Address section
		// ==================

		// What month did you move into this address
		Select dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText("-- Month --");
		dropdown.selectByVisibleText("January");
		dropdown.selectByVisibleText("February");
		dropdown.selectByVisibleText("March");
		dropdown.selectByVisibleText("April");
		dropdown.selectByVisibleText("May");
		dropdown.selectByVisibleText("June");
		dropdown.selectByVisibleText("July");
		dropdown.selectByVisibleText("August");
		dropdown.selectByVisibleText("September");
		dropdown.selectByVisibleText("October");
		dropdown.selectByVisibleText("November");
		dropdown.selectByVisibleText("December");

		// Validate no more items listed than above - Expect 13 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(13, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableYearsForMovedInDate() throws Exception {

		// Address section
		// ==================

		// What year did you move into this address.
		Select dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText("-- Year --");

		int cnt = 0;
		for (int i = cnt; i > -100; i--) {
			dropdown.selectByVisibleText(gtb.fn_GetYear(i));
			cnt++;
		}

		// Validate no more items listed than above - Expect 102 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(102, l.size());

		// ** End Of Test **
	}

	@Test
	public void test_AvailableSourceOfIncomeOptions() {

		// Your Finances section - for quick apply journey
		// ===============================================

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			log.info("QuickApply - test_AvailableSourceOfIncomeOptions");
			// What is your current source of income?
			Select dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
			dropdown.selectByVisibleText("Please select");
			dropdown.selectByVisibleText("Benefits");
			dropdown.selectByVisibleText("Benefits And Part Time Employment");
			dropdown.selectByVisibleText("Benefits And Full Time Employment");
			dropdown.selectByVisibleText("Part Time Employment Only");
			dropdown.selectByVisibleText("Full Time Employment Only");
			dropdown.selectByVisibleText("Pension");
			dropdown.selectByVisibleText("Self Employed");

			// Validate no more items listed than above - Expect 8 items
			List<WebElement> l = dropdown.getOptions();
			Assert.assertEquals(8, l.size());
		}

		// ** End of Test **
	}

	@Test
	public void test_AvailableIncomeFrequencyOptions() {

		// Your Finances section - for quick apply journey
		// ===============================================

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			log.info("QuickApply - test_AvailableIncomeFrequencyOptions");
			// What is your income frequency?
			Select dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
			dropdown.selectByVisibleText("Please select");
			dropdown.selectByVisibleText("Weekly");
			dropdown.selectByVisibleText("Fortnightly");
			dropdown.selectByVisibleText("Monthly");
			dropdown.selectByVisibleText("Annually");

			// Validate no more items listed than above - Expect 5 items
			List<WebElement> l = dropdown.getOptions();
			Assert.assertEquals(5, l.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_AvailableIncomeMethodOptions() {

		// Your Finances section - for quick apply journey
		// ===============================================

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			log.info("QuickApply - test_AvailableIncomeMethodOptions");
			// What is your income method?
			Select dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
			dropdown.selectByVisibleText("Please select");
			dropdown.selectByVisibleText("Direct Deposit");
			dropdown.selectByVisibleText("Cheque");
			dropdown.selectByVisibleText("Cash");
			dropdown.selectByVisibleText("Other");

			// Validate no more items listed than above - Expect 5 items
			List<WebElement> l = dropdown.getOptions();
			Assert.assertEquals(5, l.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_MandatoryFieldsAsterisk() {

		// Invoke the hidden Previous Agreement Number field to check label
		if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		}

		// Check all required fields which are mandatory are identified by an *
		// suffix

		// Your Loan Section
		Assert.assertEquals("Previous Agreement Number\n?", getDriver().findElement(By.xpath("//label[@for='PreviousAgreementNumber']")).getText());
		// Assert.assertEquals("On which day of the week would you like to make your repayments?*\n?",
		// getDriver().findElement(By.cssSelector(".frequency-selected__payments > p:nth-child(1)")).getText());
		Assert.assertEquals("What will you use your loan for?*", getDriver().findElement(By.xpath("//label[@for='LoanPurposeValue']")).getText());
		// Assert.assertEquals("For our own research, please tell us the minimum loan amount you would find useful today?*\n?",
		// getDriver().findElement(By.xpath("//label[@for='MinimumLoanValue']")).getText());
		Assert.assertEquals("I have read and agree to your website cookie policy", getDriver().findElement(By.xpath("//label[@for='CookieAccepted']")).getText());

		// Personal Details Section
		Assert.assertEquals("Title*", getDriver().findElement(By.xpath("//label[@for='CustomerTitle']")).getText());
		Assert.assertEquals("Forename*", getDriver().findElement(By.xpath("//label[@for='Forename']")).getText());
		Assert.assertEquals("Surname*", getDriver().findElement(By.xpath("//label[@for='Surname']")).getText());
		Assert.assertEquals("Date of Birth*", getDriver().findElement(By.xpath("//label[@for='DateOfBirth']")).getText());
		Assert.assertEquals("What is your marital status?*", getDriver().findElement(By.xpath("//label[@for='MaritalStatusValue']")).getText());
		Assert.assertEquals("How many dependants do you have?*\n?", getDriver().findElement(By.xpath("//label[@for='NumberOfDependantsValue']")).getText());

		// Your Address Section
		Assert.assertEquals("What is your residential status?*", getDriver().findElement(By.xpath("//label[@for='ResidencyTypeValue']")).getText());
		Assert.assertEquals("Moved in date*", getDriver().findElement(By.xpath("//label[@for='CurrentAddress_DisplayDateMovedIn']")).getText());

		// Address Search Section
		Assert.assertEquals("Postcode*\n?", getDriver().findElement(By.xpath("//label[@for='CurrentAddress_Postcode']")).getText());

		// Your Contact Details Section
		Assert.assertEquals("Mobile phone number*", getDriver().findElement(By.xpath("//label[@for='MobilePhoneNumber']")).getText());
		Assert.assertEquals("Email Address*\n?", getDriver().findElement(By.xpath("//label[@for='EmailAddress']")).getText());

		// Your Finances bit for quick apply journey

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			Assert.assertEquals("What is your current source of income?*", getDriver().findElement(By.xpath("//label[@for='EmploymentStatusValue']")).getText());
			Assert.assertEquals("What is your regular income amount?*", getDriver().findElement(By.xpath("//label[@for='Income']")).getText());
			Assert.assertEquals("How often do you receive this regular income?*", getDriver().findElement(By.xpath("//label[@for='IncomeFrequencyValue']")).getText());
			Assert.assertEquals("How do you receive this income?*", getDriver().findElement(By.xpath("//label[@for='IncomeMethodValue']")).getText());
			Assert.assertEquals("What is your monthly rent/mortgage amount?*", getDriver().findElement(By.xpath("//label[@for='HousingCostsAmount']")).getText());
			Assert.assertEquals("Do you have any Credit Cards?*", getDriver().findElement(By.xpath("//label[@for='HasCreditCards']")).getText());
			Assert.assertEquals("Do you have any other loans?*", getDriver().findElement(By.xpath("//label[@for='HasOtherLoans']")).getText());

			// Invoke repayments amount field visibility to check field label
			if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsYes")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());
			Assert.assertEquals("If yes, what are your monthly loan and credit card repayments? *", getDriver().findElement(By.xpath("//label[@for='LoansRepaymentsAmount']")).getText());

		}

		// ** End Of Test **
	}

	@Test
	public void test_MandatoryFieldValidationMessages() {

		// Invoke the hidden Previous Agreement Number field to check validation
		// message
		if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		}

		// click on the Next:Your Finances if Apply or Review Your Quote of
		// Quick-Apply
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		// Your Loan Section
		// =================

		// Check validation message for Previous Agreement Number
		Assert.assertEquals("Please enter your agreement number", getDriver().findElement(By.xpath("//span[@data-valmsg-for='PreviousAgreementNumber']")).getText());

		// Check validation message for day of week
		Assert.assertEquals("Please select your payment day", getDriver().findElement(By.xpath("//span[@data-valmsg-for='PreferredPaymentDayValue']")).getText());

		// Check validation message for loan usage
		Assert.assertEquals("Please select what you will use your loan for", getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoanPurposeValue']")).getText());

		// Check validation message for minimum loan amount
		// Assert.assertEquals("Please enter a minimum loan value amount",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='MinimumLoanValue']")).getText());

		// Check validation message for cookie policy
		Assert.assertEquals("Please accept to proceed", getDriver().findElement(By.xpath("//span[@data-valmsg-for='CookieAccepted']")).getText());

		// Personal Details Section
		// ========================

		// Check validation message for Title
		Assert.assertEquals("Please select your title", getDriver().findElement(By.xpath("//span[@data-valmsg-for='CustomerTitle']")).getText());

		// Check validation message for Forename
		Assert.assertEquals("Please enter your forename", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());

		// Check validation message for Surname
		Assert.assertEquals("Please enter your surname", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());

		// Check validation message for Date Of Birth
		Assert.assertEquals("Please provide your date of birth", getDriver().findElement(By.xpath("//span[@data-valmsg-for='DateOfBirth.Year']")).getText());

		// Check validation message for Marital Status
		Assert.assertEquals("Please select your marital status", getDriver().findElement(By.xpath("//span[@data-valmsg-for='MaritalStatusValue']")).getText());

		// Check validation message for Dependants
		Assert.assertEquals("Please select your number of dependants", getDriver().findElement(By.xpath("//span[@data-valmsg-for='NumberOfDependantsValue']")).getText());

		// Your Address Section
		// ====================

		// Check validation message for Residency type
		Assert.assertEquals("Please select your residential status", getDriver().findElement(By.xpath("//span[@data-valmsg-for='ResidencyTypeValue']")).getText());

		// Check validation message for Moved in Date
		Assert.assertEquals("Moved in date must be before today", getDriver().findElement(By.xpath("//span[@data-valmsg-for='CurrentAddress.DisplayDateMovedIn.Year']")).getText());

		// Your Contact Details Section
		// ============================

		// Check validation message for Mobile phone number
		Assert.assertEquals("Please enter your mobile number", getDriver().findElement(By.xpath("//span[@data-valmsg-for='MobilePhoneNumber']")).getText());

		// Check validation message for Email Address
		Assert.assertEquals("Please enter your email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());

		// Your Finances bit for quick apply journey

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			// Check validation message for current source of income
			Assert.assertEquals("Please select your current income source", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmploymentStatusValue']")).getText());

			// Check validation message for regular income amount
			Assert.assertEquals("Please enter your regular income", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());

			// Check validation message for regular income amount
			Assert.assertEquals("Please select how often you receive your regular income", getDriver().findElement(By.xpath("//span[@data-valmsg-for='IncomeFrequencyValue']")).getText());

			// Check validation message for income receive method
			Assert.assertEquals("Please select how you receive your regular income", getDriver().findElement(By.xpath("//span[@data-valmsg-for='IncomeMethodValue']")).getText());

			// Check validation message for has credit cards
			Assert.assertEquals("The Do you have any Credit Cards?* field is required.", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HasCreditCards']")).getText());

			// Check validation message for has other loans
			Assert.assertEquals("The Do you have any other loans?* field is required.", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HasOtherLoans']")).getText());

		}

		if (getDriver().getCurrentUrl().contains("quick-apply")) {
			// Invoke repayments amount field visibility to check field label
			if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsYes")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());
		}

		// click on the Next:Your Finances if Apply or Review Your Quote of
		// Quick-Apply
		getDriver().findElement(By.id("ContinueButton")).click();

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			// Check validation message for repayments amount
			Assert.assertEquals("Please enter your monthly loan/credit card repayments", getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());

		}

		// ** End Of Test **
	}

	@Test
	public void test_MandatoryFieldCurrentAddresses() {

		// Testing Current Address Only Mandatory check
		// ============================================

		// Fill in form first, take defaults where possible otherwise fill with
		// valid data, expect for Current Address

		// On which day of the week would you like to make your repayments -
		// Monday
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");
		// getDriver().findElement(By.id("MinimumLoanValue")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB,
		// Keys.SHIFT));

		// getDriver().findElement(By.linkText("Monday")).click();

		// What will you use your loan for - Household Goods
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Household Goods");

		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£100");

		// Please read our web-site cookie policy and tick this box to agree -
		// is Ticked
		if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
			getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("CookieAccepted")).click();
		}

		// Personal Details section
		// ========================

		// Applicants Title - Mr
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Mr");
		// Applicants Firstname - Tari
		getDriver().findElement(By.id("Forename")).sendKeys("Tari");
		// Applicants Surname - Ghan
		getDriver().findElement(By.id("Surname")).sendKeys("Ghan");
		// Applicants DOB - Day - 1st
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText("01");
		// Applicants DOB - Month - January
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText("January");
		// Applicants DOB - Year - 1963
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText("1963");
		// Applicants Marital Status - Divorced
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Divorced");
		// Applicants Number Of Dependants - 0
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("0");

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - 07850121212
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// Applicant Email Address - tarighan@test.com
		getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");

		// Your Address
		// ------------

		// Applicants Residential Status - Owner Occupier
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Owner Occupier");

		// Next Action: Submit page
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		gcb.waitForVisibilityOfElement(By.xpath("//span[@data-valmsg-for='CurrentAddress.CurrentAddressSearchPostcode']"));

		// Assert mandatory validation message is displayed when postcode not
		// entered
		Assert.assertEquals("Please provide your current address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='CurrentAddress.CurrentAddressSearchPostcode']")).getText());

		// Enter a valid postcode but do not do a search

		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD1 2SU");

		// Next Action: Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// ** End of Test **
	}

	@Test
	public void test_InvalidEmailAddresses() {

		// Validate that by entering an invalid format email address in the
		// email address field
		// a validation message is raised

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email@example");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email@-example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email@111.222.333.44444");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email@example..com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("Abc..123@example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email.example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email@example@example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys(".email@example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email.@example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		getDriver().findElement(By.id("EmailAddress")).sendKeys("email..email@example.com");
		getDriver().findElement(By.id("EmailAddress")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid email address", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmailAddress']")).getText());
		getDriver().findElement(By.id("EmailAddress")).clear();

		// ** End Of Test **
	}

	@Test
	public void test_FieldLengthInvalidCharacters() {

		// where field lengths on certain fields are breached or where invalid
		// characters maintained
		// a validation message is raised

		// Personal Details
		// ================

		// Forename
		// =========

		// more than 25 characters, numeric values or special characters raises
		// validation message
		getDriver().findElement(By.id("Forename")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaa");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		Assert.assertEquals("Forename must be a maximum length of 25 characters", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa1");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your forename contains invalid characters", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa%");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Your forename contains invalid characters",getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa!");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Your forename contains invalid characters",getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("John-Paul");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("John Paul");
		getDriver().findElement(By.id("Forename")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		getDriver().findElement(By.id("Forename")).sendKeys("Derk's");
		getDriver().findElement(By.id("DateOfBirth_Day")).click();
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Forename']")).getText());
		getDriver().findElement(By.id("Forename")).clear();

		// Surname
		// ========

		// more than 25 characters, numeric values or special characters raises
		// validation message
		getDriver().findElement(By.id("Surname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaa");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("Surname must be a maximum length of 25 characters", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa1");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your surname contains invalid characters", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa%");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Your surname contains invalid characters",getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaa~");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Your surname contains invalid characters",getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("Mirski-Fitton");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("MirskiFitton");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("Mirski Fitton");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		getDriver().findElement(By.id("Surname")).sendKeys("Fitton's");
		getDriver().findElement(By.id("Surname")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Surname']")).getText());
		getDriver().findElement(By.id("Surname")).clear();

		// Address Search
		// ==============

		// navigate to the full address input fields and check field lengths
		// if field lengths are surpassed, validation message is raised

		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);
		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		// Flat Number
		// =============
		getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys("11111111111");
		getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your flat number must not contain more than 10 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_FlatNumber']")).getText());

		// Building Name
		// =============
		getDriver().findElement(By.id("CurrentAddress_BuildingName")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
		getDriver().findElement(By.id("CurrentAddress_BuildingName")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your house/building name must not contain more than 25 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_BuildingName']")).getText());

		// HouseNumber
		// =============
		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("11111111111");
		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your house number must not contain more than 10 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_HouseNumber']")).getText());

		// Street
		// =============
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("aaaaaaaaaaaaa aaaaaaaaaaaa");
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your street must not contain more than 25 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Street']")).getText());

		// District
		// =============
		getDriver().findElement(By.id("CurrentAddress_District")).sendKeys("aaaaaaaaaaaaa aaaaaaaaaaaa");
		getDriver().findElement(By.id("CurrentAddress_District")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your district must not contain more than 25 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_District']")).getText());

		// Town City
		// =============
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("aaaaaaaaaaaaa aaaaaaaaaaaa");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your town/city must not contain more than 25 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_TownCity']")).getText());

		// County
		// =============
		getDriver().findElement(By.id("CurrentAddress_County")).sendKeys("aaaaaaaaaaaaa aaaaaaaaaaaa");
		getDriver().findElement(By.id("CurrentAddress_County")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your county must not contain more than 25 characters", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_County']")).getText());

		// // Post Code
		// // =========
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("bb22 33dddd");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(Keys.TAB);
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='CurrentAddress.Postcode']")).getText());
		//
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("bb222 2LY");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(Keys.TAB);
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		//
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD2 2LYN");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(Keys.TAB);
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		//
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD2 22YN");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(Keys.TAB);
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		//
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD2 2L");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys(Keys.TAB);
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());

		// Your Contact Details
		// ====================

		// Mobile Number
		// =============

		// longer than 11 chars with space
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07900 5624670");
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid mobile phone number", getDriver().findElement(By.xpath("//span[@for='MobilePhoneNumber']")).getText());
		getDriver().findElement(By.id("MobilePhoneNumber")).clear();

		// longer than 11 chars without space
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("079005624670");
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid mobile phone number", getDriver().findElement(By.xpath("//span[@for='MobilePhoneNumber']")).getText());
		getDriver().findElement(By.id("MobilePhoneNumber")).clear();

		// No leading "0"
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("7900562467");
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid mobile phone number", getDriver().findElement(By.xpath("//span[@for='MobilePhoneNumber']")).getText());
		getDriver().findElement(By.id("MobilePhoneNumber")).clear();

		// No leading "07"
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("08900562467");
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid mobile phone number", getDriver().findElement(By.xpath("//span[@for='MobilePhoneNumber']")).getText());
		getDriver().findElement(By.id("MobilePhoneNumber")).clear();

		// Only numbers
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("079O0562467");
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter a valid mobile phone number", getDriver().findElement(By.xpath("//span[@for='MobilePhoneNumber']")).getText());
		getDriver().findElement(By.id("MobilePhoneNumber")).clear();

		// ** End Of Test **
	}

	@Test(enabled = false)
	public void test_InvalidNINOs() {

		getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);

		String sValidationMessage = "Please enter a valid National Insurance Number";

		// Personal Details
		// ----------------

		getDriver().manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS); // Reduce
		// implicit
		// wait
		// time
		// for
		// this
		// test

		// Applicants NI Number
		// Note if find element does not find the element containing the error
		// text then it means that validation
		// message did not get triggered. Be-aware of rendering timing.
		getDriver().findElement(By.id("NiNumber")).clear();
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_FA400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).clear();
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_IA400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_QA400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_UA400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_VA400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_ND400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NF400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NI400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NQ400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NU400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NV400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NO400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_BG400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_GB400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NK400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_KN400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_TN400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_ZZ400737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737E);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737F);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737G);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737H);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737I);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737J);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737K);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737L);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737M);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737N);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737DA);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NAX00737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4X0737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA40X737D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400X37D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007X7D);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA40073XD);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737O);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737P);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737Q);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737R);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737S);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737T);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737U);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737V);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737W);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737X);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA400737Z);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007370);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007371);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007372);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007373);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007374);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007375);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007376);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007377);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007378);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());
		getDriver().findElement(By.id("NiNumber")).sendKeys(gcb.AInvalidNINO_NA4007379);
		getDriver().findElement(By.id("NiNumber")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("NiNumber")).clear();
		Assert.assertEquals(sValidationMessage, getDriver().findElement(By.xpath("//span[@data-valmsg-for='NiNumber']/span")).getText());

		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// ** End Of Test **
	}

	@Test
	public void test_FirstPaymentDueDateCalculations() {

		By byLblPaymentDate = By.cssSelector(".frequency-selected__payments > p:nth-child(1)");

		// Loan Offer section
		// ==================

		// On which day of the week would you like to make your repayments -
		// Validate first payment date for each Day of Week
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");
		// getDriver().findElement(By.id("MinimumLoanValue")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));

		// getDriver().findElement(By.linkText("Monday")).click();

		new WebDriverWait(getDriver(), 2).until(ExpectedConditions.textToBePresentInElement(getDriver().findElement(byLblPaymentDate),
				"Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Monday") + "."));
		Assert.assertEquals(getDriver().findElement(byLblPaymentDate).getText(), "Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Monday") + ".");

		// getDriver().findElement(By.linkText("Tuesday")).click();
		dropdown.selectByVisibleText("Tuesday");
		new WebDriverWait(getDriver(), 2).until(ExpectedConditions.textToBePresentInElement(getDriver().findElement(byLblPaymentDate),
				"Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Tuesday") + "."));
		Assert.assertEquals(getDriver().findElement(byLblPaymentDate).getText(), "Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Tuesday") + ".");

		// getDriver().findElement(By.linkText("Wednesday")).click();
		dropdown.selectByVisibleText("Wednesday");
		new WebDriverWait(getDriver(), 2).until(ExpectedConditions.textToBePresentInElement(getDriver().findElement(byLblPaymentDate),
				"Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Wednesday") + "."));
		Assert.assertEquals(getDriver().findElement(byLblPaymentDate).getText(), "Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Wednesday") + ".");

		// getDriver().findElement(By.linkText("Thursday")).click();
		dropdown.selectByVisibleText("Thursday");
		new WebDriverWait(getDriver(), 2).until(ExpectedConditions.textToBePresentInElement(getDriver().findElement(byLblPaymentDate),
				"Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Thursday") + "."));
		Assert.assertEquals(getDriver().findElement(byLblPaymentDate).getText(), "Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Thursday") + ".");

		// getDriver().findElement(By.linkText("Friday")).click();
		dropdown.selectByVisibleText("Friday");
		new WebDriverWait(getDriver(), 2).until(ExpectedConditions.textToBePresentInElement(getDriver().findElement(byLblPaymentDate),
				"Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Friday") + "."));
		Assert.assertEquals(getDriver().findElement(byLblPaymentDate).getText(), "Your first payment will be on " + gcb.fn_PreferredPaymentDate(TimeHackHelper.getPanDate(), "Friday") + ".");

		// ** End Of Test **
	}

	@Test
	public void test_ApplicantUnderAgeOverAge() {

		gsCurrentUrl = getDriver().getCurrentUrl();

		String sDOB;

		// Validate Under Age policy rule

		// Personal Details
		// ----------------

		// Calculate a under 18 years DOB in real time
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -6205); // subtract 17 years of days
		SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
		sDOB = s.format(new Date(cal.getTimeInMillis()));
		log.info("Under 18 years DOB: " + sDOB);

		// Personal Details
		// ----------------

		// Applicants DOB - Day
		Select dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText(sDOB.substring(8, 10));
		// Applicants DOB - Month
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(sDOB.substring(5, 7)));
		// Applicants DOB - Year
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText(sDOB.substring(0, 4));

		// Under Age Assertions
		// ====================

		// Check for DOB field validation error message as applicant entered
		// date is under 18 years of age
		Assert.assertTrue(getDriver().getPageSource().contains("You must be aged between 18 and 74 to apply for a Satsuma loan"));

		// Invoke Next action: Next: Your finances for Apply route or Review
		// Your Quote for Quick Apply route
		getDriver().findElement(By.id("ContinueButton")).click();

		// Check page cannot progress to next stage - Remain on same page after
		// validation error
		Assert.assertEquals(gsCurrentUrl, getDriver().getCurrentUrl());

		// Validate Under Age policy rule

		// Personal Details
		// ----------------

		// Calculate a under 18 years DOB in real time
		cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) - 76);
		sDOB = s.format(new Date(cal.getTimeInMillis()));
		log.info("75 and over years DOB: " + sDOB);

		// Personal Details
		// ----------------

		// Applicants DOB - Day
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText(sDOB.substring(8, 10));
		// Applicants DOB - Month
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText(gtb.fn_GetMonthFullWording(sDOB.substring(5, 7)));
		// Applicants DOB - Year
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText(sDOB.substring(0, 4));

		// Over Age Assertions
		// ====================

		// Check for DOB field validation error message as applicant entered
		// date 75 and over years of age
		Assert.assertTrue(getDriver().getPageSource().contains("You must be aged between 18 and 74 to apply for a Satsuma loan"));

		// Invoke Next action: Next: Your finances for Apply route or Review
		// Your Quote for Quick Apply route
		getDriver().findElement(By.id("ContinueButton")).click();

		// Check page cannot progress to next stage - Remain on same page after
		// validation error
		Assert.assertEquals(gsCurrentUrl, getDriver().getCurrentUrl());

		// ** End Of Test **
	}

	// @Test
	// public void test_MaxLoanValuesAndTermsForNewCustomers() {
	//
	// // check that where No is chosen for existing customer max loan value =
	// // £1000
	// // and max minimum amount request = £1000
	//
	// getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
	// //
	// Assert.assertEquals("1000.00",getDriver().findElement(By.xpath("//input[@id='LoanAmount']")).getAttribute("max"));
	// Select dropdown = new
	// Select(getDriver().findElement(By.id("MinimumLoanValue")));
	// dropdown.selectByVisibleText("£1000");
	//
	// // Validate no more than 92 items listed £100 - £1000 for min loan
	// // amount requests
	// List<WebElement> l = dropdown.getOptions();
	// Assert.assertEquals(92, l.size());
	//
	// // ** End Of Test **
	//
	// }

	@Test
	public void test_RepaymentFrequencyDropdownOptions() throws Exception {

		// Check that Repayments Frequency selectable dropdown options are
		// available as specified below.
		// This test is specific to the uploaded pricing table, so the
		// re-payment frequency listing must match the latested available
		// uploaded pricing
		log.info("WARNING: " + "This test is specific to the uploaded pricing table, so the re-payment frequency listing must match the latested available uploaded pricing");

		String[] exp = { "13 weeks", "17 weeks", "21 weeks", "26 weeks", "30 weeks", "34 weeks", "39 weeks", "43 weeks", "47 weeks", "52 weeks" };
		WebElement dropdown = getDriver().findElement(By.id("TermAboutYouCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating repayment frequency dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 10) {
			Assert.fail("Failed: Expecting 10 option listings, found " + options.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_MaxLoanValuesAndTermsForExistingCustomers() {

		// Check that when Yes is chosen for existing customer can select loan
		// values from £100 to £2000

		getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("min"));
		Assert.assertEquals("2000", getDriver().findElement(By.id("LoanAmountAboutYouCalc")).getAttribute("max"));

		// Check that loan amount dropdown is options range from £100 to £2000
		// only in increments of £10

		String[] exp = { "100", "110", "120", "130", "140", "150", "160", "170", "180", "190", "200", "210", "220", "230", "240", "250", "260", "270", "280", "290", "300", "310", "320", "330", "340",
				"350", "360", "370", "380", "390", "400", "410", "420", "430", "440", "450", "460", "470", "480", "490", "500", "510", "520", "530", "540", "550", "560", "570", "580", "590", "600",
				"610", "620", "630", "640", "650", "660", "670", "680", "690", "700", "710", "720", "730", "740", "750", "760", "770", "780", "790", "800", "810", "820", "830", "840", "850", "860",
				"870", "880", "890", "900", "910", "920", "930", "940", "950", "960", "970", "980", "990", "1000", "1010", "1020", "1030", "1040", "1050", "1060", "1070", "1080", "1090", "1100",
				"1110", "1120", "1130", "1140", "1150", "1160", "1170", "1180", "1190", "1200", "1210", "1220", "1230", "1240", "1250", "1260", "1270", "1280", "1290", "1300", "1310", "1320", "1330",
				"1340", "1350", "1360", "1370", "1380", "1390", "1400", "1410", "1420", "1430", "1440", "1450", "1460", "1470", "1480", "1490", "1500", "1510", "1520", "1530", "1540", "1550", "1560",
				"1570", "1580", "1590", "1600", "1610", "1620", "1630", "1640", "1650", "1660", "1670", "1680", "1690", "1700", "1710", "1720", "1730", "1740", "1750", "1760", "1770", "1780", "1790",
				"1800", "1810", "1820", "1830", "1840", "1850", "1860", "1870", "1880", "1890", "1900", "1910", "1920", "1930", "1940", "1950", "1960", "1970", "1980", "1990", "2000" };

		WebElement dropdown = getDriver().findElement(By.id("LoanAmountAboutYouCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating loan amount dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = cnt; i < exp.length; i++) {
				if (we.getText().equals("£" + exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 191) {
			Assert.fail("Failed: Expecting 191 option listings, found " + options.size());
		}

		// ** End Of Test **

	}

	@Test
	public void test_BehaviourOfPreviousAgreementNumberTextBoxForExistingCustomers() {

		// Check Visibility Behaviour
		// ==========================

		// Ensure that we default Customer as New, before we begin this test
		if (!getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
		}

		// Check that the Previous Agreement Number field is available and
		// enabled when Customer
		// specifies that they are an existing customer

		if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		}

		Assert.assertTrue(getDriver().findElement(By.xpath("//label[@for='PreviousAgreementNumber']")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAgreementNumber")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAgreementNumber")).isEnabled());

		// Check that visibility of Previous Agreement number field is
		// surpressed when Customer
		// Specifies that they are new
		if (!getDriver().findElement(By.id("SaysIsExistingCustomerNo")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerNo")).click();
		}

		// element is now destroyed when you click no
		// Assert.assertFalse(getDriver().findElement(By.id("PreviousAgreementNumber")).isDisplayed());

		// Check Field Validation
		// ======================

		if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		}
		// Assert when agreement number too short
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("12345678901");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your agreement number should be 12 digits long.", getDriver().findElement(By.cssSelector(".field-validation-error")).getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// Assert when agreement number too long
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("1234567890123");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your agreement number should be 12 digits long.", getDriver().findElement(By.cssSelector(".field-validation-error")).getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// Assert when agreement number when alphanumeric
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("123456789O123");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your agreement number should be 12 digits long. Your agreement number should only contain numbers.", getDriver().findElement(By.cssSelector(".field-validation-error"))
				.getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// Assert when agreement number when alphabetic
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("ABCDEFGHIJKL");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your agreement number should only contain numbers.", getDriver().findElement(By.cssSelector(".field-validation-error")).getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// Assert when agreement number with forward slash
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("/23456789012");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Your agreement number should only contain numbers.", getDriver().findElement(By.cssSelector(".field-validation-error")).getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// Assert when agreement number not entered
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys("1");
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.BACK_SPACE);
		getDriver().findElement(By.id("PreviousAgreementNumber")).sendKeys(Keys.TAB);
		Assert.assertEquals("Agreement number is required", getDriver().findElement(By.cssSelector(".field-validation-error")).getText());
		getDriver().findElement(By.id("PreviousAgreementNumber")).clear();

		// ** End Of Test **

	}

	@Test
	public void test_QASAddressSearchOnPostcodeOnlySingleAddressFound() {

		// Postcode BD1 2SU should only return 1 address at No 1 Godwin Street
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD1 2SU");
		// Search now
		// getDriver().findElement(By.id("CurrentAddressAddressSearch")).click();
		getDriver().findElement(By.id("CurrentAddressAddressSearch")).sendKeys(Keys.ENTER);

		// wait for element to be stale and back again
		By by = By.id("CurrentAddress_CurrentAddressChosenAddress");
		waitForStaleThenActiveElement(by);

		Select dropdown;
		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("1", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Godwin Street", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD1 2SU", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASAddressSearchOnPostcodeOnlyMultipleAddressesFound() {

		// Postcode BD5 8JQ should return more than 1 address
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD5 8JQ");
		// Search now
		// getDriver().findElement(By.id("CurrentAddressAddressSearch")).click();
		getDriver().findElement(By.id("CurrentAddressAddressSearch")).sendKeys(Keys.ENTER);
		By by = By.id("CurrentAddress_CurrentAddressChosenAddress");
		// wait for element to go stale and visible again
		waitForStaleThenActiveElement(by);

		// find element again
		Select dropdown = new Select(getDriver().findElement(by));

		if (dropdown.getOptions().size() <= 2) {
			Assert.fail("Failed: Expecting more than 1 address to be listed");
		}

		// Assert that "Select address" option is defaulted to prompt customer
		// to pick and address from the list
		Assert.assertEquals("Select address", dropdown.getFirstSelectedOption().getText());

		// Assert that address lines are not visible when address not selected
		// from dropdown
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_FlatNumber")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_BuildingName")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_HouseNumber")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_Street")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_District")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_TownCity")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("CurrentAddress_Postcode")).isDisplayed());

		getDriver().findElement(by).sendKeys(Keys.SPACE); // try to focus on
															// element by
															// sending space bar
															// to it.

		// Select address 2 Hallbank Close, BRADFORD, West Yorkshire, BD5 8JQ
		// option from the list
		dropdown.selectByVisibleText("2 Hallbank Close, BRADFORD, West Yorkshire, BD5 8JQ");

		new WebDriverWait(getDriver(), 3).until(ExpectedConditions.textToBePresentInElementValue(getDriver().findElement(By.id("CurrentAddress_HouseNumber")), "2"));

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("2", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Hallbank Close", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD5 8JQ", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASAddressSearchOnSpecificAddress() {

		// House Number 24 & Postcode BD7 4BG should only return 1 address
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).sendKeys("24");
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD7 4BG");
		// Search now
		// getDriver().findElement(By.id("CurrentAddressAddressSearch")).click();
		getDriver().findElement(By.id("CurrentAddressAddressSearch")).sendKeys(Keys.ENTER);

		// wait for element to be stale and back again
		By by = By.id("CurrentAddress_CurrentAddressChosenAddress");
		waitForStaleThenActiveElement(by);

		Select dropdown;
		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("24 Highlands Grove, BRADFORD, West Yorkshire, BD7 4BG", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("24", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Highlands Grove", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD7 4BG", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASAddressSearchOnCurrentAddressNotFound() {

		// Invalid Address search details
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).sendKeys("999");
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD99 9GG");
		// Search now
		// getDriver().findElement(By.id("CurrentAddressAddressSearch")).click();
		getDriver().findElement(By.id("CurrentAddressAddressSearch")).sendKeys(Keys.ENTER);
		waitForTextInElement(By.id("CurrentAddressNoAddressesFound"), "No address found. Please try again, or enter your address manually.");

		// Assert that appropriate messages displayed to indicate address not
		// found
		Assert.assertEquals("No address found. Please try again, or enter your address manually.", getDriver().findElement(By.id("CurrentAddressNoAddressesFound")).getText(), "no address message");

		// getDriver().findElement(By.linkText("enter your address manually")).click();
		getDriver().findElement(By.linkText("enter your address manually")).sendKeys(Keys.ENTER);

		// Assert that address lines are visible for entering the address
		// manually.
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_FlatNumber")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_BuildingName")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_HouseNumber")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_Street")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_District")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_TownCity")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_Postcode")).isDisplayed());

		// Assert that address line are blank
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are enabled for re-input after manual entry
		// selected
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_FlatNumber")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_BuildingName")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_HouseNumber")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_Street")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_District")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_TownCity")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_County")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("CurrentAddress_Postcode")).isEnabled());

		// ** End Of Test **
	}

	public void waitForTextInElement(By by, String textToWaitFor) {
		try {
			(new WebDriverWait(getDriver(), 3)).until(ExpectedConditions.textToBePresentInElementLocated(by, textToWaitFor));
		} catch (TimeoutException e) {
			log.warn("Waited for text: " + textToWaitFor + " to appear in element: " + by);
		}
	}

	@Test
	public void test_QASPreviousAddressSearchOnPostcodeOnlySingleAddressFound() {

		String sCurrentMonth;
		String sNextMonth;
		String sYear2YearsAgo;

		// Establish boundary date conditions to trigger previous address entry.

		// Get todays date
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		sCurrentMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// Subtract 2 years 11 months from the calendar to enforce less than 3
		// years at address
		cal.add(Calendar.YEAR, -3);
		cal.add(Calendar.MONTH, 1);
		sNextMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sYear2YearsAgo = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("2 years 11 months ago: " + cal.getTime() + " Current Month:" + sCurrentMonth + " Next Month:" + sNextMonth + " Years 2 Years Ago:" + sYear2YearsAgo);

		// Trigger Previous Address section by entering moved in date 2 years 11
		// months ago
		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sNextMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should be displayed
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddressWrapper")).isDisplayed());

		// Trigger removal of Previous Address section by entering moved in date
		// 2 years 12 months ago
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sCurrentMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should not be displayed
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddressWrapper")).isDisplayed());

		// Trigger Previous Address section by entering moved in date 2 years 11
		// months ago
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sNextMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should be displayed
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddressWrapper")).isDisplayed());

		// Postcode BD1 2SU should only return 1 address at No 1 Godwin Street
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD1 2SU");
		// Search now
		// getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
		getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.ENTER);

		By by = By.id("PreviousAddress_PreviousAddressChosenAddress");
		// wait for element to go stale and visible again
		waitForStaleThenActiveElement(by);

		// find element again
		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("1", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Godwin Street", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD1 2SU", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASPreviousSearchOnPostcodeOnlyMultipleAddressesFound() {

		String sCurrentMonth;
		String sNextMonth;
		String sYear2YearsAgo;

		// Establish boundary date conditions to trigger previous address entry.

		// Get todays date
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		sCurrentMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// Subtract 2 years 11 months from the calendar to enforce less than 3
		// years at address
		cal.add(Calendar.YEAR, -3);
		cal.add(Calendar.MONTH, 1);
		sNextMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sYear2YearsAgo = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("2 years 11 months ago: " + cal.getTime() + " Current Month:" + sCurrentMonth + " Next Month:" + sNextMonth + " Years 2 Years Ago:" + sYear2YearsAgo);

		// Trigger Previous Address section by entering moved in date 2 years 11
		// months ago
		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sNextMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should be displayed
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).isDisplayed());

		// Postcode BD5 8JQ should return more than 1 address
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD5 8JQ");
		// Search now
		// getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
		getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.ENTER);
		By by = By.id("PreviousAddress_PreviousAddressChosenAddress");

		waitForStaleThenActiveElement(by);

		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() <= 2) {
			Assert.fail("Failed: Expecting more than 1 address to be listed");
		}

		// Assert that "Select address" option is defaulted to prompt customer
		// to pick and address from the list
		Assert.assertEquals("Select address", dropdown.getFirstSelectedOption().getText());

		// Assert that address lines are not visible when address not selected
		// from dropdown
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_FlatNumber")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_BuildingName")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_HouseNumber")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_Street")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_District")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_TownCity")).isDisplayed());
		Assert.assertFalse(getDriver().findElement(By.id("PreviousAddress_Postcode")).isDisplayed());

		getDriver().findElement(by).sendKeys(Keys.SPACE); // try to focus on
															// element by
															// sending keys to
															// it

		// Select address 2 Hallbank Close, BRADFORD, West Yorkshire, BD5 8JQ
		// option from the list
		dropdown.selectByVisibleText("2 Hallbank Close, BRADFORD, West Yorkshire, BD5 8JQ");

		new WebDriverWait(getDriver(), 3).until(ExpectedConditions.textToBePresentInElementValue(getDriver().findElement(By.id("PreviousAddress_HouseNumber")), "2"));

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("2", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Hallbank Close", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD5 8JQ", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASPreviousAddressSearchOnSpecificAddress() {

		String sCurrentMonth;
		String sNextMonth;
		String sYear2YearsAgo;

		// Establish boundary date conditions to trigger previous address entry.

		// Get todays date
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		sCurrentMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// Subtract 2 years 11 months from the calendar to enforce less than 3
		// years at address
		cal.add(Calendar.YEAR, -3);
		cal.add(Calendar.MONTH, 1);
		sNextMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sYear2YearsAgo = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("2 years 11 months ago: " + cal.getTime() + " Current Month:" + sCurrentMonth + " Next Month:" + sNextMonth + " Years 2 Years Ago:" + sYear2YearsAgo);

		// Trigger Previous Address section by entering moved in date 2 years 11
		// months ago
		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sNextMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should be displayed
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).isDisplayed());

		// House Number 24 & Postcode BD7 4BG should only return 1 address
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).sendKeys("24");
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD7 4BG");
		// Search now
		// getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
		getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.ENTER);
		By by = By.id("PreviousAddress_PreviousAddressChosenAddress");

		waitForStaleThenActiveElement(by);

		dropdown = new Select(getDriver().findElement(by));

		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("24 Highlands Grove, BRADFORD, West Yorkshire, BD7 4BG", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("24", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Highlands Grove", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD7 4BG", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("readOnly"));

		// ** End Of Test **
	}

	@Test
	public void test_QASAddressSearchOnPreviousAddressNotFound() {

		String sCurrentMonth;
		String sNextMonth;
		String sYear2YearsAgo;

		// Establish boundary date conditions to trigger previous address entry.

		// Get todays date
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		sCurrentMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// Subtract 2 years 11 months from the calendar to enforce less than 3
		// years at address
		cal.add(Calendar.YEAR, -3);
		cal.add(Calendar.MONTH, 1);
		sNextMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sYear2YearsAgo = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("2 years 11 months ago: " + cal.getTime() + " Current Month:" + sCurrentMonth + " Next Month:" + sNextMonth + " Years 2 Years Ago:" + sYear2YearsAgo);

		// Trigger Previous Address section by entering moved in date 2 years 11
		// months ago
		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sNextMonth);
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sYear2YearsAgo);

		// Previous Address section should be displayed
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).isDisplayed());

		// House Number 24 & Postcode BD7 4BG should only return 1 address
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).sendKeys("999");
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD9 9GG");
		// Search now
		// getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
		getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.ENTER);

		// Assert that appropriate messages displayed to indicate address not
		// found
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddressNoAddressesFound")).getAttribute("innerHTML").contains("No address found"));

		// getDriver().findElement(By.linkText("enter your address manually")).click();
		getDriver().findElement(By.linkText("enter your address manually")).sendKeys(Keys.ENTER);

		// Assert that address lines are visible for entering the address
		// manually.
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_FlatNumber")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_BuildingName")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_HouseNumber")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_Street")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_District")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_TownCity")).isDisplayed());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_Postcode")).isDisplayed());

		// Assert that address line are blank
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are enabled for re-input after manual entry
		// selected
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_FlatNumber")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_BuildingName")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_HouseNumber")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_Street")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_District")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_TownCity")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_County")).isEnabled());
		Assert.assertTrue(getDriver().findElement(By.id("PreviousAddress_Postcode")).isEnabled());

		// ** End Of Test **
	}

	@Test
	public void test_MarketingOptionBehaviour() {

		// select checkbox to scroll to it
		getDriver().findElement(By.id("OptOutOfMarketingByPost")).sendKeys(Keys.SPACE);

		// Assert that the marketing options can be ticked and unticked
		if (!getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected()) {
			getDriver().findElement(By.id("OptOutOfMarketingByPost")).click();
		}
		Assert.assertTrue(getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected(), "check opt out marketing by post is enabled");
		getDriver().findElement(By.id("OptOutOfMarketingByPost")).click();
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByPost")).isSelected(), "check opt out marketing by post is disabled");

		if (!getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected()) {
			getDriver().findElement(By.id("OptOutOfMarketingByEmail")).click();
		}
		Assert.assertTrue(getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected(), "check opt out marketing by email is enabled");
		getDriver().findElement(By.id("OptOutOfMarketingByEmail")).click();
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByEmail")).isSelected(), "check opt out marketing by email is disabled");

		if (!getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected()) {
			getDriver().findElement(By.id("OptOutOfMarketingBySMS")).click();
		}
		Assert.assertTrue(getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected(), "check opt out marketing by sms is enabled");
		getDriver().findElement(By.id("OptOutOfMarketingBySMS")).click();
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingBySMS")).isSelected(), "check opt out marketing by sms is disabled");

		if (!getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected()) {
			getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).click();
		}
		Assert.assertTrue(getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected(), "check opt out marketing by tele is enabled");
		getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).click();
		Assert.assertFalse(getDriver().findElement(By.id("OptOutOfMarketingByTelephone")).isSelected(), "check opt out marketing by tele is disabled");

		// ** End Of Test **
	}

	@Test
	public void test_ConsentAndUseOfPersonalInformation() {

		// Your Finances section - for quick apply journey
		// ===============================================

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			log.info("QuickApply - test_ConsentAndUseOfPersonalInformation");

			// Please tick to confirm you have consented - Defaulted as
			// Un-ticked
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());

			// Check Consent and Use of Personal Information accordian not read
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[1]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[2]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[3]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[4]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[5]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[6]//a[@class='accordian-trigger']")).isDisplayed());
			Assert.assertTrue(getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[7]//a[@class='accordian-trigger']")).isDisplayed());

			// Check that Please tick to confirm you have consented is Un
			// tickable as we have not read the information

			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}

			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());

			// Read Consent and Use of Personal Information
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[1]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[2]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[3]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[4]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[5]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[6]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());
			getDriver().findElement(By.xpath("//form//div[@id='accordian-consent']/section[7]//a[@class='accordian-trigger']")).click();
			if (!getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("AgreedToBureauSearch")).isSelected());

		}
	}

	@Test
	public void test_VisibilityOfLoanCreditCardRepaymentField() {

		// Your Finances section - for quick apply journey
		// ===============================================

		if (getDriver().getCurrentUrl().contains("quick-apply")) {

			log.info("QuickApply - test_VisibilityOfLoanCreditCardRepaymentField");
			// Check enabling of the
			// "If yes, what are your monthly loan and credit card repayments?*"
			// field

			if (getDriver().findElement(By.id("HasCreditCardsYes")).isSelected() || getDriver().findElement(By.id("HasCreditCardsNo")).isSelected()
					|| getDriver().findElement(By.id("HasOtherLoansYes")).isSelected() || getDriver().findElement(By.id("HasOtherLoansNo")).isSelected()) {
				Assert.fail("This test requires Do you have credit cards and/or loans Yes/No option to be all unticked");
			}

			// Is repayments amount field visible when Have any credit cards =
			// Yes and Have any loans = Not Set
			if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsYes")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Is repayments amount field not visible when Have any credit cards
			// = No and Have any loans = Not Set
			if (getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsNo")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Is repayments amount field visible when Have any loans = Yes and
			// Have any credit cards = No
			if (!getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
				getDriver().findElement(By.id("HasOtherLoansYes")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Is repayments amount field not visible when Have any loans = No
			// and Have any credit cards = No
			if (getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
				getDriver().findElement(By.id("HasOtherLoansNo")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Is repayments amount field visible when Have any credit cards =
			// Yes and Have any loan = Yes
			if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsYes")).click();
			}
			if (!getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
				getDriver().findElement(By.id("HasOtherLoansYes")).click();
			}
			Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

			// Is repayments amount field Not visible when Have any credit cards
			// = No and Have any loans = No
			if (!getDriver().findElement(By.id("HasCreditCardsNo")).isSelected()) {
				getDriver().findElement(By.id("HasCreditCardsNo")).click();
			}
			if (!getDriver().findElement(By.id("HasOtherLoansNo")).isSelected()) {
				getDriver().findElement(By.id("HasOtherLoansNo")).click();
			}
			Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		}

	}

	@Test(enabled = false)
	// deprecated behaviour
	public void test_CurrentAndPreviousAddressMovedInDate() throws Exception {

		// Testing Current Address Moved In Date
		// =====================================

		// Fill in form first, take defaults where possible otherwise fill with
		// valid data, except for Current Address Moved In Date

		// On which day of the week would you like to make your repayments -
		// Monday
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// What will you use your loan for - Household Goods
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Household Goods");

		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£100");

		// Please read our web-site cookie policy and tick this box to agree -
		// is Ticked
		if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
			getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("CookieAccepted")).click();
		}

		// Personal Details section
		// ========================

		// Applicants Title - Mr
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Mr");
		// Applicants Firstname - Tari
		getDriver().findElement(By.id("Forename")).sendKeys("Tari");
		// Applicants Surname - Ghan
		getDriver().findElement(By.id("Surname")).sendKeys("Ghan");
		// Applicants DOB - Day - 1st
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText("01");
		// Applicants DOB - Month - January
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText("January");
		// Applicants DOB - Year - 1963
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText("1963");
		// Applicants Marital Status - Divorced
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Divorced");
		// Applicants Number Of Dependants - 0
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("0");

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - 07850121212
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// Applicant Email Address - tarighan@test.com
		getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");

		// Your Address
		// ------------

		// Applicants Residential Status - Owner Occupier
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Owner Occupier");

		// Fill in Your Finances section if quick apply route used
		if (gcb.gsQuickApply.equals("true")) {

			// Income source
			dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
			dropdown.selectByVisibleText("Benefits");

			// Income
			getDriver().findElement(By.id("Income")).clear();
			getDriver().findElement(By.id("Income")).sendKeys("300");

			// Income Frequency
			dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
			dropdown.selectByVisibleText("Weekly");

			// Income Method
			dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
			dropdown.selectByVisibleText("Direct Deposit");

			// Housing costs amount
			getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0");

			// Has Credit cards
			if (!getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
			}

			// Has Other Loans
			if (!getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
			}

			// Other outgoings
			getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0");

			// Consents and Use of Personal Information
			// Declaration
			getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).click();
			// Using my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).click();
			// Sharing my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).click();
			// Credit reference agencies
			getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).click();
			// Verifying my identity and fraud checks
			getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).click();
			// Access to information
			getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).click();
			// Marketing
			getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).click();

			// Have agreed to bureau search - Must tick to progress
			if (!getDriver().findElement(By.xpath("//input[@id='AgreedToBureauSearch']")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
		}

		// Applicants Current Address Moved In Month- Set to future date, note
		// that this should trigger
		// Previous Address section to be displayed as 2 addresses required if
		// moved in date less than 3 years

		// Calculate a future date

		String sWhichMonth, sWhichYear;
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());

		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);
		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("24");
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");

		// Applicants Previous Address Moved In Month - Set to previous month

		// Get previous month
		cal.add(Calendar.MONTH, -2);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Past Date: Previous Month:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Enter previous address details manually
		getDriver().findElement(By.id("PreviousAddressManualEntry")).click();
		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).sendKeys("2");
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Previous Street");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("BD5 8JQ");

		// Next Action: Your Finances - Submit page
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		// Assert Moved In Date cannot be in the future against field
		Assert.assertEquals("You must pick a date earlier than today", getDriver().findElement(By.xpath("//span[@data-valmsg-for='CurrentAddress.DisplayDateMovedIn']")).getText());
		// Assert Moved in Date cannot be in future against validation message
		// summary section
		Assert.assertEquals("You must pick a date earlier than today",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='CurrentAddress.DisplayDateMovedIn']")).getText());

		// Check that Previous address and Current address moved in dates cannot
		// coincide

		// Reset current address moved in date to the previous address moved in
		// date
		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert Moved In Date cannot be in the future against field
		Assert.assertEquals("The date you moved into your previous address must be before the date you moved into your current address",
				getDriver().findElement(By.xpath("//span[@data-valmsg-for='PreviousAddress.DisplayDateMovedIn']")).getText());
		// Assert Moved in Date cannot be in future against validation message
		// summary section
		Assert.assertEquals("The date you moved into your previous address must be before the date you moved into your current address",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='PreviousAddress.DisplayDateMovedIn']")).getText());

		// Get future date for previous address
		cal.add(Calendar.MONTH, 2);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Future Date: Next Month:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert Moved In Date cannot be in the future against field
		Assert.assertEquals("You must pick a date earlier than today", getDriver().findElement(By.xpath("//span[@data-valmsg-for='PreviousAddress.DisplayDateMovedIn']")).getText());
		// Assert Moved in Date cannot be in future against validation message
		// summary section
		Assert.assertEquals("You must pick a date earlier than today",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='PreviousAddress.DisplayDateMovedIn']")).getText());

		// Check that we can progress on when Moved in Dates conform to
		// validation checks

		// Get valid past date for previous address
		cal.add(Calendar.MONTH, -3);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Past Date: Previous Month:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Next Action: Your Finances or Review Your Quote - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		if (gcb.gsQuickApply.equals("true")) {
			gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
		}
		if (!gcb.gsQuickApply.equals("true")) {
			gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		}

		// ** End of Test **
	}

	// This will fail as defect not fixed bug
	@Test(enabled = false)
	public void test_CurrentAndPreviousAddressCannotCoincide() throws Exception {

		// Testing Current Address and Previous Address cannot be the same
		// ===============================================================

		// Fill in form first, take defaults where possible otherwise fill with
		// valid data, except for Current Address Moved In Date

		// On which day of the week would you like to make your repayments -
		// Monday
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// What will you use your loan for - Household Goods
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Household Goods");

		// For our own research, please tell us the minimum loan amount you
		// would find useful today - £100
		dropdown = new Select(getDriver().findElement(By.id("MinimumLoanValue")));
		dropdown.selectByVisibleText("£100");

		// Please read our web-site cookie policy and tick this box to agree -
		// is Ticked
		if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
			getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("CookieAccepted")).click();
		}

		// Personal Details section
		// ========================

		// Applicants Title - Mr
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Mr");
		// Applicants Firstname - Tari
		getDriver().findElement(By.id("Forename")).sendKeys("Tari");
		// Applicants Surname - Ghan
		getDriver().findElement(By.id("Surname")).sendKeys("Ghan");
		// Applicants DOB - Day - 1st
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText("01");
		// Applicants DOB - Month - January
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText("January");
		// Applicants DOB - Year - 1963
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText("1963");
		// Applicants Marital Status - Divorced
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Divorced");
		// Applicants Number Of Dependants - 0
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("0");

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - 07850121212
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// Applicant Email Address - tarighan@test.com
		getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");

		// Your Address
		// ------------

		// Applicants Residential Status - Owner Occupier
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Owner Occupier");

		// Fill in Your Finances section if quick apply route used
		if (gcb.gsQuickApply.equals("true")) {

			// Income source
			dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
			dropdown.selectByVisibleText("Benefits");

			// Income
			getDriver().findElement(By.id("Income")).clear();
			getDriver().findElement(By.id("Income")).sendKeys("300");

			// Income Frequency
			dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
			dropdown.selectByVisibleText("Weekly");

			// Income Method
			dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
			dropdown.selectByVisibleText("Direct Deposit");

			// Housing costs amount
			getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0");

			// Has Credit cards
			if (!getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
			}

			// Has Other Loans
			if (!getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
			}

			// Other outgoings
			getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0");

			// Consents and Use of Personal Information
			// Declaration
			getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).click();
			// Using my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).click();
			// Sharing my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).click();
			// Credit reference agencies
			getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).click();
			// Verifying my identity and fraud checks
			getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).click();
			// Access to information
			getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).click();
			// Marketing
			getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).click();

			// Have agreed to bureau search - Must tick to progress
			if (!getDriver().findElement(By.xpath("//input[@id='AgreedToBureauSearch']")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
		}

		// Applicants Current Address Moved In Month- Set to a few months in
		// past to trigger the previous
		// address section when moved in date less than 3 years ago

		// Calculate a recent moved in date

		String sWhichMonth, sWhichYear;
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		// Get date 6 months ago
		cal.add(Calendar.MONTH, -6);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Moved In Date in the past 6 months ago: Next Month:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Calculate a previous address moved in date, say 1 year ago

		// Get previous address a year ago
		cal.add(Calendar.YEAR, -1);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Previous Address Moved In Date a year ago: Year:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Test current and previous address - Same House Number and Post Code
		// is minimum check, should be case insensitive and for post code
		// insensitive to white space

		// Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);
		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("24");
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");

		getDriver().findElement(By.id("PreviousAddressManualEntry")).sendKeys(Keys.ENTER);
		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).sendKeys("24");
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("Bd74bg");

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert previous address cannot be the same as current address against
		// validation message summary section
		Assert.assertEquals("Your previous address looks the same as your current address, please check and try again",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='']")).getText());

		// Test current and previous address - Same House/Building name and Post
		// Code is minimum check, should be case insensitive

		// Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);
		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_BuildingName")).sendKeys("Enterprise House");
		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");

		getDriver().findElement(By.id("PreviousAddressManualEntry")).click();
		getDriver().findElement(By.id("PreviousAddress_BuildingName")).sendKeys("ENTERPRISE HOUSE");
		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("BD7 4BG");

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert previous address cannot be the same as current address against
		// validation message summary section
		Assert.assertEquals("Your previous address looks the same as your current address, please check and try again",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='']")).getText());

		// Test current and previous address - Same Flat Number and Post Code is
		// minimum check, should be case insensitive

		// Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);
		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys("1A");
		getDriver().findElement(By.id("CurrentAddress_BuildingName")).clear();
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");

		getDriver().findElement(By.id("PreviousAddressManualEntry")).click();
		getDriver().findElement(By.id("PreviousAddress_FlatNumber")).sendKeys("1a");
		getDriver().findElement(By.id("PreviousAddress_BuildingName")).clear();
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("BD7 4BG");

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert previous address cannot be the same as current address against
		// validation message summary section
		Assert.assertEquals("Your previous address looks the same as your current address, please check and try again",
				getDriver().findElement(By.xpath("//div[@class='validation-summary-errors']//li[@data-field='']")).getText());

		// ** End of Test **
	}

	@Test(enabled = false)
	public void test_CurrentAndPreviousAddressManualEntryOfInvalidPostcodes() throws Exception {

		// Testing Current Address and Previous Address manual entry of post
		// codes
		// =======================================================================

		// Fill in form first, take defaults where possible otherwise fillf with
		// valid data

		// On which day of the week would you like to make your repayments -
		// Monday
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// dropdown.selectByVisibleText("Monday");
		// getDriver().findElement(By.id("MinimumLoanValue")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));

		getDriver().findElement(By.linkText("Monday")).click();

		// What will you use your loan for - Household Goods
		Select dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Household Goods");

		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£100");

		// Please read our web-site cookie policy and tick this box to agree -
		// is Ticked
		if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
			getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("CookieAccepted")).click();
		}

		// Personal Details section
		// ========================

		// Applicants Title - Mr
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Mr");
		// Applicants Firstname - Tari
		getDriver().findElement(By.id("Forename")).sendKeys("Tari");
		// Applicants Surname - Ghan
		getDriver().findElement(By.id("Surname")).sendKeys("Ghan");
		// Applicants DOB - Day - 1st
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText("01");
		// Applicants DOB - Month - January
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText("January");
		// Applicants DOB - Year - 1963
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText("1963");
		// Applicants Marital Status - Divorced
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Divorced");
		// Applicants Number Of Dependants - 0
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("0");

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - 07850121212
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// Applicant Email Address - tarighan@test.com
		getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");

		// Your Address
		// ------------

		// Applicants Residential Status - Owner Occupier
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Owner Occupier");

		// Fill in Your Finances section if quick apply route used
		if (gcb.gsQuickApply.equals("true")) {

			// Income source
			dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
			dropdown.selectByVisibleText("Benefits");

			// Income
			getDriver().findElement(By.id("Income")).clear();
			getDriver().findElement(By.id("Income")).sendKeys("300");

			// Income Frequency
			dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
			dropdown.selectByVisibleText("Weekly");

			// Income Method
			dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
			dropdown.selectByVisibleText("Direct Deposit");

			// Housing costs amount
			getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0");

			// Has Credit cards
			if (!getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasCreditCardsNo']")).click();
			}

			// Has Other Loans
			if (!getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).isSelected()) {
				getDriver().findElement(By.xpath("//input[@id='HasOtherLoansNo']")).click();
			}

			// Other outgoings
			getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0");

			// Consents and Use of Personal Information
			// Declaration
			getDriver().findElement(By.xpath("//a[@href='#consent-declaration']")).click();
			// Using my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-using-personal-info']")).click();
			// Sharing my personal information
			getDriver().findElement(By.xpath("//a[@href='#consent-sharing-personal-info']")).click();
			// Credit reference agencies
			getDriver().findElement(By.xpath("//a[@href='#consent-credit-reference-agencies']")).click();
			// Verifying my identity and fraud checks
			getDriver().findElement(By.xpath("//a[@href='#consent-fraud-checks']")).click();
			// Access to information
			getDriver().findElement(By.xpath("//a[@href='#consent-access-to-info']")).click();
			// Marketing
			getDriver().findElement(By.xpath("//a[@href='#consent-marketing']")).click();

			// Have agreed to bureau search - Must tick to progress
			if (!getDriver().findElement(By.xpath("//input[@id='AgreedToBureauSearch']")).isSelected()) {
				getDriver().findElement(By.id("AgreedToBureauSearch")).click();
			}
		}

		// Applicants Current Address Moved In Month- Set to a few months in
		// past to trigger the previous
		// address section when moved in date less than 3 years ago

		// Calculate a recent moved in date

		String sWhichMonth, sWhichYear;
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		// Get date 6 months ago
		cal.add(Calendar.MONTH, -6);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Moved In Date in the past 6 months ago: Next Month:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Calculate a previous address moved in date, say 1 year ago

		// Get previous address a year ago
		cal.add(Calendar.YEAR, -1);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Previous Address Moved In Date a year ago: Year:" + sWhichMonth + " Year:" + sWhichYear);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Test with just alphabetic post code

		// Enter current address details manually - With invalid post code
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);

		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("2");
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Godwin Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("LEEDS");

		// getDriver().findElement(By.id("PreviousAddressManualEntry")).click();
		getDriver().findElement(By.id("PreviousAddressManualEntry")).sendKeys(Keys.ENTER);

		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).sendKeys("4");
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Godwin Street");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("Leeds");

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert that current address post code is invalid
		Assert.assertEquals("The field Postcode is invalid.", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		// Assert that previous address post code is invalid
		Assert.assertEquals("The field Postcode is invalid.", getDriver().findElement(By.xpath("//span[@for='PreviousAddress_Postcode']")).getText());

		// Test with just alphanumeric post code

		// Enter current address details manually - With invalid post code
		getDriver().findElement(By.id("CurrentAddress_Postcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("ZZ1 1ZZ");

		getDriver().findElement(By.id("PreviousAddress_Postcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("zz11zz");

		// Next Action: Your Finances - Submit page
		getDriver().findElement(By.id("ContinueButton")).click();

		// Assert that current address post code is invalid
		Assert.assertEquals("The field Postcode is invalid.", getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		// Assert that previous address post code is invalid
		Assert.assertEquals("The field Postcode is invalid.", getDriver().findElement(By.xpath("//span[@for='PreviousAddress_Postcode']")).getText());

		// Test with just special British Army Post Office post code, these can
		// take a valid format i.e BF1 1AA is Lisburn Northern Island

		// // this postcode is no longer valid
		// // Enter current address details manually - With invalid post code
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).clear();
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BF1 1AA");
		//
		// getDriver().findElement(By.id("PreviousAddress_Postcode")).clear();
		// getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("bf11Aa");
		//
		// // Next Action: Your Finances - Submit page
		// // getDriver().findElement(By.id("ContinueButton")).click();
		// getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);
		//
		// // NOTE: at the moment this step fails as above two postcodes are
		// // accepted as valid
		//
		// waitForVisibilityOfElement(By.xpath("//span[@for='CurrentAddress_Postcode']"));
		// // Assert that current address post code is invalid
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='CurrentAddress_Postcode']")).getText());
		// // Assert that previous address post code is invalid
		// Assert.assertEquals("The field Postcode is invalid.",
		// getDriver().findElement(By.xpath("//span[@for='PreviousAddress_Postcode']")).getText());
		// ** End of Test **
	}

	private void waitForVisibilityOfElement(By by) {
		// wait for postcode textbox to appear
		WebDriverWait wait = new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT);
		wait.until(ExpectedConditions.visibilityOf(getDriver().findElement(by)));
	}

	@Test
	public void test_PreviousAddressMissing() throws Exception {

		// Testing for previous address is missing
		// =======================================

		// Fill in form first, take defaults where possible otherwise fill with
		// valid data

		// // On which day of the week would you like to make your repayments -
		// // Monday
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");
		// getDriver().findElement(By.id("MinimumLoanValue")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("LoanPurposeValue")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));

		// getDriver().findElement(By.linkText("Monday")).click();

		// What will you use your loan for - Household Goods
		dropdown = new Select(getDriver().findElement(By.id("LoanPurposeValue")));
		dropdown.selectByVisibleText("Household Goods");

		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£100");

		// Please read our web-site cookie policy and tick this box to agree -
		// is Ticked
		if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
			getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
			getDriver().findElement(By.id("CookieAccepted")).click();
		}

		// Personal Details section
		// ========================

		// Applicants Title - Mr
		dropdown = new Select(getDriver().findElement(By.id("CustomerTitle")));
		dropdown.selectByVisibleText("Mr");
		// Applicants Firstname - Tari
		getDriver().findElement(By.id("Forename")).sendKeys("Tari");
		// Applicants Surname - Ghan
		getDriver().findElement(By.id("Surname")).sendKeys("Ghan");
		// Applicants DOB - Day - 1st
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		dropdown.selectByVisibleText("01");
		// Applicants DOB - Month - January
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		dropdown.selectByVisibleText("January");
		// Applicants DOB - Year - 1963
		dropdown = new Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		dropdown.selectByVisibleText("1963");
		// Applicants Marital Status - Divorced
		dropdown = new Select(getDriver().findElement(By.id("MaritalStatusValue")));
		dropdown.selectByVisibleText("Divorced");
		// Applicants Number Of Dependants - 0
		dropdown = new Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		dropdown.selectByVisibleText("0");

		// Your Contact Details
		// --------------------

		// Applicant Mobile Phone - 07850121212
		getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// Applicant Email Address - tarighan@test.com
		getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");

		// Your Address
		// ------------

		// Applicants Residential Status - Owner Occupier
		dropdown = new Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		dropdown.selectByVisibleText("Owner Occupier");

		// Applicants Current Address Moved In Month- Set to todays date, note
		// that this should trigger
		// Previous Address section to be displayed as 2 addresses required if
		// moved in date less than 3 years

		// Get todays date

		String sWhichMonth, sWhichYear;
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());

		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.ENTER);

		waitForVisibilityOfElement(By.id("CurrentAddress_Postcode"));

		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("24");
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");

		// Next Action: Your Finances - Submit page
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		// Assert that current address has been lived in less than 3 year,
		// prompt to enter previous address against validation message summary
		// section
		Assert.assertEquals("Moved in date must be before today", getDriver().findElement(By.xpath("//span[@for='PreviousAddress_DisplayDateMovedIn_Year']")).getText());
		Assert.assertEquals("Please provide your previous address", getDriver().findElement(By.xpath("//span[@for='PreviousAddress_PreviousAddressSearchPostcode']")).getText());

		// ** End of Test **
	}

	@Test
	public void test_QASCurrentAddressEditable() {

		// Postcode BD1 2SU should only return 1 address at No 1 Godwin Street
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_CurrentAddressSearchPostcode")).sendKeys("BD1 2SU");
		// Search now
		// getDriver().findElement(By.id("CurrentAddressAddressSearch")).click();
		getDriver().findElement(By.id("CurrentAddressAddressSearch")).sendKeys(Keys.ENTER);

		// wait for element to be stale and then back again
		By by = By.id("CurrentAddress_CurrentAddressChosenAddress");
		waitForStaleThenActiveElement(by);

		Select dropdown;
		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("value"));
		Assert.assertEquals("1", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("value"));
		Assert.assertEquals("Godwin Street", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("value"));
		Assert.assertEquals("", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("value"));
		Assert.assertEquals("BRADFORD", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("value"));
		Assert.assertEquals("West Yorkshire", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("value"));
		Assert.assertEquals("BD1 2SU", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("value"));

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("readOnly"));

		// getDriver().findElement(By.id("CurrentAddressEditAddress")).click();
		getDriver().findElement(By.id("CurrentAddressEditAddress")).sendKeys(Keys.ENTER);

		// Assert that address lines are enabled for re-input after QAS search
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_FlatNumber")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_BuildingName")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_HouseNumber")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_Street")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_District")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_TownCity")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_County")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("CurrentAddress_Postcode")).getAttribute("type"));

		// Check that we can amend the fields
		getDriver().findElement(By.id("CurrentAddress_FlatNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_FlatNumber")).sendKeys("Deck A");
		getDriver().findElement(By.id("CurrentAddress_BuildingName")).clear();
		getDriver().findElement(By.id("CurrentAddress_BuildingName")).sendKeys("Enterprise House");
		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).clear();
		getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("1701");
		getDriver().findElement(By.id("CurrentAddress_Street")).clear();
		getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Bridge Street");
		getDriver().findElement(By.id("CurrentAddress_District")).clear();
		getDriver().findElement(By.id("CurrentAddress_District")).sendKeys("Solar System");
		getDriver().findElement(By.id("CurrentAddress_TownCity")).clear();
		getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Earth");
		getDriver().findElement(By.id("CurrentAddress_Postcode")).clear();
		getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("EE1 1EE");

		// ** End Of Test **
	}

	@Test
	public void test_PreviousAddressEditable() throws Exception {

		// Applicants Current Address Moved In Month- Set to a few months in
		// past to trigger the previous
		// address section when moved in date less than 3 years ago

		// Calculate a recent moved in date

		String sWhichMonth, sWhichYear;
		Calendar cal = Calendar.getInstance();
		log.info("Today: " + cal.getTime());
		// Get date 6 months ago
		cal.add(Calendar.MONTH, -6);
		sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		log.info("Calculated Moved In Date in the past 6 months ago: Next Month:" + sWhichMonth + " Year:" + sWhichYear);

		Select dropdown;

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		dropdown.selectByVisibleText(sWhichMonth);

		dropdown = new Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		dropdown.selectByVisibleText(sWhichYear);

		// Postcode BD1 2SU should only return 1 address at No 1 Godwin Street
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchHouseNameOrNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_PreviousAddressSearchPostcode")).sendKeys("BD1 2SU");
		// Search now
		// getDriver().findElement(By.id("PreviousAddressAddressSearch")).click();
		getDriver().findElement(By.id("PreviousAddressAddressSearch")).sendKeys(Keys.ENTER);
		By by = By.id("PreviousAddress_PreviousAddressChosenAddress");

		waitForStaleThenActiveElement(by);

		dropdown = new Select(getDriver().findElement(by));
		if (dropdown.getOptions().size() != 2) {
			Assert.fail("Failed: Expecting only 1 address to be listed");
		}

		// Assert that the single address found is selected automatically
		Assert.assertEquals("Provident Financial, 1 Godwin Street, BRADFORD, West Yorkshire, BD1 2SU", dropdown.getFirstSelectedOption().getText());

		// Assert that selected address is pre-populated in the individual
		// address lines

		// Assert.assertEquals("",getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("placeholder"));
		// Assert.assertEquals("",getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("placeholder"));
		// Assert.assertEquals("1",getDriver().findElement(By.id("PreviousAddress_BuildingNumber]")).getAttribute("value"));
		// Assert.assertEquals("Godwin Street",getDriver().findElement(By.id("PreviousAddress_Street")).getText());
		// Assert.assertEquals("",getDriver().findElement(By.id("PreviousAddress_District")).getText());
		// Assert.assertEquals("BRADFORD",getDriver().findElement(By.id("PreviousAddress_TownCity")).getText());
		// Assert.assertEquals("West Yorkshire",getDriver().findElement(By.id("PreviousAddress_County")).getText());
		// Assert.assertEquals("BD1 2SU",getDriver().findElement(By.id("PreviousAddress_Postcode")).getText());

		// Assert that address lines are not enabled for re-input after QAS
		// search
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("readOnly"));
		Assert.assertEquals("true", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("readOnly"));

		// getDriver().findElement(By.id("PreviousAddressEditAddress")).click();
		getDriver().findElement(By.id("PreviousAddressEditAddress")).sendKeys(Keys.ENTER);

		// Assert that address lines are enabled for re-input after QAS search
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_FlatNumber")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_BuildingName")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_HouseNumber")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_Street")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_District")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_TownCity")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_County")).getAttribute("type"));
		Assert.assertEquals("text", getDriver().findElement(By.id("PreviousAddress_Postcode")).getAttribute("type"));

		// Check that we can amend the fields
		getDriver().findElement(By.id("PreviousAddress_FlatNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_FlatNumber")).sendKeys("Deck A");
		getDriver().findElement(By.id("PreviousAddress_BuildingName")).clear();
		getDriver().findElement(By.id("PreviousAddress_BuildingName")).sendKeys("Enterprise House");
		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).clear();
		getDriver().findElement(By.id("PreviousAddress_HouseNumber")).sendKeys("1701");
		getDriver().findElement(By.id("PreviousAddress_Street")).clear();
		getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Bridge Street");
		getDriver().findElement(By.id("PreviousAddress_District")).clear();
		getDriver().findElement(By.id("PreviousAddress_District")).sendKeys("Solar System");
		getDriver().findElement(By.id("PreviousAddress_TownCity")).clear();
		getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Earth");
		getDriver().findElement(By.id("PreviousAddress_Postcode")).clear();
		getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("EE1 1EE");

		// ** End of Test **
	}

}
