package automation.tests.powercurve.pcow;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.ProxySelector;
import java.util.Properties;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.support.SoapUIException;

public class PowercurveWrapperTest {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	String soapUITestFile = "PowerCurveDecisioningWrapperService-soapui-project.xml";
	String soapUITestCase = "B2C Preliminary Accept";
	String soapUITestSuite = "B2C";

	@Test
	public void test() throws XmlException, SoapUIException, Exception {
		soapUIB2CPrelimCall("TalTestDeployOne", "TalTestDeployOne", "1972-01-02T00:00:00");
	}

	public String _getConfigProperty(String psName) throws Exception {

		Properties prop = new Properties();
		String sTmp;
		InputStream input = null;

		input = new FileInputStream("target/classes/config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sTmp = prop.getProperty(psName);
		log.info("_getConfigProperty: " + psName + "=" + sTmp);
		return sTmp;
	}

	public void soapUIB2CPrelimCall(String firstname, String lastname, String dob) throws XmlException, SoapUIException, Exception {
		String gsSOAPUIProjectFolder = _getConfigProperty("SOAPUIProjectFolder");
		String powerCurveWrapperServer = _getConfigProperty("PowerCurveWrapperServer");

		log.info("SoapUIB2CPrelimCall - folder:  " + gsSOAPUIProjectFolder + " testsuite: " + soapUITestSuite + " testcase: " + soapUITestCase);

		ProxySelector proxy = ProxySelector.getDefault();
		WsdlProject project = new WsdlProject(gsSOAPUIProjectFolder + soapUITestFile);
		ProxySelector.setDefault(proxy);

		TestSuite testSuite = project.getTestSuiteByName(soapUITestSuite);
		TestCase testCase = testSuite.getTestCaseByName(soapUITestCase);

		testCase.setPropertyValue("firstname", firstname);
		testCase.setPropertyValue("surname", lastname);
		testCase.setPropertyValue("dob", dob);
		testCase.setPropertyValue("server", powerCurveWrapperServer);

		TestRunner runner = testCase.run(new PropertiesMap(), false);

		log.info("Runner Reason: " + runner.getReason());
		log.info("Runner Status: " + runner.getStatus());

		Assert.assertEquals(runner.getStatus().toString(), "FINISHED", "SoapUI Scenario Status");
	}
}
