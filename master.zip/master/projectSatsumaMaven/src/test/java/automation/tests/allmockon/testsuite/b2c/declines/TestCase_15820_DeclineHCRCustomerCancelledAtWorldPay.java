package automation.tests.allmockon.testsuite.b2c.declines;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_15820_DeclineHCRCustomerCancelledAtWorldPay extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_DeclineCustomerCancelledAtWorldPaySecureCardRegistrationPage() throws Exception {
		// Initialise Agreement Number for new applicant
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer
		gcb.prGetApplicantProfile(4);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		//
		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// =======================

		// Landed on WorldPay - Secure Card Registration page
		Assert.assertTrue(getDriver().getTitle().contains("Welcome to WorldPay"));
		Assert.assertEquals("Secure Card Registration Page", getDriver().findElement(By.xpath("//h1")).getText());

		// Customer cancels
		getDriver().findElement(By.id("op-DPCancel")).click();

		gcb.prAssertOnPageWorldPayPaymentCancelled(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================
		//
		// gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check that no new proposal agreement is created in PAN to record
		// decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Fail test if an agreement is found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Fail: An agreement found in PAN, should not have been created.");
		}

	}

	@Test
	public void test_DeclineCustomerCancelledAtWorldPayCardDetailsPage() throws Exception {

		// Initialise Agreement Number for new applicant
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer
		gcb.prGetApplicantProfile(4);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// =======================

		// Landed on WorldPay - Secure Card Registration page
		Assert.assertTrue(getDriver().getTitle().contains("Welcome to WorldPay"));
		Assert.assertEquals("Secure Card Registration Page", getDriver().findElement(By.xpath("//h1")).getText());

		// Has Visa Debit
		if (gcb.gsCreditCardType.equals("Visa Debit")) {
			getDriver().findElement(By.xpath("//input[@name='op-DPChoose-VISA^SSL']")).click();
		} else {
			Assert.fail("Aborted: Applicant Profile used must define CreditCardType as Visa Debit");
		}

		// Landed on WorldPay - Card Details page
		//(new WebDriverWait(getDriver(), 60)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//img[@alt='Cancel']")));
		Assert.assertEquals("WorldPay card payment", getDriver().getTitle());

		getDriver().findElement(By.xpath("//img[@alt='Cancel']")).click();

		gcb.prAssertOnPageWorldPayPaymentCancelled(gsSatsumaSiteUrl);

		// // Home Credit page
		// // ================
		//
		// gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check that no new proposal agreement is created in PAN to record
		// decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Fail test if an agreement is found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Fail: An agreement found in PAN, should not have been created.");
		}

	}
}
