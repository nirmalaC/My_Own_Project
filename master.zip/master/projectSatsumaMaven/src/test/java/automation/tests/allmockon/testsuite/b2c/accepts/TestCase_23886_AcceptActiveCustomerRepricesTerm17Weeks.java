package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23886_AcceptActiveCustomerRepricesTerm17Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice17weeks1020() throws Exception {
		existingCustomerAccepts("1020", "17", "Weekly", "680", 133);
	}

	@Test
	public void test_Reprice17weeks1110() throws Exception {
		existingCustomerAccepts("1110", "17", "Weekly", "740", 133);
	}

	@Test
	public void test_Reprice17weeks1280() throws Exception {
		existingCustomerAccepts("1210", "17", "Weekly", "1000", 133);
	}

}
