package automation.tests.sandpiper.mockson.b2c.providentdatawrapper;

import java.io.IOException;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.support.SoapUIException;

public class B2CReferred109Fraud extends AllMocksOnTest {

	private static final int MONTHLY_APPLICANT_ID = 284;
	private static final int WEEKLY_APPLICANT_ID = 171;

	@Test
	public void B2CReferralWeekly() throws Exception {
		test109(WEEKLY_APPLICANT_ID);
	}

	@Test
	public void B2CReferralMonthly() throws Exception {
		test109(MONTHLY_APPLICANT_ID);
	}

	protected void test109(int applicantId) throws Exception, XmlException, SoapUIException, IOException {
		// needs a row in the STKXXSatsumaFraud.dbo.Blacklist
		final String FRAUD_TRIGGER_MOBILE_NO = "07540203000";

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(applicantId);

		gcb.prCreateUniquePerson();

		// this mobile number triggers fraud warning
		gcb.gsMobileNumber = FRAUD_TRIGGER_MOBILE_NO;

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Former Paid Up Vulnerable Completion page
		// =========================================

		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// verify fraud in PAN
		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 109
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertTrue(getDriver().getPageSource().contains("109"));
		// Expect agreement to be referred for fraud 109
		// set Secondary Referral
		Assert.assertTrue(getDriver().getPageSource().contains("Applicant found on the Fraud Exclusion List"));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

}
