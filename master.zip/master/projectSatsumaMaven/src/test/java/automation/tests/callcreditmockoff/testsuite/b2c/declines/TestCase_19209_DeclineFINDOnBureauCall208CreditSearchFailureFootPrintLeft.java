package automation.tests.callcreditmockoff.testsuite.b2c.declines;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.CallCreditOffTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class TestCase_19209_DeclineFINDOnBureauCall208CreditSearchFailureFootPrintLeft extends CallCreditOffTest {

	@Test
	public void test_HardDeclineWhenExperianCustomerMismatch() throws Exception {

		// Data Preparation
		// ================

		// Get a application profile for Bureau result 208 - Credit Search
		// Failure - Footprint Left, where the data provided doesn’t match the
		// data in Experian database
		// Mrs Elaine-Stell Goodnan
		gcb.prGetApplicantProfile(60);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			log.warn("Aborted: An agreement is found, trying to remove");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Finished Decline page
		// =====================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result22
		// Have we landed on the FIND Hard Decline page in context that the
		// applicant is not successful on this occasion and credit check has
		// been performed.
		gcb.prAssertOnPageFinishedIDResult22(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "Credit Search Failure - Footprint Left" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 208 - Credit Search Failure -
		// Footprint Left.
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		assertTrue(getDriver().getPageSource().contains("Credit Search Failure – Footprint Left"));

		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("title")));
		dropdown.selectByVisibleText(gcb.gsTitle);

		String tmpStr = getDriver().findElement(By.id("surname")).getAttribute("value");
		if (!(tmpStr.contains("AutoDel"))) {
			getDriver().findElement(By.id("surname")).clear();
			getDriver().findElement(By.id("surname")).sendKeys("AutoDel" + tmpStr);
		}
		getDriver().findElement(By.id("PanLinkSubmit_5")).click();

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}
