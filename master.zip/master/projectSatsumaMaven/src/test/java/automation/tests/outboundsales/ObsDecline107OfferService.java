package automation.tests.outboundsales;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnOutboundTest;
import automation.test.offerservice.enums.OfferPartyStatus;

public class ObsDecline107OfferService extends AllMocksOnOutboundTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	String pancode = "107";
	String OUTBOUND_URL = "";
	private final static int WEEKLY_APPLICANT_ID = 363;

	@Test
	public void ObsNbWeeklySXRecentDecline() throws Exception {
		OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);

		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		gcb.seedFLEIneligibleOffer("SX", OfferPartyStatus.UNKNOWN, false);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		test107AboutYouDecline(pancode + "SX", WEEKLY_APPLICANT_ID, "SX");
	}

	@Test
	public void ObsFLWeeklyDeclineCFFraud() throws Exception {
		OUTBOUND_URL = outbound.getOutboundSalesServer();

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(WEEKLY_APPLICANT_ID);

		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "1000", "12", "Monthly");

		// gcb.seedFLEEligibleOffer(false, 2000);
		gcb.seedFLEIneligibleOffer("CF", OfferPartyStatus.UNKNOWN, false);

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		log.debug("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB + " " + gcb.gsPostcode);

		gcb.seedFLEIneligibleOffer("CF", OfferPartyStatus.ACTIVE, false);

		test107AboutYouDecline(pancode + "CF", WEEKLY_APPLICANT_ID, "CF");

	}

	private void test107AboutYouDecline(String pancode, int applicantId, String source) throws Exception {

		getDriver().manage().deleteAllCookies();
		getDriver().get(OUTBOUND_URL + "/development/backend/killsession");
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		outbound.navigateToHomePage();

		outbound.assertOnPageHome(OUTBOUND_URL);

		gcb.prClickForNextAction();

		outbound.assertOnPageAboutYou(OUTBOUND_URL);

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		if (source.equals("SX")) {
			outbound.prAssertOnPageFinishedIDResult8(OUTBOUND_URL + "/");
		} else if (source.equals("CF")) {
			outbound.prAssertOnPageFinishedIDResult5(OUTBOUND_URL + "/");
		} else {
			outbound.prAssertOnPageFinishedIDResult5(OUTBOUND_URL);
		}

		// String reasonCode =
		// PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname,
		// gcb.gsSurname);
		// String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB,
		// gcb.gsFirstname, gcb.gsSurname);
		//
		// Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode,
		// ApplicationType.OBS), "Reason Code");
		// Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode,
		// ApplicationType.OBS), "Group Code");
	}

	@AfterMethod
	public void afterTest() throws Exception {
	}

}
