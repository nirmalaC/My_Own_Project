package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;
import automation.dao.SatsumaCustomer;

import com.eviware.soapui.support.SoapUIException;

public class TestSuite_4671_MobileApiFurtherLendingTest extends MobileAPITest {

	public final static String APP_VERSION_NO = "1.1";

	@Test
	public void testCase_32364_ApplyFLOneActive() throws Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement("100", "13");
		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		float eligibleAmount = gcb.calcEligibleAmount(100, 71.58f);
		gcb.seedFLEEligibleOffer(false, (double) eligibleAmount);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		Assert.assertEquals(Float.parseFloat(from(myAccountString).get("EligibleAmount").toString()), eligibleAmount);

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(eligibleAmount)));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		 gcb.prClickForNextAction1();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}

	@Test
	public void testCase_31899_ApplyFLOnePaidUp() throws Exception {
		final String PLATFORM = "Android";

		satsumaCustomer = addNewPaidUpAgreement("800", "52");
		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		float eligibleAmount = gcb.calcEligibleAmount(800, 0f);
		gcb.seedFLEEligibleOffer(true, (double) eligibleAmount);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		Assert.assertEquals(Float.parseFloat(from(myAccountString).get("EligibleAmount").toString()), eligibleAmount);

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(eligibleAmount)));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}

	@Test
	public void testCase_32365_ApplyFLOneActiveMonthly() throws Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement("100", "12", "monthly");

		// set back frequency to weekly 13
		gcb.gsRequestedTerm = "13";
		gcb.gsRepaymentFrequency = "Weekly";

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		float eligibleAmount = gcb.calcEligibleAmount(100, 71.58f);

		gcb.seedFLEEligibleOffer(false, (double) eligibleAmount);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		Assert.assertEquals(Float.parseFloat(from(myAccountString).get("EligibleAmount").toString()), eligibleAmount);

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(eligibleAmount)));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}

	@Test
	public void testCase_31893_ApplyFLNoEligible() throws Exception {
		final String PLATFORM = "Android";

		satsumaCustomer = addNewAgreement();
		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		// sends you to login page doesn't log you in as you are not eligible
		// for FL
		login.assertOnPageFLApplyForALoan(gsSatsumaSiteUrl);
	}

	@Test
	public void testCase_32366_ApplyFLOneActiveOnePaidUp() throws Exception {
		final String PLATFORM = "Android";

		satsumaCustomer = addNewPaidUpAgreement("800", "52");
		satsumaCustomer = addFurtherHalfPaidUpAgreement(satsumaCustomer.getAgreements().get(0));

		// Get Expected Loan Offer Details, 2nd loan is only for £100 over 13
		// weeks
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, 13, 100);

		gcb.gsRequestedLoanAmount = "100";
		gcb.gsRequestedTerm = "13";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		float eligibleAmount = gcb.calcEligibleAmount(100, 71.58f);

		gcb.seedFLEEligibleOffer(false, (double) eligibleAmount);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		Assert.assertEquals(Float.parseFloat(from(myAccountString).get("EligibleAmount").toString()), eligibleAmount);

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(eligibleAmount)));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	}

	@Test(enabled = false)
	// not completed yet
	public void testCase_32368_ApplyFLB2B() throws XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "Android";

		SatsumaCustomer satsumaCustomer = addB2BAgreement();

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		String accessToken = from(responseString).get("access_token");
		String refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().body("Email", equalTo(satsumaCustomer.getEmailAddress())).statusCode(200).extract().response().asString();

		float eligibleAmount = gcb.calcEligibleAmount(800, 0f);
		Assert.assertEquals(Float.parseFloat(from(myAccountString).get("EligibleAmount").toString()), eligibleAmount);

		// journeyLink furtherlending
		String furtherLendingLink = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString().replace("\"", "");

		log.info(furtherLendingLink);

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		getDriver().get(furtherLendingLink);

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(eligibleAmount)));

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		getDriver().findElement(By.id("ContinueButtonStep1")).sendKeys(Keys.PAGE_DOWN);
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		gcb.prClickForNextAction();

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);
	}

}
