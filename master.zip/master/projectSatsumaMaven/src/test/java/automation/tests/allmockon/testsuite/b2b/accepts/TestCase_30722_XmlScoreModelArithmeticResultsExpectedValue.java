package automation.tests.allmockon.testsuite.b2b.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

/*
 * System Test
 This test is concerned with ensuring that the calculation of the XML Scorecard Score is correct.
 To test use the attached WCFStorm XML as a template and modify using the parameterised data in the test case. Use the attached Experian mock response and place in D:\inetpub\wwwroot\Satsuma.Service\bin\Responses\Experian.Interactive on the appropriate App Server.
 Ensure that the SatsumaBrokerPreliminaryEnhancedWorkflow has ItemId="61" : SamplingRatioA="0.00".
 Experian Mock must be ON, all others can be ON or OFF

 15.09 - CV - now out of scope as strategy change in powercurve means application variables no longer used in score.

 */

// same as test case TestCase_15655_AcceptHappyPath100Over13
public class TestCase_30722_XmlScoreModelArithmeticResultsExpectedValue extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void fullTimeEmployedPaidWeekly() throws Exception {
		// weekly full time employed
		gcb.prGetApplicantProfile(186);
		// create unique person but doesn't change DOB
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// gcb.setRandomDOB("1967");
		gcb.gsDOB = "01/01/1967";

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_XmlFilter", "TestCase_30710_Satsuma B2B: Xml Filter", "Aspire", "");
		// // TestCase testCase =
		// // gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter",
		// // "TestCase_30708_Satsuma B2B: Accept Happy Path", "Aspire", "");
		//
		// String decisionRef =
		// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		//
		// // // verify predip score
		// // verifyXmlScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// // "467.1304509");

		Assert.assertEquals(PowerCurveDBHelper.getScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 467.0f, "Score");
	}

	// weekly unemployed
	@Test
	public void UnemployedPaidWeekly() throws Exception {
		// weekly unemployed
		gcb.prGetApplicantProfile(187);
		// create unique person but doesn't change DOB
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		gcb.gsDOB = "01/01/1967";
		// gcb.gsDOB = gcb.formatDate(gcb.gsDOB, "dd/MM/yyyy", "MM/dd/yyyy");

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_XmlFilter", "TestCase_30710_Satsuma B2B: Xml Filter", "Aspire", "");
		// String decisionRef =
		// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		//
		// // verify predip score
		// verifyXmlScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "340.856412");

		Assert.assertEquals(PowerCurveDBHelper.getScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 340.0f, "Score");

	}

	// annually fulltimeemployed
	@Test
	public void fullTimeEmployedPaidAnnually() throws Exception {
		// weekly full time employed
		gcb.prGetApplicantProfile(188);
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		gcb.gsDOB = "03/03/1967";
		// gcb.gsDOB = gcb.formatDate(gcb.gsDOB, "dd/MM/yyyy", "MM/dd/yyyy");

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_XmlFilter", "TestCase_30710_Satsuma B2B: Xml Filter", "Aspire", "");
		// String decisionRef =
		// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		//
		// // verify predip score
		// verifyXmlScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "524.1097656");
		Assert.assertEquals(PowerCurveDBHelper.getScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 524.0f, "Score");

	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
