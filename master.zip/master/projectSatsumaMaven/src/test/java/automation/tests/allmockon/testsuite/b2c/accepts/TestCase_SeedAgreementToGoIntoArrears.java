package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.SkipException;
import org.testng.annotations.Test;

import automation.basetests.BrowserTest;

public class TestCase_SeedAgreementToGoIntoArrears extends BrowserTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {

		String sAgreementNumber = "";

		// customer goesintoarrears
		gcb.prGetApplicantProfile(291);

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			throw new SkipException("Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

	}

}
