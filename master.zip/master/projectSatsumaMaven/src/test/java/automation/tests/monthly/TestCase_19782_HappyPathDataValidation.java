package automation.tests.monthly;

import automation.basetests.AllMocksAcceptTests;

/* combination of different happy path scenarios with different data / customer info, data mapping information is checked by queryingthe database*/
/*****************
 * Tests,Loan term (weeks),Day to make repayments,Loan purpose,Title,Marital
 * Status,Dependants,Residence type,Moved in Month,Income Type,Income
 * Frequency,Payment Method,Credit Cards,Other Loans,sortcode,Account
 * number,Account holder Test 1,13,Monday,Household goods,Mr,Divorced,0,Owner
 * Occupier,January,Benefits,Weekly,Direct Debit,Yes,No,,, Test2,17,Tuesday,Home
 * Improvment,Mrs,Living with Partner,1,Living with parents,Febraury,Benefits
 * and Part time Employment,Fortnighlty,Cheque,No,Yes,,,
 * Test3,21,Wednesday,Family,Miss,Married,2,Tenant unfurnished,March,Benefits
 * and Full time Employment,Monthly,Cash,Yes,No,,,
 * Test4,26,Thursday,Vehicle,Ms,Separated,3+,Tenant furnished,April,Part time
 * Employment Only,Annually,Other,No,yes,,,
 * Test5,30,Friday,Holiday,Mr,Single,0,Council,May,Full Time Employment
 * Only,Weekly,Direct Debit,Yes,No,,, Test6,34,Monday,Debt
 * Repayment,Mrs,Widowed,1,Joint Owner,June,Pension,Fortnighlty,Cheque,No,Yes,,,
 * Test7,39,Tuesday,Personal,Miss,Divorced,2,Owner Occupier,July,Self
 * Employed,Monthly,Cash,Yes,No,,, Test8,43,Wednesday,Other,Ms,Living with
 * Partner,3+,Living with parents,August,Benefits,Annually,Other,No,Yes,,,
 * Test9,47,Thursday,Household goods,Mr,Married,0,Tenant
 * unfurnished,September,Benefits and Part time Employment,Weekly,Direct
 * Debit,Yes,No,,, Test10,52,Friday,Home Improvment,Mrs,Separated,1,Tenant
 * furnished,October,Benefits and Full time
 * Employment,Fortnighlty,Cheque,No,Yes,,,
 * Test11,13,Monday,Family,Miss,Single,2,Council,November,Part time Employment
 * Only,Monthly,Cash,Yes,Yes,,, Test12,17,Tuesday,Vehicle,Ms,Widowed,3+,Joint
 * Owner,December,Full Time Employment Only,Annually,Other,No,No,,, Test
 * 13,13,Monday,Personal Spend ,Mr,Other,0,Other,January,Student,Weekly,Direct
 * Debit,Yes,No,,, Test 14,17,Tuesday,General living expenses,Mrs,Living with
 * Partner,1,Living with parents,Febraury,Armed
 * Forces,Fortnighlty,Cheque,No,Yes,,, Test 15,21,Wednesday,Family
 * Occasion,Miss,Married,2,Tenant
 * furnished,March,Unemployed,Monthly,Cash,Yes,No,,, Test
 * 16,47,Thursday,Vehicle,Ms,Other,3+,Other,April,Employed
 * Temporaray,Annually,Other,No,yes,,, Test
 * 17,52,Friday,Holiday,Mr,Single,0,Council,May,Home Maker,Weekly,Direct
 * Debit,Yes,No,,, Test 18,13,Monday,General living expenses,Mr,Divorced,0,Owner
 * Occupier,January,Benefits,Weekly,Direct Debit,Yes,No,,,
 ***************************/
public class TestCase_19782_HappyPathDataValidation extends AllMocksAcceptTests {

	// private void newCustomerAcceptAndVerifyDataMappingKB(int
	// applicationProfileId) throws Exception {
	// newCustomerAccept(applicationProfileId);
	// String decisionRef =
	// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	// log.debug("decision ref: " + decisionRef);
	// // get knowledge base string from db(s)
	// String dataMappingString =
	// ZoralKnowledgeBaseHelper.getDataMappingString(gcb.knowledgeBaseDB,
	// gcb.zoralDB, gcb.connectivityDB, decisionRef);
	// XmlKnowledgeBase xmlKB = new XmlKnowledgeBase(dataMappingString);
	// verifyKnowledgeBaseAgainstCustomer(xmlKB);
	// }
	//
	// @Test
	// public void testRow1() throws Exception {
	// // 189
	// newCustomerAcceptAndVerifyDataMappingKB(189);
	// }
	//
	// @Test
	// public void testRow2() throws Exception {
	// // 190
	// newCustomerAcceptAndVerifyDataMappingKB(190);
	// }
	//
	// @Test
	// public void testRow3() throws Exception {
	// // 191
	// newCustomerAcceptAndVerifyDataMappingKB(191);
	// }
	//
	// @Test
	// public void testRow4() throws Exception {
	// // 192
	// newCustomerAcceptAndVerifyDataMappingKB(192);
	// }
	//
	// @Test
	// public void testRow5() throws Exception {
	// // 193
	// newCustomerAcceptAndVerifyDataMappingKB(193);
	// }
	//
	// @Test
	// public void testRow6() throws Exception {
	// // 194
	// newCustomerAcceptAndVerifyDataMappingKB(194);
	// }
	//
	// @Test
	// public void testRow7() throws Exception {
	// // 195
	// newCustomerAcceptAndVerifyDataMappingKB(195);
	// }
	//
	// @Test
	// public void testRow8() throws Exception {
	// // 196
	// newCustomerAcceptAndVerifyDataMappingKB(196);
	// }
	//
	// @Test
	// public void testRow9() throws Exception {
	// // 197
	// newCustomerAcceptAndVerifyDataMappingKB(197);
	// }
	//
	// @Test
	// public void testRow10() throws Exception {
	// // 198
	// newCustomerAcceptAndVerifyDataMappingKB(198);
	// }
	//
	// @Test
	// public void testRow11() throws Exception {
	// // 199
	// newCustomerAcceptAndVerifyDataMappingKB(199);
	// }
	//
	// @Test
	// public void testRow12() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(200);
	// }
	//
	// @Test
	// public void testRow13() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(201);
	// }
	//
	// @Test
	// public void testRow14() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(202);
	// }
	//
	// @Test
	// public void testRow15() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(203);
	// }
	//
	// @Test
	// public void testRow16() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(204);
	// }
	//
	// @Test
	// public void testRow17() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(205);
	// }
	//
	// @Test
	// public void testRow18() throws Exception {
	// newCustomerAcceptAndVerifyDataMappingKB(206);
	// }

}
