package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23510_AcceptNewCustomerRepricesTerm13Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice13weeks100() throws Exception {
		newCustomerAccept("100", "13", "Weekly", 208);
	}

	@Test
	public void test_Reprice13weeks200() throws Exception {
		newCustomerAccept("200", "13", "Weekly", 133);
	}

	@Test
	public void test_Reprice13weeks1000() throws Exception {
		newCustomerAccept("1000", "13", "Weekly", 133);
	}

}
