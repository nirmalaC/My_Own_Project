package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.tools.EntityHubHelper;

public class TestCase_11316_DeclineABUDCustomerHasRecentlyBeenRejected extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_CustomerHasRecentlyBeenRejected() throws Exception {

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);

		// Seed Pan Credit target test environment with an rejected agreement.
		gcb.prSeedUniqueRejectedAgreementInPAN(gcb.gsPanCreditServiceServer, "104191");
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of rejected agreement for this test failed. ");
		}

		log.info("Rejected Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke only if we have not switched on quick application
		// functionality, by directly navigating to
		// the next page i.e. Your Finances otherwise this is combined page
		// journey
		if (!gcb.gsQuickApply.equals("true")) {
			// Invoke Next action: Next: Your Finances
			gcb.prClickForNextAction();

			// Your Finances Page
			// ==================

			// gcb.prAssertOnPageYourFinances( gsSatsumaSiteUrl);
		}

		// Fill in applicants finance details from the profile
		// gcb.prFillInPageYourFinances();

		// Invoke Next action: Next: Review Your Quote
		// gcb.prClickForNextAction();

		// Decline page expected
		// =====================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result8
		// You have previously been declined for a Satsuma loan. We can see that
		// you have previously submitted an application for a Satsuma Loan,
		// which was unfortunately declined.
		gcb.prAssertOnPageFinishedIDResult8(gsSatsumaSiteUrl);

	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}

}
