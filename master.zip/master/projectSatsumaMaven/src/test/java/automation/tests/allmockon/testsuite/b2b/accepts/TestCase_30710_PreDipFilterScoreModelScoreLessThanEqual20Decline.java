package automation.tests.allmockon.testsuite.b2b.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

/*
 *System Test
 This test is concerned with ensuring that a Pre-DiP Filter Score less than 30 results in a decline response to the Broker Service request.
 To test use the attached WCFStorm XML as a template and modify using the parameterised data in the test case.
 Ensure that the SatsumaBrokerPreliminaryEnhancedWorkflow has ItemId="61" : SamplingRatioA="1.00" and ItemId="21" : SamplingRatioA="1.00".
 Can be tested with all mocks ON.
 */

public class TestCase_30710_PreDipFilterScoreModelScoreLessThanEqual20Decline extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {
		// gcb.prGetApplicantProfile(184);
		gcb.prGetApplicantProfile(281);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();

		// soapui test case called expected to decline
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		// String decisionRef =
		// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		// // verify predip score
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "29.86262461");
		//
		// String reasonCode =
		// ZoralScoreDatabaseHelper.getReasonDescription(gcb.zoralDB,
		// decisionRef);
		// Assert.assertEquals(reasonCode, "110 PreDIP Score Reject");

		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 13.0f, "check predip score");

	}
}
