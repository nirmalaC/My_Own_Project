package automation.tests.allmockon.login.uat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class TestCase_14269_UATCoreRegressionComplianceRiskWarningWording extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Override
	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

	}

	@Test
	public void test() throws Exception {
		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		sHome.assertComplianceWording();

		gcb.takeIncrementScreenshot();

		// Invoke Next action: Apply now

		final By byBtnApply = By.id("SubmitHomeCalc");
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnApply)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnApply)));
		getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
		getDriver().findElement(byBtnApply).click();

		// getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.ENTER);

		sHome.assertComplianceWording();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		final By byBtnStartYourApplication = By.linkText("Start your application");
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.ENTER);

		// About You page
		// ==============

		sHome.assertComplianceWording();

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		// back to home page
		getDriver().get(this.gsSatsumaSiteUrl);

		// contact us
		By byLnkHeaderContactUs = By.id("header-link-contact-us");
		getDriver().findElement(byLnkHeaderContactUs).click();
		sHome.assertComplianceWording();

		// faqs
		By byLnkHeaderFAQ = By.id("header-link-faqs");
		getDriver().findElement(byLnkHeaderContactUs).click();
		sHome.assertComplianceWording();

	}
}
