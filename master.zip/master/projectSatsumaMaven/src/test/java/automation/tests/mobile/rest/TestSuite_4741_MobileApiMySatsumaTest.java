package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;
import automation.dao.SatsumaCustomer;
import automation.test.offerservice.enums.OfferPartyStatus;

import com.eviware.soapui.support.SoapUIException;

public class TestSuite_4741_MobileApiMySatsumaTest extends MobileAPITest {

	public final static String APP_VERSION_NO = "1.1";

	// 31892 - fetch content
	@Test
	public void testCase_31144_myaccountIOS() throws Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		// Assert.assertEquals(from(myAccountString).get("CreditScore.Score"),
		// NEW_LOAN_MOBILE_CREDIT_SCORE);
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	// 31892 - fetch content
	@Test
	public void testCase_31144_myAccountAndroid() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		// SatsumaCustomer satsumaCustomer = addNewAgreement();
		SatsumaCustomer satsumaCustomer = addNewHalfPaidUpAgreement();
		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEEligibleOffer(false, 1000d);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), 1000.0f);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	@Test
	public void testCase_mySatsumaCreditCard() throws Exception {
		applyForWebAgreementCheckMobileCreditCard("4444333322221111", "01/2019", "Visa Debit", "123");

	}

	@Test
	public void testCase_mySatsumaDiffCreditCard() throws IOException, ParseException, Exception {
		applyForWebAgreementCheckMobileCreditCard("5454545454545454", "12/2026", "Mastercard", "123");
	}

	private void applyForWebAgreementCheckMobileCreditCard(String creditCardNo, String creditCardExpiry, String creditCardType, String creditCardCVS) throws Exception, IOException, ParseException {

		SatsumaCustomer satsumaCustomer = newCustomerAccept(creditCardNo, creditCardExpiry, creditCardType, creditCardCVS, 133);

		final String PLATFORM = "Android";
		loginPassword = "Password1";
		encodedPassword = RsaPasswordEncoder.rsaEncode(loginPassword);
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), satsumaCustomer.getAgreements().get(0));
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		// Assert credit card
		Assert.assertEquals(from(myAccountString).get("Agreements[0].CardNumber"), "**** **** **** " + creditCardNo.substring(12));
		Assert.assertEquals(from(myAccountString).get("Agreements[0].CardExpiry"), creditCardExpiry.substring(0, 3) + creditCardExpiry.substring(5));
	}

	// 31892 - no date header
	@Test
	public void testCase_31136_noDateHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));

	}

	// 31892 - invalid app version header
	@Test
	public void testCase_32702_invalidAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '1.1'"));
	}

	// 31892 - no app version header
	@Test
	public void testCase_31137_noAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31139_invalidPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		given().log().all().contentType("application/json").header("platform", "Windows").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_31138_noPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		given().log().all().contentType("application/json").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'Platform'"));
	}

	// 31892 - no platform header
	@Test
	public void testCase_31293_noToken() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount - no token gives 401 unauthorized
		given().log().all().contentType("application/json").header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + "").when().get(ACCOUNT_URL).then().log().all().statusCode(401);
	}

	@Test
	public void testCase_37710_referredMonthlyAgreement() throws Exception {
		SatsumaCustomer satsumaCustomer = addNewReferredMonthlyAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("SQ", OfferPartyStatus.UNKNOWN, false);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Pending");
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("CreditScore"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].InstalmentType"), "Monthly");
	}

	@Test
	public void testCase_31152_referredAgreement() throws Exception {
		SatsumaCustomer satsumaCustomer = addNewReferredAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("SQ", OfferPartyStatus.UNKNOWN, false);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Pending");
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("CreditScore"), null);
	}

	@Test
	public void testCase_31143_tempArrangement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addTempArrangementAgreement();
		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), true);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Active");
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
	}

	@Test
	public void testCase_31143_frozenAgreement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addFrozenAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("SR", OfferPartyStatus.ACTIVE, false);

		// myaccount - verify 0 agreements
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).expect()
				.body("Agreements.findall.size()", equalTo(0)).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		// doesn't display frozen agreements
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
	}

	@Test
	public void testCase_37711_monthlyTempArrangement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addTempArrangementMonthlyAgreement();
		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("TA", OfferPartyStatus.ACTIVE, false);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), true);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Active");
		Assert.assertEquals(from(myAccountString).get("Agreements[0].InstalmentType"), "Monthly");

	}

	@Test
	public void testCase_37709_frozenMonthlyAgreement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addFrozenMonthlyAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("SR", OfferPartyStatus.FROZEN_DEFAULTED, false);

		// myaccount - verify 0 agreements
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).expect()
				.body("Agreements.findall.size()", equalTo(0)).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		// doesn't display frozen agreements
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
	}

	@Test
	public void testCase_31145_twoActiveLoansUpAgreement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addNewHalfPaidUpAgreement();
		tempSatsumaCustomer = addFurtherHalfPaidUpAgreement(tempSatsumaCustomer.getAgreements().get(0));
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEIneligibleOffer("SC", OfferPartyStatus.ACTIVE, false);

		// myaccount - verify 2 agreements
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).expect()
				.body("Agreements.findall.size()", equalTo(2)).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		// doesn't display frozen agreements
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Active");
		Assert.assertEquals(from(myAccountString).get("Agreements[1].Status"), "Active");
	}

	@Test
	public void testCase_31145_oneActiveOnePaidUpLoansUpAgreement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addNewPaidUpAgreement("500", "13");
		tempSatsumaCustomer = addFurtherHalfPaidUpAgreement(tempSatsumaCustomer.getAgreements().get(0));
		final String PLATFORM = "iOS";

		gcb.seedFLEEligibleOffer(false, 1000d);

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount - verify 2 agreements
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).expect()
				.body("Agreements.findall.size()", equalTo(2)).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		// doesn't display frozen agreements
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), 1000.0f);
		// Assert.assertEquals(from(myAccountString).get("CreditScore.Score"),
		// NEW_LOAN_MOBILE_CREDIT_SCORE);
	}

	@Test
	public void testCase_37708_oneActiveOnePaidUpLoansUpMonthlyAgreement() throws Exception {
		SatsumaCustomer tempSatsumaCustomer = addNewPaidUpMonthlyAgreement("500", "12");
		tempSatsumaCustomer = addFurtherHalfPaidUpMonthlyAgreement(tempSatsumaCustomer.getAgreements().get(0));
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", tempSatsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		gcb.seedFLEEligibleOffer(false, 1000d);

		// myaccount - verify 2 agreements
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).expect()
				.body("Agreements.findall.size()", equalTo(2)).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), tempSatsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), tempSatsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), tempSatsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), tempSatsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), 1000.0f);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].InstalmentType"), "Monthly");
		Assert.assertEquals(from(myAccountString).get("Agreements[1].InstalmentType"), "Monthly");
		if (from(myAccountString).get("Agreements[0].Status").equals("NotActive")) {
			Assert.assertEquals(from(myAccountString).get("Agreements[1].Status"), "Active");
		} else {
			Assert.assertEquals(from(myAccountString).get("Agreements[0].Status"), "Active");
		}
	}
}
