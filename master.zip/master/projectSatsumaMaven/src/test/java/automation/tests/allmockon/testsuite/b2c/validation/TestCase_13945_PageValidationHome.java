package automation.tests.allmockon.testsuite.b2c.validation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class TestCase_13945_PageValidationHome extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {
		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// Goto Satsuma site
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============
		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// select weekly term
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// Connect to TestShed database

	}

	@AfterMethod
	public void tearDown() throws Exception {
		// Disconnect from TestShed database

	}

	@Test
	public void test_NavigationHeaderApplyNowButton() throws Exception {

		// Check button text
		Assert.assertEquals("Apply now", getDriver().findElement(By.id("header-apply-link")).getText());
		// Navigate to Start Application page
		getDriver().findElement(By.id("header-apply-link")).click();
		// Landed on Start Application page
		Assert.assertEquals(gsSatsumaSiteUrl + "apply", getDriver().getCurrentUrl());
		// Assert.assertEquals("Apply | Satsuma Loans",getDriver().getTitle());
		Assert.assertEquals("Your loan application... | Satsuma Loans", getDriver().getTitle());
	}

	@Test
	public void test_NavigationFooterApplyNowButton() throws Exception {

		// Check button text
		// Assert.assertEquals("Apply Now",getDriver().findElement(By.xpath("//a[@href='/apply/']")).getText());
		Assert.assertEquals("Apply now", getDriver().findElement(By.cssSelector("a[href='/apply']")).getText());
		// Navigate to Start Application page
		// getDriver().findElement(By.xpath("//a[@href='/apply/']")).click();
		getDriver().findElement(By.cssSelector("a[href='/apply']")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.cssSelector("a[href='/apply/']")).click();
		getDriver().findElement(By.cssSelector("a[href='/apply']")).sendKeys(Keys.ENTER);

		// Landed on Start Application page
		gcb.waitForUrl(gsSatsumaSiteUrl + "apply");
		Assert.assertEquals(gsSatsumaSiteUrl + "apply", getDriver().getCurrentUrl());
		// Assert.assertEquals("Apply | Satsuma Loans", getDriver().getTitle());
		// title seems to have changed 20/01/2016
		Assert.assertEquals("Your loan application... | Satsuma Loans", getDriver().getTitle());
	}

	@Test
	public void test_NavigationCalcApplyNowButton() throws Exception {

		// Check button text
		Assert.assertEquals("Apply now", getDriver().findElement(By.id("SubmitHomeCalc")).getText());
		// Navigate to Start Application page
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("SubmitHomeCalc")).click();
		// Landed on Start Application page
		Assert.assertEquals(gsSatsumaSiteUrl + "apply", getDriver().getCurrentUrl());
		// Assert.assertEquals("Apply | Satsuma Loans",getDriver().getTitle());
		Assert.assertEquals("Your loan application... | Satsuma Loans", getDriver().getTitle());
	}

	@Test
	public void test_NewCustomerPageDefaults() throws Exception {

		Assert.assertEquals("Short term loans with no hidden fees", getDriver().findElement(By.cssSelector("h1.headertext__heading")).getText());

		// Loan Calculator Slider - Default loan amount is £1000 within range
		// £100 to £1000 over 26 weeks
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("value"));
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("min"));
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("max"));
		Assert.assertEquals("10", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("step"));

		Select dropdown;
		dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		// dropdown.selectByVisibleText("£" + gcb.gsRequestedLoanAmount);
		dropdown.selectByVisibleText("£1000");

		Assert.assertEquals("3", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("value"));
		Assert.assertEquals("0", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("max"));
		Assert.assertEquals("1", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("step"));

		gcb.prGetACurrentSatsumaLoanCharge("Weekly", 26, 1000);

		// Pricing for £1000 26 weeks - Defaulted correctly
		// Assert.assertEquals("£1000",
		// getDriver().findElement(By.id("LoanAmountHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), getDriver().findElement(By.id("TotalInterestHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), getDriver().findElement(By.id("TotalAmountHomeCalcText")).getText());

		// ** End of Test **
	}

	@Test
	public void test_ExistingCustomerPageDefaults() throws Exception {

		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		gcb.prAssertOnPageExistingCustomer(gsSatsumaSiteUrl);

		// Check Calc header title
		// Assert.assertEquals("Existing Customer",
		// getDriver().findElement(By.xpath("//h1[@class='withCalc']")).getText());

		// Check Calc header title
		Assert.assertEquals("Welcome Back!", getDriver().findElement(By.cssSelector("h1.headertext__heading")).getText());

		// Loan Calculator Slider - Default loan amount is £1000 within range
		// £100 to £2000 over 26 weeks
		Assert.assertEquals("1000", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("value"));
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("min"));
		Assert.assertEquals("2000", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("max"));
		Assert.assertEquals("10", getDriver().findElement(By.id("LoanAmountHomeCalc")).getAttribute("step"));

		Assert.assertEquals("6", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("value"));
		Assert.assertEquals("0", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("max"));
		Assert.assertEquals("1", getDriver().findElement(By.id("TermHomeCalc")).getAttribute("step"));

		gcb.prGetACurrentSatsumaLoanCharge("Weekly", 39, 1000);

		// Pricing for £1000 26 weeks - Defaulted correctly
		// Assert.assertEquals("£1000",
		// getDriver().findElement(By.id("LoanAmountHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), getDriver().findElement(By.id("TotalInterestHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountHomeCalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), getDriver().findElement(By.id("TotalAmountHomeCalcText")).getText());

		// ** End of Test **
	}

	@Test
	public void test_NewCustomerLoanAmountDropdownOptions() throws Exception {

		// Check that loan amount dropdown is options range from £100 to £1000
		// only in increments of £10
		// This page will offer only max of £1000 for new customers

		String[] exp = { "100", "110", "120", "130", "140", "150", "160", "170", "180", "190", "200", "210", "220", "230", "240", "250", "260", "270", "280", "290", "300", "310", "320", "330", "340", "350", "360", "370", "380", "390", "400", "410", "420", "430", "440", "450", "460", "470", "480",
				"490", "500", "510", "520", "530", "540", "550", "560", "570", "580", "590", "600", "610", "620", "630", "640", "650", "660", "670", "680", "690", "700", "710", "720", "730", "740", "750", "760", "770", "780", "790", "800", "810", "820", "830", "840", "850", "860", "870", "880",
				"890", "900", "910", "920", "930", "940", "950", "960", "970", "980", "990", "1000" };

		WebElement dropdown = getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating new customerloan amount dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals("£" + exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 91) {
			Assert.fail("Failed: Expecting 91 option listings, found " + options.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_ExistingCustomerLoanAmountDropdownOptions() throws Exception {

		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// Check that loan amount dropdown is options range from £100 to £2000
		// only in increments of £10
		// This page will offer max of £2000 for existing customers

		String[] exp = { "100", "110", "120", "130", "140", "150", "160", "170", "180", "190", "200", "210", "220", "230", "240", "250", "260", "270", "280", "290", "300", "310", "320", "330", "340", "350", "360", "370", "380", "390", "400", "410", "420", "430", "440", "450", "460", "470", "480",
				"490", "500", "510", "520", "530", "540", "550", "560", "570", "580", "590", "600", "610", "620", "630", "640", "650", "660", "670", "680", "690", "700", "710", "720", "730", "740", "750", "760", "770", "780", "790", "800", "810", "820", "830", "840", "850", "860", "870", "880",
				"890", "900", "910", "920", "930", "940", "950", "960", "970", "980", "990", "1000", "1010", "1020", "1030", "1040", "1050", "1060", "1070", "1080", "1090", "1100", "1110", "1120", "1130", "1140", "1150", "1160", "1170", "1180", "1190", "1200", "1210", "1220", "1230", "1240",
				"1250", "1260", "1270", "1280", "1290", "1300", "1310", "1320", "1330", "1340", "1350", "1360", "1370", "1380", "1390", "1400", "1410", "1420", "1430", "1440", "1450", "1460", "1470", "1480", "1490", "1500", "1510", "1520", "1530", "1540", "1550", "1560", "1570", "1580", "1590",
				"1600", "1610", "1620", "1630", "1640", "1650", "1660", "1670", "1680", "1690", "1700", "1710", "1720", "1730", "1740", "1750", "1760", "1770", "1780", "1790", "1800", "1810", "1820", "1830", "1840", "1850", "1860", "1870", "1880", "1890", "1900", "1910", "1920", "1930", "1940",
				"1950", "1960", "1970", "1980", "1990", "2000" };

		WebElement dropdown = getDriver().findElement(By.id("LoanAmountHomeCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating existing customer loan amount dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals("£" + exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 191) {
			Assert.fail("Failed: Expecting 191 option listings, found " + options.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_NewCustomerRepaymentFrequencyDropdownOptions() throws Exception {

		// Check that Repayment Frequency selectable dropdown options are
		// available as specified below.
		// This test is specific to the uploaded pricing table, so the
		// re-payment frequency listing must match the latested available
		// uploaded pricing
		log.info("WARNING: " + "This test is specific to the uploaded pricing table, so the re-payment frequency listing must match the latested available uploaded pricing");

		String[] exp = { "13 weeks", "17 weeks", "21 weeks", "26 weeks", "30 weeks", "34 weeks", "39 weeks", "43 weeks", "47 weeks", "52 weeks" };
		WebElement dropdown = getDriver().findElement(By.id("TermHomeCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating repayment frequency dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 10) {
			Assert.fail("Failed: Expecting 10 option listings, found " + options.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_ExistingCustomerRepaymentFrequencyDropdownOptions() throws Exception {

		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// Check that Repayment Frequency selectable dropdown options are
		// available as specified below.
		// This test is specific to the uploaded pricing table, so the
		// re-payment frequency listing must match the latested available
		// uploaded pricing
		log.info("WARNING: " + "This test is specific to the uploaded pricing table, so the re-payment frequency listing must match the latested available uploaded pricing");

		String[] exp = { "13 weeks", "17 weeks", "21 weeks", "26 weeks", "30 weeks", "34 weeks", "39 weeks", "43 weeks", "47 weeks", "52 weeks" };
		WebElement dropdown = getDriver().findElement(By.id("TermHomeCalcDropdown"));
		Select select = new Select(dropdown);

		log.info("INFO: Validating repayment frequency dropdown options");

		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			int cnt = 0;
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					log.info("Dropdown option: " + we.getText() + " expected");
					break;
				}
				cnt++;
			}
			if (cnt >= exp.length) {
				Assert.fail("Failed: Dropdown option:" + we.getText() + " not expected");
			}
		}

		// As we only check for existence of specific listings, we must also
		// check that other values have not been included
		// by virtue of checking the listing count
		if (options.size() != 10) {
			Assert.fail("Failed: Expecting 10 option listings, found " + options.size());
		}

		// ** End Of Test **
	}

	@Test
	public void test_IsMoneyAdviceServiceLinkGood() throws Exception {

		// This test piece is driven by CMS which could change at any time,
		// therefore ignoring on the assumption that UAT will pick this up

		// Check access possible to Money Advice Service site in a new window
		String parentWindow = getDriver().getWindowHandle();

		gcb.waitForClickableElement(By.linkText("moneyadviceservice.org.uk"));

		WebElement linkMoneyAdviceService = getDriver().findElement(By.linkText("moneyadviceservice.org.uk"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", linkMoneyAdviceService);
		// getDriver().findElement(By.linkText("moneyadviceservice.org.uk")).click();

		Thread.sleep(2000);

		if (!_switchWindowByTitle("Money Advice Service")) {
			Assert.fail("Aborted: Unable to navigate to Money Advice Service");
		} else {
			getDriver().close();
			getDriver().switchTo().window(parentWindow);
		}

		// ** End of Test **
	}

	@Test
	public void test_LoanAmountIncrementalPlus() throws Exception {

		// // <+> loan amount adjuster should increment by £10
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setAmount(500)");

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£500");

		getDriver().findElement(By.id("AmountMoreButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£510", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_LoanAmountDecrementalMinus() throws Exception {

		// // <-> loan amount adjuster should decrement by £10
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setAmount(500)");

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£500");

		getDriver().findElement(By.id("AmountLessButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£490", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_NewCustomerLoanAmountIncrementalBoundary() throws Exception {

		// // <+> loan amount adjuster should not go beyond slider max range
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setAmount(1000)");

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£1000");
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.PAGE_UP); // use

		getDriver().findElement(By.id("AmountMoreButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£1000", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_NewCustomerLoanAmountDecrementalBoundary() throws Exception {

		// // <-> loan amount adjuster should not go beyond slider min range
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setAmount(100)");

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£100");

		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.PAGE_UP); // use

		getDriver().findElement(By.id("AmountLessButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£100", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_ExistingLoanAmountIncrementalBoundary() throws Exception {
		getDriver().findElement(linkExistingCustomers).sendKeys("");
		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// // <+> loan amount adjuster should not go beyond slider max range
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setAmount(2000)");
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£2000");
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.HOME); // use
		// apply
		// button
		// to
		// focus
		// right
		// area
		// of
		// screen
		getDriver().findElement(By.id("AmountMoreButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£2000", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_ExistingLoanAmountDecrementalBoundary() throws Exception {
		getDriver().findElement(linkExistingCustomers).sendKeys(Keys.TAB);
		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		dropdown.selectByVisibleText("£100");
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.PAGE_UP); // use

		getDriver().findElement(By.id("AmountLessButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("LoanAmountHomeCalcDropdown")));
		Assert.assertEquals("£100", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_LoanTermIncrementalPlus() throws Exception {

		// // <+> loan term adjuster should increment to next term
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setTerm(30)");

		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("30 weeks");

		getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		Assert.assertEquals("34 weeks", dropdown.getFirstSelectedOption().getText());
	}

	@Test
	public void test_LoanTermDecrementalMinus() throws Exception {

		// <-> loan term adjuster should decrement to last term
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setTerm(30)");
		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("30 weeks");

		getDriver().findElement(By.id("#TermLessButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		Assert.assertEquals("26 weeks", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_NewCustomerLoanTermIncrementalBoundary() throws Exception {

		// // <+> loan term adjuster should not go beyond slider max range
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setTerm(52)");

		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("52 weeks");

		getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		Assert.assertEquals("52 weeks", dropdown.getFirstSelectedOption().getText());
	}

	@Test
	public void test_NewCustomerLoanTermDecrementalBoundary() throws Exception {

		// // <-> loan term adjuster should not go beyond slider min range
		// JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// js.executeScript("HomeCalc.setTerm(13)");

		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("13 weeks");

		getDriver().findElement(By.id("#TermLessButtonHomeCalc")).click();
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		Assert.assertEquals("13 weeks", dropdown.getFirstSelectedOption().getText());

	}

	@Test
	public void test_ExistingCustomerLoanTermIncrementalBoundary() throws Exception {
		getDriver().findElement(linkExistingCustomers).sendKeys("");
		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// <+> loan term adjuster should not go beyond slider max range
		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("52 weeks");
		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(""); // use
																		// apply
																		// button
																		// to
																		// focus
																		// right
																		// area
																		// of
																		// screen
		getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();

		Assert.assertEquals("52 weeks", dropdown.getFirstSelectedOption().getText());
	}

	@Test
	public void test_ExistingCustomerLoanTermDecrementalBoundary() throws Exception {

		getDriver().findElement(linkExistingCustomers).sendKeys("");
		getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(By.id("TermTypeHomeCalcWeekly")).click();

		// <-> loan term adjuster should not go beyond slider min range
		Select dropdown = new Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
		dropdown.selectByVisibleText("13 weeks");

		getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(""); // use
																		// apply
																		// button
																		// to
																		// focus
																		// right
																		// area
																		// of
																		// screen
		getDriver().findElement(By.id("#TermLessButtonHomeCalc")).click();
		Assert.assertEquals("13 weeks", dropdown.getFirstSelectedOption().getText());

	}

	// This test is now out of scope as there is no estimate on the home page.
	// @Test
	// public void test_LoanTermApproxRepaymentDateCalculation() throws
	// Exception {
	//
	// // Assert that the guide re-payment end date is calculated correctly for
	// // each of the available weekly loan terms.
	// // JavascriptExecutor js = (JavascriptExecutor) getDriver();
	// // js.executeScript("HomeCalc.setTerm(13)");
	//
	// Select dropdown = new
	// Select(getDriver().findElement(By.id("TermHomeCalcDropdown")));
	// dropdown.selectByVisibleText("13 weeks");
	//
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(13),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(17),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(21),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(26),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(30),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(34),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(39),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(43),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(47),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// getDriver().findElement(By.id("#TermMoreButtonHomeCalc")).click();
	// Assert.assertEquals(gcb.fnGetApproxRepaymentDateCalculation(52),
	// getDriver().findElement(By.id("RepaymentEndDateHomeCalcText")).getText());
	// }

}
