package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnIDVReferralTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CReferral910OFANameMismatchLowAccMatchConf extends B2CAllMocksOnIDVReferralTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "OFA Name Mismatch Low Confidence";
	private static final String EXPECTED_PAN_CODE = "910";
	private static final int WEEKLY_APPPLICANT_ID = 229;
	private static final int NEW_BUS_WEEKLY_APPPLICANT_ID = 303;
	private static final int MONTHLY_APPPLICANT_ID = 285;
	private static final int NEW_BUS_MONTHLY_APPPLICANT_ID = 304;

	@Test
	public void testB2cNbReferralWeekly() throws Exception {
		b2CNewBusinessReferral(WEEKLY_APPPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cNbReferralMonthly() throws Exception {
		b2CNewBusinessReferral(MONTHLY_APPPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
