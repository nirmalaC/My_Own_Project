package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23771_AcceptNewCustomerRepricesTerm52Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice52weeks100() throws Exception {
		newCustomerAccept("100", "52", "Weekly", 133);
	}

	@Test(enabled = false)
	public void test_Reprice52weeks750() throws Exception {
		newCustomerAccept("750", "52", "Weekly", 133);
	}

	@Test
	public void test_Reprice52weeks1000() throws Exception {
		newCustomerAccept("1000", "52", "Weekly", 133);
	}

}
