package automation.tests.allmockon.testsuite.b2c.accepts;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;
import automation.dao.CustomerType;
import automation.satsuma.pages.TimeHackHelper;
import automation.test.offerservice.enums.OfferPartyStatus;

import com.eviware.soapui.support.SoapUIException;

public class B2CAcceptPaidUpCustomerSourceV2PE extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void existingNotRegistered() throws Exception {
		gcb.prGetApplicantProfile(208);
		gcb.prCreateUniquePerson();
		// Overwrite applicant profile requested loan terms
		gcb.gsRequestedLoanAmount = "100";
		gcb.gsRequestedTerm = "13";
		gcb.gsRepaymentFrequency = "Weekly";

		gcb.seedFLEEligibleOffer("PE", 1000d, false, OfferPartyStatus.PAID_UP, 0);

		runTestJourney();
	}

	@Test
	public void existingRegistered() throws Exception {
		seedAndRegisterLogin(700f, "52", false);

		gcb.seedFLEEligibleOffer("PE", 2000d, false, OfferPartyStatus.PAID_UP, 0);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(2000));

		gcb.gsRequestedLoanAmount = "990";
		gcb.gsRequestedTerm = "13";
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		runLoginTestJourney();
	}

	public void runTestJourney() throws Exception {

		String sAgreementNumber;

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, "100", "13");

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		gcb.prConfirmLVA();

		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		if (gcb.gsRepaymentFrequency.equalsIgnoreCase("weekly")) {
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		} else if (gcb.gsRepaymentFrequency.equalsIgnoreCase("monthly")) {
			String expectedStartDate = gcb.getScheduleStartDateForMonthly(1, TimeHackHelper.getPanDate());
			String expectedEndDate = gcb.getScheduleEndDateForMonthly(expectedStartDate, Integer.parseInt(gcb.gsRequestedTerm));
			// get expected date
			gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
					gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode, expectedStartDate, expectedEndDate);
		} else {
			Assert.fail("Error invalid frequency");
		}

	}

	public void seedAndRegisterLogin(float originalLoanAmount, String originalLoanTerm, boolean paidUp) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);
		gcb.setRandomBankDetails();
		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, "weekly");
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

	}

	public void runLoginTestJourney() throws NumberFormatException, Exception {
		gcb.gsRequestedLoanAmount = "990";
		gcb.gsRequestedTerm = "13";
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();

		gcb.waitForClickableElement(By.id("ContinueButtonStep1"));
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		login.prAssertOnPageQuote(gsSatsumaSiteUrl);

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		String newBankAccountName = "New Name";
		String newBankAccountNumber = "99999999";
		String newBankSortCode = "888888";
		String newBankAccountOpenDate = "13/12/2012";

		// changes bank details and clicks submit button
		login.changeFLBankDetails(newBankAccountName, newBankAccountNumber, newBankSortCode, newBankAccountOpenDate);

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);
		gcb.prNavigateToPANBankDetails();
		login.prAssertPANBankDetails(newBankAccountName, newBankSortCode, newBankAccountNumber);
	}
}
