package automation.tests.allmockon.testsuite.b2b.referrals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;

import com.eviware.soapui.model.testsuite.TestCase;

public class TestCase_1206_ReferredFRDNewCustIsFraud extends B2BAllMocksOnTest {

	@Test
	public void test() throws Exception {

		// Get Applicant Profile 81 from TestshedDB
		gcb.prGetApplicantProfile(81);
		log.debug(gcb.gsFirstname);
		log.debug(gcb.gsSurname);

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase

		String sAPR = new String("");
		String sLoanAmount;
		String sTAP;

		gsSatsumaSiteUrl = testCase.getPropertyValue("ptcURL");
		sAPR = testCase.getPropertyValue("ptcAPR");
		sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		log.debug("Customer Link: " + gsSatsumaSiteUrl);
		log.debug("APR is: " + sAPR);
		log.debug("Returned Loan Amount is: " + sLoanAmount);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================

		getDriver().get(gsSatsumaSiteUrl);

		// Check if landed on expected page
		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsCurrentUrl = getDriver().getCurrentUrl();

		log.debug(gsCurrentUrl);
		Assert.assertTrue(gsCurrentUrl.contains(gsSatsumaSiteUrl + "referral/Start?key="));

		// Check Details on Page

		// Loan Amount
		Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsRequestedLoanAmount));

		// Loan Term
		Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsRequestedTerm));

		// Weekly Repayment Amount
		// hard coded at the moment, need to think about bringing in this value
		// in from table of charges
		Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsExpectedRepayment));

		// APR
		Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsExpectedAPR));

		// Firstpayment Day of the week LOV picker

		// What will you use your loan for?
		Select dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Monday");
		dropdown.selectByVisibleText("Tuesday");
		dropdown.selectByVisibleText("Wednesday");
		dropdown.selectByVisibleText("Thursday");
		dropdown.selectByVisibleText("Friday");

		// Validate no more items listed than above - Expect 9 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(6, l.size());

		// website cookie policy radio button

		Assert.assertFalse(getDriver().findElement(By.id("CookieAccepted")).isSelected());

		// Select preferred payment date & check the website cookie policy
		// button
		dropdown = new Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		dropdown.selectByVisibleText("Monday");

		// Complete Details
		// ==================

		// Select the Cookie Radio button
		getDriver().findElement(By.id("CookieAccepted")).click();

		// Click Your Bank Details button
		getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		// Bank Details Screen
		// ===================

		// Check you have landed on the Bank Page
		gsCurrentUrl = getDriver().getCurrentUrl();
		Assert.assertEquals(gsCurrentUrl, gsSatsumaSiteUrl + "Referral/BankDetails");

		// Enter Bank Details
		// ==================

		// Bank account name
		getDriver().findElement(By.id("AccountHolder")).sendKeys(gcb.gsBankAccountName);

		// Bank account number & sortcode
		getDriver().findElement(By.id("AccountNumber")).sendKeys(gcb.gsBankAccountNumber);
		getDriver().findElement(By.id("SortCodePart1")).sendKeys(gcb.gsBankSortcode.substring(0, 2));
		getDriver().findElement(By.id("SortCodePart2")).sendKeys(gcb.gsBankSortcode.substring(2, 4));
		getDriver().findElement(By.id("SortCodePart3")).sendKeys(gcb.gsBankSortcode.substring(4, 6));

		// Select Date Bank Account opened
		dropdown = new Select(getDriver().findElement(By.id("AccountOpenMonth")));
		dropdown.selectByVisibleText("1");

		dropdown = new Select(getDriver().findElement(By.id("AccountOpenYear")));
		dropdown.selectByVisibleText("2012");

		// Click Your Payment Details button
		getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		// WorldPay
		// ========

		// Check you have landed on the Worldpay Portal Page
		gsCurrentUrl = getDriver().getCurrentUrl();
		Assert.assertTrue(gsCurrentUrl.contains("https://secure-test.worldpay.com"));

		// click on Maestro button
		getDriver().findElement(By.xpath("//input[@alt='Visa']")).click();

		// Complete card number, CVV
		String sDebitCard = gcb.gsCreditCardNumber;
		getDriver().findElement(By.id("cardNoInput")).sendKeys(sDebitCard);

		// CVV
		getDriver().findElement(By.id("cardCVV")).sendKeys("000");

		// Expiry Date
		dropdown = new Select(getDriver().findElement(By.xpath("//select[@name='cardExp.month']")));
		dropdown.selectByValue("1");

		dropdown = new Select(getDriver().findElement(By.xpath("//select[@name='cardExp.year']")));
		dropdown.selectByValue("2029");

		// Name on Card
		getDriver().findElement(By.id("name")).sendKeys(gcb.gsBankAccountName);

		// Click on Make Payment
		getDriver().findElement(By.id("op-PMMakePayment")).click();

		// Click on the continue button on the Worldpay simulator page
		getDriver().findElement(By.xpath("//input[@name='continue']")).click();

		// Credit Agreement page
		// ======================

		// Landed on correct page
		gsCurrentUrl = getDriver().getCurrentUrl();
		Assert.assertEquals(gsSatsumaSiteUrl + "Referral/Agreement", gsCurrentUrl);
		Assert.assertTrue(getDriver().getTitle().contains("Agreement | Satsuma Loans"));

		// Credit Agreement
		// ----------------

		// Product Explanation - Read acknowledged

		getDriver().findElement(By.xpath("//a[@href='#agreement-product-explanation']")).click();

		getDriver().findElement(By.xpath("//input[@id='ReadProductExplanation']")).click();

		// Pre-Contract Credit Information
		// -------------------------------

		// 1. Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-contact-details']")).click();

		// 2. Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features']")).click();

		// 3. Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-the-credit']")).click();

		// 4. Other important legal aspects - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-legal-aspects']")).click();

		// 5. Additional information innthe case of distance marketing of
		// financial services - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-additional-info']")).click();

		// Contractual Terms and Conditions
		// --------------------------------

		// 6. Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-conditions']")).click();

		// 7. Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing-terms']")).click();

		// Confirm above sections read
		getDriver().findElement(By.xpath("//input[@id='ReadPreContract']")).click();

		// Credit Agreement and E-Signature
		// Fixed Sum Loan Agreement
		// --------------------------------

		// Parties to the Agreement - Contact details - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-parties-to-agreement']")).click();

		// Check name on agreement
		getDriver().getPageSource().contains(gcb.gsTitle + " " + gcb.gsFirstname + " " + gcb.gsSurname);

		// Key features of the credit product - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-key-features-credit-product']")).click();

		// Costs of the credit - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-costs-of-credit']")).click();

		// Right of withdrawal - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-right-of-withdrawal']")).click();

		// Other important information - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-other-important-info']")).click();

		// Terms and conditions - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-terms-and-conditions']")).click();

		// Marketing - Read acknowledged
		getDriver().findElement(By.xpath("//a[@href='#agreement-marketing']")).click();

		// Confirm above section read
		getDriver().findElement(By.xpath("//input[@id='ReadFixedSumLoanAgreement']")).click();

		// Get the Customers Agreement Number

		String lsAgreementNumber = getDriver().findElement(By.xpath("//span[@class='right']")).getText();
		log.debug("Agreement Number is " + lsAgreementNumber);

		// pass agreement number found to global agreement number
		gcb.gsPANAgreementNumber = lsAgreementNumber;

		// Signature of Customer
		// ---------------------

		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(gcb.gsFirstname);
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(gcb.gsSurname);

		// Click Complete Your Application button
		getDriver().findElement(By.xpath("//button[@class='button primary-button']")).click();

		// Landed on correct completion page
		gsCurrentUrl = getDriver().getCurrentUrl();
		Assert.assertEquals(gsCurrentUrl, gsSatsumaSiteUrl + "Referral/Complete");
		Assert.assertEquals("Your application is now being processed and verified. | Satsuma Loans", getDriver().getTitle());

		// Pancredit
		// =========

		log.debug(gcb._getConfigProperty("PanCreditServiceServer"));
		getDriver().get(gcb._getConfigProperty("PanCreditServiceServer") + "/panCoreSaas/app");

		// Find Agreement in Pancredit and amend surname
		Assert.assertTrue(getDriver().getTitle().contains("pancredit"));

		getDriver().findElement(By.id("username")).sendKeys(gcb._getConfigProperty("PanCreditUsername"));
		getDriver().findElement(By.id("password")).sendKeys(gcb._getConfigProperty("PanCreditPassword"));

		getDriver().findElement(By.id("PanLinkSubmit")).click();
		getDriver().findElement(By.id("agreementNumber")).sendKeys(gcb.gsPANAgreementNumber);
		getDriver().findElement(By.id("PanLinkSubmit_0")).click();

		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?component=%24PanDirectLink&page=HomeExistingAgreements&service=direct&session=T&sp=S" + gcb.gsPANAgreementNumber + "']")).click();

		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?page=NewBusiness%2FNBNameAndAddresses&service=page']")).click();

		getDriver().findElement(By.id("surname")).clear();
		getDriver().findElement(By.id("surname")).sendKeys("AutoDel");

		getDriver().findElement(By.id("PanLinkSubmit_5")).click();

		// check that the agreement has been Referred for the appropriate reason
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Referral Queue");
		Assert.assertTrue(getDriver().getPageSource().contains(gcb.gsProfileBriefNote));

		getDriver().findElement(By.xpath("//span[@class='bannerMenuOption']")).click();

		// Logout of Pancredit Front Office
		getDriver().findElement(By.xpath("//a[@href='/panCoreSaas/app?component=%24PanDirectLink_48&page=HomePage&service=direct&session=T&state:HomePage=BrO0ABXcSAAAAAQAAC2N1cnJlbnRQYWdlc3IAEWphdmEubGFuZy5JbnRlZ2VyEuKgpPeBhzgCAAFJAAV2YWx1ZXhyABBqYXZhLmxhbmcuTnVtYmVyhqyVHQuU4IsCAAB4cAAAAAE%3D']")).click();

	}
}
