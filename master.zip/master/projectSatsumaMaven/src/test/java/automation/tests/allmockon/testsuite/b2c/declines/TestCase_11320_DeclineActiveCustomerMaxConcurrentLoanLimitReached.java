package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.test.offerservice.enums.OfferPartyStatus;

public class TestCase_11320_DeclineActiveCustomerMaxConcurrentLoanLimitReached extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_MaxConcurrentLoanLimitReached() throws Exception {

		// Data Preparation
		// ================
		gcb.prGetApplicantProfile(4);
		gcb.prCreateUniquePerson();

		// Seed 1st 50% paid active agreement for this person in PAN
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
		log.info("1st Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);
		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of 1st 50% paid active agreement for this test failed.");
		}

		// Seed 2nd 50% paid active agreement for this person in PAN
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
		log.info("2nd Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);
		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of 2nd 50% paid active agreement for this test failed.");
		}

		// seed FLE ineligble due to concurrent loans offer
		gcb.seedFLEIneligibleOffer("SC", OfferPartyStatus.ACTIVE, false);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// Decline page expected to be triggered on 3rd concurrent loan
		// application
		// ========================================================================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result2
		// We're sorry, This is because you have reached the outstanding loan
		// limit on your account.
		gcb.prAssertOnPageFinishedIDResult2(gsSatsumaSiteUrl);

	}
}
