package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23883_AcceptActiveCustomerRepricesTerm13Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice13weeks1020() throws Exception {
		existingCustomerAccepts("1020", "13", "Weekly", "680", 133);
	}

	@Test
	public void test_Reprice13weeks1050() throws Exception {
		existingCustomerAccepts("1050", "13", "Weekly", "700", 133);
	}

	@Test
	public void test_Reprice13weeks1280() throws Exception {
		existingCustomerAccepts("1280", "13", "Weekly", "1000", 133);
	}
}
