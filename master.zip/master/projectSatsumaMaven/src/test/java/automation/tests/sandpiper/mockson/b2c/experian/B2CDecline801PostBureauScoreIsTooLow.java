package automation.tests.sandpiper.mockson.b2c.experian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnExperianDeclineTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline801PostBureauScoreIsTooLow extends B2CAllMocksOnExperianDeclineTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Post-Bureau Score is Too Low";
	private static final String EXPECTED_PAN_CODE = "801";
	private static final int WEEKLY_APPLICANT_ID = 264;
	private static final int MONTHLY_APPLICANT_ID = 265;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		b2CNewBusinessHardDecline(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		b2CNewBusinessHardDecline(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cFlDeclineWeekly() throws Exception {
		b2CFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cFlDeclineMonthly() throws Exception {
		b2CFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cLoginDeclineWeekly() throws Exception {
		b2CLoginFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cLoginDeclineMonthly() throws Exception {
		b2CLoginFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	// @Test
	// public void B2CNBWeekly() throws Exception {
	//
	// // Data Preparation
	// // ================
	//
	// // Get a Experian application profile for Post-Bureau Score is Too Low
	// // Applicant Mr Gavin Cowlishaw
	// gcb.prGetApplicantProfile(61);
	//
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber +
	// " found, please remove and re-try test");
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Home Credit page
	// // ================
	//
	// gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on
	// // "Post Bureau Score is Too Low" reason is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 801 - Post-Bureau Score is Too
	// // Low
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("Post-Bureau Score is Too Low"));
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	//
	// }

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
