package automation.tests.framework;


public class SatsumaApplicationDatabaseHelperTest {
	//
	// @Test(enabled =false)
	// public void test() {
	// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromAgreement("800000040200");
	// }
}
