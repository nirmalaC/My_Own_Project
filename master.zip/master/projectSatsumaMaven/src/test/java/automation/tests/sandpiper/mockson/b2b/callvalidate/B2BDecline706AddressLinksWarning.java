package automation.tests.sandpiper.mockson.b2b.callvalidate;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.support.SoapUIException;

public class B2BDecline706AddressLinksWarning extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 355;
	private static final int MONTHLY_APPLICANT_ID = 354;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "706";

	@Test
	public void b2BLoginDeclineWeekly() throws XmlException, IOException, SoapUIException, SQLException, Exception {
		b2bFurtherLendingLoginDeclineTest(PAN_CODE, WEEKLY_APPLICANT_ID);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();

		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
