package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;
import automation.dao.SatsumaCustomer;

import com.eviware.soapui.support.SoapUIException;

public class TestSuite_4745_MobileApiTokenTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	// 31892 - fetch content
	@Test
	public void testCase_31984_32092_refreshTokenIOS() throws Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);

		// refresh
		responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678")
				.param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();
		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all()
				.extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	// 31892 - fetch content
	@Test
	public void testCase_31984_31888_refreshTokenAndroid() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);

		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);

		// refresh
		responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678")
				.param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();
		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount check same person comes back
		myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all()
				.extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);
	}

	// calling refresh with different device id to that used to get token
	// calling access
	@Test
	public void testCase_32721_refreshTokenWrongDeviceId() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log()
				.all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);

		// refresh
		responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678")
				.param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();
		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount check same person comes back
		myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all()
				.extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].HasActivePaymentArrangement"), false);

		// refresh again this time using different deviceID
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "99999999")
				.param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all().statusCode(400);
	}

	@Test
	public void testCase_32086_noTokenMyAccount() {
		final String PLATFORM = "Android";

		given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + "").when().get(ACCOUNT_URL).then().log().all().statusCode(401);

	}

// This is an invalid test as the consents are been separated (As part of EUGDPR Party API - Updated on 11/05/2018)
//	@Test
//	public void testCase_31982_noTokenUpdateContactPrefs() {
//		final String PLATFORM = "Android";
//
//		String jsonBody = "{ \"Online\": \"true\" }";
//		given().log().all().contentType("application/json").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Platform", PLATFORM).header("Authorization", "Bearer " + "").body(jsonBody).when().put(UPDATE_CONTACT_PREF_URL).then().log().all()
//				.statusCode(401);
//	}

	@Test
	public void testCase_32088_noTokenFLJourneyLink() {
		final String PLATFORM = "Android";

		// FL link without token
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + "").when().get(JOURNEY_LINK_FL_URL).then().log().all()
				.statusCode(401);

	}

	// 31892 - no date header
	@Test
	public void testCase_31993_noDateHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// login
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).param("grant_type", "password").param("client_id", "12345678").param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword)
				.when().post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).param("grant_type", "refresh_token").param("client_id", "12345678").param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all()
				.statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));

	}

	// 31892 - invalid app version header
	@Test
	public void testCase_31998_invalidAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// login
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("FailureType", equalTo("AppVersionNotSupported"))
				.body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678").param("refresh_token", refreshToken)
				.when().post(TOKEN_URL).then().log().all().body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));
	}

	// 31892 - no app version header
	@Test
	public void testCase_31994_noAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// login
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678").param("username", satsumaCustomer.getEmailAddress())
				.param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678").param("refresh_token", refreshToken).when().post(TOKEN_URL).then()
				.log().all().statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31996_invalidPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// login
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "Windows").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", APP_VERSION_NO).param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "Windows").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", APP_VERSION_NO).param("grant_type", "refresh_token").param("client_id", "12345678")
				.param("refresh_token", refreshToken).when().post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_31995_noPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// login
		given().contentType("application/x-www-form-urlencoded").log().all().header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678").param("username", satsumaCustomer.getEmailAddress())
				.param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'Platform'"));

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("client_id", "12345678").param("refresh_token", refreshToken).when()
				.post(TOKEN_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'Platform'"));
	}

	@Test
	public void testCase_31991_badPassword() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";
		encodedPassword = RsaPasswordEncoder.rsaEncode("WrongPassword1");

		// login - currently gives 400 should it be 401?
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().statusCode(400);

	}

	@Test
	public void testCase_32017_noDeviceId() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement();
		final String PLATFORM = "iOS";
		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// refresh
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "refresh_token").param("refresh_token", refreshToken).when()
				.post(TOKEN_URL).then().log().all().statusCode(400).body("error", equalTo("invalid_client"));
	}
}
