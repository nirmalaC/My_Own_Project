package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;

public class TestSuite_4740_MobileApiContentServiceTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	// 31892 - fetch content
	@Test
	public void testCase_31892_fetchContentIOS() throws Exception {
		String responseString = given().contentType("application/json").log().all().header("platform", "iOS").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(CONTENT_URL).then().log().all().statusCode(200).extract().response().asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	// 31892 - fetch content
	@Test
	public void testCase_31892_fetchContentContentAndroid() {
		String responseString = given().contentType("application/json").log().all().header("platform", "Android").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(CONTENT_URL).then().log().all().statusCode(200).extract().response()
				.asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	// 31892 - no date header
	@Test
	public void testCase_31986_noDateHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("appVersionNumber", APP_VERSION_NO).when().get(CONTENT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));
	}

	// 31892 - invalid app version header
	@Test
	public void testCase_31988_invalidAppVersionHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("appVersionNumber", "0").when().get(CONTENT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("AppVersionNotSupported"))
				.body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));
	}

	// 31892 - no app version header
	@Test
	public void testCase_31987_noAppVersionHeader() {
		given().contentType("application/json").log().all().header("platform", "Android").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(CONTENT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31988_invalidPlatformHeader() {
		given().contentType("application/json").log().all().header("platform", "Windows").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(CONTENT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader"))
				.body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_32591_noPlatformHeader() {
		given().contentType("application/json").log().all().header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(CONTENT_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'Platform'"));
	}
}
