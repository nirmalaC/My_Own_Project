package automation.tests.allmockon.login.loginandregistration;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.xmlbeans.XmlException;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import automation.basetests.MySatsumaSliderBarTest;

import com.eviware.soapui.support.SoapUIException;

public class TestCase_32796_ApplyFLActiveCustomerDiffBankDetails extends MySatsumaSliderBarTest {
	@Test
	public void test() throws XmlException, SoapUIException, IOException, Exception {

		// seed and register an agreement
		seedAndRegisterLogin(700f, "52", false);

		gcb.gsRequestedLoanAmount = "990";
		gcb.gsRequestedTerm = "13";
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		login.clickApplyStartSecondLoan();
		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(700f, 696.53f)));

		// // change bank details in PAN
		// gcb.prLogIntoPanCreditFrontOffice();
		// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
		// gcb.prNavigateToPANBankDetails();
		// String changedName = "";
		// String changedSortCode = "";
		// String changedAccountNo = "";
		// gcb.prEditPANBankDetails("Changed Name", "888888", "88888888");
		// // continue bank application to bank details screen and verify

		// verify you cannot amend bank details

		login.assertOnPageFL(gsSatsumaSiteUrl, gcb.formatCurrencyToDisplayNoDP(String.valueOf(Float.toString(gcb.calcEligibleAmount(700f, 696.53f)))));

		log.info(gcb.gsRequestedLoanAmount);

		login.confirmDetailsAboutYou("Household Goods", gcb.formatCurrencyToDisplayNoDP(String.valueOf(gcb.gsRequestedLoanAmount)), gcb.gsRequestedTerm, gcb.gsRepaymentFrequency, gcb.gsPreferredPaymentDow, Boolean.parseBoolean(gcb.gsMarketingOptInEmail),
				Boolean.parseBoolean(gcb.gsMarketingOptInSMS), Boolean.parseBoolean(gcb.gsMarketingOptInPhone), Boolean.parseBoolean(gcb.gsMarketingOptInPost));

		// gcb.prClickForNextAction();
		gcb.waitForClickableElement(By.id("ContinueButtonStep1"));
		getDriver().findElement(By.id("ContinueButtonStep1")).click();

		login.assertOnPageFLYourFinances(gsSatsumaSiteUrl);

		login.confirmDetailsYourFinances();

		gcb.prClickForNextAction();

		gcb.prAssertQuoteOfferAsPerRequest();

		gcb.prClickForNextAction();

		log.debug("date bank account opened " + gcb.gsBankAccountOpenDate);
		log.debug("bank account no " + gcb.gsBankAccountNumber);
		log.debug("bank sort code " + gcb.gsBankSortcode);
		log.debug("bank account name " + gcb.gsBankAccountName);

		SimpleDateFormat dateInFormatter = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat monthDateFormatter = new SimpleDateFormat("MMMM");
		SimpleDateFormat yearDateFormatter = new SimpleDateFormat("yyyy");
		Date dateBankAccount = dateInFormatter.parse(gcb.gsBankAccountOpenDate);
		String bankMonthOpened = monthDateFormatter.format(dateBankAccount);
		String bankYearOpened = yearDateFormatter.format(dateBankAccount);

		log.debug("bankMonthOpened " + bankMonthOpened);
		log.debug("bankYearOpened " + bankYearOpened);

		login.assertFLBankDetailsPage(gcb.gsBankAccountName, gcb.gsBankAccountNumber, gcb.gsBankSortcode, bankMonthOpened, bankYearOpened);

		String newBankAccountName = "New Name";
		String newBankAccountNumber = "99999999";
		String newBankSortCode = "888888";
		String newBankAccountOpenDate = "13/12/2012";

		// changes bank details and clicks submit button
		login.changeFLBankDetails(newBankAccountName, newBankAccountNumber, newBankSortCode, newBankAccountOpenDate);

		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		gcb.prAssertOnPageFLCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		log.info("new further lending agreement number: " + sAgreementNumber);
		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		login.assertOnPageFLAcceptComplete(gsSatsumaSiteUrl);

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);
		gcb.prNavigateToPANBankDetails();
		login.prAssertPANBankDetails(newBankAccountName, newBankSortCode, newBankAccountNumber);

	}
}
