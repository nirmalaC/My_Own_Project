package automation.tests.allmockon.login.loginandregistration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

import com.eviware.soapui.support.SoapUIException;

public class TestCase_28994_GroupASelfInitiatedRegistrationSoap extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_SOAPUIAgreement() throws Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		// //bug fixed
		// // currently there is a bug in pan that does not set the title, so
		// this
		// // sets the title through pan front office
		// gcb.prLogIntoPanCreditFrontOffice();
		// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
		// gcb.prPANChangePersonTitle("Mrs");
		// gcb.prPANClickNameUpdateButton();
		// gcb.prLogoutFromPanCreditFrontOffice();

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test(enabled = false)
	public void test_SOAPUIAgreement50PaidUp() throws Exception {
		List<String> createdAgreements = new ArrayList<String>();
		createdAgreements.add(seed50PaidUp("100", "52"));
		createdAgreements.add(seed50PaidUp("100", "52"));
		createdAgreements.add(seed50PaidUp("100", "52"));
		createdAgreements.add(seed50PaidUp("100", "52"));
		createdAgreements.add(seed50PaidUp("100", "52"));
		createdAgreements.add(seed50PaidUp("500", "52"));
		createdAgreements.add(seed50PaidUp("500", "52"));
		createdAgreements.add(seed50PaidUp("500", "52"));
		createdAgreements.add(seed50PaidUp("500", "52"));
		createdAgreements.add(seed50PaidUp("500", "52"));
		createdAgreements.add(seed50PaidUp("800", "52"));
		createdAgreements.add(seed50PaidUp("800", "52"));
		createdAgreements.add(seed50PaidUp("800", "52"));
		createdAgreements.add(seed50PaidUp("800", "52"));
		createdAgreements.add(seed50PaidUp("800", "52"));
		createdAgreements.add(seed50PaidUp("1000", "52"));
		createdAgreements.add(seed50PaidUp("1000", "52"));
		createdAgreements.add(seed50PaidUp("1000", "52"));
		createdAgreements.add(seed50PaidUp("1000", "52"));
		createdAgreements.add(seed50PaidUp("1000", "52"));

		for (String temp : createdAgreements) {
			log.info(temp);
		}

	}

	private String seed50PaidUp(String loanAmount, String loanTerm) throws XmlException, SoapUIException, IOException, Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(6);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, loanAmount, loanTerm, "weekly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

		return gcb.gsPANAgreementNumber + "," + gcb.gsEmailAddress + "," + gcb.gsPANPersonId + "," + loanAmount + "," + loanTerm;
	}
}
