package automation.tests.smartcheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.SmartCheckBaseTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class SmartCheckDecline107OfferService extends SmartCheckBaseTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test107HX() throws Exception {
		newCustFLEDeclineTest(408, "107", "HX");
	}

	@Test
	public void test107CF() throws Exception {
		newCustFLEDeclineTest(408, "107", "CF");
	}

	@Test
	public void test107HY() throws Exception {
		newCustFLEDeclineTest(408, "107", "HY");
	}

	@Test
	public void test107HZ() throws Exception {
		newCustFLEDeclineTest(408, "107", "HZ");
	}

	@Test
	public void test107SC() throws Exception {
		newCustFLEDeclineTest(408, "107", "SC");
	}

	@AfterMethod
	public void teardown() throws Exception {
		// clear down customer
		if (smartcheck.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
