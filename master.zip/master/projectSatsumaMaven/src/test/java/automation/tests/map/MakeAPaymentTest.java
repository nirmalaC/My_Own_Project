package automation.tests.map;

import org.testng.SkipException;
import org.testng.annotations.Test;

import automation.basetests.BrowserTest;
import automation.tools.EntityHubHelper;

public class MakeAPaymentTest extends BrowserTest {

	@Test
	public void test() throws Exception {
		if (!gcb._getConfigProperty("RunMapTests").equalsIgnoreCase("true"))
			throw new SkipException("Not running map test, if you want to run set system property RunMapTests=true");

		map.prGetApplicantProfile(6);

		// open pan and try to find an agreement or customer in arrears
		gcb.prLogIntoPanCreditFrontOffice();
		map.searchForCustomerAgreement("customer", "goesintoarrears", "*");
		// map.findAgreementInArrearsInPAN(2);
		map.getAgreementInfoFromPAN();
		gcb.prLogoutFromPanCreditFrontOffice();

		// transfer properties
		gcb.gsFirstname = map.gsFirstname;
		gcb.gsSurname = map.gsSurname;
		gcb.gsDOB = map.gsDOB;
		gcb.gsPostcode = map.gsPostcode;
		gcb.gsPANAgreementNumber = map.gsPANAgreementNumber;

		login.gsFirstname = map.gsFirstname;
		login.gsSurname = map.gsSurname;
		login.gsDOB = map.gsDOB;
		login.gsPostcode = map.gsPostcode;
		login.gsPANAgreementNumber = map.gsPANAgreementNumber;
		login.gsEmailAddress = map.gsEmailAddress;
		gcb.gsEmailAddress = map.gsEmailAddress;

		login.gsLoginUsername = map.gsEmailAddress;
		login.gsLoginPassword = "Password1";

		gcb.gsLoginUsername = map.gsEmailAddress;
		gcb.gsLoginPassword = "Password1";

		// if customer is not registered, then register them
		if (!EntityHubHelper.checkIfCustomerRegistered(gcb._getConfigProperty("EntitySearchDB"), gcb.gsFirstname, gcb.gsSurname)) {
			log.debug("customer is not registered, registering them...");

			// navigate to register
			login.navigateToRegistrationPage(gsSatsumaSiteUrl);

			// register a new account
			login.fillInPageIdentifyYourAccount();

			// select your password
			login.assertOnPagePassword(gsSatsumaSiteUrl);
			login.fillInPageCompleteYourRegistration();

			// check successful registration
			login.assertOnPageRegistered(gsSatsumaSiteUrl);

		}

		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// log into satsuma website
		login.loginInPageLogin();

		// make a payment
		map.makeAPayment(10.00f);
		map.assertOnPageMapWorldPay();
		map.fillInPageMapWorldpay();

		// wait for success message page
		map.assertOnPageMySatsumaWorldPayComplete();

		map.verifyPaymentInMySatsuma();

		// log out
		login.logoutInPageLogin();

		// verify payment in PAN
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prNavigateToPANCreditAgreement(map.gsPANAgreementNumber);
		map.verifyArrearsZero();
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}
