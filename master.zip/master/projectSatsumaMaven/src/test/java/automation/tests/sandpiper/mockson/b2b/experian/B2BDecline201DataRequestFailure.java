package automation.tests.sandpiper.mockson.b2b.experian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

public class B2BDecline201DataRequestFailure extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 336;
	private static final int MONTHLY_APPLICANT_ID = 337;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	String PAN_CODE = "201";

	@Test
	public void b2BNBDeclineWeekly() throws Exception {

		b2bDeclineTest(PAN_CODE, WEEKLY_APPLICANT_ID);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
