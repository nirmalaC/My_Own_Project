package automation.tests.experian.downsell;

import automation.basetests.ExperianMockOffTestAdapted;

public class TestCase_WeeklyDownsellNPRTScoreDownsellTo800 extends ExperianMockOffTestAdapted {

	// @Test
	// public void downsellTo800() throws Exception {
	// SatsumaExperianAgreement agreement =
	// ExperianDataHelper.getSatsumaExperianAgreement("LISA", "HOOK");
	// log.debug(agreement.toString());
	// ExperianDataHelper.convertToCookbook(agreement, gcb);
	// gcb.setRandomEmail();
	// newCustomerQuoteVerifyDownsell("1000", "13", "Weekly", 133, true);
	// }
}
