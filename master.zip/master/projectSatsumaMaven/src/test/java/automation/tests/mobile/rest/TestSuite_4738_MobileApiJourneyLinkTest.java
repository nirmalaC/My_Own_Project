package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;

import com.eviware.soapui.support.SoapUIException;

public class TestSuite_4738_MobileApiJourneyLinkTest extends MobileAPITest {
	public final static String APP_VERSION_NO = "1.1";

	@Test
	public void testCase_32698_furtherLendingLoggedInIOS() throws Exception {
		satsumaCustomer = addNewHalfPaidUpAgreement();

		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// journeyLink furtherlending
		responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	@Test
	public void testCase_32699_furtherLendingLoggedInAndroid() throws Exception {
		satsumaCustomer = addNewHalfPaidUpAgreement();

		final String PLATFORM = "Android";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// journeyLink furtherlending
		responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when()
				.get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(200).extract().response().asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	@Test
	public void testCase_31020_applyiOS() throws SQLException, XmlException, SoapUIException, IOException, Exception {

		final String PLATFORM = "iOS";

		// journeyLink apply
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then().log().all().statusCode(200)
				.extract().response().asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	@Test
	public void testCase_31022_applyAndroid() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "Android";

		// journeyLink apply
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then().log().all().statusCode(200)
				.extract().response().asString();
		Assert.assertTrue(responseString.length() > 0);
	}

	// 31892 - no date header
	@Test
	public void testCase_31026_noDateHeaderApplyAndFL() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		satsumaCustomer = addNewHalfPaidUpAgreement();

		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// apply
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).when().get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));

		// fl
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + accessToken).when().get(JOURNEY_LINK_APPLY_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'DateAndTime'"));
	}

	// 31892 - invalid app version header
	@Test
	public void testCase_31028_invalidAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";
		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// apply
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));

		// fl
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("Authorization", "Bearer " + accessToken).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then().log().all()
				.statusCode(400).body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));

	}

	// 31892 - no app version header
	@Test
	public void testCase_31024_noAppVersionHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// apply
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(400).body("FailureType", equalTo("MissingHeader"))
				.body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

		// fl
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("Authorization", "Bearer " + accessToken).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("MissingHeader")).body("FriendlyMessage", equalTo("Missing header 'AppVersionNumber'"));

	}

	// 31892 - invalid platform header
	@Test
	public void testCase_31027_invalidPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// apply
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "windows").header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

		// fl
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", "windows").header("appVersionNumber", APP_VERSION_NO).header("Authorization", "Bearer " + accessToken).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then()
				.log().all().statusCode(400).body("FailureType", equalTo("InvalidHeader")).body("FriendlyMessage", equalTo("Invalid header 'Platform'"));

	}

	// 31892 - no platform header
	@Test
	public void testCase_31025_noPlatformHeader() throws SQLException, XmlException, SoapUIException, IOException, Exception {
		final String PLATFORM = "iOS";

		satsumaCustomer = addNewHalfPaidUpAgreement();

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", APP_VERSION_NO).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678")
				.param("username", satsumaCustomer.getEmailAddress()).param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// apply
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_FL_URL).then().log().all().statusCode(400)
				.body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));

		// fl
		given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "0").header("Authorization", "Bearer " + accessToken).header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").when().get(JOURNEY_LINK_APPLY_URL).then().log().all()
				.statusCode(400).body("FailureType", equalTo("AppVersionNotSupported")).body("FriendlyMessage", equalTo("App version '0' not supported. Minimum '" + APP_VERSION_NO + "'"));

	}

}
