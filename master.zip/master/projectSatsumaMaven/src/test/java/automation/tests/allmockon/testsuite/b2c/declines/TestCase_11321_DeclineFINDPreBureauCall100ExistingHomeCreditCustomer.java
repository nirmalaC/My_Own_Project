package automation.tests.allmockon.testsuite.b2c.declines;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;

public class TestCase_11321_DeclineFINDPreBureauCall100ExistingHomeCreditCustomer extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// disabled as no longer relevent since offer service now allows certain HC
	// customers through
	@Test(enabled = false)
	public void test_DeclineExistingHomeCreditApplicant() throws Exception {

		// Initialise gcb.gsPANAgreementNumber for new customer scenario
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// // Get a application profile for Pre Bureau result 100 - Existing
		// Home
		// // Credit Customer
		// // Mrs Lorraine Newman
		// gcb.prGetApplicantProfile(66);
		// Changed to Zahir Ahmed
		// Changed to Elizabeth Sicberras 02/01/1954 E3 5JG

		// needs to be changed to Ann Cross
		gcb.prGetApplicantProfile(170);
		gcb.setRandomEmail();
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

		// check person's current status
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (!gcb.gsPANPersonId.equals("")) {
			log.warn("PersonID: " + gcb.gsPANPersonId + " found, trying to remove");
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();

			// navigate back to about you

			getDriver().manage().deleteAllCookies();
			getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

			// Goto Satsuma site
			getDriver().get(this.gsSatsumaSiteUrl);

			// Home page
			// ==============

			gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

			// Invoke Next action: Apply now

			final By byBtnApply = By.id("SubmitHomeCalc");
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnApply)));
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnApply)));
			getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
			getDriver().findElement(byBtnApply).click();

			// Your Application page
			// =====================

			gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

			final By byBtnStartYourApplication = By.linkText("Start your application");
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
			(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
			// Invoke Next action: Start your application
			getDriver().findElement(By.linkText("Start your application")).click();

		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// // Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
		//
		// // Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Have we landed on the FIND Decline page in context that the applicant
		// is found to be Home Credit customer
		gcb.prAssertOnPageFinishedIDResult23(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline
		// reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "Existing Home Credit Customer" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be rejected with a 102 - External Lending
		// Decision Failure.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains("Existing Home Credit Customer"));

		// gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
