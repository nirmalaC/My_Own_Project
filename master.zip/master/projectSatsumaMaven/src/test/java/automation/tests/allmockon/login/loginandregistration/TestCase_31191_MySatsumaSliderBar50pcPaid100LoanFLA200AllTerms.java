package automation.tests.allmockon.login.loginandregistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.MySatsumaSliderBarTest;

public class TestCase_31191_MySatsumaSliderBar50pcPaid100LoanFLA200AllTerms extends MySatsumaSliderBarTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test13Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 13, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test3Months() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Monthly", 3, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test17Weeks() throws Exception {
		seedAndRegisterLogin(100f, "13", false);
		login.clickApplyStartSecondLoan();
		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 17, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test21Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 21, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test26Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 26, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test30Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 30, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test34Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 34, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test39Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 39, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test43Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 43, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test47Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 47, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test
	public void test52Weeks() throws Exception {

		seedAndRegisterLogin(100f, "13", false);

		login.clickApplyStartSecondLoan();

		login.assertOnPageAboutYou(gsSatsumaSiteUrl, gcb.gsFirstname, Float.toString(gcb.calcEligibleAmount(100f, 71.58f)));

		// test the slider
		test_AboutYouSliderPricingCalculations("Weekly", 52, 100, 200);

		// gcb.logoutInPageLogin();
		// gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}
}
