package automation.tests.sandpiper.mockson.b2b.experian;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.support.SoapUIException;

public class B2BDecline204WorstCurrentStatus extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 331;
	private static final int MONTHLY_APPLICANT_ID = 330;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "204a";

	@Test
	public void b2BLoginDeclineWeekly() throws XmlException, IOException, SoapUIException, SQLException, Exception {
		b2bFurtherLendingLoginDeclineTest(PAN_CODE, WEEKLY_APPLICANT_ID);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
