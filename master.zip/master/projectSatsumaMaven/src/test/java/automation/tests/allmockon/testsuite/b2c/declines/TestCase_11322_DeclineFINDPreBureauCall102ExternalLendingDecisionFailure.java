package automation.tests.allmockon.testsuite.b2c.declines;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_11322_DeclineFINDPreBureauCall102ExternalLendingDecisionFailure extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// Has not worked for the last few sprints, disabled for now
	@Test(enabled = false)
	public void test_DeclineOnExternalLendingDecisionFailure() throws Exception {

		// Initialise gcb.gsPANAgreementNumber for new customer scenario
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a application profile pre Bureau result 102 - External Lending
		// Decision Failure
		// Mrs Jennifer Morgar
		gcb.prGetApplicantProfile(65);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke only if we have not switched on quick application
		// functionality, by directly navigating to
		// the next page i.e. Your Finances otherwise this is combined page
		// journey
		if (!gcb.gsQuickApply.equals("true")) {
			// Invoke Next action: Next: Your Finances
			gcb.prClickForNextAction();

			// Your Finances Page
			// ==================

			gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		}

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result24
		// Have we landed on the FIND Decline page in context that the applicant
		// is not successful on this occasion and no credit check has been
		// performed
		gcb.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct decline on
		// "External Lending Decision Failure" reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be rejected with a 102 - External Lending
		// Decision Failure.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		Assert.assertTrue(getDriver().getPageSource().contains("External Lending Decision Failure"));

		gcb.prPANRenameAgreementsApplicantSurname(gcb.gsPANAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}

}
