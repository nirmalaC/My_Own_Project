package automation.tests.cma;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_33370_B2CCMAExistingCustomerHappyPath extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice13weeks1020() throws Exception {
		existingCustomerAccepts("1020", "13", "Weekly", "680", 133);
	}
}
