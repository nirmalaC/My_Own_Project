package automation.tests.sandpiper.mockson.b2c.experian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnExperianDeclineResult24Test;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline201LatestCreditSearchFailure extends B2CAllMocksOnExperianDeclineResult24Test {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String CREDIT_SEARCH_FAILURE_DESC = "Latest Credit Search Failure";
	private static final String CREDIT_SEARCH_FAILURE_CODE = "201";
	private static final int WEEKLY_APPLICANT_ID = 282;
	private static final int MONTHLY_APPLICANT_ID = 283;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		b2CNewBusinessHardDecline(WEEKLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		b2CNewBusinessHardDecline(MONTHLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	@Test
	public void testB2cFlDeclineWeekly() throws Exception {
		b2CFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	@Test
	public void testB2cFlDeclineMonthly() throws Exception {
		b2CFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	@Test
	public void testB2cLoginDeclineWeekly() throws Exception {
		b2CLoginFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	@Test
	public void testB2cLoginDeclineMonthly() throws Exception {
		b2CLoginFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, CREDIT_SEARCH_FAILURE_CODE, CREDIT_SEARCH_FAILURE_DESC);
	}

	// @Test
	// public void B2CNBWeekly() throws Exception {
	//
	// // Data Preparation
	// // ================
	//
	// // Get a Mocked application profile as template for creating a dynamic
	// // unique person. This person
	// // does not exist in the Experian Database.
	//
	// gcb.prGetApplicantProfile(4);
	//
	// gcb.gsFirstname = "johnny";
	// gcb.gsSurname = "datarequestfailurescems";
	//
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// gcb.gsPANAgreementNumber = "";
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Finished Decline page
	// // =====================
	//
	// // Landed on correct decline page - This specific decline page is
	// // identified with id=Result24
	// // Have we landed on the FIND Decline page in context that the applicant
	// // is not successful on this occasion and no credit check has been
	// // performed
	// gcb.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);
	//
	// // Check new proposal agreement created in PAN to record decline reason
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: "
	// + gcb.gsPANPersonId);
	//
	// // Abort test if an agreement not found
	// if (gcb.gsPANAgreementNumber.isEmpty()) {
	// Assert.fail("Aborted: An agreement not found. ");
	// }
	//
	// // Abort test if the agreement is not of Rejected status
	// if (gcb.gsPANAgreementNumber.equals("Rejected")) {
	// Assert.fail("Aborted: Agreement not Rejected as expected.");
	// }
	//
	// // In PanCredit check that the correct decline on
	// // "Latest Credit Search Failure" reason is recorded
	// //
	// ================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);
	//
	// // Expect agreement to be referred with a 201 - Experian Latest Credit
	// // Search Failure, when experian is unable to locate this person
	// // or if Experian is down.
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Rejected");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Rejected Agreements");
	// Assert.assertTrue(getDriver().getPageSource().contains("Latest Credit Search Failure"));
	// Assert.assertTrue(getDriver().getPageSource().contains("201"));
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	//
	// }

	@AfterMethod
	public void afterTest() throws Exception {
		// Log into PanCredit Front Office
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname);
		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
