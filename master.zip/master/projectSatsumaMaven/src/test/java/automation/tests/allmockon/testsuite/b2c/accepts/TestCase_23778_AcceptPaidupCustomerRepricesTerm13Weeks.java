package automation.tests.allmockon.testsuite.b2c.accepts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_23778_AcceptPaidupCustomerRepricesTerm13Weeks extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice13weeks1020() throws Exception {

		// prPerformAccepts("1020", "13", "Weekly", "510");
		prPerformAccepts("1020", "13", "Weekly", "710");
	}

	@Test
	public void test_Reprice13weeks1200() throws Exception {
		// prPerformAccepts("1200", "13", "Weekly", "600");
		prPerformAccepts("1200", "13", "Weekly", "800");
	}

	@Test(enabled = false)
	public void test_Reprice13weeks2000() throws Exception {
		// prPerformAccepts("2000", "13", "Weekly", "1000");
		prPerformAccepts("1500", "13", "Weekly", "1000");
	}

	public void prPerformAccepts(String psLoanAmount, String psLoanTerm, String psRepaymentFrequency, String psPaidUpLoanAmount) throws Exception {

		String sAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(130);
		gcb.prCreateUniquePerson();
		// Seed Pan Credit target test environment with an active full paid up
		// agreement.
		gcb.gsRequestedLoanAmount = psPaidUpLoanAmount;
		gcb.gsRequestedTerm = psLoanTerm;
		gcb.gsRepaymentFrequency = psRepaymentFrequency;
		// gcb.prSeedUnique100PCntPaidUpSpecifiedLoanTermAgreementInPAN(gcb.gsPanCreditServiceServer);
		gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
		// gcb.prSeedUnique50PCntPaidUpSpecifiedLoanTermAgreementInPAN(gcb.gsPanCreditServiceServer);

		gcb.seedFLEEligibleOffer(false, 2000d);
		log.info("Active 100% Paid Up Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of active 100% paid agreement for this test failed. ");
		}

		// Overwrite applicant profile requested loan terms
		gcb.gsRequestedLoanAmount = psLoanAmount;
		gcb.gsRequestedTerm = psLoanTerm;
		gcb.gsRepaymentFrequency = psRepaymentFrequency;
		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);
		log.info("INFO: Repricing check for loan term " + gcb.gsRequestedLoanAmount + " " + gcb.gsRequestedTerm + " " + gcb.gsRepaymentFrequency);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: ?
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and that there are other
		// options available to them
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."), "check on LVA page");

		gcb.waitForSelectedTextInElement(By.id("TotalInterestLVACalcText"), gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest));

		// Assert that Interest, Weekly repayments and TAP are displayed
		// correctly
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), getDriver().findElement(By.id("TotalInterestLVACalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountLVACalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), getDriver().findElement(By.id("TotalAmountLVACalcText")).getText());

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();
		}

		// Invoke Next action: Next: ? Your Quote if Quick Apply else Your
		// Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.EXISTING_NOT_ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result13 in context Great news!
		// Your
		// // next Satsuma Loan has been approved (For existing customer)
		// gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		// gcb.assertFLEESigOffer();

	}
}
