package automation.tests.framework;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.tools.ZoralKnowledgeBaseHelper;

public class ZoralKnowledgeBaseHelperTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() {
		ZoralKnowledgeBaseHelper.getDataMappingString("TST7KnowledgeBaseStorage", "TST7DecisionEngineStoragev13", "TST7ConnectivityStorage", "20a78c1c-5e70-e611-a457-005056ae561b");
	}

}
