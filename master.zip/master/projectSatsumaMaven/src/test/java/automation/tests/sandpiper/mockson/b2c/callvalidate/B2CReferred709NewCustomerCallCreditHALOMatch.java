package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnCallCreditReferralTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CReferred709NewCustomerCallCreditHALOMatch extends B2CAllMocksOnCallCreditReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Callcredit HALO Match";
	private static final String EXPECTED_PAN_CODE = "709";
	private static final int WEEKLY_APPLICANT_ID = 234;
	private static final int NEW_BUS_WEEKLY_APPLICANT_ID = 318;
	private static final int MONTHLY_APPLICANT_ID = 269;
	private static final int NEW_BUS_MONTHLY_APPLICANT_ID = 317;

	@Test
	public void testB2cNbReferralWeekly() throws Exception {
		b2CNewBusinessReferral(NEW_BUS_WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cNbReferralMonthly() throws Exception {
		b2CNewBusinessReferral(NEW_BUS_MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cFLReferralWeekly() throws Exception {
		b2CFLReferral(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cFLReferralMonthly() throws Exception {
		b2CFLReferral(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cLoginReferralWeekly() throws Exception {
		b2CLoginFLReferral(WEEKLY_APPLICANT_ID, EXPECTED_PAN_DESC, EXPECTED_PAN_CODE);
	}

	@Test
	public void testB2cLoginReferralMonthly() throws Exception {
		b2CLoginFLReferral(MONTHLY_APPLICANT_ID, EXPECTED_PAN_DESC, EXPECTED_PAN_CODE);
	}

	// @Test
	// public void test_ReferIfApplicantCallCreditSearchDeterminesHALOMatch()
	// throws Exception {
	//
	// String sAgreementNumber;
	//
	// // Data Preparation
	// // ================
	//
	// // Get a application profile for applicant on Mocked Callcredit test
	// // environment who is flagged with HALO Match
	// // Applicant Halo Match
	// gcb.prGetApplicantProfile(234);
	// gcb.setRandomEmail();
	// // Determine if test subject has agreements on the target PAN
	// // environment, if so we need to remove links to this
	// // person as the test expects them to be a new customer (not known to
	// // Provident)
	// gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	//
	// if (gcb.gsPANAgreementFound.equals("true")) {
	// PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB,
	// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, gcb.gsFirstname,
	// gcb.gsSurname);
	// log.warn("Aborted: An agreement is found, trying to remove");
	// removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
	// }
	//
	// // Get Expected Loan Offer Details
	// gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency,
	// Integer.parseInt(gcb.gsRequestedTerm),
	// Integer.parseInt(gcb.gsRequestedLoanAmount));
	//
	// // About You page
	// // ==============
	//
	// gcb.prFillInPageAboutYou();
	//
	// // Invoke Next action: Next: Your Finances
	// gcb.prClickForNextAction();
	//
	// // Your Finances Page
	// // ==================
	//
	// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
	//
	// // Fill in applicants finance details from the profile
	// gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
	//
	// // Invoke Next action: Next: Review Your Quote
	// gcb.prClickForNextAction();
	//
	// // Your Quote page
	// // ==============
	//
	// gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);
	//
	// // Invoke Next action: Next: Bank Details
	// gcb.prClickForNextAction();
	//
	// // Bank Details page
	// // =================
	//
	// gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);
	//
	// // Fill in applicants bank details from the profile
	// gcb.prFillInPageBankDetailsRandom();
	//
	// // Invoke Next action: Next: Payment Details
	// gcb.prClickForNextAction();
	//
	// // WorldPay Test Page
	// // ==================
	//
	// // Fill in applicants card details from the profile and trigger a
	// // Approved response
	// gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved",
	// "Postcode and address matched");
	//
	// // Password screen Login Phase 2
	// // =====================
	//
	// // Fill in password box
	// gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
	// gcb.fillInPageMySatsumaAccount("Password1");
	//
	// // Credit Agreement page
	// // ======================
	//
	// gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);
	//
	// // Read and Sign the Credit Agreement
	// gcb.prReadAndSignCreditAgreement();
	//
	// // Capture Agreement Number from the Credit Agreement page
	// sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();
	//
	// // Invoke Next action: Next: Complete Your Agreement
	// gcb.prClickForNextAction();
	//
	// // Completion page
	// // ===============
	//
	// // Landed on completion page type Result11 in context Your application
	// // is now being processed and verified.
	// // Within 24 hours customer care team will contact you whether your
	// // application has been accepted.
	// // gcb.prAssertOnPageCompletionIDResult11(gsSatsumaSiteUrl);
	// gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);
	//
	// // In PanCredit try and remove test subject agreement, so that we can
	// // re-run the test next time using same subject
	// // but also check that the correct decline on "Callcredit HALO Match"
	// // reason is recorded
	// //
	// ===============================================================================================================
	//
	// // Log into PanCredit Front Office
	// gcb.prLogIntoPanCreditFrontOffice();
	//
	// gcb.prNavigateToPANCreditAgreement(sAgreementNumber);
	//
	// // Expect agreement to be referred with a 709 - Callcredit HALO Match
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(),
	// "Decision Referred");
	// Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(),
	// "Queue Referral Queue");
	// Assert.assertTrue(getDriver().getPageSource().contains("Callcredit HALO Match"));
	//
	// // Log out of PanCredit Front Office
	// gcb.prLogoutFromPanCreditFrontOffice();
	//
	// }

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
