package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23770_AcceptNewCustomerRepricesTerm47Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice47weeks100() throws Exception {
		newCustomerAccept("100", "47", "Weekly", 133);
	}

	@Test
	public void test_Reprice47weeks250() throws Exception {
		newCustomerAccept("250", "47", "Weekly", 133);
	}

	@Test
	public void test_Reprice47weeks1000() throws Exception {
		newCustomerAccept("1000", "47", "Weekly", 133);
	}

}
