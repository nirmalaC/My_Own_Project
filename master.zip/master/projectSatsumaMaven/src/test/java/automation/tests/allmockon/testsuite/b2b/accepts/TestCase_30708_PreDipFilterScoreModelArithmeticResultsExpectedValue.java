package automation.tests.allmockon.testsuite.b2b.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;

/*
 * System Test
 This test is concerned with ensuring that the calculation of the Pre-DiP Filter Score is correct.
 To test use the attached WCFStorm XML as a template and modify using the parameterised data in the test case.  
 Ensure that the SatsumaBrokerPreliminaryEnhancedWorkflow has ItemId="61" : SamplingRatioA="1.00" and ItemId="21" : SamplingRatioA="1.00".
 Can be tested with all mocks ON.
 */

// same as test case TestCase_15655_AcceptHappyPath100Over13
public class TestCase_30708_PreDipFilterScoreModelArithmeticResultsExpectedValue extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void testRow1() throws Exception {
		gcb.prGetApplicantProfile(174);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();

		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "50.53320086");

		// Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB,
		// gcb.gsFirstname, gcb.gsSurname), "50.53320086",
		// "check predip score");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 50.0f, "check predip score");

	}

	@Test
	public void testRow2() throws Exception {
		gcb.prGetApplicantProfile(175);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "69.96650331");

		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 69.0f, "check predip score");

	}

	@Test
	public void testRow3() throws Exception {
		gcb.prGetApplicantProfile(176);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "38.1607807");

		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 38.0f, "check predip score");

	}

	@Test
	public void testRow4() throws Exception {
		gcb.prGetApplicantProfile(177);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// soapui test case called expected to decline
		// TestCase testCase =
		// gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter",
		// "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		//
		// String decisionRef =
		// SatsumaApplicationDatabaseHelper.getDecisionReferenceFromForenameSurnameDOB(gcb.applicationDB,
		// gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "23.61861733");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 23.0f, "check predip score");

	}

	@Test
	public void testRow5() throws Exception {
		gcb.prGetApplicantProfile(178);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		Thread.sleep(200);
		System.out.println("powercureve value --->" + gcb.powercurveDB);
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 50.0f, "check predip score");

	}

	@Test
	public void testRow6() throws Exception {
		gcb.prGetApplicantProfile(179);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "49.91357236");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 49.0f, "check predip score");

	}

	@Test
	public void testRow7() throws Exception {
		gcb.prGetApplicantProfile(180);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "41.28914065");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 41.0f, "check predip score");

	}

	@Test
	public void testRow8() throws Exception {
		gcb.prGetApplicantProfile(181);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "52.43555792");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 52.0f, "check predip score");

	}

	@Test
	public void testRow9() throws Exception {
		gcb.prGetApplicantProfile(182);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "56.75940599");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 56.0f, "check predip score");

	}

	@Test
	public void testRow10() throws Exception {
		gcb.prGetApplicantProfile(183);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();
		gcb.setRandomEmail();
		// call soap ui and generate broker lead
		String brokerUrl = preDipScoreBrokerSomeNullLeadSoapUi();
		// // get dip id
		// String decisionRef = extractDipIdFromLink(brokerUrl);
		// // verify score using dip id
		// verifyPreDipFilterScoreFromDecisionRef(gcb.zoralDB, decisionRef,
		// "50.53320086");
		Assert.assertEquals(PowerCurveDBHelper.getPreDipScore(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname), 50.0f, "check predip score");

	}

}
