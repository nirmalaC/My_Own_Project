package automation.tests.monthly;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_MonthlyNewCustomer4Months extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_LoanAmount100() throws Exception {
		newCustomerAccept("100", "4", "Monthly", 133);
	}

	@Test
	public void test_LoanAmount200() throws Exception {
		newCustomerAccept("200", "4", "Monthly", 133);
	}

	@Test
	public void test_LoanAmount500() throws Exception {
		newCustomerAccept("500", "4", "Monthly", 133);
	}

	@Test
	public void test_LoanAmount1000() throws Exception {
		newCustomerAccept("1000", "4", "Monthly", 133);
	}

}
