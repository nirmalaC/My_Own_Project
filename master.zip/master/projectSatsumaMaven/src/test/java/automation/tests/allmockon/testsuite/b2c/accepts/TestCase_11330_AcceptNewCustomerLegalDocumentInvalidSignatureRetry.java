package automation.tests.allmockon.testsuite.b2c.accepts;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_11330_AcceptNewCustomerLegalDocumentInvalidSignatureRetry extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_AcceptLDCCustomerAfterInvalidSignatureRetry() throws Exception {

		String sAgreementNumber = "";
		String sFirstname, sSurname;

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer.

		gcb.prGetApplicantProfile(5);
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		gcb.gsPANAgreementNumber = "";

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action:
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Take copy of original firstname and surname, then try to sign
		// document with alternate name
		sFirstname = gcb.gsFirstname;
		sSurname = gcb.gsSurname;
		gcb.gsFirstname = "Thisis";
		gcb.gsSurname = "Notme";

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// assertEquals("Forename does not match to previous entered forename.",getDriver().findElement(By.xpath("//span[@for='CustomerFirstnameSignature']")));

		// Retry with correct firstname incorrect surname
		gcb.gsFirstname = sFirstname;
		getDriver().findElement(By.id("CustomerFirstnameSignature")).clear();
		getDriver().findElement(By.id("CustomerFirstnameSignature")).sendKeys(sFirstname);

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// assertEquals("Surname does not match to previous entered surname.",getDriver().findElement(By.xpath("//span[@for='CustomerSurnameSignature']")));

		// Retry with correct firstname correct surname
		gcb.gsSurname = sSurname;
		getDriver().findElement(By.id("CustomerSurnameSignature")).clear();
		getDriver().findElement(By.id("CustomerSurnameSignature")).sendKeys(sSurname);

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result19 in context Great news!
		// Your
		// // Satsuma Loan has been approved (For new customer)
		// gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount,
				gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP, gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber,
				gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}
}
