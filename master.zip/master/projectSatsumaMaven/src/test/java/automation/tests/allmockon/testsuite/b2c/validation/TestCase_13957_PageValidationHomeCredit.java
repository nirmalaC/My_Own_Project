package automation.tests.allmockon.testsuite.b2c.validation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;
import automation.dao.CustomerType;

public class TestCase_13957_PageValidationHomeCredit extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");
		// Goto Satsuma site
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database

	}

	@AfterMethod
	public void tearDown() throws Exception {

		// Disconnect from TestShed database

	}

	@Test
	public void test_WorldPayPaymentRefusedApplicantReferredToHomeCredit() throws Exception {

		// Initialise Agreement Number for new applicant
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer
		gcb.prGetApplicantProfile(4);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// CV - 24-02-2016 - behaviour has now changed so gives 3 chances for
		// the card before refusing loan, test adjusted to reflect
		// Fill in applicants card details from the profile and trigger a
		// Refused response
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched", gsSatsumaSiteUrl);

		// 2nd chance to pass card details
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched", gsSatsumaSiteUrl);

		// 3rd chance to pass card details
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched", gsSatsumaSiteUrl);

		// Home Credit page
		// ================
		// loan should be refused and home credit loan offered

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

	}

}
