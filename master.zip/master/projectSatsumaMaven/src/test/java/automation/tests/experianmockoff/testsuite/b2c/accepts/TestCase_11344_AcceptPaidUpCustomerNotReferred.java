package automation.tests.experianmockoff.testsuite.b2c.accepts;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.ExperianMockOffTest;
import automation.dao.CustomerType;
import automation.satsuma.pages.CookBook;
import automation.tools.ToolBox;

public class TestCase_11344_AcceptPaidUpCustomerNotReferred extends ExperianMockOffTest {

	static WebDriver driver;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	public String gsSatsumaSiteUrl; // Satsuma Site
	public String gsdbTESTSHEDConnectionString; // TestShed database connection
												// string

	CookBook gcb = new CookBook();
	ToolBox gtb = new ToolBox();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		// Read config.properties for firefox proxy settings
		Properties prop = new Properties();
		String sProxyIP;
		String sProxyPort;
		String sNoProxyOn;
		String sZoralAppServerStatusUrl;
		InputStream input = null;

		input = new FileInputStream("config.properties");
		// load a properties file
		prop.load(input);

		// get the property value
		sProxyIP = prop.getProperty("ProxyIP");
		if (sProxyIP.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyIP missing");
		else
			log.info("BeforeClass: config.properties ProxyIP=" + sProxyIP);

		sProxyPort = prop.getProperty("ProxyPort");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties ProxyPort missing");
		else
			log.info("BeforeClass: config.properties ProxyPort=" + sProxyPort);

		sNoProxyOn = prop.getProperty("NoProxyOn");
		if (sProxyPort.isEmpty())
			Assert.fail("BeforeClass: config.properties NoProxyOn missing");
		else
			log.info("BeforeClass: config.properties NoProxyOn=" + sNoProxyOn);

		sZoralAppServerStatusUrl = prop.getProperty("ZoralAppServerStatusUrl");
		if (sZoralAppServerStatusUrl.isEmpty())
			Assert.fail("BeforeClass: config.properties ZoralAppServerStatusUrl missing");
		else
			log.info("BeforeClass: config.properties sZoralAppServerStatusUrl=" + sZoralAppServerStatusUrl);

		input.close();

		// Setup Browser with proxy
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", sProxyIP);
		profile.setPreference("network.proxy.http_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.ssl", sProxyIP);
		profile.setPreference("network.proxy.ssl_port", Integer.parseInt(sProxyPort));
		profile.setPreference("network.proxy.no_proxies_on", sNoProxyOn);
		driver = new FirefoxDriver(profile);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		// Check Satsuma mock status - Abort test if inconsistent status found
		//
		// Mock Requirements for these tests are
		// 1. Experian mock : Off
		// 2. CallCredit mock : On
		// 3. PanCredit mock : Off
		// 4. Affordability mock: On
		// 5. Statistical calculations mock: On

		driver.get(sZoralAppServerStatusUrl);

		assertEquals("Satsuma services", driver.getTitle());
		assertEquals("Experian mock: Off", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[1]")).getText());
		assertEquals("CallCredit mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[2]")).getText());
		// //assertEquals("PanCredit mock: Off",driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[3]")).getText());
		assertEquals("Affordability mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[4]")).getText());
		assertEquals("Statistical calculations mock: On", driver.findElement(By.xpath("//body//div[@class='panel-body']/div/ul/li[5]")).getText());
	}

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		// Goto Satsuma site
		driver.get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		driver.findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		driver.findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
	}

	@AfterMethod
	public void tearDown() throws Exception {
	}

	@Test
	public void test_HappyPathPaidUpCustomerNoChangeOfAddress() throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get Experian applicant Mr Gary Simos as test subject with applicant
		// profile for a weekly product request.
		// Applicant: Mr Gary Simos
		gcb.prGetApplicantProfile(4);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need a Paid Up agreement for this test
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true") && !gcb.gsPANAgreementStatus.equals("Completed")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, but not fully paid, please remove and re-try test");
		} else if (gcb.gsPANAgreementFound.equals("false")) {

			// Seed a fully paid up agreement for this person in PAN
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

			log.info("Fully Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of fully paid agreement for this test failed.");
			}

		} else {
			log.info("INFO: Agreement " + gcb.gsPANAgreementNumber + " in paid up state already exists");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: ?
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and that there are other
		// options available to them
		assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Loan Amount Slider defaulted to £100 - Original request
		assertEquals("100", driver.findElement(By.id("LoanAmountLVACalc")).getAttribute("min"));
		assertEquals("200", driver.findElement(By.id("LoanAmountLVACalc")).getAttribute("max"));
		assertEquals("100", driver.findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to £100 - Original request
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		assertEquals("£100", dropdown.getFirstSelectedOption().getText());

		// Loan Term defaulted to 13 weeks - Original request
		assertEquals("0", driver.findElement(By.id("TermLVACalc")).getAttribute("min"));
		assertEquals("9", driver.findElement(By.id("TermLVACalc")).getAttribute("max"));
		assertEquals("0", driver.findElement(By.id("TermLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to 13 weeks - Original request
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		assertEquals("13 weeks", dropdown.getFirstSelectedOption().getText());

		// User does not want anymore but just accepts the original request
		gcb.gsRequestedTerm = "13";
		gcb.gsRequestedLoanAmount = "100";

		// Get Expected Loan Offer Details for Loan Term Validation
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// Assert that Interest, Weekly repayments and TAP are displayed
		// correctly
		// Pricing for £100 13 weeks - Defaulted correctly
		assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), driver.findElement(By.id("TotalInterestLVACalcText")).getText());
		assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), driver.findElement(By.id("RepaymentAmountLVACalcText")).getText());
		assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), driver.findElement(By.id("TotalAmountLVACalcText")).getText());

		// Invoke Next action: Next: ? Your Quote if Quick Apply else Your
		// Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.EXISTING_NOT_ACTIVE_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		//(new WebDriverWait(getDriver(), 60)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page
		// ===============

		// Landed on completion page type Result13 in context Great news! Your
		// next Satsuma Loan has been approved (For existing customer)
		gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);

		// Give time for PAN to catch up with its transactions, otherwise next
		// step assertions may fail
		Thread.sleep(30000);

		gcb.prAssertNewNonBrokeredAgreementForPaidUpCustomer(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		// Navigate to the newly created agreement in PAN
		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Rename applicant's surname
		gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
