package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;
import automation.tools.EntityHubHelper;

public class TestCase_11291_DeclineHCROnCallCredit401BankEnhancedFailure extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_IsBankEnhancedSearchFailureReferredToHomeCredit() throws Exception {

		// Data Preparation
		// ================

		// Get a application profile for CallCredit test subject with a Bank
		// Enhanced Failure set.
		// Applicant Mr BankEnhanced Failure
		gcb.prGetApplicantProfile(106);
		gcb.setRandomDOB();
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		EntityHubHelper.removeFromHub(gcb.entitySearchDB,gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============
		gcb.gsPANAgreementNumber = "";

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.prFillInPageAboutYou();

		// // Testing Current Address and Previous Address cannot be the same
		// // ===============================================================
		//
		// // Fill in form first, take defaults where possible otherwise fill
		// with
		// // valid data, except for Current Address Moved In Date
		//
		// // On which day of the week would you like to make your repayments -
		// // Monday
		// Select dropdown = new
		// Select(getDriver().findElement(By.id("PreferredPaymentDayValue")));
		// dropdown.selectByVisibleText("Monday");
		//
		// // What will you use your loan for - Household Goods
		// dropdown = new
		// Select(getDriver().findElement(By.id("LoanPurposeValue")));
		// dropdown.selectByVisibleText("Household Goods");
		//
		// // For our own research, please tell us the minimum loan amount you
		// // would find useful today - £100
		// dropdown = new
		// Select(getDriver().findElement(By.id("MinimumLoanValue")));
		// dropdown.selectByVisibleText("£100");
		//
		// // Please read our web-site cookie policy and tick this box to agree
		// -
		// // is Ticked
		// if (!getDriver().findElement(By.id("CookieAccepted")).isSelected()) {
		// getDriver().findElement(By.id("CookieAccepted")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("CookieAccepted")).click();
		// }
		//
		// // Personal Details section
		// // ========================
		//
		// // Applicants Title - Mr
		// dropdown = new
		// Select(getDriver().findElement(By.id("CustomerTitle")));
		// dropdown.selectByVisibleText("Mr");
		// // Applicants Firstname - Tari
		// getDriver().findElement(By.id("Forename")).sendKeys("BankEnhanced");
		// // Applicants Surname - Ghan
		// getDriver().findElement(By.id("Surname")).sendKeys("Failure");
		// // Applicants DOB - Day - 1st
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Day")));
		// dropdown.selectByVisibleText("01");
		// // Applicants DOB - Month - January
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Month")));
		// dropdown.selectByVisibleText("January");
		// // Applicants DOB - Year - 1963
		// dropdown = new
		// Select(getDriver().findElement(By.id("DateOfBirth_Year")));
		// dropdown.selectByVisibleText("1963");
		// // Applicants Marital Status - Divorced
		// dropdown = new
		// Select(getDriver().findElement(By.id("MaritalStatusValue")));
		// dropdown.selectByVisibleText("Divorced");
		// // Applicants Number Of Dependants - 0
		// dropdown = new
		// Select(getDriver().findElement(By.id("NumberOfDependantsValue")));
		// dropdown.selectByVisibleText("0");
		//
		// // Your Contact Details
		// // --------------------
		//
		// // Applicant Mobile Phone - 07850121212
		// getDriver().findElement(By.id("MobilePhoneNumber")).sendKeys("07850121212");
		// // Applicant Email Address - tarighan@test.com
		// getDriver().findElement(By.id("EmailAddress")).sendKeys("tarighan@test.com");
		//
		// // Your Address
		// // ------------
		//
		// // Applicants Residential Status - Owner Occupier
		// dropdown = new
		// Select(getDriver().findElement(By.id("ResidencyTypeValue")));
		// dropdown.selectByVisibleText("Owner Occupier");
		//
		// // Applicants Current Address Moved In Month- Set to a few months in
		// // past to trigger the previous
		// // address section when moved in date less than 3 years ago
		//
		// // Calculate a recent moved in date
		//
		// String sWhichMonth, sWhichYear;
		// Calendar cal = Calendar.getInstance();
		// log.info("Today: " + cal.getTime());
		// // Get date 6 months ago
		// cal.add(Calendar.MONTH, -6);
		// sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		// log.info("Calculated Moved In Date in the past 6 months ago: Next Month:"
		// + sWhichMonth + " Year:" + sWhichYear);
		//
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Month")));
		// dropdown.selectByVisibleText(sWhichMonth);
		//
		// dropdown = new
		// Select(getDriver().findElement(By.id("CurrentAddress_DisplayDateMovedIn_Year")));
		// dropdown.selectByVisibleText(sWhichYear);
		//
		// // Calculate a previous address moved in date, say 1 year ago
		//
		// // Test current and previous address - Same House Number and Post
		// Code
		// // is minimum check, should be case insensitive and for post code
		// // insensitive to white space
		//
		// // Enter current address details manually
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).sendKeys(Keys.TAB);
		// getDriver().findElement(By.id("CurrentAddressManualEntry")).click();
		// getDriver().findElement(By.id("CurrentAddress_HouseNumber")).sendKeys("24");
		// getDriver().findElement(By.id("CurrentAddress_Street")).sendKeys("Current Street");
		// getDriver().findElement(By.id("CurrentAddress_TownCity")).sendKeys("Bradford");
		// getDriver().findElement(By.id("CurrentAddress_Postcode")).sendKeys("BD7 4BG");
		//
		// // Get previous address a year ago
		// cal.add(Calendar.YEAR, -1);
		// sWhichMonth = new SimpleDateFormat("MMMM").format(cal.getTime());
		// sWhichYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		// log.info("Calculated Previous Address Moved In Date a year ago: Year:"
		// + sWhichMonth + " Year:" + sWhichYear);
		//
		// dropdown = new
		// Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Month")));
		// dropdown.selectByVisibleText(sWhichMonth);
		//
		// dropdown = new
		// Select(getDriver().findElement(By.id("PreviousAddress_DisplayDateMovedIn_Year")));
		// dropdown.selectByVisibleText(sWhichYear);
		//
		// //
		// getDriver().findElement(By.id("PreviousAddressManualEntry")).click();
		// getDriver().findElement(By.id("PreviousAddressManualEntry")).sendKeys(Keys.ENTER);
		// getDriver().findElement(By.id("PreviousAddress_HouseNumber")).sendKeys("2");
		// getDriver().findElement(By.id("PreviousAddress_Street")).sendKeys("Previous Street");
		// getDriver().findElement(By.id("PreviousAddress_TownCity")).sendKeys("Bradford");
		// getDriver().findElement(By.id("PreviousAddress_Postcode")).sendKeys("BD5 8JQ");

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		// gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// Home Credit page
		// ================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Check that NO new proposal agreement is created in PAN to record
		// decline reason as its not required unlike others
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement is found, not expected");
		}

	}

}
