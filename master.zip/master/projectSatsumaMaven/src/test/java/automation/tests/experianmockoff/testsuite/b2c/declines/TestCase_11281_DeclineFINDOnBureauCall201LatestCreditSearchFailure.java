package automation.tests.experianmockoff.testsuite.b2c.declines;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.ExperianMockOffTest;
import automation.dao.CustomerType;

/* This test does not currently work... */

public class TestCase_11281_DeclineFINDOnBureauCall201LatestCreditSearchFailure extends ExperianMockOffTest {

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
	}

	@AfterMethod
	public void tearDown() throws Exception {

	}

	@Test
	public void test_DeclineWhenCustomerNotFoundInExperianOrExperianSystemFailure() throws Exception {

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// does not exist in the Experian Database.

		gcb.prGetApplicantProfile(4);

		// Uniquefy the application so that a match is not found in experian
		// gcb.prCreateUniquePerson();
		gcb.prOldCreateUniquePerson();

		gcb.gsFirstname = "XXX";
		gcb.gsSurname = "YYY";
		gcb.gsPostcode = "BD1 2SU";
		gcb.gsBuildingNumber = "201";
		gcb.gsStreet = "XXX";

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		gcb.gsPANAgreementNumber = "";

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Finished Decline page
		// =====================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result24
		// Have we landed on the FIND Decline page in context that the applicant
		// is not successful on this occasion and no credit check has been
		// performed
		gcb.prAssertOnPageFinishedIDResult24(gsSatsumaSiteUrl);

		// Check new proposal agreement created in PAN to record decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement not found
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: An agreement not found. ");
		}

		// Abort test if the agreement is not of Rejected status
		if (gcb.gsPANAgreementNumber.equals("Rejected")) {
			Assert.fail("Aborted: Agreement not Rejected as expected.");
		}

		// In PanCredit check that the correct decline on
		// "Latest Credit Search Failure" reason is recorded
		// ================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(gcb.gsPANAgreementNumber);

		// Expect agreement to be referred with a 201 - Experian Latest Credit
		// Search Failure, when experian is unable to locate this person
		// or if Experian is down.
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Rejected");
		assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Rejected Agreements");
		assertTrue(getDriver().getPageSource().contains("Latest Credit Search Failure"));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
