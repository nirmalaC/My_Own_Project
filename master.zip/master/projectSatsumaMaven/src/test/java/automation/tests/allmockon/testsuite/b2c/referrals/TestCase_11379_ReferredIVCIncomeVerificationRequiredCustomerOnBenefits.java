package automation.tests.allmockon.testsuite.b2c.referrals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_11379_ReferredIVCIncomeVerificationRequiredCustomerOnBenefits extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_ReferBenefitsApplicantForIncomeVerifyNoPlayslip() throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		log.info("WARNING: This test subject is mocked and requires deployment of mocked response XML file Affordability.Benefits.xml in ...Satsuma.Service/bin/Responses/Affordability");

		// Get a application profile for a mocked applicant whose source of
		// income is "On Benefits" and whose's affordability is flagged as being
		// max'd out
		// Applicant Mr Affordability Benefits
		// Affordability IVCIVPAY
		gcb.prGetApplicantProfile(90);
		gcb.setRandomEmail();
		gcb.setRandomPostcode();
		gcb.setRandomDOB();

		// Check existance of previous agreement, if found remove from PanCredit
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test if an agreement is found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			// Assert.fail("Aborted: An agreement is found, please remove agreement from PanCredit and re-run ");
			log.warn("Agreement " + gcb.gsPANAgreementNumber + " found, trying to remove it");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Payslip page
		// ============

		gcb.prAssertOnPagePayslip(gsSatsumaSiteUrl);

		getDriver().findElement(By.id("UserWillSendPayslipNo")).sendKeys(Keys.TAB);
		getDriver().findElement(By.id("UserWillSendPayslipNo")).click();

		// Invoke Next action: Next: Continue
		gcb.prClickForNextAction();

		// Waiting for your email page
		// ===========================

		// gcb.prAssertOnPageCompletionIDResult16(gsSatsumaSiteUrl);

		// goes to HC referral page instead
		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// // CV - behaviour has now changed, instead payslip page is shown
		// where you can say if you can or cannot prove your income
		// // Completion page - Great news! Your loan with Satsuma Loans has
		// been
		// // approved in principle. We just need to verify your income.
		// //
		// ==============================================================================================================================
		//
		// //gcb.prAssertOnPageCompletionIDResult17(gsSatsumaSiteUrl);
		//
		// // In PanCredit try and remove test subject agreement, so that we can
		// // re-run the test next time using same subject
		// // but also check that the correct refer on
		// // "Verify Income: Payslip Expected" reason is recorded
		// //
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 902 - Verify Income: No
		// Payslip.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Verify Income:No Payslip");

		Assert.assertTrue(getDriver().getPageSource().contains("Verify Income:No Payslip"));

		gcb.prPANRenameAgreementsApplicantSurname(sAgreementNumber);

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}

}
