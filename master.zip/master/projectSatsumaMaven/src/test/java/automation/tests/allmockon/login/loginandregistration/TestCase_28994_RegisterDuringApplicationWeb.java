package automation.tests.allmockon.login.loginandregistration;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_28994_RegisterDuringApplicationWeb extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test(enabled = false)
	// removed as not needed for smoke test call
	public void test_WebJourneyAgreement52weeks1000() throws Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(165);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		prPerformAccepts("1000", "52", "Weekly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		gcb.gsLoginUsername = gcb.gsEmailAddress;
		gcb.gsLoginPassword = "Password1";

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test(enabled = false)
	public void test_WebJourneyAgreement() throws Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(165);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		prPerformAccepts("100", "13", "Weekly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	@Test(enabled = false)
	// disabled test for now as not needed for the smoke test
	public void test_WebJourneyAgreement26Weeks200() throws Exception {

		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(165);

		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();

		prPerformAccepts("200", "26", "Weekly");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);

		gcb.logoutInPageLogin();
		gcb.prAssertOnPageLoggedOut(gsSatsumaSiteUrl);

	}

	public void prPerformAccepts(String psLoanAmount, String psLoanTerm, String psRepaymentFrequency) throws Exception {

		// Overwrite applicant profile requested loan terms
		gcb.gsRequestedLoanAmount = psLoanAmount;
		gcb.gsRequestedTerm = psLoanTerm;
		gcb.gsRepaymentFrequency = psRepaymentFrequency;
		gcb.gsLoginUsername = gcb.gsEmailAddress;
		gcb.gsLoginPassword = "Password1";

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);
		log.info("INFO: Repricing check for loan term " + gcb.gsRequestedLoanAmount + " " + gcb.gsRequestedTerm + " " + gcb.gsRepaymentFrequency);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.LOGIN_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount(gcb.gsLoginPassword);

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		String sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// close popup window
		By byBtnClosePopUp = By.cssSelector(".mfp-close");
		getDriver().findElement(byBtnClosePopUp).click();

		// Landed on completion page type Result19 in context Great news! Your
		// Satsuma Loan has been approved (For new customer)
		// gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}
}
