package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23563_AcceptNewCustomerRepricesTerm39Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice39weeks100() throws Exception {
		newCustomerAccept("100", "39", "Weekly", 133);
	}

	@Test
	public void test_Reprice39weeks800() throws Exception {
		newCustomerAccept("800", "39", "Weekly", 133);
	}

	@Test
	public void test_Reprice39weeks1000() throws Exception {
		newCustomerAccept("1000", "39", "Weekly", 133);
	}

}
