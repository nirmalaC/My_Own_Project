package automation.tests.allmockon.login.uat;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_14290_WrongWorldPay3TimesHCRAccept extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test() throws Exception {

		// Initialise Agreement Number for new applicant
		gcb.gsPANAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person. This person
		// is a new customer
		gcb.prGetApplicantProfile(4);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement
		// created is created for an unique person, generated dynamically.
		gcb.prCreateUniquePerson();

		// Abort test is data preparation failed
		if (gcb.gsSurname.isEmpty()) {
			Assert.fail("Aborted: Creating unique person for this test failed.");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Refused response
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched",gsSatsumaSiteUrl);

		final By byDivCardFailedMsg = By.cssSelector(".containercell > tbody:nth-child(1) > tr:nth-child(7) > td:nth-child(1) > div:nth-child(1)");
		Assert.assertTrue(getDriver().findElement(byDivCardFailedMsg).getText().contains("You have 2 more attempts"), "Assert card failure message");

		// 2nd chance
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched",gsSatsumaSiteUrl);
		Assert.assertTrue(getDriver().findElement(byDivCardFailedMsg).getText().contains("You have 1 more attempt"), "Assert card failure message");

		// 3rd chance
		gcb.prFillInTestWorldPayAndRespond("Refused", "Failed", "Postcode and address not matched",gsSatsumaSiteUrl);

		// Home Credit page
		// ================
		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		// Accept home credit referral
		hc.fillInPageHomeCreditReferral(gcb.gsFirstname, gcb.gsSurname);

		// Home Credit Decision Accepted
		hc.assertOnPageHomeCreditAcceptedInPrinciple(gsSatsumaSiteUrl, gcb.gsTitle, gcb.gsFirstname, gcb.gsSurname);

		// Check that no new proposal agreement is created in PAN to record
		// decline reason
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		log.info("Latest Agreement: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Fail test if an agreement is found
		if (!gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Fail: An agreement found in PAN, should not have been created.");
		}
	}
}
