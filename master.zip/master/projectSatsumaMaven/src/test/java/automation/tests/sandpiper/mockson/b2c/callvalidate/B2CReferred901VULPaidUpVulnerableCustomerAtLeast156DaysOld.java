package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnCallCreditReferralTest;
import automation.dao.CustomerType;

public class B2CReferred901VULPaidUpVulnerableCustomerAtLeast156DaysOld extends B2CAllMocksOnCallCreditReferralTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Vulnerable Customer";
	private static final String EXPECTED_PAN_CODE = "901";
	private static final int WEEKLY_APPLICANT_ID = 5;
	private static final int MONTHLY_APPLICANT_ID = 275;

	@Test
	public void B2CWeekly() throws Exception {
		test901(WEEKLY_APPLICANT_ID);
	}

	@Test
	public void B2CMonthly() throws Exception {
		test901(MONTHLY_APPLICANT_ID);
	}

	public void test901(int applicantId) throws Exception {

		String sAgreementNumber;

		// Data Preparation
		// ================

		// Get a application profile to template for a unique person
		gcb.prGetApplicantProfile(applicantId);
		gcb.prCreateUniquePerson();

		// Seed Pan Credit target test environment with an active paid up
		// agreement. The agreement`
		// created is created for an unique person, generated dynamically.
		gcb.prSeedSpecifiedVulnerablePersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
		// gcb.prSeedSpecifiedVulnerablePersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		// seed vulnerable offer
		gcb.seedFLEEligibleOffer(true, 500d, true);

		log.info("Full Paid Vulnerable Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of full paid vulnerable agreement for this test failed. ");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		gcb.prClickForNextAction();

		// CV - 08.03.2016 - now includes the Change Loan Amount screen despite
		// the fact that loan requested is within limits

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		// Loan Amount Slider defaulted to £200 as this is the maximum amount
		// the customer is offered as his previous request was higher
		Assert.assertEquals(gcb.gsRequestedLoanAmount, getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));
		gcb.prConfirmLVA();

		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================
		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Former Paid Up Vulnerable Completion page
		// =========================================

		// gcb.prAssertOnPageCompletionIDResult12(gsSatsumaSiteUrl);

		gcb.assertOnPageMySatsumaReview(gsSatsumaSiteUrl);

		// In PanCredit try and remove test subject agreement, so that we can
		// re-run the test next time using same subject
		// but also check that the correct refer on "Vulnerable Customer is set"
		// reason is recorded
		// ===============================================================================================================

		// Log into PanCredit Front Office
		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		// Expect agreement to be referred with a 901 - Vulnerable Customer is
		// set.
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingLeft']")).getText(), "Decision Referred");
		Assert.assertEquals(getDriver().findElement(By.xpath("//form[@id='PanForm']//span[@class='spanHeadingRight']")).getText(), "Queue Suspected Vulnerable (NB)");
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_PAN_CODE));
		Assert.assertTrue(getDriver().getPageSource().contains(EXPECTED_PAN_DESC));

		// Log out of PanCredit Front Office
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
