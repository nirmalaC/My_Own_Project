package automation.tests.mobile.rest;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.from;
import static org.hamcrest.Matchers.equalTo;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.MobileAPITest;
import automation.dao.SatsumaCustomer;

public class DataSetup extends MobileAPITest {
	List<String> weeklyAgreements = new ArrayList();
	List<String> monthlyAgreements = new ArrayList();

	String testName = "";

	@BeforeMethod
	public void setUpBefore(Method method) throws Exception {
		testName = method.getName();
		getDriver().manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	}

	@Test
	public void newWeeklyLoan() throws Exception {

		newWeeklyLoan("500", "52", "weekly1@t.com");
		newWeeklyLoan("600", "52", "weekly2@t.com");
		newWeeklyLoan("700", "52", "weekly3@t.com");
		newWeeklyLoan("800", "13", "weekly4@t.com");
		newWeeklyLoan("900", "13", "weekly5@t.com");
		newWeeklyLoan("1000", "52", "weekly6@t.com");
		newWeeklyLoan("100", "52", "weekly7@t.com");
		newWeeklyLoan("200", "52", "weekly8@t.com");
		newWeeklyLoan("300", "52", "weekly9@t.com");
		newWeeklyLoan("400", "52", "weekly10@t.com");
		newWeeklyLoan("500", "52", "weekly11@t.com");
		newWeeklyLoan("600", "52", "weekly12@t.com");
		newWeeklyLoan("700", "52", "weekly13@t.com");
		newWeeklyLoan("800", "52", "weekly14@t.com");
		newWeeklyLoan("900", "52", "weekly15@t.com");
		newWeeklyLoan("1000", "52", "weekly16@t.com");
		newWeeklyLoan("100", "52", "weekly17@t.com");
		newWeeklyLoan("200", "52", "weekly18@t.com");
		newWeeklyLoan("300", "52", "weekly19@t.com");
		newWeeklyLoan("400", "52", "weekly20@t.com");
		newWeeklyLoan("500", "52", "weekly21@t.com");
		newWeeklyLoan("600", "26", "weekly22@t.com");
		newWeeklyLoan("700", "39", "weekly23@t.com");

		printList(weeklyAgreements);
	}

	@Test
	public void newWeeklyLoan2() throws Exception {
		newWeeklyLoan("700", "52", "weekly24@t.com");
		newWeeklyLoan("800", "52", "weekly25@t.com");
		newWeeklyLoan("900", "52", "weekly26@t.com");
		newWeeklyLoan("1000", "52", "weekly27@t.com");
		newWeeklyLoan("1000", "52", "weekly28@t.com");
		newWeeklyLoan("1000", "52", "weekly29@t.com");

		printList(weeklyAgreements);
	}

	@Test
	public void newWeeklyLoan3() throws Exception {
		newWeeklyLoan("1000", "52", "weekly30@t.com");
		newWeeklyLoan("1000", "52", "weekly31@t.com");

		printList(weeklyAgreements);
	}

	@Test
	public void newWeeklyLoan4() throws Exception {
		newWeeklyLoan("1000", "52", "weekly32@t.com");
		newWeeklyLoan("1000", "52", "weekly33@t.com");
		newWeeklyLoan("1000", "52", "weekly34@t.com");
		newWeeklyLoan("1000", "52", "weekly35@t.com");

		printList(weeklyAgreements);
	}

	@Test
	public void newWeeklyLoan5() throws Exception {
		newWeeklyLoan("1000", "52", "weekly36@t.com");
		newWeeklyLoan("1000", "52", "weekly37@t.com");
		newWeeklyLoan("1000", "52", "weekly38@t.com");
		newWeeklyLoan("1000", "52", "weekly39@t.com");

		printList(weeklyAgreements);
	}

	@Test
	public void newLoanMonthly2() throws Exception {
		newLoanMonthly("500", "12", "monthly24@t.com");
		newLoanMonthly("600", "12", "monthly25@t.com");
		// newLoanMonthly("700", "12", "monthly26@t.com");
		// newLoanMonthly("800", "12", "monthly27@t.com");
		// newLoanMonthly("900", "12", "monthly28@t.com");
		// newLoanMonthly("1000", "12", "monthly29@t.com");

		printList(monthlyAgreements);
	}

	@Test
	public void newLoanMonthly3() throws Exception {
		newLoanMonthly("1000", "12", "monthly30@t.com");
		newLoanMonthly("1000", "12", "monthly31@t.com");
		printList(monthlyAgreements);
	}

	@Test
	public void newLoanMonthly4() throws Exception {
		newLoanMonthly("1000", "12", "monthly32@t.com");
		newLoanMonthly("1000", "12", "monthly33@t.com");
		newLoanMonthly("1000", "12", "monthly34@t.com");
		newLoanMonthly("1000", "12", "monthly35@t.com");
		printList(monthlyAgreements);
	}

	@Test
	public void newLoanMonthly5() throws Exception {
		newLoanMonthly("1000", "12", "monthly36@t.com");
		newLoanMonthly("1000", "12", "monthly37@t.com");
		newLoanMonthly("1000", "12", "monthly38@t.com");
		newLoanMonthly("1000", "12", "monthly39@t.com");
		printList(monthlyAgreements);
	}

	@Test
	public void newLoanMonthly() throws Exception {
		/*
		 * newLoanMonthly("500", "12", "monthly1@t.com"); newLoanMonthly("600",
		 * "12", "monthly2@t.com"); newLoanMonthly("700", "12",
		 * "monthly3@t.com"); newLoanMonthly("800", "3", "monthly4@t.com");
		 * newLoanMonthly("900", "3", "monthly5@t.com"); newLoanMonthly("1000",
		 * "3", "monthly6@t.com"); newLoanMonthly("100", "12",
		 * "monthly7@t.com"); newLoanMonthly("200", "12", "monthly8@t.com");
		 * newLoanMonthly("300", "12", "monthly9@t.com");
		 */
		newLoanMonthly("400", "12", "monthly10@t.com");
		newLoanMonthly("500", "12", "monthly11@t.com");
		newLoanMonthly("600", "12", "monthly12@t.com");
		newLoanMonthly("700", "12", "monthly13@t.com");
		newLoanMonthly("800", "12", "monthly14@t.com");
		newLoanMonthly("900", "12", "monthly15@t.com");
		newLoanMonthly("1000", "12", "monthly16@t.com");
		newLoanMonthly("100", "12", "monthly17@t.com");
		newLoanMonthly("200", "12", "monthly18@t.com");
		newLoanMonthly("300", "12", "monthly19@t.com");
		newLoanMonthly("400", "12", "monthly20@t.com");
		newLoanMonthly("500", "12", "monthly21@t.com");
		newLoanMonthly("600", "6", "monthly22@t.com");
		newLoanMonthly("700", "9", "monthly23@t.com");

		printList(monthlyAgreements);
	}

	private void printList(List<String> list) {
		for (String item : list) {
			log.info(item);
		}
	}

	private void newLoanMonthly(String amount, String term, String email) throws Exception {
		SatsumaCustomer satsumaCustomer = addNewMonthlyAgreement(amount, term, email);

		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "1")
				.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678").param("username", satsumaCustomer.getEmailAddress())
				.param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", "1")
				.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);

		updateCreditCardNumber(agreementNumber);

		log.debug("Created Agreement test: " + testName + " agreementno: " + agreementNumber + " firstname: " + satsumaCustomer.getForename() + "surname: " + satsumaCustomer.getSurname() + " email: "
				+ satsumaCustomer.getEmailAddress());
		monthlyAgreements.add(agreementNumber + "," + satsumaCustomer.getForename() + "," + satsumaCustomer.getSurname() + "," + satsumaCustomer.getEmailAddress());
	}

	private void newWeeklyLoan(String amount, String term, String email) throws Exception {
		SatsumaCustomer satsumaCustomer = addNewAgreement(amount, term, email);

		final String PLATFORM = "iOS";

		// login
		String responseString = given().contentType("application/x-www-form-urlencoded").log().all().header("platform", PLATFORM).header("appVersionNumber", "1")
				.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").param("grant_type", "password").param("client_id", "12345678").param("username", satsumaCustomer.getEmailAddress())
				.param("password", encodedPassword).when().post(TOKEN_URL).then().log().all().body("token_type", equalTo("bearer")).statusCode(200).extract().response().asString();

		// extract tokens
		accessToken = from(responseString).get("access_token");
		refreshToken = from(responseString).get("refresh_token");
		log.info("access_token: " + accessToken);
		log.info("refresh_token: " + refreshToken);

		// myaccount
		String myAccountString = given().log().all().contentType("application/json").header("platform", PLATFORM).header("appVersionNumber", "1")
				.header("DateAndTime", "Tue, 26 Apr 2016 14:00:00 GMT").header("Authorization", "Bearer " + accessToken).when().get(ACCOUNT_URL).then().log().all().extract().response().asString();
		Assert.assertEquals(from(myAccountString).get("Forename"), satsumaCustomer.getForename());
		Assert.assertEquals(from(myAccountString).get("Surname"), satsumaCustomer.getSurname());
		Assert.assertEquals(from(myAccountString).get("Email"), satsumaCustomer.getEmailAddress());
		Assert.assertEquals(from(myAccountString).get("DateOfBirth"), satsumaCustomer.getDob());
		Assert.assertEquals(from(myAccountString).get("EligibleAmount"), null);
		Assert.assertEquals(from(myAccountString).get("Agreements[0].AgreementNumber"), agreementNumber);

		updateCreditCardNumber(agreementNumber);

		log.debug("Created Agreement test: " + testName + " agreementno: " + agreementNumber + " firstname: " + satsumaCustomer.getForename() + "surname: " + satsumaCustomer.getSurname() + " email: "
				+ satsumaCustomer.getEmailAddress());
		weeklyAgreements.add(agreementNumber + "," + satsumaCustomer.getForename() + "," + satsumaCustomer.getSurname() + "," + satsumaCustomer.getEmailAddress());
	}

	private void updateCreditCardNumber(String agreement) throws Exception {
		By byLinkContAuth = By.linkText("Continuous Authority");
		By byBtnEnterNewCard = By.id("enterNewCardDetailsButton");
		By byImgVisa = By.cssSelector("input[alt=\"Visa\"]");

		By byTextCardNo = By.id("cardNoInput");
		By byTextcardCVV = By.id("cardCVV");
		By byDDCardExpMonth = By.name("cardExp.month");
		By byDDCardExpYear = By.name("cardExp.year");
		By byTextCardName = By.id("name");
		By byTextAddressOne = By.id("address1");
		By byTextTown = By.id("town");
		By byTextPostcode = By.id("postcode");

		By byBtnMakePayment = By.id("op-PMMakePayment");

		By byBtnContinue = By.name("continue");

		By byLinkHome = By.xpath("//span[text()='Home']");

		final String ADDRESS_LINE_1 = "1 STREET ST";
		final String TOWN = "BRADFORD";
		final String POSTCODE = "BD1 2SU";
		final String CARD_HOLDER = "AUTO TEST";
		final String CARD_NUMBER = "4444333322221111";
		final String CVV_NUMBER = "123";
		final String EXP_MONTH = "12";
		final String EXP_YEAR = "2034";

		gcb.prLogIntoPanCreditFrontOffice();

		log.info("doing agreement " + agreement);
		gcb.prNavigateToPANCreditAgreement(agreement);
		getDriver().findElement(byLinkContAuth).click();
		getDriver().findElement(byBtnEnterNewCard).click();
		getDriver().findElement(byImgVisa).click();

		getDriver().findElement(byTextCardNo).sendKeys(CARD_NUMBER);
		getDriver().findElement(byTextcardCVV).sendKeys(CVV_NUMBER);

		(new Select(getDriver().findElement(byDDCardExpMonth))).selectByValue(EXP_MONTH);
		(new Select(getDriver().findElement(byDDCardExpYear))).selectByValue(EXP_YEAR);

		getDriver().findElement(byTextCardName).sendKeys(CARD_HOLDER);
		getDriver().findElement(byTextAddressOne).sendKeys(ADDRESS_LINE_1);
		getDriver().findElement(byTextTown).sendKeys(TOWN);
		getDriver().findElement(byTextPostcode).sendKeys(POSTCODE);

		getDriver().findElement(byBtnMakePayment).click();

		int counter = 0;

		while (true) {
			try {
				getDriver().findElement(byBtnContinue).click();
				break;
			} catch (NoSuchElementException e) {
				log.warn("no home button found trying last button again");
				counter++;
				if (counter > 5) {
					log.error("could't find continue button on PFO");

					break;
				}
				getDriver().findElement(byBtnMakePayment).click();
			}
		}

		getDriver().findElement(byLinkHome).click();
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
