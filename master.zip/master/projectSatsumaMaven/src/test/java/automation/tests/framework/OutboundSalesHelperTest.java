package automation.tests.framework;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.tools.OutboundSalesHelper;

public class OutboundSalesHelperTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void testExtractFromEmail() {
		final String sample = "300\" height=\"55\" src=\"http://satzorout5.ho.pfgroup.provfin.com/content/images/outbound-sales-images/Continue-Your-Application-Image.png\" style=\"display: block; margin: 0; padding: 0; border: none;\" border=\"0\" class=\"imgClass\" alt=\"Continue your application\"></a>                      </td>                  </tr>                  <tr>                      <td align=\"center\">                          <span style=\"color: #8A8786; font-family: Arial, Times, serif; font-size: 10px;\"><a href=\"http://satzorapp5.ho.pfgroup.provfin.com/salescustomer?key=986c3d34-14a8-471c-8fa0-6c3cdd91c557\" title=\"Continue application\" alt=\"Continue application\">Continue your application</a></span>                      </td>                  </tr>                  <tr>                      <td height=\"10\" style=\"font-size: 10px; line-height: 10px;\">                          <!-- spacer ";
		log.info(OutboundSalesHelper.extractUrlFromEmail("satzorout5.ho.pfgroup.provfin.com", "satzorout5.ho.pfgroup.provfin.com", sample));
	}
}
