package automation.tests.sandpiper.mockson.b2b.experian;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.satsuma.pages.ApplicationType;
import automation.tools.PowerCurveDBHelper;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.support.SoapUIException;

public class B2BDecline801ScoreTooLow extends B2BAllMocksOnTest {

	private static final int WEEKLY_APPLICANT_ID = 401;

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	String PAN_CODE = "801";

	@Test
	public void b2BNBDeclineWeekly() throws Exception {
		b2bDeclineTest(PAN_CODE, WEEKLY_APPLICANT_ID);
	}

	protected void b2bDeclineTest(String PAN_CODE, int applicantId) throws Exception, XmlException, IOException, SoapUIException, SQLException {
		// Data Preparation
		// ================
		// Get a Experian application profile for Bureau result 203 - Applicant
		// Has IVA = btob iva
		gcb.prGetApplicantProfile(applicantId);

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_30710_Satsuma B2B: PreDip Decline", "Aspire", "");

		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(PAN_CODE, ApplicationType.B2B), "Group Code");
	}

	@AfterMethod
	public void afterTest() throws Exception {
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
	}
}
