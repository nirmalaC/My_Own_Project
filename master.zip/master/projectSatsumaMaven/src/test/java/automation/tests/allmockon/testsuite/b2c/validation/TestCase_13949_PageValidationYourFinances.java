package automation.tests.allmockon.testsuite.b2c.validation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class TestCase_13949_PageValidationYourFinances extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database

		gcb.gsPANAgreementNumber = "";

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);
		gcb.prCreateUniquePerson();
		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

	}

	@Test
	public void test_PageDefaults() throws Exception {

		// What is your current source of income - Default is Please Select
		Select dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// What is your regular income amount - Default is blanked
		Assert.assertEquals(getDriver().findElement(By.id("Income")).getText(), "");

		// How often do you receive this regular income - Default is Please
		// Select
		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// How do you receive this income - Default is Please Select
		dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
		Assert.assertEquals("Please select", dropdown.getFirstSelectedOption().getText());

		// What is you monthly rent/mortgage amount - Default is blanked
		Assert.assertEquals(getDriver().findElement(By.id("HousingCostsAmount")).getText(), "");

		// Do you have any Credit Cards - Default is un-ticked both Yes and No
		Assert.assertFalse(getDriver().findElement(By.id("HasCreditCardsYes")).isSelected());
		Assert.assertFalse(getDriver().findElement(By.id("HasCreditCardsNo")).isSelected());

		// Do you have any other loans - Default is un-ticked both Yes and No
		Assert.assertFalse(getDriver().findElement(By.id("HasOtherLoansYes")).isSelected());
		Assert.assertFalse(getDriver().findElement(By.id("HasOtherLoansNo")).isSelected());

		// If yes, what are your monthly loan and credit card repayments? -
		// Default not visible
		Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		// Excluding the above, what is the value of other significant monthly
		// outgoings - Default is blanked
		Assert.assertEquals(getDriver().findElement(By.id("OtherOutgoingsAmount")).getText(), "");

		// ** End Of Test **/
	}

	@Test
	public void test_MandatoryFieldsAstrix() {

		Assert.assertEquals("Which best describes your employment status?*", getDriver().findElement(By.xpath("//label[@for='EmploymentStatusValue']")).getText());
		Assert.assertEquals("What is your regular income amount after tax?*\n?", getDriver().findElement(By.xpath("//label[@for='Income']")).getText());
		Assert.assertEquals("How often do you receive your money?*", getDriver().findElement(By.xpath("//label[@for='IncomeFrequencyValue']")).getText());
		Assert.assertEquals("How do you get paid / receive your income?*\n?", getDriver().findElement(By.xpath("//label[@for='IncomeMethodValue']")).getText());
		Assert.assertEquals("How much do you pay towards your rent/mortgage per month?*", getDriver().findElement(By.xpath("//label[@for='HousingCostsAmount']")).getText());
		Assert.assertEquals("Do you have any Credit Cards?*", getDriver().findElement(By.xpath("//label[@for='HasCreditCards']")).getText());
		Assert.assertEquals("Do you have any other loans?*", getDriver().findElement(By.xpath("//label[@for='HasOtherLoans']")).getText());

		// Invoke repayments amount field visibility to check field label
		if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsYes")).click();
			getDriver().findElement(By.id("HasCreditCardsYes")).sendKeys(Keys.SPACE);
		}
		gcb.waitForVisibilityOfElement(By.id("LoansRepaymentsAmount"));
		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed(), "check loans repayment amount is displayed");
		Assert.assertEquals("If yes, what are your monthly loan and credit card repayments?*", getDriver().findElement(By.xpath("//label[@for='LoansRepaymentsAmount']")).getText());

		// ** End Of Test **/
	}

	@Test
	public void test_MandatoryFieldValidationmessages() {

		// click on the Next:Your Finances if Apply or Review Your Quote of
		// Quick-Apply
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		gcb.waitForVisibilityOfElement(By.xpath("//span[@data-valmsg-for='EmploymentStatusValue']"));

		// Check validation message for current source of income
		// Assert.assertEquals("Please select your current income source",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmploymentStatusValue']")).getText());
		Assert.assertEquals("Please select your employment status", getDriver().findElement(By.xpath("//span[@data-valmsg-for='EmploymentStatusValue']")).getText());

		// Check validation message for regular income amount
		Assert.assertEquals("Please enter your regular income after tax", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());

		// Check validation message for regular income amount
		Assert.assertEquals("Please select how often you receive your regular income", getDriver().findElement(By.xpath("//span[@data-valmsg-for='IncomeFrequencyValue']")).getText());

		// Check validation message for income receive method
		Assert.assertEquals("Please select how you receive your regular income", getDriver().findElement(By.xpath("//span[@data-valmsg-for='IncomeMethodValue']")).getText());

		// Check validation message for has credit cards
		Assert.assertEquals("The Do you have any Credit Cards? field is required.", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HasCreditCards']")).getText());

		// Check validation message for has other loans
		Assert.assertEquals("The Do you have any other loans? field is required.", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HasOtherLoans']")).getText());

		// Invoke repayments amount field visibility to check field label
		if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsYes")).click();
			getDriver().findElement(By.id("HasCreditCardsYes")).sendKeys(Keys.SPACE);
		}
		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed(), "loans repayment amount is displayed");

		// click on the Next:Your Finances if Apply or Review Your Quote of
		// Quick-Apply
		// getDriver().findElement(By.id("ContinueButton")).click();
		getDriver().findElement(By.id("ContinueButton")).sendKeys(Keys.ENTER);

		gcb.waitForVisibilityOfElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']"));

		// Check validation message for repayments amount
		Assert.assertEquals("Please enter your monthly loan/credit card repayments", getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());

		// ** End Of Test **/
	}

	@Test
	public void test_FieldLengthInvalidCharacters() {

		// Where field lengths on certain fields are breached or where invalid
		// characters maintained
		// a validation message is raised

		// What is your regular income amount?

		// Reject £
		getDriver().findElement(By.id("Income")).sendKeys(" £ ");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		getDriver().findElement(By.id("Income")).sendKeys("£9,999.00 ");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Reject Alphabetic
		getDriver().findElement(By.id("Income")).sendKeys("AbCdEfgH");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Reject Alphanumeric
		getDriver().findElement(By.id("Income")).sendKeys("123O");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Reject Negative
		getDriver().findElement(By.id("Income")).sendKeys("-");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Zero
		getDriver().findElement(By.id("Income")).sendKeys("0");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Reject Decimal places greater than 2
		getDriver().findElement(By.id("Income")).sendKeys("0.991");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Decimal places up to 1
		getDriver().findElement(By.id("Income")).sendKeys("0.9");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Decimal places up to 2
		getDriver().findElement(By.id("Income")).sendKeys("0.99");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// //CV - disabled this as not really relevent anymore
		// // Accept Leading spaced valid values
		// getDriver().findElement(By.id("Income")).sendKeys(" 123");
		// getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		// getDriver().findElement(By.id("Income")).clear();
		//
		// //CV - disabled this as not really relevent anymore
		// // Accept Trailing spaced valid values
		// getDriver().findElement(By.id("Income")).sendKeys("123 ");
		// getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		// getDriver().findElement(By.id("Income")).clear();

		Select dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText("Weekly");

		// Reject Income greater than 999 when Income Frequency is Weekly
		getDriver().findElement(By.id("Income")).sendKeys("999.01");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter an amount between 0 and 999", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Income of Zero when Income Frequency is Weekly
		getDriver().findElement(By.id("Income")).sendKeys("0");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText("Monthly");

		// Reject Income greater than 9999 when Income Frequency is Monthly
		getDriver().findElement(By.id("Income")).sendKeys("9999.01");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter an amount between 0 and 9,999", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Income less of Zero when Income Frequency is Monthly
		getDriver().findElement(By.id("Income")).sendKeys("00");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText("Fortnightly");

		// Reject Income greater than 9999 when Income Frequency is Fortnightly
		getDriver().findElement(By.id("Income")).sendKeys("9999.01");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter an amount between 0 and 9,999", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Income of Zero when Income Frequency is Fortnightly
		getDriver().findElement(By.id("Income")).sendKeys("000");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText("Annually");

		// Reject Income greater than 99999 when Income Frequency is Annually
		getDriver().findElement(By.id("Income")).sendKeys("99999.01");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter an amount between 0 and 99,999", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// Accept Income of Zero when Income Frequency is Annually
		getDriver().findElement(By.id("Income")).sendKeys("0000");
		getDriver().findElement(By.id("Income")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='Income']")).getText());
		getDriver().findElement(By.id("Income")).clear();

		// What is your monthly rent/mortgage amount

		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(" £ ");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("£9,999.00 ");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Reject Alphabetic
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("AbCdEfgH");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Reject Alphanumeric
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("123O");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Reject Negative
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("-");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Accept Zero
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Reject Decimal places greater than 2
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0.991");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Accept Decimal places up to 1
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0.9");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// Accept Decimal places up to 2
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("0.99");
		getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// // CV - no longer relevent test
		// // Accept Leading spaced valid values
		// getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(" 123");
		// getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		// getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// // // CV - no longer relevent test
		// // Accept Trailing spaced valid values
		// getDriver().findElement(By.id("HousingCostsAmount")).sendKeys("123 ");
		// getDriver().findElement(By.id("HousingCostsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='HousingCostsAmount']")).getText());
		// getDriver().findElement(By.id("HousingCostsAmount")).clear();

		// What is your Other outgoings

		// Reject £
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(" £ ");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("£9,999.00 ");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Reject Alphabetic
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("AbCdEfgH");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Reject Alphanumeric
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("123O");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Reject Negative
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("-");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Accept Zero
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Reject Decimal places greater than 2
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0.991");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("Please enter the amount as a number, without £ signs", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Accept Decimal places up to 1
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0.9");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Accept Decimal places up to 2
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("0.99");
		getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// // CV - no longer relevant
		// // Accept Leading spaced valid values
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(" 123");
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();
		//
		// // Accept Trailing spaced valid values
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys("123 ");
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='OtherOutgoingsAmount']")).getText());
		// getDriver().findElement(By.id("OtherOutgoingsAmount")).clear();

		// Invoke repayments amount field visibility to check field label
		if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			getDriver().findElement(By.id("HasCreditCardsYes")).click();
		}
		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		// What is monthly loan/creditcard repayments

		// //Bug 42283
		// // Reject £
		// getDriver().findElement(By.id("LoansR epaymentsAmount")).sendKeys(" £ ");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		//
		// //Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("£9,999.00 ");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // Reject Alphabetic
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("AbCdEfgH");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // Reject Alphanumeric
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("123O");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // Reject Negative
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("-");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // // Accept Zero
		// //
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("0");
		// //
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// // Assert.assertEquals("",
		// //
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// // getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // Reject Decimal places greater than 2
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("0.991");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("Please enter the amount as a number, without £ signs",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();

		// Accept Decimal places up to 1
		getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("0.9");
		getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();

		// Accept Decimal places up to 2
		getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("0.99");
		getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		Assert.assertEquals("", getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();

		// // CV - no longer relevant
		// // Accept Leading spaced valid values
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(" 123");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();
		//
		// // Accept Trailing spaced valid values
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys("123 ");
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).sendKeys(Keys.TAB);
		// Assert.assertEquals("",
		// getDriver().findElement(By.xpath("//span[@data-valmsg-for='LoansRepaymentsAmount']")).getText());
		// getDriver().findElement(By.id("LoansRepaymentsAmount")).clear();

		// ** End Of Test **/
	}

	@Test
	public void test_AvailableSourceOfIncomeOptions() {

		// What is your current source of income?
		Select dropdown = new Select(getDriver().findElement(By.id("EmploymentStatusValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Benefits");
		dropdown.selectByVisibleText("Benefits And Part Time Employment");
		dropdown.selectByVisibleText("Benefits And Full Time Employment");
		dropdown.selectByVisibleText("Part Time Employment Only");
		dropdown.selectByVisibleText("Full Time Employment Only");
		dropdown.selectByVisibleText("Retired ( Pension)");
		dropdown.selectByVisibleText("Self Employed");
		dropdown.selectByVisibleText("Armed Forces");
		dropdown.selectByVisibleText("Home Maker");
		dropdown.selectByVisibleText("Unemployed");
		dropdown.selectByVisibleText("Employed Temporary");
		dropdown.selectByVisibleText("Student");

		// Validate no more items listed than above - Expect 8 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(13, l.size());

		// ** End of Test **
	}

	@Test
	public void test_AvailableIncomeFrequencyOptions() {

		// What is your income frequency?
		Select dropdown = new Select(getDriver().findElement(By.id("IncomeFrequencyValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Weekly");
		dropdown.selectByVisibleText("Fortnightly");
		dropdown.selectByVisibleText("Monthly");
		dropdown.selectByVisibleText("Annually");

		// Validate no more items listed than above - Expect 5 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(5, l.size());

		// ** End Of Test **/
	}

	@Test
	public void test_AvailableIncomeMethodOptions() {

		// What is your income method?
		Select dropdown = new Select(getDriver().findElement(By.id("IncomeMethodValue")));
		dropdown.selectByVisibleText("Please select");
		dropdown.selectByVisibleText("Direct Into Bank Account");
		dropdown.selectByVisibleText("Cheque");
		dropdown.selectByVisibleText("Cash");
		dropdown.selectByVisibleText("Other");

		// Validate no more items listed than above - Expect 5 items
		List<WebElement> l = dropdown.getOptions();
		Assert.assertEquals(5, l.size());

		// ** End Of Test **/
	}

	@Test
	public void test_VisibilityOfLoanCreditCardRepaymentField() {

		// Check enabling of the
		// "If yes, what are your monthly loan and credit card repayments?*"
		// field

		if (getDriver().findElement(By.id("HasCreditCardsYes")).isSelected() || getDriver().findElement(By.id("HasCreditCardsNo")).isSelected() || getDriver().findElement(By.id("HasOtherLoansYes")).isSelected() || getDriver().findElement(By.id("HasOtherLoansNo")).isSelected()) {
			Assert.fail("Aborted: This test requires Do you have credit cards and/or loans Yes/No option to be all unticked");
		}

		// Is repayments amount field visible when Have any credit cards = Yes
		// and Have any loans = Not Set
		if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsYes")).click();
			getDriver().findElement(By.id("HasCreditCardsYes")).sendKeys(Keys.SPACE);
		}

		gcb.waitForVisibilityOfElement(By.id("LoansRepaymentsAmount"));

		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed(), "check loan repayment amount is shown");

		// Is repayments amount field not visible when Have any credit cards =
		// No and Have any loans = Not Set
		if (getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsNo")).click();
			getDriver().findElement(By.id("HasCreditCardsNo")).sendKeys(Keys.SPACE);
		}

		Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed(), "check loan repayment is NOT shown");

		// Is repayments amount field visible when Have any loans = Yes and Have
		// any credit cards = No
		if (!getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
			// getDriver().findElement(By.id("HasOtherLoansYes")).click();
			getDriver().findElement(By.id("HasOtherLoansYes")).sendKeys(Keys.SPACE);
		}
		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		// Is repayments amount field not visible when Have any loans = No and
		// Have any credit cards = No
		if (getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
			// getDriver().findElement(By.id("HasOtherLoansNo")).click();
			getDriver().findElement(By.id("HasOtherLoansNo")).sendKeys(Keys.SPACE);
		}
		Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		// Is repayments amount field visible when Have any credit cards = Yes
		// and Have any loan = Yes
		if (!getDriver().findElement(By.id("HasCreditCardsYes")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsYes")).click();
			getDriver().findElement(By.id("HasCreditCardsYes")).sendKeys(Keys.SPACE);
		}
		if (!getDriver().findElement(By.id("HasOtherLoansYes")).isSelected()) {
			// getDriver().findElement(By.id("HasOtherLoansYes")).click();
			getDriver().findElement(By.id("HasOtherLoansYes")).sendKeys(Keys.SPACE);
		}
		Assert.assertTrue(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

		// Is repayments amount field Not visible when Have any credit cards =
		// No and Have any loans = No
		if (!getDriver().findElement(By.id("HasCreditCardsNo")).isSelected()) {
			// getDriver().findElement(By.id("HasCreditCardsNo")).click();
			getDriver().findElement(By.id("HasCreditCardsNo")).sendKeys(Keys.SPACE);
		}
		if (!getDriver().findElement(By.id("HasOtherLoansNo")).isSelected()) {
			// getDriver().findElement(By.id("HasOtherLoansNo")).click();
			getDriver().findElement(By.id("HasOtherLoansNo")).sendKeys(Keys.SPACE);
		}
		Assert.assertFalse(getDriver().findElement(By.id("LoansRepaymentsAmount")).isDisplayed());

	}

	@Test
	public void test_IsMoneyAdviceServiceLinkGood() throws Exception {

		// This test piece is driven by CMS which could change at any time,
		// therefore ignoring on the assumption that UAT will pick this up

		// Check access possible to Money Advice Service site in a new window
		String parentWindow = getDriver().getWindowHandle();

		gcb.waitForClickableElement(By.linkText("moneyadviceservice.org.uk"));
		WebElement linkMoneyAdviceService = getDriver().findElement(By.linkText("moneyadviceservice.org.uk"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", linkMoneyAdviceService);
		// getDriver().findElement(By.linkText("moneyadviceservice.org.uk")).click();

		Thread.sleep(2000);

		if (!_switchWindowByTitle("Money Advice Service")) {
			Assert.fail("Aborted: Unable to navigate to Money Advice Service");
		} else {
			getDriver().close();
			getDriver().switchTo().window(parentWindow);
		}

		// ** End of Test **
	}
}
