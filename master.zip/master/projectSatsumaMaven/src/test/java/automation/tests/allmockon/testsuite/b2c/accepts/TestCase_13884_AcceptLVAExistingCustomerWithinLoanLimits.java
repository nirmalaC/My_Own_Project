package automation.tests.allmockon.testsuite.b2c.accepts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_13884_AcceptLVAExistingCustomerWithinLoanLimits extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_ExistingCustomerWithinLoanLimitsIsOfferedLVA() throws Exception {

		// Scenario
		// ========
		//
		// This test is to ensure that the LVA is presented to provide alternate
		// loan offers available to existing customers who
		// are within there loan limits. The test subject used has an 50% paid
		// up active loan for £200 over 17 weeks and is applying
		// for another £200 over 17 weeks. As the test subject has an existing
		// loan active loan which is being paid up then he can be
		// offered up to £400, therefore the LVA page is presented to prompt the
		// test subject that they have alternative offers.
		//
		// In this test the test subject once presented with the LVA page
		// decides only to continue with there initial request of £200 over 17
		// weeks.

		String sAgreementNumber = "";

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person, this person is set up to request £200 over 17 weeks
		gcb.prGetApplicantProfile(130);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically. The
		// loan term is £200 over 13 weeks and 50% paid up
		gcb.prSeedUniqueHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		log.info("Active Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of active half paid agreement for this test failed. ");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: ?
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and that there are other
		// options available to them
		Assert.assertTrue(getDriver().findElement(By.xpath("//form/p")).getText().contains("Great news! As an existing Satsuma Loans customer there are a number of loan options available to you."));

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		gcb.waitForSelectedTextInElement(By.id("TotalInterestLVACalcText"), gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest));

		// Loan Amount Slider defaulted to £200 - Original request
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("min"));
		// Assert.assertEquals("400",
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("max"));
		Assert.assertTrue(getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("max").contains("1000"), "check max is correct, does not take into account decimal places");
		Assert.assertEquals("200", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to £200 - Original request
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		Assert.assertEquals("£200", dropdown.getFirstSelectedOption().getText());

		// Loan Term defaulted to 17 weeks - Original request
		Assert.assertEquals("0", getDriver().findElement(By.id("TermLVACalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermLVACalc")).getAttribute("max"));
		Assert.assertEquals("1", getDriver().findElement(By.id("TermLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to 17 weeks - Original request
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		Assert.assertEquals("17 weeks", dropdown.getFirstSelectedOption().getText());

		// User does not want anymore but just accepts the original request
		gcb.gsRequestedTerm = "17";
		gcb.gsRequestedLoanAmount = "200";

		// Get Expected Loan Offer Details for Loan Term Validation
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// Assert that Interest, Weekly repayments and TAP are displayed
		// correctly
		// Pricing for £200 17 weeks - Defaulted correctly
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedInterest), getDriver().findElement(By.id("TotalInterestLVACalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedRepayment), getDriver().findElement(By.id("RepaymentAmountLVACalcText")).getText());
		Assert.assertEquals(gcb.formatCurrencyToDisplay(gcb.gsExpectedTAP), getDriver().findElement(By.id("TotalAmountLVACalcText")).getText());

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();
		}

		// Invoke Next action: Next: ? Your Quote if Quick Apply else Your
		// Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);
		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result13 in context Great news!
		// Your
		// // next Satsuma Loan has been approved (For existing customer)
		// gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}
}
