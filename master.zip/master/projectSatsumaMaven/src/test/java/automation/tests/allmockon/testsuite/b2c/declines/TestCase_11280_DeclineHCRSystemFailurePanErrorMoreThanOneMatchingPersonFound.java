package automation.tests.allmockon.testsuite.b2c.declines;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class TestCase_11280_DeclineHCRSystemFailurePanErrorMoreThanOneMatchingPersonFound extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// should this test be disabled since it throws an error when multiple pan
	// matches are found
	@Test(enabled = false)
	public void test_SystemFailurePanError() throws Exception {

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);

		// Seed Pan Credit target test environment with an rejected agreement.
		gcb.prSeedUniqueActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of active agreement for this test failed. ");
		}

		log.info("Active agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Create a new contact record with cloned details but different by
		// Surname
		gcb.prCreateBySurnameUniquePersonContactInPAN(gcb.gsPanCreditServiceServer);

		// Abort test is data preparation failed
		if (gcb.gsSurnameTemp.isEmpty()) {
			Assert.fail("Aborted: Seeding of cloned contact record for this test failed. ");
		}

		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurnameTemp, gcb.gsPostcode, gcb.gsSurname);

		gcb.prLogoutFromPanCreditFrontOffice();

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// Goto Satsuma site
		getDriver().get(this.gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Invoke Next action: Apply now
		getDriver().findElement(By.id("SubmitHomeCalc")).click();

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: ?
		gcb.prClickForNextAction();

		// Home Credit page
		// =====================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

	}

}
