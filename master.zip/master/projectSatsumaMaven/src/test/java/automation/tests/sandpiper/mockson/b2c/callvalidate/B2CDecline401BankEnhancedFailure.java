package automation.tests.sandpiper.mockson.b2c.callvalidate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnCallCreditDeclineTest;
import automation.dao.CustomerType;
import automation.satsuma.pages.ApplicationType;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline401BankEnhancedFailure extends B2CAllMocksOnCallCreditDeclineTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String EXPECTED_PAN_DESC = "Bank Enhanced Failure";
	private static final String EXPECTED_PAN_CODE = "401";
	private static final int WEEKLY_APPLICANT_ID = 106;
	private static final int MONTHLY_APPLICANT_ID = 410;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		runTest(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		runTest(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cFlDeclineWeekly() throws Exception {
		b2CFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cFlDeclineMonthly() throws Exception {
		b2CFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cLoginDeclineWeekly() throws Exception {
		b2CLoginFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	@Test(enabled = false)
	public void testB2cLoginDeclineMonthly() throws Exception {
		b2CLoginFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, EXPECTED_PAN_CODE, EXPECTED_PAN_DESC);
	}

	public void runTest(int applicantId, String pancode, String pandesc) throws Exception {

		// Data Preparation
		// ================

		// Get a application profile for CallCredit test subject with a Bank
		// Enhanced Failure set.
		// Applicant Mr BankEnhanced Failure
		gcb.prGetApplicantProfile(applicantId);
		gcb.setRandomDOB();
		gcb.setRandomEmail();
		gcb.setRandomPostcode();

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============
		gcb.gsPANAgreementNumber = "";

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		// gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		int counter = 3;

		// Bank Details page
		// =================
		while (counter > 0) {
			gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

			// Fill in applicants bank details from the profile
			gcb.prFillInPageBankDetailsRandom();

			// Invoke Next action: Next: Payment Details
			gcb.prClickForNextAction();
			counter--;
		}

		// Home Credit page
		// ================

		gcb.prAssertOnPageHomeCredit(gsSatsumaSiteUrl);

		String reasonCode = PowerCurveDBHelper.getReasonCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);
		String groupCode = PowerCurveDBHelper.getGroupCode(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname);

		Assert.assertEquals(reasonCode, gcb.getReasonCodeFromPANCode(pancode, ApplicationType.B2C), "Reason Code");
		Assert.assertEquals(groupCode, gcb.getGroupCodeFromPANCode(pancode, ApplicationType.B2C), "Group Code");
	}

	@AfterMethod
	public void afterTest() throws Exception {
		if (gcb.gsFirstname != null) {
			// Log into PanCredit Front Office
			EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
			PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);

			gcb.prLogIntoPanCreditFrontOffice();
			gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, "*", "AutoDel" + gcb.gsSurname);
			gcb.prLogoutFromPanCreditFrontOffice();
		} else {
			log.warn("Couldn't remove person agreements after test");
		}
	}
}
