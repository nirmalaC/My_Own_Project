package automation.tests.allmockon.login.uat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_14298_UATCoreRegressionTrackingPanCreditLastPaidReferrer extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public final String affiliateLink1 = "?orig=offmar&source=acquisition&camp=directmail&cmpid=directmail-customer_recruitment-generic-generic&utm_medium=directmail&utm_source=customer_recruitment&utm_content=generic&utm_campaign=gene";
	public final String affiliateLink2 = "?red=1&ref=DIR_MODUS&affid=weblink1&cmpid=affiliate-MODUS-weblink1-apply&utm_medium=affiliate&utm_source=MODUS&utm_content=weblink1&utm_campaign=apply";

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// Goto Satsuma site first affiliate
		getDriver().get(this.gsSatsumaSiteUrl + affiliateLink1);

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl + affiliateLink1);

		gcb.takeIncrementScreenshot();

		// Goto Satsuma site second affiliate
		getDriver().get(this.gsSatsumaSiteUrl + affiliateLink2);

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl + affiliateLink2);

		gcb.takeIncrementScreenshot();

		// Invoke Next action: Apply now

		final By byBtnApply = By.id("SubmitHomeCalc");
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnApply)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnApply)));
		getDriver().findElement(byBtnApply).sendKeys(Keys.TAB);
		getDriver().findElement(byBtnApply).click();

		// getDriver().findElement(By.id("SubmitHomeCalc")).sendKeys(Keys.ENTER);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		final By byBtnStartYourApplication = By.linkText("Start your application");
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(getDriver().findElement(byBtnStartYourApplication)));
		(new WebDriverWait(getDriver(), EXPLICIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(getDriver().findElement(byBtnStartYourApplication)));
		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();
		// getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.ENTER);

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);
		gcb.takeIncrementScreenshot();

		// Connect to TestShed database

	}

	@Test
	public void test() throws Exception {
		String sAgreementNumber;

		// Data Preparation
		// ================

		gcb.prGetApplicantProfile(133);
		gcb.prCreateUniquePerson();

		log.info("INFO: Applicant " + gcb.gsFirstname + " " + gcb.gsSurname + " " + gcb.gsDOB);

		// Determine if test subject has agreements on the target PAN
		// environment, if so we need to remove links to this
		// person as the test expects them to be a new customer (not known to
		// Provident)
				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			Assert.fail("Aborted: Agreement " + gcb.gsPANAgreementNumber + " found, please remove and re-try test");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.NEW_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched", gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page
		// ===============

		// Landed on completion page type Result19 in context Great news! Your
		// Satsuma Loan has been approved (For new customer)
		gcb.prAssertOnPageCompletionIDResult19(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

		// Check in PAN that affiliate details have been provided

		gcb.prLogIntoPanCreditFrontOffice();

		gcb.prNavigateToPANCreditAgreement(sAgreementNumber);

		gcb.prOpenAdditionalDetails();

		// To verify tracking has worked successfully, check the following
		// details are correct:-
		// Internet Affiliate Sub ID
		// Internet Campaign weblink1
		// Internet Device MOBI / DESK
		// Internet IP Address
		// Internet Search Ad Group
		// Internet Search Campaign
		// Internet Search Term
		// Internet Source DIR_MODUS
		// Internet Type Affiliate
		// Marketing Channel Internet
		// Marketing Company Satsuma

		gcb.prVerifyAffiliate("", "weblink1", "DESK", "", "", "", "DIR_MODUS", "Affiliate", "Internet", "Satsuma");

		gcb.prLogoutFromPanCreditFrontOffice();

	}
}
