package automation.tests.allmockon.testsuite.b2b.accepts;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;
import automation.test.offerservice.enums.OfferPartyStatus;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.support.SoapUIException;

// same as test case TestCase_15655_AcceptHappyPath100Over13
public class B2BAcceptExistingCustomer100Over13 extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void tempTest() throws Exception {

		gcb.prGetApplicantProfile(208);

		gcb.gsFirstname = "Eva";
		gcb.gsSurname = "Branson";
		gcb.gsDOB = "20/07/1970";
		gcb.gsPostcode = "SE28 8RE";
		gcb.gsBuildingNumber = "380";

		gcb.setRandomEmail();

		gcb.gsRequestedLoanAmount = "1000";

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = testCase.getPropertyValue("ptcAPR");
		String sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		String sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================
		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		String agreementNo = b2bAcceptJourney(gsSatsumaBrokerUrl, true);

	}

	@Test
	public void existingRegistered() throws Exception {

		seedAndRegisterLogin(100f, "13", true);

		gcb.logoutInPageLogin();

		gcb.gsRequestedLoanAmount = "1000";

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = testCase.getPropertyValue("ptcAPR");
		String sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		String sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================
		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		String agreementNo = b2bAcceptJourney(gsSatsumaBrokerUrl, true);

	}

	@Test
	public void existingNotRegistered() throws Exception {

		gcb.prGetApplicantProfile(164);

		// create unique person
		gcb.prCreateUniquePerson();

		gcb.seedFLEEligibleOffer("PE", 800d, false, OfferPartyStatus.PAID_UP, 0);

		gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);

		gcb.gsRequestedLoanAmount = "1000";

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_HappyPath", "TestCase_15655_Satsuma B2B: Accept Happy Path 100 over 13", "Aspire", "");

		// capture return values from SOAPUI TestCase
		String sAPR = testCase.getPropertyValue("ptcAPR");
		String sLoanAmount = testCase.getPropertyValue("ptcLoanAmount");
		String sTAP = testCase.getPropertyValue("ptcTAP");

		// Check that the financial details returned on the Broker response are
		// the same as those expected
		Assert.assertEquals(sAPR, gcb.gsExpectedAPR);
		Assert.assertEquals(sLoanAmount, gcb.gsRequestedLoanAmount);
		Assert.assertEquals(sTAP, gcb.gsExpectedTAP);

		// using the url captured in the response goto website
		// user is presented with the Broker Lead landing page

		// Broker Landing Page
		// ===================
		String gsSatsumaBrokerUrl = testCase.getPropertyValue("ptcURL");

		log.info("Customer Link: " + gsSatsumaBrokerUrl);
		log.info("APR is: " + sAPR);
		log.info("Returned Loan Amount is: " + sLoanAmount);

		String agreementNo = b2bAcceptJourney(gsSatsumaBrokerUrl, false);

	}

	public void seedAndRegisterLogin(float originalLoanAmount, String originalLoanTerm, boolean paidUp) throws XmlException, SoapUIException, Exception {
		// Get a Mocked application profile as template for creating a dynamic
		// unique person.
		gcb.prGetApplicantProfile(208);
		gcb.setRandomBankDetails();
		// create an unique person, generated dynamically.
		// gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		float outstandingAmount = 0;
		if (!paidUp) {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm, "weekly");
			outstandingAmount = Float.valueOf(gcb.gsPANPaidUpAmount);
		} else {
			// Seed Pan Credit target test environment with an active agreement.
			// The
			// agreement
			gcb.prSeedSpecifiedPersonFullPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer, Integer.toString((int) originalLoanAmount), originalLoanTerm);
			outstandingAmount = 0f;
		}

		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");

		// navigate to register
		gcb.navigateToRegistrationPage(gsSatsumaSiteUrl);

		// register a new account
		gcb.fillInPageIdentifyYourAccount();

		// select your password
		gcb.assertOnPagePassword(gsSatsumaSiteUrl);
		gcb.fillInPageCompleteYourRegistration();

		// check successful registration
		gcb.assertOnPageRegistered(gsSatsumaSiteUrl);

		// navigate to login
		gcb.navigateToLoginPage(gsSatsumaSiteUrl);
		gcb.assertOnLoginPage(gsSatsumaSiteUrl);

		// try to login with the new credentials
		gcb.loginInPageLogin();
		gcb.prAssertOnPageLoggedIn(gsSatsumaSiteUrl);
		login.assertAgreementInfo(Float.toString(originalLoanAmount), "December", "2016", gcb.gsPANAgreementNumber);

		gcb.seedFLEEligibleOffer("PE", 800d, false);

		login.activateAndAssertEligibility(gcb.formatCurrencyNoDP(1000));

	}

}
