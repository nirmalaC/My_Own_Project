package automation.tests.allmockon.testsuite.b2c.validation;

import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class TestCase_13945_PageValidationHomeExistingCustomerSliders26Weekly extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {
		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");
		// Goto Satsuma site
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);
		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		// Connect to TestShed database

	}

	@AfterMethod
	public void tearDown() throws Exception {
		// Disconnect from TestShed database

	}

	@Test
	public void test_ExistingCustomerSliderPricingCalculationsFor26WeeklyTerm() throws Exception {
		// getDriver().findElement(linkExistingCustomers).click();
		getDriver().findElement(linkExistingCustomers).sendKeys(Keys.ENTER);
		test_HomeSliderPricingCalculations("Weekly", 26, 100, 1000);
		// ** End of Test **
	}
}
