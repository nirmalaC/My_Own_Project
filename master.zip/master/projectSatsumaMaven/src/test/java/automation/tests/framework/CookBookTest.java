package automation.tests.framework;

import java.io.IOException;
import java.text.ParseException;

import org.apache.xmlbeans.XmlException;
import org.junit.Ignore;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.satsuma.pages.CookBook;
import automation.satsuma.pages.Login;

import com.eviware.soapui.support.SoapUIException;

public class CookBookTest {
	protected ThreadLocal<RemoteWebDriver> threadDriver = null;
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	CookBook gcb = new CookBook(threadDriver);
	Login login = new Login(threadDriver);

	@Test
	public void testDateCalculatorWeekly() throws Exception {

		String dOW = "MONDAY";
		String currentDate = "01/11/2017";
		String result = gcb.fn_PreferredPaymentDate(currentDate, dOW);

		Assert.assertEquals(result, "13th November 2017");
	}

	@Test
	public void testDateCalculatorMonthly() {
		String currentDate = "20/11/2017";
		String termType = "Monthly";
		String preferredPaymentDay = "10th";
		String actual = gcb.getFirstRepaymentDate(currentDate, termType, preferredPaymentDay);

		Assert.assertEquals(actual, "10/01/2018", "First repayment date");
	}

	@Test
	public void testDateCalculatorMonthly2() {
		String currentDate = "20/11/2017";
		String termType = "Monthly";
		String preferredPaymentDay = "29th";
		String actual = gcb.getFirstRepaymentDate(currentDate, termType, preferredPaymentDay);

		Assert.assertEquals(actual, "29/12/2017", "First repayment date");
	}

	@Test
	public void testDateCalcFinalRepaymentDateWeekly() {
		int term = 13;
		String termType = "Weekly";
		String firstRepaymentDate = "20/11/2017";
		String actual = gcb.getLastRepaymentDate(termType, firstRepaymentDate, term);

		Assert.assertEquals(actual, "19/02/2018");
	}

	@Test
	public void testDateCalcFinalRepaymentDateMonthly() {
		int term = 9;
		String termType = "Monthly";
		String firstRepaymentDate = "20/11/2017";

		String actual = gcb.getLastRepaymentDate(termType, firstRepaymentDate, term);

		Assert.assertEquals(actual, "20/08/2018");

	}

	@Test
	public void testCurrencyFormatter() throws Exception {
		Assert.assertEquals(gcb.formatCurrencyToDisplay("10.00"), "£10.00");
		Assert.assertEquals(gcb.formatCurrencyToDisplay("100.00"), "£100.00");
		Assert.assertEquals(gcb.formatCurrencyToDisplay("1000.00"), "£1,000.00");
		Assert.assertEquals(gcb.formatCurrencyToDisplay("1000000.00"), "£1,000,000.00");
	}

	@Test
	public void testGetRandomDOB() {
		log.info(gcb.getRandomDOB());
		log.info(gcb.getRandomDOB());
		log.info(gcb.getRandomDOB());
	}

	@Test
	public void testGetUniqueFirstnameSurnameDOB() throws XmlException, SoapUIException, IOException, Exception {
		gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
		gcb.prCreateUniquePerson();
	}

	@Test
	@Ignore
	public void testCalcEligibleAmount() {
		Assert.assertEquals(gcb.calcEligibleAmount(1000.00f, 995.01f), 1000.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(1000.00f, 920.00f), 1080.00f);
		// Assert.assertEquals(gcb.calcEligibleAmount(300.00f, 200.00f),
		// 600.00f);
		// Assert.assertEquals(gcb.calcEligibleAmount(210.00f, 200.00f),
		// 500.00f);
		// Assert.assertEquals(gcb.calcEligibleAmount(710.00f, 0f), 1500.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(700.00f, 695.00f), 1100.00f);
	}

	@Test
	public void testCalcEligibleAmountNew() throws ClassNotFoundException {
		Assert.assertEquals(gcb.calcEligibleAmount(1000.00f, 995.01f, 13, "Weekly"), 700.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(1000.00f, 0f, 13, "Weekly"), 1500.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(700.00f, 501.01f, 13, "Weekly"), 1040.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(600.00f, 0f, 13, "Weekly"), 1000.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(600.00f, 429.325f, 13, "Weekly"), 1000.00f);
		Assert.assertEquals(gcb.calcEligibleAmount(100.00f, 143.14f, 13, "Weekly"), 1000.00f);
	}

	@Test
	public void testRandomPostCode() {
		log.info(gcb.randomPostcode());
	}

	@Test
	public void testReadableRandomName() {
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
		log.info(gcb.getReadableRandomName());
	}

	@Test
	public void testMonthlyStartDateAndEndDate() throws ParseException {
		Assert.assertEquals(gcb.getScheduleStartDateForMonthly(1, "06/10/2016"), "01/12/2016");
		Assert.assertEquals(gcb.getScheduleStartDateForMonthly(1, "01/10/2016"), "01/11/2016");
		Assert.assertEquals(gcb.getScheduleEndDateForMonthly("01/10/2016", 12), "01/09/2017");
	}

	@Test
	public void test_Fn_PreferredPaymentDate() {
		Assert.assertEquals(gcb.fn_PreferredPaymentDate("08/08/2017", "TUESDAY"), "15th August 2017");
		Assert.assertEquals(gcb.fn_PreferredPaymentDate("08/08/2017", "WEDNESDAY"), "16th August 2017");
		Assert.assertEquals(gcb.fn_PreferredPaymentDate("08/08/2017", "THURSDAY"), "17th August 2017");
		Assert.assertEquals(gcb.fn_PreferredPaymentDate("08/08/2017", "FRIDAY"), "18th August 2017");
		Assert.assertEquals(gcb.fn_PreferredPaymentDate("08/08/2017", "MONDAY"), "21st August 2017");

	}

	@Test
	public void testFormatDate() {
		String dateFormatIn = "dd MMMM yyyy";
		String dateFormatOut = "dd/MM/yyyy";
		String date = "20 April 2029";
		try {
			Assert.assertEquals(gcb.formatDate(date, dateFormatIn, dateFormatOut), "20/04/2029");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testFormatDate2() {
		String dateFormatOut = "dd MMMM yyyy";
		String dateFormatIn = "dd/MM/yyyy";
		String date = "20/04/2029";
		try {
			Assert.assertEquals(gcb.formatDate(date, dateFormatIn, dateFormatOut), "20 April 2029");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
