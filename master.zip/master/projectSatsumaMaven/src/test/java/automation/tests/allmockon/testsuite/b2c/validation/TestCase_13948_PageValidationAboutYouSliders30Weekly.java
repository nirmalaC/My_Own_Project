package automation.tests.allmockon.testsuite.b2c.validation;

import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.PageValidationTest;

public class TestCase_13948_PageValidationAboutYouSliders30Weekly extends PageValidationTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");
		getDriver().manage().deleteAllCookies();
		getDriver().get(this.gsSatsumaSiteUrl + "/development/backend/killsession");
		// Goto Satsuma site
		gcb.prGoToSatsumaHome(gsSatsumaSiteUrl);

		// Home page
		// ==============

		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);

		gcb.prClickAndGoToApplyPage(gsSatsumaSiteUrl);

		// Your Application page
		// =====================

		gcb.prAssertOnPageYourApplication(gsSatsumaSiteUrl);

		// Invoke Next action: Start your application
		getDriver().findElement(By.linkText("Start your application")).sendKeys(Keys.TAB);
		getDriver().findElement(By.linkText("Start your application")).click();

		// About You page
		// ==============

		gcb.prAssertOnPageAboutYou(gsSatsumaSiteUrl);

		// Connect to TestShed database
		

	}

	@Test
	public void test_SliderPricingCalculationsFor30WeeklyTerm() throws SQLException {

		// We are checking the full pricing up to £2000, so need to select
		// Existing customer to adjust slider to £2000
		if (!getDriver().findElement(By.id("SaysIsExistingCustomerYes")).isSelected()) {
			getDriver().findElement(By.id("SaysIsExistingCustomerYes")).click();
		}
		test_AboutYouSliderPricingCalculations("Weekly", 30, 100, 2000);
		// ** End of Test **
	}

}
