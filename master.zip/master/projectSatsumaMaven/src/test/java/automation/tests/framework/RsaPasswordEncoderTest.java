package automation.tests.framework;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.tests.mobile.rest.RsaPasswordEncoder;

public class RsaPasswordEncoderTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void testRSAPasswordEncoder() throws IOException {
		log.info(RsaPasswordEncoder.rsaEncode("12letmeiN!"));
	}

}
