package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class TestCase_16568_DeclineActiveCustomerInTemporaryArrangement extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_DeclineCustomerWhenInArrears() throws Exception {

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person
		gcb.prGetApplicantProfile(5);

		// Seed Pan Credit target test environment with an agreement in
		// temporray arrangement.
		gcb.prSeedUniqueActiveAgreementInArrangementInPAN(gcb.gsPanCreditServiceServer);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of agreement in temporary arrangement for this test failed. ");
		}

		log.info("Rejected Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke only if we have not switched on quick application
		// functionality, by directly navigating to
		// the next page i.e. Your Finances otherwise this is combined page
		// journey
		if (!gcb.gsQuickApply.equals("true")) {
			// Invoke Next action: Next: Your Finances
			gcb.prClickForNextAction();

			// Your Finances Page
			// ==================

			// gcb.prAssertOnPageYourFinances( gsSatsumaSiteUrl);
		}

		// Fill in applicants finance details from the profile
		// gcb.prFillInPageYourFinances();

		// Invoke Next action: Next: Review Your Quote
		// gcb.prClickForNextAction();

		// Decline page expected
		// =====================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result5
		// Thank you for your interest in another Satsuma Loan. Unfortunately
		// we're unable to process your application for a further loan today.
		gcb.prAssertOnPageFinishedIDResult5(gsSatsumaSiteUrl);

	}

}
