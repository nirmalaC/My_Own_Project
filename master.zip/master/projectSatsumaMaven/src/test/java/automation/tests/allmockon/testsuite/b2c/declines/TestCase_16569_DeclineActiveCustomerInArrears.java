package automation.tests.allmockon.testsuite.b2c.declines;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;

public class TestCase_16569_DeclineActiveCustomerInArrears extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_DeclineCustomerWhenInArrears() throws Exception {

		// Data Preparation
		// ================

		// Get application profile for Mocked based applicant
		// Applicant: Mr Ian Arrears
		gcb.prGetApplicantProfile(94);

		gcb.setRandomDOB();
		gcb.setRandomEmail();
		gcb.setRandomPostcode();

				gcb.prGetPersonsLatestAgreementStatusInPAN(gcb.gsPanCreditServiceServer, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB, gcb.gsPostcode);

		if (gcb.gsPANAgreementFound.equals("true")) {
			log.warn("Found: Agreement " + gcb.gsPANAgreementNumber + " found, but not in arrears, please remove and re-try test");
			removeAgreementAndReturnToAboutYou(gcb.gsPANAgreementNumber);

			// Seed a Active agreement for this person in PAN
			gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of active agreement for this test failed.");
			}

			log.info("Active Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		} else {

			// Seed a Active agreement for this person in PAN
			gcb.prSeedSpecifiedPersonActiveAgreementInPAN(gcb.gsPanCreditServiceServer);

			// Abort test is data preparation failed
			if (gcb.gsPANAgreementNumber.isEmpty()) {
				Assert.fail("Aborted: Seeding of active agreement for this test failed.");
			}

		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke only if we have not switched on quick application
		// functionality, by directly navigating to
		// the next page i.e. Your Finances otherwise this is combined page
		// journey
		if (!gcb.gsQuickApply.equals("true")) {
			// Invoke Next action: Next: Your Finances
			gcb.prClickForNextAction();

			// Your Finances Page
			// ==================
			// CV - 2016-02-24 no longer called before decline S3
			// gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);
		}

		// Fill in applicants finance details from the profile
		// CV - 2016-02-24 no longer called before decline S3
		// gcb.prFillInPageYourFinances();

		// Invoke Next action: Next: Review Your Quote
		// CV - 2016-02-24 no longer called before decline S3
		// gcb.prClickForNextAction();

		// Decline page expected
		// =====================

		// Landed on correct decline page - This specific decline page is
		// identified with id=Result5
		// Thank you for your interest in another Satsuma Loan. Unfortunately
		// we're unable to process your application for a further loan today.
		gcb.prAssertOnPageFinishedIDResult5(gsSatsumaSiteUrl);

	}
}
