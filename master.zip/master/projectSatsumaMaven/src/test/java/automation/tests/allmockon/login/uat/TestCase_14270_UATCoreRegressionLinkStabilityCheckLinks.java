package automation.tests.allmockon.login.uat;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.satsuma.pages.SatsumaHome;

// Has this test been finished?
public class TestCase_14270_UATCoreRegressionLinkStabilityCheckLinks extends AllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Override
	@BeforeMethod
	public void setUpBefore() throws Exception {

		gsSatsumaSiteUrl = gcb._getConfigProperty("SatsumaSiteUrl");
		gsdbTESTSHEDConnectionString = gcb._getConfigProperty("TestShedDBConnection");
		gcb.gsSOAPUIProjectFolder = gcb._getConfigProperty("SOAPUIProjectFolder");
		gcb.gsPanCreditServiceServer = gcb._getConfigProperty("PanCreditServiceServer");
		gcb.gsQuickApply = gcb._getConfigProperty("QuickApply");

		gcb.gsPANFrontOfficeUid = gcb._getConfigProperty("PanFrontOfficeUid");
		gcb.gsPANFrontOfficePwd = gcb._getConfigProperty("PanFrontOfficePwd");

		getDriver().manage().deleteAllCookies();

	}

	@Test(enabled = false)
	// not yet completed
	public void test() throws Exception {
		// Goto Satsuma site
		getDriver().get(gsSatsumaSiteUrl);

		// Home page
		// ==============
		gcb.prAssertOnPageHome(gsSatsumaSiteUrl);
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byImgSatsumaLoansLogo, "Short Term Loans | Official Site | Satsuma Loans", gsSatsumaSiteUrl);
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkHeaderFAQ, "Frequently Asked Questions | FAQs | Satsuma Loans", gsSatsumaSiteUrl + "faqs");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkHeaderContactUs, "Contact Us | Get In Touch | Satsuma Loans", gsSatsumaSiteUrl + "contact-us");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkHeaderExistingCustomer, "Existing customers | Satsuma Loans", gsSatsumaSiteUrl + "existing-customers");
		/*test doesn't specify this step --- */clickLinkCheckTitleUrlAndBack(SatsumaHome.byImgSatsumaLoansLogo, "Short Term Loans | Satsuma Loans", gsSatsumaSiteUrl);
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkHowOurLoansWork, "How our loans work | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkLoansExplained, "Loan Options | Loans Explained | Satsuma Loans", gsSatsumaSiteUrl + "loans-explained");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkToolsAndTips, "Tools and tips | Satsuma Loans", gsSatsumaSiteUrl + "tools-and-tips");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkAboutUs, "About us | Satsuma Loans", gsSatsumaSiteUrl + "about-us");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnk135Years, "Provident heritage | Satsuma Loans", gsSatsumaSiteUrl + "about-us/provident-heritage");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkSayYes, "Instant Decision | Quick Decision | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works/instant-decision");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkPayOutsBetween, "How our loans work | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkManageable, "Weekly Repayment Loans | Pay Back Weekly Loans | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works/weekly-repayment-loans");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkAmountAgree, "Our Charges | No Fees | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works/our-charges");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFromAmount, "1000 Loans | Satsuma Loans", gsSatsumaSiteUrl + "loans-explained/loan-reason/1000-loans");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		/*clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkPercentOfCustomer, "Customer Reviews | Satsuma Loans", gsSatsumaSiteUrl + "about-us/customer-reviews");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below */
		/*clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFindOutMore, "About us | Satsuma Loans", gsSatsumaSiteUrl + "about-us");*/
		/*getDriver().findElement(SatsumaHome.byLnkFindOutMore).sendKeys(Keys.SPACE);//scroll page down to interact with elements below*/
		/*clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkMoreReasons, "A trusted lender | Satsuma Loans", gsSatsumaSiteUrl + "about-us/a-trusted-lender");*/
		getDriver().findElement(SatsumaHome.byLnkSayYes).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkWeeklyRepayments, "Weekly Repayment Loans | Pay Back Weekly Loans | Satsuma Loans", gsSatsumaSiteUrl + "how-it-works/weekly-repayment-loans");
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		getDriver().findElement(SatsumaHome.byLnkSayYes).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkSeeAllReviews, "Customer Reviews | Satsuma Loans", gsSatsumaSiteUrl + "about-us/customer-reviews");
		
		getDriver().findElement(SatsumaHome.byLnk135Years).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		getDriver().findElement(SatsumaHome.byLnkSayYes).sendKeys(Keys.SPACE);//scroll page down to interact with elements below
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterHome, "Short Term Loans | Satsuma Loans", gsSatsumaSiteUrl);
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterCookies, "Cookies | Satsuma Loans", gsSatsumaSiteUrl + "about-our-cookies");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterAffiliates, "Join Our Affiliate Programme | Satsuma Loans", gsSatsumaSiteUrl + "affiliates");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterTerms, "Terms and conditions | Satsuma Loans", gsSatsumaSiteUrl + "terms-and-conditions");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterAccessibility, "Accessibility options | Satsuma Loans", gsSatsumaSiteUrl + "accessibility");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterSiteMap, "Sitemap | Satsuma Loans", gsSatsumaSiteUrl + "sitemap");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterPrivacy, "Privacy Policy | Satsuma Loans",	gsSatsumaSiteUrl + "privacy");	
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkFooterReadAllFAQs, "Frequently Asked Questions | FAQs | Satsuma Loans", gsSatsumaSiteUrl + "faqs");
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byLnkContactUsEmail, "Short Term Loans | Satsuma Loans", gsSatsumaSiteUrl);//mailto link - stays on same page
		clickLinkCheckTitleUrlAndBack(SatsumaHome.byOtherWaysToContactUs, "Contact Us | Get In Touch | Satsuma Loans", gsSatsumaSiteUrl + "contact-us");
				
		// getDriver().findElement(SatsumaHome.byLnkHeaderFAQ).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "faqs");
		// gcb.waitForTitle(
		// "Frequently Asked Questions | FAQs | Satsuma Loans");
		//
		// getDriver().findElement(SatsumaHome.byLnkHeaderContactUs).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "contact-us");
		// gcb.waitForTitle(
		// "Contact Us | Get In Touch | Satsuma Loans");
		//
		// getDriver().findElement(SatsumaHome.byLnkHeaderExistingCustomer).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "existing-customers");
		// gcb.waitForTitle( "Existing customers | Satsuma Loans");
		//
		// getDriver().findElement(SatsumaHome.byImgSatsumaLoansLogo).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl);
		// gcb.waitForTitle( "Short Term Loans | Satsuma Loans");
		//
		// getDriver().findElement(SatsumaHome.byLnkHowOurLoansWork).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "how-it-works");
		// gcb.waitForTitle( "How our loans work | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkLoansExplained).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "loans-explained");
		// gcb.waitForTitle(
		// "Loan Options | Loans Explained | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkToolsAndTips).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "tools-and-tips");
		// gcb.waitForTitle( "Tools and tips | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkAboutUs).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us");
		// gcb.waitForTitle( "About us | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnk135Years).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us/provident-heritage");
		// gcb.waitForTitle( "Provident heritage | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkSayYes).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "how-it-works/instant-decision");
		// gcb.waitForTitle(
		// "Instant Decision | Quick Decision | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkPayOutsBetween).sendKeys("");
		// getDriver().findElement(SatsumaHome.byLnkPayOutsBetween).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "how-it-works");
		// gcb.waitForTitle( "How our loans work | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkManageable).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl +
		// "how-it-works/weekly-repayment-loans");
		// gcb.waitForTitle(
		// "Weekly Repayment Loans | Pay Back Weekly Loans | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkAmountAgree).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "how-it-works/our-charges");
		// gcb.waitForTitle(
		// "Our Charges | No Fees | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkFromAmount).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl +
		// "loans-explained/loan-reason/1000-loans");
		// gcb.waitForTitle( "1000 Loans | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkPercentOfCustomer).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us/customer-reviews");
		// gcb.waitForTitle( "Customer Reviews | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkFindOutMore).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us");
		// gcb.waitForTitle( "About us | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkMoreReasons).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us/a-trusted-lender");
		// gcb.waitForTitle( "A trusted lender | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkWeeklyRepayments).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl +
		// "how-it-works/weekly-repayment-loans");
		// gcb.waitForTitle(
		// "Weekly Repayment Loans | Pay Back Weekly Loans | Satsuma Loans");
		// getDriver().navigate().back();
		//
		// getDriver().findElement(SatsumaHome.byLnkSeeAllReviews).click();
		// gcb.waitForUrl(gsSatsumaSiteUrl + "about-us/customer-reviews");
		// gcb.waitForTitle( "Customer Reviews | Satsuma Loans");
		// getDriver().navigate().back();

	}

	private void clickLinkCheckTitleUrlAndBack(By by, String title, String url) {
		String previousUrl = getDriver().getCurrentUrl();
		getDriver().findElement(by).sendKeys("");
		try {
			getDriver().findElement(by).click();
		} catch (WebDriverException e) {
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", getDriver().findElement(by));
		}
		gcb.waitForUrl(url);
		gcb.waitForTitle( title);
		gcb.takeIncrementScreenshot();
		getDriver().get(previousUrl);
	}
}
