package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23889_AcceptActiveCustomerRepricesTerm26Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice26weeks1020() throws Exception {
		existingCustomerAccepts("1020", "26", "Weekly", "680", 133);
	}

	@Test
	public void test_Reprice26weeks1190() throws Exception {
		existingCustomerAccepts("1190", "26", "Weekly", "840", 133);
	}

	@Test
	public void test_Reprice26weeks1040() throws Exception {
		existingCustomerAccepts("1040", "26", "Weekly", "1000", 133);
	}

}
