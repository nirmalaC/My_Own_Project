package automation.tests.allmockon.testsuite.b2c.accepts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.AllMocksOnTest;
import automation.dao.CustomerType;

public class TestCase_11324_AcceptLVAExistingCustomerExposureExceeded extends AllMocksOnTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_AcceptLVAExistingCustomerExposureExceeded2K() throws Exception {

		String sAgreementNumber = "";

		// Capture current Url
		gsCurrentUrl = getDriver().getCurrentUrl();

		// Data Preparation
		// ================

		// Get a Mocked application profile as template for creating a dynamic
		// unique person, this person is
		// is asking more which exceeds the 2K barrier for concurrent loan

		gcb.prGetApplicantProfile(6);

		// Seed Pan Credit target test environment with an active agreement. The
		// agreement`
		// created is created for an unique person, generated dynamically.

		log.info("INFO: Creating half paid up agreement original loan £1000, then requesting amount to £1600 to force outside loan limits £2000");
		// Initial loan was for a £1000, change global variable
		// gcb.gsRequestedLoanAmount to £1000 temporarily to allow creation of
		// agreement then
		// revert to £1600 to force outside of loan limit
		gcb.gsRequestedLoanAmount = "1000";
		gcb.prSeedUniqueHalfPaidUpAgreementInPAN(gcb.gsPanCreditServiceServer);
		gcb.gsRequestedLoanAmount = "1600";

		log.info("Active Half Paid Agreement created: " + gcb.gsPANAgreementNumber + " PersonId: " + gcb.gsPANPersonId);

		// Abort test is data preparation failed
		if (gcb.gsPANAgreementNumber.isEmpty()) {
			Assert.fail("Aborted: Seeding of active half paid agreement for this test failed. ");
		}

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// About You page
		// ==============

		gcb.prFillInPageAboutYou();

		// Invoke Next action:
		gcb.prClickForNextAction();

		// Assert that we have landed on the LVA page - Loan Value Adjustment
		gcb.prAssertOnPageLoanValueAdjustment(gsSatsumaSiteUrl);

		// Assert that we have landed on the LVA page in the appropriate
		// context, that the customer is existing and what maximum loan amount
		// can be offered
		// The maximum loan amount should be £1280 which is determined as
		// follows. If 1st loan TAP is £1431.04 and is 50% paid up ie. £715.53
		// with the remaining amount
		// £715.51 then maximum exposure amount is £2000 minus £715.53 =
		// £1284.47 rounded down to the nearest £10 is £1280.00
		Assert.assertTrue(getDriver().findElement(By.id("JourneyForm")).getText().contains("We’ve had a quick look at your Satsuma Loans account and based on what we know, we would be prepared to lend you up to £1,280.00."));

		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));
		gcb.waitForDropdownSelectedText(By.id("LoanAmountLVACalcDropdown"), "£1280");

		// Loan Amount Slider defaulted to £1280 as this is the maximum amount
		// the customer is offered as his previous request was higher
		Assert.assertEquals("100", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("min"));
		// Assert.assertEquals("1280",
		// getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("max"));
		Assert.assertTrue(getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("max").contains("1280"), "check max is correct, does not take into account decimal places");
		Assert.assertEquals("1280", getDriver().findElement(By.id("LoanAmountLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to £1280
		Select dropdown = new Select(getDriver().findElement(By.id("LoanAmountLVACalcDropdown")));
		Assert.assertEquals("£1280", dropdown.getFirstSelectedOption().getText());

		// Loan Term defaulted to 13 weeks
		Assert.assertEquals("0", getDriver().findElement(By.id("TermLVACalc")).getAttribute("min"));
		Assert.assertEquals("9", getDriver().findElement(By.id("TermLVACalc")).getAttribute("max"));
		Assert.assertEquals("0", getDriver().findElement(By.id("TermLVACalc")).getAttribute("value"));

		// Loan Amount dropdown defaulted to 13 weeks
		dropdown = new Select(getDriver().findElement(By.id("TermLVACalcDropdown")));
		Assert.assertEquals("13 weeks", dropdown.getFirstSelectedOption().getText());

		// User accepts the defaulted limit, adjust the requested loan term
		gcb.gsRequestedTerm = "13";
		gcb.gsRequestedLoanAmount = "1280";

		// Get Expected Loan Offer Details
		gcb.prGetACurrentSatsumaLoanCharge(gcb.gsRepaymentFrequency, Integer.parseInt(gcb.gsRequestedTerm), Integer.parseInt(gcb.gsRequestedLoanAmount));

		// added by affordibility project
		if (!getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).isSelected()) {
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).sendKeys(Keys.chord(Keys.TAB, Keys.SHIFT));
			getDriver().findElement(By.id("CustomerAffordabilityConfirmation")).click();
		}

		// Invoke Next action: Next: Your Finances
		gcb.prClickForNextAction();

		// Your Finances Page
		// ==================

		gcb.prAssertOnPageYourFinances(gsSatsumaSiteUrl);

		// Fill in applicants finance details from the profile
		gcb.prFillInPageYourFinances(CustomerType.ACTIVE_CUSTOMER);

		// Invoke Next action: Next: Review Your Quote
		gcb.prClickForNextAction();

		// Your Quote page
		// ==============

		gcb.prAssertOnPageQuote(gsSatsumaSiteUrl);

		// Assert that quoted offer is representative of requested loan terms
		gcb.prAssertQuoteOfferAsPerRequest();

		// Invoke Next action: Next: Bank Details
		gcb.prClickForNextAction();

		// Bank Details page
		// =================

		gcb.prAssertOnPageBankDetails(gsSatsumaSiteUrl);

		// Fill in applicants bank details from the profile
		gcb.prFillInPageBankDetailsRandom();

		// Invoke Next action: Next: Payment Details
		gcb.prClickForNextAction();

		// WorldPay Test Page
		// ==================

		// Fill in applicants card details from the profile and trigger a
		// Approved response
		gcb.prFillInTestWorldPayAndRespond("Authorised", "Approved", "Postcode and address matched",gsSatsumaSiteUrl);

		// Password screen Login Phase 2
		// =====================

		// Fill in password box
		gcb.assertOnPageMySatsumaAccount(gsSatsumaSiteUrl);
		gcb.fillInPageMySatsumaAccount("Password1");

		// Credit Agreement page
		// ======================

		// (new WebDriverWait(getDriver(),
		// 180)).until(ExpectedConditions.presenceOfElementLocated(By.id("agreement-product-explanation")));

		gcb.prAssertOnPageCreditAgreement(gsSatsumaSiteUrl);

		// Read and Sign the Credit Agreement
		gcb.prReadAndSignCreditAgreement();

		// Capture Agreement Number from the Credit Agreement page
		sAgreementNumber = gcb.fnCaptureCreditAgreementNumber();

		// Assert key content of the credit agreement page to ensure that
		// details corresponds to the applicants loan request and personal
		// details
		gcb.prAssertCreditAgreement();

		// Invoke Next action: Next: Complete Your Agreement
		gcb.prClickForNextAction();

		// Completion page - changed for login phase 2
		// ===============

		gcb.assertOnPageMySatsumaAccept(gsSatsumaSiteUrl);

		// // Landed on completion page type Result13 in context Great news!
		// Your
		// // next Satsuma Loan has been approved (For existing customer)
		// gcb.prAssertOnPageCompletionIDResult13(gsSatsumaSiteUrl);

		// Assert that the agreement is created in PANCredit as per the
		// applicant's requested/quoted details
		// =================================================================================================

		gcb.prAssertNewNonBrokeredAgreement(gcb.gsPanCreditServiceServer, sAgreementNumber, gcb.gsRepaymentFrequency, gcb.gsRequestedTerm, gcb.gsExpectedRepayment, gcb.gsRequestedLoanAmount, gcb.gsExpectedAPR, gcb.gsExpectedFlatRate, gcb.gsExpectedDailyRate, gcb.gsExpectedTAP,
				gcb.gsPreferredPaymentDow, gcb.gsFirstname, gcb.gsSurname, gcb.gsMobileNumber, gcb.gsEmailAddress, gcb.gsStreet, gcb.gsPostcode);

	}
}
