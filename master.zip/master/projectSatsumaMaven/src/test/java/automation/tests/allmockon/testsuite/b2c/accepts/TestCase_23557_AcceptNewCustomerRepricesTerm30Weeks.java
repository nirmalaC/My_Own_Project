package automation.tests.allmockon.testsuite.b2c.accepts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import automation.basetests.AllMocksAcceptTests;

public class TestCase_23557_AcceptNewCustomerRepricesTerm30Weeks extends AllMocksAcceptTests {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void test_Reprice30weeks100() throws Exception {
		newCustomerAccept("100", "30", "Weekly", 133);
	}

	@Test
	public void test_Reprice30weeks600() throws Exception {
		newCustomerAccept("600", "30", "Weekly", 133);
	}

	@Test
	public void test_Reprice30weeks1000() throws Exception {
		newCustomerAccept("1000", "30", "Weekly", 133);
	}

}
