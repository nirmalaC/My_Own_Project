package automation.tests.sandpiper.mockson.b2c.experian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import automation.basetests.B2CAllMocksOnExperianDeclineTest;
import automation.tools.EntityHubHelper;
import automation.tools.PowerCurveDBHelper;

public class B2CDecline205TimeSinceMostRecentCCJ extends B2CAllMocksOnExperianDeclineTest {

	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private static final String TIME_SINCE_MOST_RECENT_CCJ_DESC = "Invalid: Time Since Most Recent CCJ";
	private static final String TIME_SINCE_MOST_RECENT_CCJ_CODE = "205";
	private static final int WEEKLY_APPLICANT_ID = 409;
	private static final int MONTHLY_APPLICANT_ID = 409;

	@Test
	public void testB2cNbDeclineWeekly() throws Exception {
		b2CNewBusinessHardDecline(WEEKLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@Test
	public void testB2cNbDeclineMonthly() throws Exception {
		b2CNewBusinessHardDecline(MONTHLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@Test
	public void testB2cFlDeclineWeekly() throws Exception {
		b2CFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@Test
	public void testB2cFlDeclineMonthly() throws Exception {
		b2CFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@Test
	public void testB2cLoginDeclineWeekly() throws Exception {
		b2CLoginFurtherLendingHardDecline(WEEKLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@Test
	public void testB2cLoginDeclineMonthly() throws Exception {
		b2CLoginFurtherLendingHardDecline(MONTHLY_APPLICANT_ID, TIME_SINCE_MOST_RECENT_CCJ_CODE, TIME_SINCE_MOST_RECENT_CCJ_DESC);
	}

	@AfterMethod
	public void afterTest() throws Exception {
		EntityHubHelper.removeFromHub(gcb.entitySearchDB, gcb.entityHubDB, gcb.gsFirstname, gcb.gsSurname);
		PowerCurveDBHelper.removeApplicantAndAppFromPCO(gcb.powercurveDB, gcb.gsFirstname, gcb.gsSurname, gcb.gsDOB);
		gcb.prLogIntoPanCreditFrontOffice();
		gcb.prSearchAndRenameCustomerBySurnameInPanCreditFrontOffice(gcb.gsFirstname, gcb.gsSurname, gcb.gsPostcode, "AutoDel" + gcb.gsSurname.substring(0, Math.min(10, gcb.gsSurname.length())));
		gcb.prLogoutFromPanCreditFrontOffice();
	}
}
