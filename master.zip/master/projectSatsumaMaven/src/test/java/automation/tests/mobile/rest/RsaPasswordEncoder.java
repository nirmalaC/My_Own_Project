package automation.tests.mobile.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class RsaPasswordEncoder {

	public static String rsaEncode(String password) throws IOException {
		Process process = new ProcessBuilder("c:\\RSA\\rsa.exe", password).start();
		InputStream is = process.getInputStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		return br.readLine();
	}

}
