package automation.tests.experian.downsell;

import automation.basetests.ExperianMockOffTestAdapted;

public class TestCase_MonthlyDownsellNPRTScoreDataProvider extends ExperianMockOffTestAdapted {
	//
	// @DataProvider(name = "test1")
	// public Object[][] createData() {
	// return new Object[][] { { "MOHAMMED", "INCE", "1000", "12" }, {
	// "MOHAMMED", "INCE", "900", "12" }, { "WILLIAM", "RAJARATNAN", "1000",
	// "12" }, { "CAROL", "KIFFF", "1000", "12" } };
	// }
	//
	// @Test(dataProvider = "test1")
	// public void downsell(String forename, String surname, String loanAmount,
	// String term) throws Exception {
	// downsellMonthlyAccept(forename, surname, loanAmount, term);
	// // downsellMonthlyAccept("MOHAMMED", "INCE", "1000", "12");
	// }
	//
	// private void downsellMonthlyAccept(String forename, String surname,
	// String loanAmount, String term) throws Exception {
	// EntityHubHelper.removeFromHub(gcb.entityHubDB, forename, surname);
	// SatsumaExperianAgreement agreement =
	// ExperianDataHelper.getSatsumaExperianAgreement(forename, surname);
	// log.debug(agreement.toString());
	// ExperianDataHelper.convertToCookbook(agreement, gcb);
	// gcb.setRandomEmail();
	// newCustomerQuoteVerifyDownsell(loanAmount, term, "Monthly", 133, true);
	// }
}
