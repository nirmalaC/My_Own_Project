package automation.tests.allmockon.testsuite.b2b.accepts;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.basetests.B2BAllMocksOnTest;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.support.SoapUIException;

/*
 *System Test
 This test is concerned with ensuring that a Pre-DiP Filter Score less than 30 results in a decline response to the Broker Service request.
 To test use the attached WCFStorm XML as a template and modify using the parameterised data in the test case.
 Ensure that the SatsumaBrokerPreliminaryEnhancedWorkflow has ItemId="61" : SamplingRatioA="1.00" and ItemId="21" : SamplingRatioA="1.00".
 Can be tested with all mocks ON.
 */

public class TestCase_32355_ProcessBrokerLeadTermIsAdjustedAutomatically extends B2BAllMocksOnTest {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	@Test
	public void testTerm1() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("1");
	}

	@Test
	public void testTerm14() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("14");
	}

	@Test
	public void testTerm18() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("18");
	}

	@Test
	public void testTerm22() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("22");
	}

	@Test
	public void testTerm27() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("27");
	}

	@Test
	public void testTerm31() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("31");
	}

	@Test
	public void testTerm35() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("35");
	}

	@Test
	public void testTerm40() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("40");
	}

	@Test
	public void testTerm44() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("44");
	}

	@Test
	public void testTerm48() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("48");
	}

	@Test
	public void testTerm99() throws Exception {
		sendIncorrectTermVerifyAutoAdjustment("99");
	}

	private void sendIncorrectTermVerifyAutoAdjustment(String loanTerm) throws XmlException, IOException, SoapUIException, Exception, SQLException {
		gcb.prGetApplicantProfile(185);
		// create unique person but doesn't change DOB
		gcb.setRandomForeName();
		gcb.setRandomSurname();
		gcb.setRandomPostcode();

		// change loan set term
		gcb.gsRequestedTerm = loanTerm;

		// soapui test case called expected to decline
		TestCase testCase = gcb.soapUISatsumaBrokerPANAPI("SatsumaB2B_PreDipFilter", "TestCase_32355_Satsuma B2B: Loan Term and Amount Auto", "Aspire", "");
		String actualLoanTerm = testCase.getPropertyValue("ptcLoanTerm");
		String actualLoanAmount = testCase.getPropertyValue("ptcLoanAmount");

		log.debug("Sent loan term: " + loanTerm + " Actual loan term: " + actualLoanTerm + " Actual loan amount: " + actualLoanAmount);

		// loan term auto adjusted
		Assert.assertEquals(actualLoanTerm, getExpectedLoanTerm(loanTerm));
		Assert.assertEquals(actualLoanAmount, gcb.gsRequestedLoanAmount);
	}

	private String getExpectedLoanTerm(String loanTerm) {
		String expectedTerm = "";
		switch (loanTerm) {
		case "1":
			expectedTerm = "13";
			break;
		case "14":
			expectedTerm = "17";
			break;
		case "18":
			expectedTerm = "21";
			break;
		case "22":
			expectedTerm = "26";
			break;
		case "27":
			expectedTerm = "30";
			break;
		case "31":
			expectedTerm = "34";
			break;
		case "35":
			expectedTerm = "39";
			break;
		case "40":
			expectedTerm = "43";
			break;
		case "44":
			expectedTerm = "47";
			break;
		case "48":
			expectedTerm = "52";
			break;
		case "99":
			expectedTerm = "52";
			break;

		}
		return expectedTerm;
	}
}
