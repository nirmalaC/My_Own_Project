package automation.tools;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import automation.satsuma.pages.TimeHackHelper;

public class ToolBox {

	ThreadLocal<?> threadDriver = null;

	public ToolBox() {

	}

	public ToolBox(ThreadLocal<?> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public WebDriver getDriver() {
		return (WebDriver) threadDriver.get();
	}

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	public String fn_GetMonthFullWording(String psMM) {

		String monthString;
		switch (psMM.replaceFirst("^0+(?!$)", "")) {
		case "1":
			monthString = "January";
			break;
		case "2":
			monthString = "February";
			break;
		case "3":
			monthString = "March";
			break;
		case "4":
			monthString = "April";
			break;
		case "5":
			monthString = "May";
			break;
		case "6":
			monthString = "June";
			break;
		case "7":
			monthString = "July";
			break;
		case "8":
			monthString = "August";
			break;
		case "9":
			monthString = "September";
			break;
		case "10":
			monthString = "October";
			break;
		case "11":
			monthString = "November";
			break;
		case "12":
			monthString = "December";
			break;
		default:
			monthString = psMM;
			break;
		}
		return monthString;
	}

	public String fn_GetMonthFullWording(int piMM) {

		String monthString;
		switch (piMM) {
		case 1:
			monthString = "January";
			break;
		case 2:
			monthString = "February";
			break;
		case 3:
			monthString = "March";
			break;
		case 4:
			monthString = "April";
			break;
		case 5:
			monthString = "May";
			break;
		case 6:
			monthString = "June";
			break;
		case 7:
			monthString = "July";
			break;
		case 8:
			monthString = "August";
			break;
		case 9:
			monthString = "September";
			break;
		case 10:
			monthString = "October";
			break;
		case 11:
			monthString = "November";
			break;
		case 12:
			monthString = "December";
			break;
		default:
			monthString = Integer.toString(piMM);
			break;
		}
		return monthString;
	}

	public String fn_ChangeDateFromDDMMYYYToDDMMMYYYY(String psDDMMYYYY) throws ParseException {

		DateFormat originalFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		DateFormat targetFormat = new SimpleDateFormat("dd MMM yyyy");
		Date date = originalFormat.parse(psDDMMYYYY);
		return targetFormat.format(date);
	}

	public String fn_ChangeDateToLongFormat(String psDDMMYYYY) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat();
		String sDay;
		String sTmp;

		DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		Date date = format.parse(psDDMMYYYY);

		String strDateFormat = "EEEE";
		sdf = new SimpleDateFormat(strDateFormat);
		sTmp = sdf.format(date) + " the ";

		strDateFormat = "d";
		sdf = new SimpleDateFormat(strDateFormat);
		sDay = sdf.format(date);
		switch (sDay) {
		case "1":
			sDay = sDay + "st";
			break;
		case "2":
			sDay = sDay + "nd";
			break;
		case "3":
			sDay = sDay + "rd";
			break;
		case "31":
			sDay = sDay + "st";
			break;
		default:
			sDay = sDay + "th";
			break;
		}

		sTmp = sTmp + sDay;

		strDateFormat = "MMMM yyyy";
		sdf = new SimpleDateFormat(strDateFormat);

		return (sTmp + " of " + sdf.format(date));
	}

	public Boolean fn_isElementPresent(String psElement) {

		try {
			getDriver().findElement(By.id("PreviousAddressMessage"));
			return true;
		} catch (org.openqa.selenium.NoSuchElementException e) {
			return false;
		}
	}

	@SuppressWarnings({ "static-access", "deprecation" })
	public String fn_GetYear(int piHowManyYears) throws Exception {

		String sYear;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
		// Get todays date
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, Integer.parseInt(yearFormat.format(sdf.parse(TimeHackHelper.getPanDate()))));
		// log.debug("Now: " + cal.getTime());
		cal.add(cal.YEAR, piHowManyYears);
		sYear = new SimpleDateFormat("yyyy").format(cal.getTime());
		// log.debug("Year: " + sYear);

		return (sYear);
	}
}