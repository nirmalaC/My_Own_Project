package automation.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZoralScoreDatabaseHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	//
	public static String getWorkflowGlobalVariablesFromDecisionRef(String applicationDbServer, String decisionRef) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String xmlWorkflowGlobalVariables = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + applicationDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database looking for decision ref for agreement " + decisionRef);
			statement = conn.createStatement();
			String queryString = "select gvars.Serialized from DecisionRequest as dr left join VerificationStatus as vs on dr.VerificationStatusId = vs.Id left join SerializedObject as winput on winput.Id = dr.WorkflowInputId left join SerializedObject as woutput on woutput.Id = dr.WorkflowOutputId left join SerializedObject as gvars on gvars.Id = dr.GlobalVariablesId where dr.WorkflowExternalId = '"
					+ decisionRef + "' and dr.WorkflowName='SatsumaBrokerPreliminaryEnhancedWorkflow';";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				xmlWorkflowGlobalVariables = rs.getString(1);
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		// log.debug(xmlWorkflowGlobalVariables);
		return xmlWorkflowGlobalVariables;
	}

	public static String getRetuneScoreFromDecisionRef(String applicationDbServer, String decisionRef) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String retuneScore = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + applicationDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database looking for decision ref for agreement " + decisionRef);
			statement = conn.createStatement();
			String queryString = "select dr.ReceivedDateTime as \"Received Time Stamp\", dpr.ProviderName as \"Data Provider Name\", cast(rs.Serialized as xml) as \"Data Provider Output Content\" from DecisionRequest as dr left join DecisionDataRequest as ddr on dr.Id = ddr.DecisionRequestId left join DataProviderRequest as dpr on dpr.Id = ddr.DataProviderRequestId left join SerializedObject as rs on dpr.OutputId = rs.Id where dr.WorkflowExternalId = '"
					+ decisionRef + "' and dpr.ProviderName='ReTunedScoreDataProvider' order by [Received Time Stamp] desc;";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				retuneScore = rs.getString("Data Provider Output Content");
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(retuneScore);
		return retuneScore;
	}

	public static String getNonPayerScoreFromDecisionRef(String applicationDbServer, String decisionRef) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String nonPayerScore = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + applicationDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database looking for decision ref for agreement " + decisionRef);
			statement = conn.createStatement();
			String queryString = "select dr.ReceivedDateTime as \"Received Time Stamp\", dpr.ProviderName as \"Data Provider Name\", cast(rs.Serialized as xml) as \"Data Provider Output Content\" from DecisionRequest as dr left join DecisionDataRequest as ddr on dr.Id = ddr.DecisionRequestId left join DataProviderRequest as dpr on dpr.Id = ddr.DataProviderRequestId left join SerializedObject as rs on dpr.OutputId = rs.Id where dr.WorkflowExternalId = '"
					+ decisionRef + "' and dpr.ProviderName='NonPayerScoreDataProvider' order by [Received Time Stamp] desc;";
			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				nonPayerScore = rs.getString("Data Provider Output Content");
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(nonPayerScore);
		return nonPayerScore;
	}

	public static String getReasonDescription(String applicationDbServer, String decisionRef) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String reasonDesc = null;
		String reasonCode = null;

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + applicationDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database looking for decision ref for agreement " + decisionRef);
			statement = conn.createStatement();
			String queryString = "select rs.ReasonCode as [ReasonCode], rs.ReasonDescription as [ReasonDescription] from DecisionRequest as dr left join Reason as rs on dr.Id = rs.DecisionRequestId where dr.WorkflowExternalId = '"
					+ decisionRef + "';";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				reasonCode = rs.getString("ReasonCode");
				reasonDesc = rs.getString("ReasonDescription");
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(reasonCode + " " + reasonDesc);
		return reasonCode + " " + reasonDesc;
	}
}
