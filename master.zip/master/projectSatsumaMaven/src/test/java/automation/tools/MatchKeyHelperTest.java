package automation.tools;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.testng.Assert;
import org.testng.annotations.Test;

public class MatchKeyHelperTest {

	@Test
	public void testMatchkeyNoAlpha() {
		String name = "76'-=>/waren()-''1   112 2";
		String key = MatchKeyHelper.generateKey(name);

		Assert.assertEquals(key, "WRN");
	}

	@Test
	public void testMatchKeyFromCSV() {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("MatchKeys.csv").getFile());

		try (Scanner scanner = new Scanner(file)) {

			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String args[] = line.split(",");
				testMatchKey(args[0], args[1], "1970-01-01", args[2].substring(0, Math.min(3, args[2].length())) + args[3].substring(0, Math.min(3, args[3].length())) + "1970-01-01");
			}

			scanner.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void testMatchKey(String forename, String surname, String dob, String expectedMatchKey) {
		System.out.println(expectedMatchKey);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateDob = null;
		try {
			dateDob = sdf.parse("1970-01-01");
		} catch (ParseException e) {
			System.err.println("Error invalid date");
		}

		String matchkey = MatchKeyHelper.generateMatchKey(forename, surname, dateDob);

		Assert.assertEquals(matchkey, expectedMatchKey);
	}

}
