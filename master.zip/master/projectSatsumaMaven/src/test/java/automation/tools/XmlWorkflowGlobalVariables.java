package automation.tools;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XmlWorkflowGlobalVariables {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	private Document doc;

	public XmlWorkflowGlobalVariables(String document) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		doc = dBuilder.parse(new InputSource(new StringReader(document)));
		doc.getDocumentElement().normalize();
	}

	// traverses xml object and finds the value and name pair and returns value
	public String getValue(String name) {
		NodeList nList = doc.getElementsByTagName("GlobalVariable");
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);

			Element eElement = (Element) nNode;
			if (eElement.getElementsByTagName("Name").item(0).getTextContent().equalsIgnoreCase(name)) {
				return eElement.getElementsByTagName("Value").item(0).getTextContent();
			}
		}
		return null;
	}

	public Document getDoc() {
		return doc;
	}

	public void setDoc(Document doc) {
		this.doc = doc;
	}
}
