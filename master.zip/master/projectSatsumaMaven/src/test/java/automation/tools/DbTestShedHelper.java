package automation.tools;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DbTestShedHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());
	public final static String SYSTEM_LOGGING_DB_CONNECTION_STRING = "jdbc:sqlserver://IT500764;instance=SQLEXPRESS;Databasename=DBTestShed;username=sa;password=P@ssw0rd123";

	public static String getDownsellAmount(String npScore, String rtScore, String term, String frequency) throws ClassNotFoundException {

		log.debug("Fetching downsell for RT: " + rtScore + " NP: " + npScore + " term: " + term + " frequency " + frequency);
		ResultSet rs = null;
		CallableStatement statement = null;
		Connection conn = null;
		String downsellAmount = null;

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			statement = conn.prepareCall("{call [dbo].[pr_GetDownsellAmount] (?,?,?,?)}");
			statement.setString("np_score", npScore);
			statement.setString("rt_score", rtScore);
			statement.setString("term", term);
			statement.setString("frequency", frequency);

			rs = statement.executeQuery();

			if (rs.next()) {
				downsellAmount = rs.getString("offerAmount");
			} else {
				log.error("No downsell amount found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		log.debug("Found downsell " + downsellAmount);
		return downsellAmount;
	}

	public static float getLoanAmountFromAvailableTAPAndTerm(float totalTapAvailable, int term, String frequency) throws ClassNotFoundException {
		log.debug("Fetching eligible loan for total tap available " + totalTapAvailable + " term: " + term + " freq: " + frequency);
		ResultSet rs = null;
		CallableStatement statement = null;
		Connection conn = null;
		int eligibleLoanAmount = 0;

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			statement = conn.prepareCall("{call [dbo].[GetAvailableLoanBasedOnTAPAndTerm] (?,?,?)}");
			statement.setFloat("piAvailableTap", totalTapAvailable);
			statement.setInt("piTerm", term);
			statement.setString("piFrequency", frequency);

			rs = statement.executeQuery();

			if (rs.next()) {
				eligibleLoanAmount = Float.valueOf(rs.getString("loanAmount")).intValue();
			} else {
				log.error("Not eligible");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		log.debug("Found eligible loan amount " + eligibleLoanAmount);
		return eligibleLoanAmount;

	}

	public static int getTAPFromLoanAmountAndTerm(int requestedLoanAmount, int term, String frequency) throws ClassNotFoundException {
		ResultSet rs = null;
		CallableStatement statement = null;
		Connection conn = null;
		int eligibleLoanAmount = 0;

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			conn = DriverManager.getConnection(SYSTEM_LOGGING_DB_CONNECTION_STRING);
			statement = conn.prepareCall("{call [dbo].[prGetACurrentSatsumaLoanCharge] (?,?,?)}");
			statement.setInt(1, requestedLoanAmount);
			statement.setInt(2, term);
			statement.setString(3, frequency);

			rs = statement.executeQuery();

			if (rs.next()) {
				eligibleLoanAmount = Integer.parseInt(rs.getString("loanAmount"));
			} else {
				log.error("Not eligible");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		log.debug("Found eligible loan amount " + eligibleLoanAmount);
		return eligibleLoanAmount;
	}
}
