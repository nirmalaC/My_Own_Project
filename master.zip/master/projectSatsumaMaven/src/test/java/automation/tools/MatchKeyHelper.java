package automation.tools;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MatchKeyHelper {

	public static String generateMatchKey(String forename, String surname, Date dob) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String keyForename = generateKey(forename);
		String keySurname = generateKey(surname);

		return keyForename.substring(0, Math.min(3, keyForename.length())) + keySurname.substring(0, Math.min(3, keySurname.length())) + sdf.format(dob);
	}

	public static String generateKey(String input) {

		if (input.isEmpty())
			return "";

		// clean string
		String value = input.replaceAll("[^a-zA-Z0-9]+", " ");

		// List<Tuple<int, int, int>> numbers = new List<Tuple<int, int,
		// int>>();

		List<Tuple> numbers = new ArrayList<Tuple>();

		int currentNumber = 0;

		while (currentNumber < value.length()) {
			numbers.add(new Tuple(currentNumber, currentNumber - 1, currentNumber + 1));
			currentNumber++;
		}

		value = value.toUpperCase();
		String matchKey = "";

		for (Tuple numberSet : numbers) {
			switch (numberSet.getLeft()) {
			case 0: {
				if (safeSubString(value, numberSet.getLeft(), 1).equals("P") && sqlLike(safeSubString(value, numberSet.getRight(), 1), "[H]")) {
					matchKey += matchKey + "F";
					break;
				}

				if (safeSubString(value, numberSet.getLeft(), 1).equals("C") && !safeSubString(value, numberSet.getRight(), 1).equals("H")) {
					matchKey += "K";
					break;
				}

				if (sqlLike(safeSubString(value, numberSet.getLeft(), 1), "[AEIOUQRTPSDFGJKLZXCVBNMWHY]")) {
					matchKey += value.substring(numberSet.getLeft(), 1);
					break;
				}

				break;
			}
			default: {
				if (safeSubString(value, numberSet.getLeft(), 1).equals(safeSubString(value, numberSet.getMiddle(), 1))) {
					break;
				}

				if (sqlLike(safeSubString(value, numberSet.getLeft(), 1), "[CK]") && sqlLike(safeSubString(value, numberSet.getMiddle(), 1), "[CK]")) {
					break;
				}

				if (safeSubString(value, numberSet.getLeft(), 1).equals("C") && !safeSubString(value, numberSet.getRight(), 1).equals("H")) {
					matchKey += "K";
					break;
				}

				if (safeSubString(value, numberSet.getLeft(), 1).equals("P") && sqlLike(safeSubString(value, numberSet.getRight(), 1), "[H]")) {
					matchKey += "F";
					break;
				}

				if (safeSubString(value, numberSet.getLeft(), 1).equals("H") && sqlLike(safeSubString(value, numberSet.getMiddle(), 1), "[SC]")) {
					matchKey += "H";
					break;
				}

				if (sqlLike(safeSubString(value, numberSet.getLeft(), 1), "[QRTPSDFGJKLZXCVBNMW]")) {
					matchKey += safeSubString(value, numberSet.getLeft(), 1);
					break;
				}

				break;
			}
			}

		}

		return matchKey.toUpperCase();

	}

	private static String safeSubString(String value, int start, int length) {
		if (value.length() >= (start + length)) {
			return value.substring(start, start + length);
		}
		return "";
	}

	private static boolean sqlLike(String str, String pattern) {
		boolean isMatch = true;
		boolean isWildCardOn = false;
		boolean isCharWildCardOn = false;
		boolean isCharSetOn = false;
		boolean isNotCharSetOn = false;
		boolean endOfPattern = false;
		List<Character> set = new ArrayList<Character>();

		int lastWildCard = -1;
		int patternIndex = 0;
		char p = '\0';

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			endOfPattern = (patternIndex >= pattern.length());
			if (!endOfPattern) {
				p = pattern.charAt(patternIndex);

				if (!isWildCardOn && p == '%') {
					lastWildCard = patternIndex;
					isWildCardOn = true;
					while (patternIndex < pattern.length() && pattern.charAt(patternIndex) == '%') {
						patternIndex++;
					}
					if (patternIndex >= pattern.length())
						p = '\0';
					else
						p = pattern.charAt(patternIndex);
				} else if (p == '_') {
					isCharWildCardOn = true;
					patternIndex++;
				} else if (p == '[') {
					if (pattern.charAt(++patternIndex) == '^') {
						isNotCharSetOn = true;
						patternIndex++;
					} else
						isCharSetOn = true;

					set.clear();
					if (pattern.charAt(patternIndex + 1) == '-' && pattern.charAt(patternIndex + 3) == ']') {

						char start = Character.toUpperCase(pattern.charAt(patternIndex));
						patternIndex += 2;
						char end = Character.toUpperCase(pattern.charAt(patternIndex));
						if (start <= end) {
							for (char ci = start; ci <= end; ci++) {
								set.add(ci);
							}
						}
						patternIndex++;
					}

					while (patternIndex < pattern.length() && pattern.charAt(patternIndex) != ']') {
						set.add(pattern.charAt(patternIndex));
						patternIndex++;
					}
					patternIndex++;
				}
			}

			if (isWildCardOn) {
				if (Character.toUpperCase(c) == Character.toUpperCase(p)) {
					isWildCardOn = false;
					patternIndex++;
				}
			} else if (isCharWildCardOn) {
				isCharWildCardOn = false;
			} else if (isCharSetOn || isNotCharSetOn) {
				boolean charMatch = (set.contains(Character.toUpperCase(c)));
				if ((isNotCharSetOn && charMatch) || (isCharSetOn && !charMatch)) {
					if (lastWildCard >= 0)
						patternIndex = lastWildCard;
					else {
						isMatch = false;
						break;
					}
				}
				isNotCharSetOn = isCharSetOn = false;
			} else {
				if (Character.toUpperCase(c) == Character.toUpperCase(p)) {
					patternIndex++;
				} else {
					if (lastWildCard >= 0)
						patternIndex = lastWildCard;
					else {
						isMatch = false;
						break;
					}
				}
			}
		}
		endOfPattern = (patternIndex >= pattern.length());

		if (isMatch && !endOfPattern) {
			boolean isOnlyWildCards = true;
			for (int i = patternIndex; i < pattern.length(); i++) {
				if (pattern.charAt(i) != '%') {
					isOnlyWildCards = false;
					break;
				}
			}
			if (isOnlyWildCards)
				endOfPattern = true;
		}
		return isMatch && endOfPattern;
	}
}

class Tuple {

	private int left;
	private int middle;
	private int right;

	public Tuple(int left, int middle, int right) {
		super();
		this.left = left;
		this.middle = middle;
		this.right = right;
	}

	public int getLeft() {
		return left;
	}

	public void setLeft(int left) {
		this.left = left;
	}

	public int getMiddle() {
		return middle;
	}

	public void setMiddle(int middle) {
		this.middle = middle;
	}

	public int getRight() {
		return right;
	}

	public void setRight(int right) {
		this.right = right;
	}

}
