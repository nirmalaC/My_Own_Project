package automation.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SatsumaApplicationDatabaseHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	//
	public static String getDecisionReferenceFromAgreement(String satsumaDbServer, String agreementNumber) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String decisionRef = null;
		try {
			Date now = new Date();

			Calendar cal = Calendar.getInstance();
			cal.setTime(now);
			cal.add(Calendar.MINUTE, -5);
			Date fiveMinsAgo = cal.getTime();

			// 2016-07-06 13:21:13.7601006
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.000");
			// must use UTC time as database is on UTC
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database looking for decision ref for agreement " + agreementNumber);
			statement = conn.createStatement();
			String queryString = "SELECT [DecisionReference] FROM [" + satsumaDbServer + "].[dbo].[Application] where AgreementReference='" + agreementNumber + "' and createDate > '" + sdf.format(fiveMinsAgo) + "'";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				decisionRef = rs.getString(1);
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(decisionRef);
		return decisionRef;
	}

	public static String getDecisionReferenceFromForenameSurnameDOB(String satsumaDbServer, String forename, String surname, String dob) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		String decisionRef = null;
		try {
			Date now = new Date();

			Calendar cal = Calendar.getInstance();
			cal.setTime(now);
			cal.add(Calendar.MINUTE, -5);
			Date fiveMinsAgo = cal.getTime();

			// 2016-07-06 13:21:13.7601006
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.000");
			// must use UTC time as database is on UTC
			sdf.setTimeZone(TimeZone.getTimeZone("GMT"));

			SimpleDateFormat dateIn = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat dateOut = new SimpleDateFormat("yyyy-MM-dd");

			Date dobDate = dateIn.parse(dob);
			String dobString = dateOut.format(dobDate);

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// Connection conn = DriverManager.getConnection(db_connect_string,
			// db_userid, db_password);
			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			log.debug("connected to database looking for decision ref for agreement for person with forename: " + forename + " surname: " + surname + " dob: " + dob);
			statement = conn.createStatement();
			String queryString = "select a.DecisionReference from Application a inner join Applicant b on b.ApplicationId = a.ApplicationId inner join Person p on p.PersonId = b.PersonId where p.Forename='" + forename + "' and p.Surname='" + surname + "' and p.DateOfBirth = '" + dobString + "'  and createDate > '" + sdf.format(fiveMinsAgo) + "' order by createDate desc";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				decisionRef = rs.getString(1);
			} else {
				log.error("No results found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		log.debug(decisionRef);
		return decisionRef;
	}
}
