package automation.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This class helps with removing a customer from the entity hub, this is needed in order to re-apply in the customers name again.
 * 
 */

public class EntityHubHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	public static void removeFromHub(String entitySearchDb, String entityHubDb, String forename, String surname) {
		Statement statement = null;
		Connection conn = null;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + entitySearchDb + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to remove customer from the hub");
			statement = conn.createStatement();
			// String queryString = "DELETE FROM [" + entitySearchDb +
			// "].[dbo].[PersonKeys] WHERE FIRSTNAME='" + forename +
			// "' AND LASTNAME= '" + surname + "';";
			String queryString = "delete from " + entitySearchDb + ".dbo.PersonKeys where id in (select systemid from " + entityHubDb + ".dbo.Links where HubId = (select top 1 hubid from " + entityHubDb + ".dbo.Links where hubid in (select hubid from " + entityHubDb
					+ ".dbo.Links where SystemCode = 'SearchData' and SystemId in (select id from " + entitySearchDb + ".dbo.PersonKeys where firstname = '" + forename + "' and LastName = '" + surname + "'))) and SystemCode = 'SearchData');delete from " + entityHubDb
					+ ".dbo.Links where hubid in (select hubid from " + entityHubDb + ".dbo.Links where SystemCode = 'SearchData' and SystemId in (select id from " + entitySearchDb + ".dbo.PersonKeys where firstname = '" + forename + "' and LastName = '" + surname + "'));";

			log.debug(queryString);
			statement.executeUpdate(queryString);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

	public static boolean checkIfCustomerRegistered(String entitySearchDb, String forename, String surname) {
		ResultSet rs = null;
		Statement statement = null;
		Connection conn = null;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + entitySearchDb + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to check if customer is registered");
			statement = conn.createStatement();
			String queryString = "SELECT COUNT(*) FROM [" + entitySearchDb + "].[dbo].[PersonKeys] WHERE FIRSTNAME='" + forename + "' AND LASTNAME= '" + surname + "';";

			log.debug(queryString);
			rs = statement.executeQuery(queryString);

			int count = 0;
			if (rs.next()) {
				count = rs.getInt(1);
			} else {
				log.error("couldn't get customer count");
			}

			return (count > 0);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return false;
	}
}
