package automation.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This class helps with removing a customer from the powercurve, this is needed in order to re-apply in the customers name again without trigger previous application found or bureau data reuse.
 * 
 */

public class PowerCurveDBHelper {
	public final static Logger log = LoggerFactory.getLogger(new Throwable().getStackTrace()[0].getClassName());

	// dob format must be 1980-01-10 00:00:00.000
	public static void removeApplicantAndAppFromPCO(String satsumaDbServer, String forename, String surname, String dob) {
		Statement statement = null;
		Connection conn = null;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to remove customer from PCO");
			statement = conn.createStatement();
			// String queryString =
			// "UPDATE EDA_TENANT1.APPLICATION SET APPLCTN_ID=null WHERE APPLCTN_ID IN (SELECT APPLCTN_ID from EDA_TENANT1.APPLICANT where SRNM='"
			// + surname + "' and FRNM='" + forename + "' and DT_OF_BRTH='" +
			// dob
			// +
			// "');UPDATE EDA_TENANT1.APPLICANT  SET PRVDNT_CSTMR_UNQ_ID=null where PRVDNT_CSTMR_UNQ_ID IN (SELECT PRVDNT_CSTMR_UNQ_ID from EDA_TENANT1.APPLICANT where SRNM='"
			// + surname + "' and FRNM='" + forename + "' and DT_OF_BRTH='" +
			// dob + "');";
			// String queryString =
			// "UPDATE EDA_TENANT1.APPLICATION SET APPLCTN_ID=null WHERE APPLCTN_ID IN (SELECT APPLCTN_ID from EDA_TENANT1.APPLICANT where SRNM='"
			// + surname + "' and FRNM='" + forename + "'"
			// +
			// ");UPDATE EDA_TENANT1.APPLICANT  SET PRVDNT_CSTMR_UNQ_ID=null where PRVDNT_CSTMR_UNQ_ID IN (SELECT PRVDNT_CSTMR_UNQ_ID from EDA_TENANT1.APPLICANT where SRNM='"
			// + surname + "' and FRNM='" + forename + "');";
			String queryString = "UPDATE EDA_TENANT1.APPLICANT  SET PRVDNT_CSTMR_UNQ_ID=null where PRVDNT_CSTMR_UNQ_ID IN (SELECT PRVDNT_CSTMR_UNQ_ID from EDA_TENANT1.APPLICANT where SRNM='" + surname + "' and FRNM='" + forename + "');";

			log.debug(queryString);
			statement.executeUpdate(queryString);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

	public static float getPreDipScore(String satsumaDbServer, String forename, String surname) {
		Statement statement = null;
		Connection conn = null;
		ResultSet rs = null;
		Float preDipScore = 0f;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to fetch score for customer " + surname + "," + forename + "from PCO");
			statement = conn.createStatement();
			// String queryString = "SELECT TOP 1 " + "APT.SRNM," + "APT.FRNM,"
			// + "APT.DT_OF_BRTH," + "APP.APPLCTN_ID," +
			// "SPARE.INPT_STRNG_L40_VR_31 [SatsumaUniqueApplicationID], " +
			// "RES.OJ_SRTD_RSN_CD_TBL_1, " + "RES.OJ_SRTD_RSN_CD_TBL_2," +
			// "OH_OTCM_NM [PostEnrichSpareScorecard],"
			// + "PA_SCR [PreDipFilterScorecard]," +
			// "OG_SCR [PostEnrichSpareScorecardScore]," +
			// "O3_SRTD_RSN_CD_TBL_1," + "O3_SRTD_RSN_CD_TBL_2,O3_DCSN_TXT," +
			// "aPPLCTN_DT,APPLCTN_TM " + "FROM EDA_TENANT1.APPLICATION APP "
			// +
			// "LEFT JOIN EDA_TENANT1.APPLICANT APT ON APT.IDS_APPLICATION = APP.IDS_APPLICATION "
			// +
			// "LEFT JOIN EDA_TENANT1.SPARES SPARE ON APP.IDS_APPLICATION = SPARE.IDS_SPARES "
			// +
			// "LEFT JOIN EDA_TENANT1.SDS_RESULTS RES ON RES.IDS_SDS_RESULTS = APP.IDS_SDS_RESULTS "
			// + "WHERE APT.SRNM='"
			// + surname + "' AND APT.FRNM='" + forename +
			// "' AND APPLCTN_ID<>null " + "ORDER BY APP.IDS_APPLICATION);";
			String queryString = "SELECT TOP 1 " + "PA_SCR [PreDipFilterScorecard] FROM EDA_TENANT1.APPLICATION APP " + "LEFT JOIN EDA_TENANT1.APPLICANT APT ON APT.IDS_APPLICATION = APP.IDS_APPLICATION " + "LEFT JOIN EDA_TENANT1.SPARES SPARE ON APP.IDS_APPLICATION = SPARE.IDS_SPARES "
					+ "LEFT JOIN EDA_TENANT1.SDS_RESULTS RES ON RES.IDS_SDS_RESULTS = APP.IDS_SDS_RESULTS " + "WHERE APT.SRNM='" + surname + "' AND APT.FRNM='" + forename + "' " + "ORDER BY APP.IDS_APPLICATION DESC;";
			log.debug(queryString);

			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				preDipScore = Float.valueOf(rs.getString("PreDipFilterScorecard"));
			} else {
				log.error("Score not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return preDipScore;
	}

	public static float getScore(String satsumaDbServer, String forename, String surname) {
		Statement statement = null;
		Connection conn = null;
		ResultSet rs = null;
		Float score = 0f;
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			log.info("connected to database to fetch score for customer " + surname + "," + forename + "from PCO");
			statement = conn.createStatement();

			String queryString = "SELECT TOP 1 " + "OG_SCR [PostEnrichSpareScorecardScore] FROM EDA_TENANT1.APPLICATION APP " + "LEFT JOIN EDA_TENANT1.APPLICANT APT ON APT.IDS_APPLICATION = APP.IDS_APPLICATION " + "LEFT JOIN EDA_TENANT1.SPARES SPARE ON APP.IDS_APPLICATION = SPARE.IDS_SPARES "
					+ "LEFT JOIN EDA_TENANT1.SDS_RESULTS RES ON RES.IDS_SDS_RESULTS = APP.IDS_SDS_RESULTS " + "WHERE APT.SRNM='" + surname + "' AND APT.FRNM='" + forename + "' " + "ORDER BY APP.IDS_APPLICATION DESC;";
			log.debug(queryString);

			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				score = Float.valueOf(rs.getString("PostEnrichSpareScorecardScore"));
				log.info("Found score: " + score);
			} else {
				log.error("Score not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return score;
	}

	public static String getReasonCode(String satsumaDbServer, String forename, String surname) {
		Statement statement = null;
		Connection conn = null;
		ResultSet rs = null;
		String reasonCode = "";
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to fetch reason code for customer " + surname + "," + forename + " from PCO");
			statement = conn.createStatement();
			String queryString = "SELECT TOP 1 " + "RES.OJ_SRTD_RSN_CD_TBL_1 [ReasonCode1] FROM EDA_TENANT1.APPLICATION APP " + "LEFT JOIN EDA_TENANT1.APPLICANT APT ON APT.IDS_APPLICATION = APP.IDS_APPLICATION " + "LEFT JOIN EDA_TENANT1.SPARES SPARE ON APP.IDS_APPLICATION = SPARE.IDS_SPARES "
					+ "LEFT JOIN EDA_TENANT1.SDS_RESULTS RES ON RES.IDS_SDS_RESULTS = APP.IDS_SDS_RESULTS " + "WHERE APT.SRNM='" + surname + "' AND APT.FRNM='" + forename + "' " + "ORDER BY APP.IDS_APPLICATION DESC;";
			log.debug(queryString);

			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				reasonCode = rs.getString("ReasonCode1");
				log.info("Reason code: " + reasonCode);
			} else {
				log.error("Code not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return reasonCode;
	}

	public static String getGroupCode(String satsumaDbServer, String forename, String surname) {
		Statement statement = null;
		Connection conn = null;
		ResultSet rs = null;
		String groupCode = "";
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String connectionString = "jdbc:sqlserver://hotstsatzordb1;databaseName=" + satsumaDbServer + ";integratedSecurity=true;";
			log.debug(connectionString);
			conn = DriverManager.getConnection(connectionString);
			System.out.println("connected to database to fetch group code for customer " + surname + "," + forename + " from PCO");
			statement = conn.createStatement();
			String queryString = "SELECT TOP 1 " + "O3_SRTD_RSN_CD_TBL_1 [GroupCode1] FROM EDA_TENANT1.APPLICATION APP " + "LEFT JOIN EDA_TENANT1.APPLICANT APT ON APT.IDS_APPLICATION = APP.IDS_APPLICATION " + "LEFT JOIN EDA_TENANT1.SPARES SPARE ON APP.IDS_APPLICATION = SPARE.IDS_SPARES "
					+ "LEFT JOIN EDA_TENANT1.SDS_RESULTS RES ON RES.IDS_SDS_RESULTS = APP.IDS_SDS_RESULTS " + "WHERE APT.SRNM='" + surname + "' AND APT.FRNM='" + forename + "' " + "ORDER BY APP.IDS_APPLICATION DESC;";
			log.debug(queryString);

			rs = statement.executeQuery(queryString);

			if (rs.next()) {
				groupCode = rs.getString("GroupCode1");
				log.info("Group code: " + groupCode);
			} else {
				log.error("Code not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (statement != null)
					statement.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return groupCode;
	}

}
