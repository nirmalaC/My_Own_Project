package automation.test.offerservice.entities;

public class OfferParty {
	private PartyVulnerabilityStatus PartyVulnerabilityStatus;

	public OfferParty() {

	}

	public OfferParty(PartyVulnerabilityStatus partyVulnerabilityStatus, String id, int offerPartyStatus, boolean isExistingCustomer) {
		super();
		PartyVulnerabilityStatus = partyVulnerabilityStatus;
		this.id = id;
		OfferPartyStatus = offerPartyStatus;
		IsExistingCustomer = isExistingCustomer;
	}

	private String id;

	private String MatchKey;

	private int OfferPartyStatus;

	private boolean IsExistingCustomer;

	public String getMatchKey() {
		return MatchKey;
	}

	public void setMatchKey(String matchKey) {
		MatchKey = matchKey;
	}

	public PartyVulnerabilityStatus getPartyVulnerabilityStatus() {
		return PartyVulnerabilityStatus;
	}

	public void setPartyVulnerabilityStatus(PartyVulnerabilityStatus PartyVulnerabilityStatus) {
		this.PartyVulnerabilityStatus = PartyVulnerabilityStatus;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getOfferPartyStatus() {
		return OfferPartyStatus;
	}

	public void setOfferPartyStatus(int OfferPartyStatus) {
		this.OfferPartyStatus = OfferPartyStatus;
	}

	public boolean getIsExistingCustomer() {
		return IsExistingCustomer;
	}

	public void setIsExistingCustomer(boolean IsExistingCustomer) {
		this.IsExistingCustomer = IsExistingCustomer;
	}

	@Override
	public String toString() {
		return "ClassPojo [PartyVulnerabilityStatus = " + PartyVulnerabilityStatus + ", id = " + id + ", OfferPartyStatus = " + OfferPartyStatus + ", IsExistingCustomer = " + IsExistingCustomer + "]";
	}
}