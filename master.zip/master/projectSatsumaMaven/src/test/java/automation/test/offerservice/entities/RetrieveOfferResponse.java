package automation.test.offerservice.entities;

public class RetrieveOfferResponse {
	OfferRequest OfferPartyProducts;

	public OfferRequest getOfferPartyProducts() {
		return OfferPartyProducts;
	}

	public void setOfferPartyProducts(OfferRequest offerPartyProducts) {
		OfferPartyProducts = offerPartyProducts;
	}
}