package automation.test.offerservice.entities;

import java.util.Date;


public class RetrieveOfferRequest {
	String Firstname;
	String Lastname;
	Date DateOfBirth;

	public RetrieveOfferRequest(String firstname, String lastname, Date dateOfBirth) {
		Firstname = firstname;
		Lastname = lastname;
		DateOfBirth = dateOfBirth;
	}

	public String getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		Firstname = firstname;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public Date getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

}